# ad-ddr

> **What this repository contains.** Code (`src/`, `scripts/`, `tests/`), manuscript and talk sources (`docs/`) and the
> main / supplementary figures (`docs/figures/*.png`). Raw data, reference files and intermediate results (`data/`,
> `results/`, the summary tables `docs/*.csv` and exploratory plots `docs/*.png` cited in the sections below) are not
> included because of their size (~70 GB); all inputs are public and `scripts/reproduce_manuscript.sh` downloads them
> and regenerates every result, figure and document (see `docs/REPRODUCIBILITY.md`). Only small hand-curated inputs are
> kept: published gene sets (`data/meta/published_sets/`) and the donor selection lists in `data/meta/`.
> `data/meta/donor_table.csv` is SEA-AD Supplementary Table 1 (convert with `scripts/read_xlsx.py`).


**DNA damage response across the Alzheimer's disease continuum: single-nucleus RNA + ATAC of human cortex (SEA-AD).**

> 中文简介：用 SEA-AD（西雅图阿尔茨海默病脑细胞图谱）的单细胞核多组学数据，检验"AD 病程中神经元 DNA 修复程序发生改变"这一假设。主要结论：(1) 在 73 个供体、9 个脑区中，**神经元的 DNA 修复/p53 程序与连续病程评分（CPS）无关**（|r| < 0.17，95% 置信区间排除了 |r| > 0.4 的效应）；(2) 阳性对照：**小胶质细胞的疾病相关程序（DAM）在 9 个脑区中全部随病程升高**，说明流程能检出真实信号（但与随机基因集相比只是勉强特异，p = 0.056）；**Sst 中间神经元随病程丢失**，复现了 SEA-AD 的核心发现；(3) 配对多组学显示，供体间 DDR 程序表达的差异**同时体现在启动子染色质可及性上**（中位 r = 0.23，置换 p = 0.001）。(4) 痴呆者神经元的修复程序看似更低，但随机基因集对照表明这是神经元整体表达谱的变化，**不是 DDR 特有的**；(5) 没有证据表明基线 DDR 高的神经元亚型更易丢失（幸存者偏差）；(6) 单细胞层面也没有检测到协同的受损神经元状态；(7) 空间转录组（MERFISH，27 个供体）中，疾病相关小胶质细胞周围的易损神经元没有局部减少（植入信号对照证明方法能检出 10% 的局部丢失）；(8) 独立队列（Morabito 2021，18 个供体）与 SEA-AD 方向一致但检验力不足，并复现了“神经元整体表达漂移、非 DDR 特有”的现象；(9) 神经元对小胶质细胞的“安抚”信号没有随病程减弱；配体-受体分析中大量看似显著的“通讯变化”，与随机配体对照相比并不更多，实际只是单个基因的表达变化；(10) 兴奋性神经元的 TP53 活性名义上随病程升高（p = 0.04），但不优于随机调控网络；在供体层面的数据上，转录因子活性的常规 p 值假阳性率约为名义水平的 3–4 倍；(11) 全转录组空间数据（Visium，每组 8 个供体）检验力不足，阳性对照在预先指定的方案下失败，无法提供新证据；(12) **唯一的正面发现：小胶质细胞 PTPRG 随 AD 病程上升**。它在 1.7 万个基因中排第 1，9 个脑区一致，排除了已知的污染因素，并在独立队列（Morabito）中复现（单侧 p = 0.022）。这与 2026 年一篇预印本（Marchi 等）一致：该预印本的分类模型给小胶质细胞 PTPRG 最大权重，并用 SEA-AD 做了验证，所以不是新发现，我们的 SEA-AD 结果也不独立于它；排第 2 的 S100A4 则未能复现，是"赢家诅咒"的例子。PTPRG 位点在 AD GWAS 中没有信号，它的上升更可能是对疾病的反应；(13) 把 24 个细胞类型 × 10 个 DDR 程序 × 9 个脑区全部与随机基因集比较，**没有任何检验达到 q < 0.1**；(14) 在斑块周围的小胶质细胞（GeoMx，37 个供体）中，阳性对照 DAM 在接触斑块处明显升高，但**DDR 程序没有特异变化**（Checkpoint/TOPBP1 仅为线索）；同切片病理的 Visium 数据检验力不足，常用 Xenium 脑 panel 不含 DDR 基因。(16) 以皮层分层为“邻域”（84 个供体的分层定量病理 + 86 个供体的 ATAC），**DNA 修复基因的表达与启动子染色质没有随本层病理出现失配**；阳性对照 DAM 的 RNA 与染色质随斑块**同步**升高（各 r = 0.37）。(17) 小鼠（5xFAD）斑块相关小胶质细胞的 ATAC（原作者已发表的数据，此处为重新分析）：DAM 位点明显更开放（阳性对照，复现了原文结果），DNA 修复位点没有特异变化（NHEJ/MMR 略降，q = 0.15）。(18) 多细胞因子分析发现，前面反复出现的"整体漂移"来自一个神经元共有因子（F1）。它是一个基因长度轴，但方向与 DNA 损伤的预期相反；去掉它之后，随机基因集的假阳性率从 21–34% 降到 1%，神经元 DDR 与痴呆的关联完全消失；(19) 全基因组"发现 → 复现"筛选在现有样本量下没有找到超出随机期望的新基因；这个漂移轴是 SEA-AD 特有的，随机基因集需要同时按表达量和基因长度匹配；(20) **在公开的 PsychAD 队列（628 个供体，无需申请）中，PTPRG 再次成为小胶质细胞中与 AD 关联最强的基因**（r = +0.54，在 17,750 个基因中排第 1，各脑库一致），这是迄今最有力的复现。(21) 小鼠单细胞尺度空间数据（Stereo-seq，相邻切片的斑块染色经配准）：斑块 25 µm 内阳性对照 Trem2/Cd68 升高 1.53 倍，**10 个 DNA 修复程序均在 ±8% 以内**（可检出约 10% 的局部变化）。(22) **DAM 状态有一组可复现的特异染色质元件**（53 个开放、74 个关闭，多为远端增强子，包括 CD9 增强子；PTPRG 增强子接近阈值）：附近基因在 RNA 中同向变化（p = 7×10⁻¹⁰），在 5xFAD 斑块相关小胶质细胞中同样更开放（p = 0.001）；斑块越多的大脑里，稳态小胶质细胞在这条染色质轴上越偏向 DAM（未参与发现的 43 个供体中 r = 0.46）。(23) AD 遗传风险富集在小胶质细胞特异的染色质中（3 倍，阳性对照），但 DAM 特异的元件太少，检验不出是否进一步富集；风险位点在 DAM 染色质轴上没有整体偏移。候选元件：RASGEF1C 增强子（DAM 中关闭，含 p = 3×10⁻¹² 的风险 SNP）和 DAPK2 启动子（DAM 中开放）。(24) 以“基因调控区”（TSS ±50 kb 内所有 peak 合并）为单位检验：RNA 中 DAM 上调的基因，其调控区整体更开放（z = 14.6），下调基因整体关闭（z = −10.7），稳态基因关闭；504 个基因调控区显著变化（单个 peak 只有 127 个），CD9、ANXA2、PTPRG、RASGEF1C 等均显著；DAM 上调基因的调控区在 5xFAD 斑块相关小胶质细胞中同样更开放，显著基因中人鼠同向的数量是随机预期的 3 倍。用小鼠单个 peak 作锚点则无济于事（人鼠 peak 层面方向一致率与随机相同）。(25) “稳态小胶质细胞随斑块偏移”在校正 DAM 样细胞比例、测序深度、测序方式、APOE 后仍然成立，最强的关联是致密核心斑块（r = 0.55），但无法与整体病程（CPS）分开。(26) 与已发表结果直接对比：Mathys 2023 报道的 **cohesin 复合物上调在 SEA-AD 中得到复现**（兴奋性神经元 r = 0.48、少突胶质细胞 r = 0.41，超出表达量和基因长度匹配的随机基因集，五个核心亚基和装载因子 NIPBL 一致上调），而 p53/DNA 损伤模块不优于随机基因。这提示与损伤相关的变化可能在基因组三维结构层面，而不是修复程序本身。(27) 在 cohesin 结合位点上：少突胶质细胞中 cohesin 基因随病程上升，但 cohesin 结合位点的可及性反而下降（r ≈ −0.35，q = 0.04），出现“转录–染色质失配”；兴奋性神经元则倾向同向上升（未过 FDR）。这是全项目最接近原始“失配”设想的线索，但发生在少突胶质细胞、涉及基因组结构机器，需要脑特异的 cohesin/CTCF 图谱和独立队列验证。(28) 在 SEA-AD 内部随机把供体分成不重叠的两半、重复 100 次：DAM 基因调控区、兴奋性神经元 cohesin 上调、少突胶质细胞 cohesin 失配、稳态小胶质细胞偏移，在另一半供体中保持方向一致的比例都 ≥ 94%；但这只能说明抽样稳定性，仍需要独立队列。(29) 在公开的 PsychAD MSSM 队列（402 个供体）中大样本检验主假设：只看常规 p 值，会得出"AD 神经元 DNA 修复显著下调（p≈10⁻⁵）"的结论，但 62–94% 的随机基因集同样"显著"；与按表达量和基因长度匹配的随机基因集比较后，10 个检验全部不显著，主假设在三个独立队列中都不成立。(30) **独立队列复现**：在 PsychAD（约 410 名供体，DLPFC，与 SEA-AD 无重叠）中，cohesin 上调再次出现（兴奋性神经元 r = +0.26、少突胶质细胞 r = +0.25，均超出表达量和基因长度匹配的随机基因集），单基因模式（STAG1、NIPBL、PDS5B 上调，WAPL、CTCF 不变）与 SEA-AD 一致。(31) **独立染色质队列复现**（人海马 multiome，22 名 75–97 岁供体，另一实验室、另一脑区、另一测序方式）：SEA-AD 的 DAM 染色质元件和基因调控区在全部 21 名可分析供体中方向一致（z = 11–34）；稳态小胶质细胞随 Braak 分期（r = +0.60）和 AD/高病理状态（r = +0.57）沿 DAM 染色质轴偏移，**这两项小胶质细胞结论得到独立复现**；少突胶质细胞 cohesin 失配**没有复现**，仍只是 SEA-AD 中的线索。项目也记录了只用 12 个供体时出现的假象，以及如何发现和排除它们。

## Question

Neurons are post-mitotic and live for decades. They have to repair DNA without the replication-coupled pathways (HR, FA, MMR). DNA double-strand breaks accumulate in AD neurons, and damaged cells can release cytosolic DNA that triggers **cGAS-STING / type-I interferon** signalling. Does this show up as a **change in repair programs** along AD progression? If it does, is the change written into chromatin as well as expression?

## Data

| Tier | Source | Used for |
|---|---|---|
| **Cohort** | SEA-AD released pseudobulk objects (`Multiregion_2026/pseudobulk_objects`, ~4 GB): summed UMI counts per region × supertype × library | CPS association: **84 MTG donors (73 not severely affected)** plus 9 more regions (35–71 donors each) |
| **Spatial** | SEA-AD MTG MERFISH (`s3://sea-ad-spatial-transcriptomics`, 498 MB processed h5ad): 27 donors, 69 sections, 1.9M cells, 180-gene panel | Microglia–neuron neighbourhoods |
| **Replication** | Morabito et al. 2021, GEO GSE174367: PFC snRNA-seq, 18 donors (11 AD / 7 control), 61k nuclei (261 MB) | Independent-cohort check of the 13 hypotheses |
| **Spatial (Visium)** | Miyoshi et al. 2024, GEO GSE233208: PFC Visium, 39 sections / 32 donors, 115k spots, full transcriptome (Seurat rds, 1.4 GB; exported with R/SeuratObject) | Spatial DDR scores vs diagnosis |
| **Multiome** | Per-donor MTG RNA + ATAC objects for 12 donors (3 per ADNC level, ~10 GB): 210k RNA nuclei, 53k nuclei with paired ATAC | RNA vs chromatin concordance |

Public bucket `s3://sea-ad-single-cell-profiling` ([Gabitto et al. 2024 Nat Neurosci](https://www.nature.com/articles/s41593-024-01774-5)). Disease axis: the **local Continuous Pseudo-progression Score (CPS)** from the 2026 multiregion release (`Global_and_Local_CPS.20260105.csv`). It supersedes the CPS stored in the 2024 MTG ATAC objects, which differs substantially for some donors. LEC has no local CPS and is excluded.

## Design

| Choice | Reason |
|---|---|
| Donor is the unit of replication | Nuclei from one donor are not independent; every test runs on donor × cell-group pseudobulks |
| Partial correlation with CPS adjusting for **age, sex, PMI, log(#nuclei)**; permutation p (10,000 shuffles) | Robust at modest n; covariates absorb ageing, post-mortem and sampling-depth effects |
| **13 pre-specified hypotheses**, BH within that family; everything else is labelled exploratory | Keeps the multiple-testing burden honest (306 exploratory tests per region) |
| Primary run excludes the 11 "severely affected" donors; sensitivity run includes them | Those donors have extreme pathology and lower data quality |
| Microglia = `Micro-PVM_*` supertypes (lymphocytes and monocytes removed) | The SEA-AD "Immune" subclass also contains T cells |
| Programs scored as mean z-scored log2 CPM of expressed program genes, within each cell group | Comparable across donors; genes not expressed in a cell type are dropped |
| ATAC: log2(program-promoter counts / matched-background counts) on **pseudobulk** counts | Per-cell chromVAR z-scores blow up for 10–30-peak promoter sets in sparse snATAC (see below) |
| Positive control: **microglial DAM** must rise with CPS | If it does not, any null result for neurons is uninterpretable |

## Results

### 1. Neuronal DNA repair programs do not track AD progression in MTG (73 donors)

![primary](docs/primary_MTG.png)

| Cells | Program | partial r | p (perm) | q |
|---|---|---|---|---|
| Excitatory neurons | NHEJ / BER / NER / Checkpoint / p53 targets | −0.13 … +0.03 | ≥ 0.28 | ≥ 0.70 |
| Inhibitory neurons | NHEJ / BER / NER / Checkpoint / p53 targets | −0.17 … −0.02 | ≥ 0.17 | ≥ 0.70 |
| **Microglia** | **DAM (positive control)** | **+0.36** | **0.003** | **0.036** |
| Microglia | cGAS-STING / IFN | +0.21 | 0.07 | 0.47 |
| Astrocytes | Reactive astrocyte | +0.02 | 0.87 | 0.94 |

The 95% CIs for every neuronal program exclude |r| > 0.4. A moderate, monotonic change in bulk neuronal repair-gene expression along CPS is unlikely. Including the severely affected donors (n = 84) gives the same picture (DAM r = +0.40, q = 0.004; all neuronal |r| < 0.13). Exploratory tests sit at the null rate (5.6% with p < 0.05; [QQ plot](docs/pvalue_qq_MTG.png)).

### 2. Same pattern across the cortical arc

![regions](docs/primary_by_region.png)

Microglial DAM rises with local CPS in **all 9 regions** (r = 0.19–0.40; q < 0.05 in MEC and MTG).

**Specificity check.** Random expression-matched microglial gene sets *also* drift upward with CPS (mean r = 0.12, 95% range −0.14 to 0.35). The pre-specified DAM score sits just above that range (empirical p = 0.056), and cGAS-STING/IFN is indistinguishable from random sets (p = 0.50). So part of the "DAM" signal is a global shift in the microglial expression profile, probably driven by changes in microglial state composition. The score was not redesigned after seeing this ([table](docs/cps_specificity.csv)). Inhibitory-neuron repair programs lean slightly negative in most regions (BER is negative in 8 of 9), but none reaches significance. The regions come from overlapping donors, so their agreement is **not** independent replication.

### 3. Multiome: donor-level DDR variation is mirrored in chromatin

![concordance](docs/concordance_null.png)

Within each cell group, across the 10 donors with ≥ 500 paired nuclei, RNA program scores correlate with promoter accessibility of the same genes. The median r over 240 cell group × program pairs is 0.23 (73% positive). Shuffling donors gives a null median of 0.00 (95% range −0.07 to 0.07; p = 0.001). BER (0.38), HR (0.37) and p53 targets (0.29) are the most concordant; the ATM/ATR checkpoint set is the only one with a negative median (−0.15). Each pair has only 7–10 donors, so only the aggregate is interpreted.

### 4. Cognition: an apparent "lower repair in dementia" signal is not DDR-specific

![cognition](docs/cognition_primary.png)

All 10 neuronal repair/p53 programs are lower in donors with dementia (r = −0.15 to −0.29; 5 with q = 0.078). The association largely survives adjustment for CPS (BER r ≈ −0.27, p ≈ 0.02), which on its own would suggest a resilience effect. Two checks change the reading:

* **RIN** is slightly lower in dementia (8.28 vs 8.62), but adding it as a covariate barely changes r.
* **Random expression-matched gene sets** show the same negative association (null mean r ≈ −0.14 to −0.19). Only BER edges past the null (empirical p = 0.06–0.08). Neuronal pseudobulk profiles shift globally with dementia, and repair genes simply follow ([table](docs/dementia_specificity.csv)).

CASI (n = 61, measured on average 32 months before death) shows no association once CPS is included. APOE4 is unrelated to any program.

### 5. Survivor bias: no evidence that high-DDR supertypes are lost first

![vulnerability](docs/vulnerability.png)

**Vulnerability (positive control reproduced).** In 73 donors, 38 of 98 MTG neuronal supertypes change in proportion along CPS (q < 0.1). The five most depleted are all Sst interneurons (Sst_20, Sst_23, Sst_25, Sst_11, Sst_2), followed by Pvalb_14, L2/3 IT_8/10 and Vip_2. This matches SEA-AD's reported vulnerable populations. Proportions are compositional, so "enriched" supertypes partly just reflect losses elsewhere ([table](docs/supertype_vulnerability.csv)).

**Baseline DDR vs vulnerability.** If damaged neurons die first, supertypes expressing repair/p53 programs most strongly in low-CPS donors should be depleted fastest. Across supertypes, Spearman rho is −0.17 to 0.27, all inside the null from random gene sets (p ≥ 0.34). Centring within subclasses gives similar values (rho −0.22 to 0.23; not separately tested). The random-set null is wide (±0.45), so this test has limited resolution: the result means **no support**, not exclusion ([table](docs/baseline_ddr_vs_vulnerability.csv)).

### 6. Cell level: no detectable coordinated damage state in neurons

![cellstate](docs/cellstate.png)

Heterogeneity is the remaining explanation: a minority of damaged neurons diluted in pseudobulks. It was tested in the 12 multiome donors (210k nuclei; scores depth-adjusted, centred within donor × supertype). Each test was compared against 50 (RNA) or 20 (ATAC) expression-matched random programs.

| Test | DDR programs | Random programs | Positive control |
|---|---|---|---|
| A. Within-nucleus co-elevation of NHEJ / BER / NER / Checkpoint / p53 (median r over 92 supertypes) | 0.011 | 0.000 (95% −0.006..0.006), p = 0.02 | Microglial DAM thirds: **0.152** vs −0.001 |
| B. Top-5% DDR nuclei vs rest: promoter accessibility of the same genes in the **same nuclei**, beyond all promoters | −0.013 log2 | 0.001, p = 0.95 | — |
| C. Fraction of high-DDR neurons vs CPS | rho = −0.10 (n = 12, descriptive) | — | — |

The DDR programs co-vary slightly more than random genes, but the effect is about 14× smaller than for a known microglial state, and it is not mirrored in chromatin of the same nuclei. Under the pre-set criterion (A **and** B), no coordinated damage state is detected at snRNA/snATAC resolution. This does not show that such neurons are absent: sparse snRNA of modestly expressed repair genes may not resolve them ([table](docs/cellstate_summary.csv)).

### 7. Spatial (MERFISH): vulnerable neurons are not locally depleted around disease-associated microglia

![spatial](docs/spatial.png)

The SEA-AD MTG MERFISH panel (180 genes) is designed for cell typing and contains **none** of the DDR, p53, DAM or cGAS-STING genes. So the spatial question is posed with cell labels: are the 23 vulnerable supertypes from result 5 (fixed before opening the spatial data) rarer around disease-associated microglia (`Micro-PVM_3-SEAAD`) than around other microglia at the same cortical depth? Data: 27 donors, 69 sections, 1.9M cells (155k microglia, 685k neurons). The null permutes the microglial state **within section × depth decile**, so laminar structure cannot create a signal; a unit test shows that a pure laminar confound gives a large naive effect but no excess.

| Analysis (27 donors) | Excess (log2) | p (≠ 0) | r with CPS | p |
|---|---|---|---|---|
| **Primary**: vulnerable supertypes, 50 µm | **+0.007** (95% CI −0.058..0.072) | 0.82 | −0.24 | 0.23 |
| Vulnerable subclasses (Sst, Sncg, L2/3 IT) | 0.000 | 1.00 | −0.22 | 0.27 |
| 30 µm / 100 µm | −0.017 / −0.009 | ≥ 0.71 | +0.08 / **−0.47** | 0.69 / 0.011 |
| Supertype confidence ≥ 0.5 only | −0.049 | 0.57 | −0.22 | 0.28 |
| **Spike-in**: remove 10% / 25% of targets near DA microglia | **−0.14 / −0.39** | < 0.001 | — | — |

* The spike-in shows the test detects a 10% local loss. The CI excludes it, and a loss above about 4% is unlikely.
* The 100 µm × CPS correlation is 1 of 10 CPS tests (BH q = 0.115). It is an exploratory lead that local loss may develop at a larger scale in later disease.
* Disease-associated microglia have **more** neurons nearby than other microglia at the same depth (+0.12 log2, p < 0.001 at all radii). This vanishes when only confidently labelled cells are kept (+0.04, p = 0.48). It is most likely segmentation spill-over: microglia touching neurons pick up neuronal transcripts and are mis-assigned. It is not interpreted as biology.
* The pre-specified positive control (astrocytes around endothelium vs OPCs) rested on a wrong premise: astrocyte **end-feet**, not somata, contact vessels. It came out negative (−0.07) and was replaced post hoc by the spike-in control. Both are reported ([table](docs/spatial_summary.csv)).

### 8. Independent cohort (Morabito 2021, PFC): consistent, but too small to confirm

![replication](docs/replication.png)

[Morabito et al. 2021 *Nat Genet*](https://doi.org/10.1038/s41588-021-00894-z) (GEO GSE174367): prefrontal cortex snRNA-seq of 18 donors, 11 late-stage AD (Braak 5–6) and 7 controls (Braak 1–2). The SEA-AD primary analysis was repeated with the design fixed in advance: same pseudobulk scoring, same 13 hypotheses, AD vs control adjusted for age, sex and log(#nuclei), and a 500-set random gene-set null. The exposure differs (diagnosis here, CPS in SEA-AD), so only direction and magnitude are compared ([table](docs/replication_primary.csv)).

* **Nothing passes BH** (min q = 0.165). With 18 donors the 95% CIs span roughly ±0.5, so this cohort can neither confirm nor refute the SEA-AD estimates. 12 of 13 SEA-AD values fall inside the Morabito CIs, and 9 of 13 share the sign.
* **The positive control does not replicate significantly**: microglial DAM r = +0.14 (CI −0.40..0.61). The direction agrees and SEA-AD's +0.36 lies inside the CI, so this reads as low power rather than contradiction.
* **The "global shift" pattern replicates.** Neuronal repair programs are nominally lower in AD (NER r ≈ −0.50 in both classes, inhibitory Checkpoint −0.58; p < 0.05). Random expression-matched gene sets are lower too (null mean −0.14 to −0.22), and no program stands out from them (p vs random 0.13–0.21). This matches result 4 in a different cohort and region: disease shifts the whole neuronal expression profile, and repair genes follow it.
* Braak stage as an ordinal exposure gives the same picture.

Stronger validation would need ROSMAP snRNA-seq (Mathys et al. 2023, 427 donors; Synapse data-use agreement).

### 9. Neuron–microglia ligand–receptor scores: no restraint-signal loss; "communication" hits are single-gene changes

![ccc](docs/ccc.png)

Expression-based communication only shows that a ligand is expressed in the sender and a receptor in the receiver. So every ligand–receptor (L-R) score, mean(log2 CPM ligand, log2 CPM receptor), is reported with its ligand-only and receptor-only components (MTG, 73 donors, adjusted for age, sex and PMI; LIANA consensus resource; least-expressed subunit for complexes).

**Pre-specified: neuronal "restraint" signals to microglia should fall with CPS.** They do not. None of 10 tests passes BH (min q = 0.23). The two nominal hits point the **opposite** way: CD200–CD200R1 rises (r = +0.24, p = 0.04), carried entirely by microglial CD200R1 (r = +0.25; neuronal CD200 unchanged), and excitatory-neuron CX3CL1 rises (r = +0.24). CSF1/IL34 were tested as separate ligands because the resource encodes them as one complex; neither changes ([table](docs/primary_restraint_signals.csv)).

**Exploratory: all 6,201 pair × direction scores.** 10–17% have p < 0.05 and 125 have q < 0.1, which looks like widespread "rewiring". Replacing the ligand with an expression-matched random gene gives the **same** rates (12–16%), so curated pairing adds nothing beyond single-gene changes ([table](docs/exploratory_vs_random.csv)). The top hits show this directly:

* CNTN3/4/6 → PTPRG (r ≈ 0.6): microglial **PTPRG** r = 0.60, neuronal ligands r ≈ 0
* S100A4 → ERBB2/ERBB3/EGFR (r ≈ 0.5): microglial **S100A4** r = 0.52, neuronal receptors r ≈ 0

This is the main caveat for CellChat-style claims, including the CD86 and ANXA1–FPR3 axes in Wang et al. 2026: without a random-pair null and an L/R decomposition, single-gene expression changes look like communication. The microglial PTPRG and S100A4 increases are far above the microglia-wide drift (≈ 0.12). They are worth following as gene-level leads, not as communication.

### 10. TF activity: TP53 "activation" in excitatory neurons does not beat random regulons

![tf](docs/tf.png)

**RNA (MTG, 73 donors).** TF activity per donor = decoupler ULM on CollecTRI regulons, using log2 CPM z-scored across donors within each cell class. Each TF is compared with matched random regulons: same number of targets, same activating/repressing signs, targets matched on expression decile (500 for TP53, 100 for other TFs) ([table](docs/tf_primary_TP53.csv)).

| Pre-specified: TP53 | r with CPS | p | q | Random regulons: sd (share with p < 0.05) | p vs random |
|---|---|---|---|---|---|
| Excitatory neurons | **+0.24** | **0.041** | 0.082 | 0.16 (21%) | 0.33 |
| Inhibitory neurons | +0.08 | 0.50 | 0.50 | 0.15 (12%) | 0.83 |

On its own, the excitatory result reads as "TP53 is activated in excitatory neurons along AD progression". Against random regulons it is unremarkable. The exploratory scan shows why: in excitatory neurons 28% of 313 TFs have p < 0.05 (33 with q < 0.1), but random regulons reach p < 0.05 20% of the time. **Nominal TF-activity p-values are 3–4× anti-conservative** under donor-level co-variation of gene expression, and no TF in any cell class beats its random regulons (q_vs_random < 0.1: 0 of 987).

**Chromatin (10 multiome donors).** TP53 binding sites were taken from ChIP-Atlas (387 TP53 ChIP-seq experiments; regions seen in ≥ 10 experiments, n = 2,672; 741 overlap snATAC peaks). The set is valid: 83% of canonical p53 targets have a site within 10 kb of the TSS, versus 2.6% of random genes. The experiments come from cancer lines (MCF-7, U2OS, HCT 116…), not neurons. Site accessibility tracks RNA-inferred TP53 activity across donors (r = +0.52 inhibitory, +0.32 excitatory; n = 10, descriptive), which is another multiome concordance in the expected direction. It is not consistently related to CPS (−0.32 / +0.13) ([table](docs/tp53_sites_multiome.csv)).

### 11. Whole-transcriptome spatial (Visium): underpowered at the donor level

![visium](docs/visium.png)

MERFISH could not measure DDR genes (result 7), so [Miyoshi et al. 2024 *Nat Genet*](https://doi.org/10.1038/s41588-024-01961-x) (GEO GSE233208) was used. It has human prefrontal-cortex Visium: 39 sections, 115,451 spots, full transcriptome, with the authors' layer annotation and per-spot cell-type deconvolution. The released Seurat object contains **no per-spot amyloid or tau measurement**, so "DDR near plaques" cannot be tested from GEO. The sections come from 32 donors (one control donor contributes 8), giving 8 donors per group (Control, earlyAD, AD, AD with Down syndrome).

Design (fixed in advance): spot scores residualised on deconvolved cell fractions, log UMI and layer; donor means; Control → earlyAD → AD as an ordinal trend (24 donors; age, sex); 100 random programs per test. AD_DS donors (ages 43–66) have no age-matched controls and are described only ([table](docs/visium_disease_trend.csv)).

* **Pre-specified spot sets** (neuronal: EX + INH ≥ 0.5, only 4.8% of spots; microglia-rich: MG ≥ 0.2). Nothing passes BH (min q = 0.41), and nothing stands out from random programs. **The positive control fails** (DAM r = −0.09).
* **Post hoc, all grey-matter spots** (77,917). DAM turns positive (r = +0.21, p = 0.32), matching SEA-AD's direction. p53 targets look borderline (r = +0.40, p = 0.053) but are not beyond random programs (p = 0.31), the same pattern as TP53 in result 10 ([table](docs/visium_disease_trend_greymatter.csv)).
* **Neuronal DDR vs neighbouring microglia** (within section): no association (pre-specified: excess over random −0.03, p = 0.12; grey matter: 0.00, p = 0.96).

With 8 donors per group the random-program null has SD ≈ 0.3, so only |r| ≳ 0.6 is detectable. More spots do not help, because the bottleneck is donors. This dataset neither supports nor contradicts the SEA-AD results.

### 12. The one positive finding: microglial PTPRG tracks AD progression (consistent with a 2026 preprint)

![ptprg](docs/ptprg.png)

The L-R scan (result 9) pointed at two microglial genes, PTPRG and S100A4. Both were followed with the same controls used everywhere else. MTG is the discovery set, so its estimates carry winner's-curse inflation ([tables](docs/ptprg_replication.csv)).

| Check | PTPRG | S100A4 |
|---|---|---|
| SEA-AD MTG, 73 donors, rank among 17,422 expressed microglial genes | **#1**, r = 0.60 (p vs 1,000 matched random genes = 0.001) | #2, r = 0.52 (0.001) |
| Other 8 regions (local CPS; regions share donors, so not independent) | all positive, r = 0.33–0.74 | all positive, r = 0.15–0.37 |
| Adjusting also for neuronal-, oligodendrocyte- and OPC-marker load and mitochondrial fraction | **r = 0.48, p = 5 × 10⁻⁵** | r = 0.38, p = 0.002 |
| Within each microglial supertype (MTG) | rises in all four (r = 0.36–0.51); highest in Micro-PVM_3-SEAAD | rises (0.31–0.50) |
| Chromatin, 9 multiome donors (descriptive) | gene-body accessibility tracks CPS (r = +0.35) and PTPRG RNA (+0.45); promoter has 1 peak only | — |
| **Morabito PFC, 18 donors, independent cohort, direction pre-specified** | **r = +0.49, one-sided p = 0.022** (Braak: +0.48, p = 0.023); top 4% genome-wide; vs random genes p = 0.06 | r = +0.20, p = 0.21: **not replicated** |
| Miyoshi Visium, microglia-rich spots | no signal (r = −0.10) | — |

* **Contamination is an obvious worry**: microglia express PTPRG *less* than neurons, astrocytes and OPCs (log2 CPM 7.9 vs 9.4–10.3; `scripts/check_ptprg_ambient.py`). But the neuronal-, oligodendrocyte- and OPC-marker loads in the microglial pseudobulk do not rise with CPS (r = −0.06, +0.16, +0.11), and adjusting for them barely moves PTPRG. The mitochondrial fraction does rise (r = +0.42); adjusting for it lowers PTPRG from 0.60 to 0.49 but leaves it strong.
* **S100A4 is the cautionary twin**: #2 in discovery, weaker in every other region, not replicated in Morabito. This is the winner's curse in action.
* **Visium cannot isolate microglial PTPRG.** Spots mix cell types, and other cells express PTPRG more than microglia do. The dataset's own DAM positive control also failed (result 11), so its null here is uninformative.

**Prior work.** A 2026 bioRxiv preprint ([Marchi et al., PMID 41993387](https://doi.org/10.64898/2026.04.07.717029)) trained an AD-vs-control classifier on ROSMAP pseudobulks, validated it in SEA-AD, and reported microglial PTPRG as the gene with the largest coefficient. PTPRG is therefore **not a new discovery**, and our SEA-AD result is not independent of that validation. What this project adds (based on the preprint's abstract; the full text was not checked):

* the gene was reached independently, from a different question (DDR) and method (continuous CPS, donor-level partial r, L-R scan), as #1 of 17,422 genes;
* consistency across 9 regions, robustness to ambient and mitochondrial confounders, and a rise within each microglial supertype;
* replication in a cohort not used there (Morabito), in a different region, with diagnosis and Braak as exposures;
* directional chromatin support from paired multiome;
* a matched counter-example (S100A4) showing why replication is needed.

Other PTPRG literature: neuronal PTPRG in AD (Zou et al. 2024 *Pharmacol Res*), Ptprg upregulation during neuroinflammation in mouse brain (2014 *Brain Struct Funct*), and a family-based genome-wide association of the PTPRG locus with AD (2016 *Mol Psychiatry*).

**Genetics: no AD GWAS signal at PTPRG.** A Mendelian-randomisation test of microglial PTPRG was not possible. PTPRG is not among the genes tested in the microglial cell-type eQTL resource (Bryois et al., Zenodo 7276971: 480 genes on chr3 for microglia; PTPRG is tested only in neurons, astrocytes and OPCs). The AD side is null too. In the largest AD GWAS ([Bellenguez et al. 2022](https://doi.org/10.1038/s41588-022-01024-z), GCST90027158, 21.1M SNPs), the minimum p over the PTPRG gene ± 100 kb is 3.3 × 10⁻⁴ across 7,827 SNPs. 64% of length-matched protein-coding genes have a smaller minimum, whereas APOE, BIN1 and TREM2 (positive controls) rank in the top 0.5% ([table](docs/gwas_locus_check.csv)). Common variants at PTPRG therefore do not contribute detectably to AD risk. The microglial increase is more plausibly a response to disease than a genetic cause, though this does not rule out a role in progression.

### 13. All cell types, all regions, against random gene sets: no DDR-specific change

![screen](docs/screen.png)

Results 1–2 tested pre-specified neuronal classes. Here every cell group (24) × DDR program (10) × region (9) was tested, 1,959 tests in all (`scripts/run_celltype_screen.py`). Each test reports the CPS partial r (age, sex, PMI, log #nuclei; severely affected donors excluded) with two p-values: `p_perm` (CPS permuted across donors) and `p_set` (against 200 random expression-matched gene sets in the same cells).

* **0 of 1,959 tests reach q < 0.1** in any region. In MTG, 4.3% of tests have p_perm < 0.05 and 2.1% have p_set < 0.05, both at or below the 5% expected by chance ([by region](docs/screen_by_region.csv), [MTG table](docs/screen_MTG.csv)).
* The microglial DAM control behaves as before: r = +0.37, p_perm = 0.0005, the same sign in 4 of 8 other regions, but only marginal against random sets (p_set = 0.065).
* With 73 donors, a single test has 80% power for |r| ≈ 0.32. What can be excluded is a moderate or larger donor-level DDR shift in any cell type. A local effect confined to cells near plaques could still be averaged away, which is what results 14–15 test.

**L5 ET HR lead, decontamination check** (`scripts/check_l5et.py`). It is still the strongest MTG test (r = +0.50, p_set = 0.005, q = 0.12). It does not look like glial ambient RNA: adjusting for microglia, oligodendrocyte, astrocyte or OPC marker load, or for library chemistry, leaves r between 0.44 and 0.57 ([table](docs/l5et_adjusted.csv)). Against it: it replicates in 0 of 6 other regions; the median is 33 nuclei per donor; BRIP1 and BLM contribute most, and BLM is 60× higher in OPCs than in L5 ET ([genes](docs/l5et_hr_genes.csv)), but leave-one-gene-out (result 39) shows that no single gene carries it (every one of the 16 leave-one-out versions keeps p_set ≤ 0.02, excess 0.40–0.56); the abundant same-layer L5 IT neurons show a weaker, same-direction effect (r = 0.18, p = 0.14 here; excess 0.26 over length-matched random genes in result 39). It stays exploratory: it does not pass FDR among the MTG tests, and its rate of nominal hits is no higher than for random gene sets.

### 14. Microglia next to plaques (GeoMx, 37 donors): positive control passes, DDR does not move

![geomx](docs/geomx_zones.png)

[GSE306381](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE306381) (UCL, Edwards lab; unpublished) profiles microglia-enriched GeoMx WTA areas of illumination (AOIs) in human hippocampus. AOIs sit in three zones: in contact with an Aβ plaque (P), periplaque (PP), and away from plaques (A). There are 270 AOIs from 20 AD, 9 cognitively unimpaired amyloid-positive and 8 non-AD donors. GEO gives no donor ID, so donors were rebuilt from the clinical fields (`scripts/build_geomx.py`). An AOI has a median of about 9,000 genes above the negative-probe background, against a median of 2% detection of DDR genes per Visium spot (result 15).

Zone contrasts are within donor: donor fixed effects plus log counts and log AOI area, zone labels permuted within donor, and 200 random expression-matched gene sets (`scripts/run_geomx_zones.py`, [table](docs/geomx_zone_effects.csv)).

* **Positive control.** DAM is higher in plaque-contact than in periplaque microglia: +0.57 SD, p_set = 0.005.
* **P vs A is dominated by a global shift.** Every program rises 0.5–1.1 SD, but so do random gene sets (null mean ≈ 0.8 SD). Only the competitive test is interpretable there, and nothing passes it, DAM included.
* **No DDR program passes q_set < 0.1 in any contrast.** One lead: Checkpoint rises A < PP < P (PP vs A +0.67 SD, p_perm = 0.0005, q_perm = 0.005, but p_set = 0.035, q_set = 0.35). It is not a proliferation signal: proliferation genes do not differ by zone, and adjusting for them leaves it unchanged. Per gene it is carried by TOPBP1 (up in all three contrasts) and ATM. FA is lower at plaque contact than periplaque (p_set = 0.025, q_set = 0.25).

### 15. Visium with same-section pathology, and the search for single-cell spatial data

**Kwon et al. 2023** ([GEN Biotechnol](https://doi.org/10.1089/genbio.2023.0019), Visium-SPG, inferior temporal cortex) has Aβ and pTau immunofluorescence quantified per spot on the same section. It covers 10 sections from 1 control and 3 AD donors. Within each AD section, grey-matter spots were summed into pseudobulks matched by BayesSpace domain (laminar position), comparing near vs far from Aβ+ spots and pTau+ vs pTau− spots, against random gene sets (`scripts/export_kwon.R`, `scripts/run_kwon_pathology.py`, [table](docs/kwon_pathology_effects.csv)). No DDR program passes (smallest q_set = 0.40). The microglial-marker control only trends at Aβ+ spots (6 of 7 sections, p_set = 0.13) and is absent for "within one spot". DDR genes are detected in a median of 2% of spots, so with 3 AD donors this is underpowered, not negative.

A layer-pseudobulk version of result 11 (`scripts/run_miyoshi_layers.py`, sections collapsed to 32 donors) agrees: no DDR change along Control → earlyAD → AD, and DAM fails as a control ([table](docs/miyoshi_layer_effects.csv)). The per-spot Amylo-Glo / OC values used in the Miyoshi paper are not in GEO or the figshare project; the authors' code reads them from an internal object.

**Single-cell spatial data that could test DDR near plaques** (searched October 2026):

| Panel / dataset | DDR genes (of 22 core) | Access | Verdict |
|---|---|---|---|
| Xenium human brain base panel (266) and SEA-AD Xenium panels (433–464) | 0 | open | cannot measure DDR |
| Lu et al. 2026 *Nat Med* custom Xenium (329 genes; same-slide Aβ/AT8/NeuN) | ATM only | EGA, no Xenium files deposited | ruled out |
| GSE282928 Visium HD 2 µm (van Olst 2025, 3 AD hippocampi) | all (whole transcriptome) | open | median 18–50 UMI per 16 µm bin, 0.1–0.24 DDR counts per bin: too shallow |
| Xenium Prime 5K / CosMx 6K panels | 22 | — | panels suitable |
| ROSMAP Xenium Prime 5K (GAGE-seq, *Science* 2026; 2 AD, 2 controls) | 22 | Synapse syn74004858, DUA | only usable option; no same-section pathology |

### 16. Layer-local pathology and repair expression vs promoter chromatin: coupled, not mismatched

![laminar](docs/laminar_mismatch.png)

The question is whether DNA-repair transcription and repair-locus chromatin come apart in pathology-rich neighbourhoods. No public human AD dataset measures chromatin in space: the only spatial chromatin data in AD are a 5xFAD spatial-ATAC study with n = 1 per group. So the cortical layer was used as the neighbourhood. SEA-AD quantitative neuropathology (QNP, [portal workbook](https://portal.brain-map.org/explore/seattle-alzheimers-disease)) gives AT8+ cells and 6E10+ objects per area in L1, L2, L3, L4 and L5-6 for 84 MTG donors. Excitatory subclasses live in known layers.

All 86 MTG ATAC donor objects were streamed into (subclass × chemistry) pseudobulks and then deleted (`scripts/stream_atac_donors.sh`, `scripts/extract_atac_pseudobulk.py`; 1 GB kept). For each subclass and donor, the RNA program score (released pseudobulks) and the promoter-accessibility score of the same genes (peaks within 1 kb of the TSS) were each residualised on technical covariates. **Mismatch = RNA − ATAC** (`scripts/run_laminar_mismatch.py`).

* **Positive control: the pipeline sees coupled RNA–chromatin change.** In microglia, DAM RNA and DAM promoter accessibility both rise with grey-matter plaque density (r = +0.37 each, p_set = 0.015 each, 72 donors), and their mismatch does not (r = 0.01). A genuine pathology response here moves expression and chromatin together.
* **Laminar test (within donor; 73 donors, 9 subclasses, 536 subclass × donor rows).** No DDR program's mismatch tracks own-layer AT8 or 6E10 (smallest q = 0.53). The leading, non-significant direction is negative for p53 targets (β = −0.35 per SD of own-layer AT8, p_perm = 0.09), meaning chromatin is relatively *more* open than expression, not less. Composition control: resident-subclass share follows own-layer NeuN density (β = +0.33, p = 0.045). ([table](docs/laminar_mismatch.csv))
* **Donor level (per subclass, grey-matter AT8 or 6E10; 168 tests).** 4.8% have p_perm < 0.05, and the smallest q is 0.45 ([table](docs/laminar_donor_level_mismatch.csv)).
* **Power.** MTG layers are highly correlated in pathology (Spearman 0.8–0.98 across layers). Within-donor variation in own-layer pathology is only 16% of the between-donor SD, and the permutation SD of β is about 0.2. Only a large mismatch per unit of local pathology (|β| ≳ 0.56) would have been detected. Layers are also coarse neighbourhoods (hundreds of µm), not the tens of µm around a plaque.

Mismatch here is a cross-sectional proxy: "repair transcription not matched by chromatin" at the time of death. Showing *failed recovery* would need repeated measures or a stimulus-withdrawal design (for example tet-off APP or CK-p25 mice), which no public human data provide.

### 17. Mouse cross-check: plaque-associated microglia open DAM loci, not repair loci

[GSE296025](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE296025) (Ardura-Fabregat et al. 2025 *Nat Neurosci*) has bulk ATAC of 5xFAD microglia sorted into CD11c+ (plaque-associated, PAM) and CD11c− fractions, plus wild-type microglia, with n = 3 each. Only MACS2 peak files are deposited. A gene's accessibility is therefore the peak fold enrichment near its TSS, rank-normalised within sample, because peak numbers differ 3-fold between samples. Each program is compared with 1,000 random gene sets matched on mean accessibility. Gene symbols are human capitalised to mouse, and Itgax (the sorting marker) is dropped from DAM (`scripts/run_mouse_pam_atac.py`, [table](docs/mouse_pam_atac.csv)).

* **Regulatory domain (peaks within 50 kb, summed).** The positive control passes clearly: DAM loci are more open in PAM than in CD11c− microglia (z = +4.7 vs random sets, p_set = 0.001, 3/3 replicates) and than in wild type (z = +5.4). No DDR program passes q_set < 0.1. The leading DDR changes go the other way: NHEJ and MMR domains are slightly *less* open in PAM (z ≈ −2.1, q_set = 0.15, 3/3 replicates). Checkpoint is not more open (z = −1.1), so the GeoMx Checkpoint/TOPBP1 lead (result 14) has no chromatin support here.
* **Promoter only (strongest peak within 1 kb).** DAM does not pass (z = −1.4): DAM promoters are largely constitutively open, and the change is distal. The DDR results at promoters (BER p_set = 0.04 PAM vs CD11c−, q = 0.40) are therefore not interpreted.

CD11c+ marks a microglial state as well as plaque contact, and the RNA in this study comes from other animals. This is a chromatin-only check of one cell type, not a test of mismatch. **This is a re-analysis of the authors' published data:** Ardura-Fabregat et al. already report more accessible regions at Csf1 / Apoe / Spp1 / Clec7a / Itgax and less at Tmem119 / Csf1r in CD11c+ microglia. The DAM control here therefore reproduces their result rather than adding independent evidence. In results 22 and 24 this dataset is used as a cross-species consistency check for the human peaks, not as an independent discovery.

### 18. Multicellular factors: one neuronal factor explains the "global drift", and removing it leaves no DDR signal

![mofa](docs/mofa.png)

MOFA+ was fitted to donor pseudobulks of five MTG cell types: excitatory and inhibitory neurons, microglia, astrocytes and oligodendrocytes. 73 donors; per view, age, sex, PMI and log(#nuclei) were regressed out and the top 1,000 genes kept; 10 factors; CPS was **not** in the model ([factors](docs/mofa_factors.csv)).

* **Cross-cell-type coordination is real but stays within lineages.** Four factors explain ≥ 10% of variance in ≥ 2 views. When donors are permuted independently within each view, which breaks cross-view coupling, the 20 refits give 0.1 such factors on average (max 2). The shared factors pair excitatory with inhibitory neurons (F1, about 55% of each), or microglia with astrocytes or oligodendrocytes (F3–F5). **No factor spans neurons and glia.**
* **No factor tracks CPS** after BH (the closest is F7: r = −0.30, q = 0.11, 9% of variance, bootstrap stability 0.73). On F7, p53 targets in astrocytes and oligodendrocytes exceed random genes (q = 0.035). This is exploratory because F7 itself is not significant.
* **Microglial PTPRG** is not captured by any single factor (largest |r| = 0.34, with the neuronal F1).

![f1](docs/f1.png)

**F1 is the "global drift" seen in results 4, 8 and 10.** It accounts for over half of neuronal variance. It tracks the neuronal mitochondrial-read fraction (r = −0.55 / −0.63), dementia (−0.31) and CPS (−0.20), but not age, PMI or RIN ([table](docs/f1_covariates.csv)). Random 20-gene neuronal sets reach p < 0.05 for dementia in **21% / 34%** of draws. With F1 as a covariate this drops to **1%** ([table](docs/f1_calibration.csv)). One factor therefore produces the anti-conservative behaviour that the random-set nulls kept catching.

**F1 is a gene-length axis, and its disease direction does not match DNA damage.** In all five views, gene loadings on F1 fall with gene length (Spearman ρ = −0.23 to −0.34). Transcription-blocking DNA damage is expected to lower *long*-gene expression. In dementia it is the *short* genes that fall in neurons (mean r −0.09 / −0.10 for the shortest quintile vs −0.01 for the longest; ρ(dementia effect, length) = +0.17 / +0.19). This hallmark of DNA damage is not seen. The axis is more consistent with a technical snRNA effect (nuclear vs cytoplasmic RNA, intronic capture of long genes), which fits its link to mitochondrial reads ([table](docs/gene_length_axis.csv)).

**Removing F1 strengthens the main null.** Without F1, 5 of 10 neuronal DDR programs are nominally lower in dementia, the result-4 pattern. With F1, none are (all |r| < 0.1), and random sets are calibrated at 1%. Against CPS, DDR programs are null either way, and none beats random sets ([table](docs/ddr_after_F1.csv)).

### 19. Searching for positives genome-wide, and how general the drift axis is

**Discovery → replication screen** (`scripts/run_discovery_screen.py`). For six cell types, every expressed gene was tested against CPS in MTG (age, sex, PMI, log #nuclei and mitochondrial fraction). Calibration used an empirical null per cell type: z = (r − median) / (1.4826 × MAD) over all genes, so a global shift is subtracted. Replication required Morabito (independent; one-sided p < 0.05 in the discovery direction) and the same sign in ≥ 4 of 8 other SEA-AD regions.

* **Pre-specified (q < 0.05 in MTG): no gene in any cell type.** The closest are CREB5 in astrocytes (r = +0.63, q = 0.08), UACA in OPCs (q = 0.13) and NKX2-1 in inhibitory neurons (r = +0.65, q = 0.19). NKX2-1 is an interneuron-lineage marker, so it likely reflects interneuron composition. PTPRG is still the top microglial gene after the extra mitochondrial adjustment (p = 3 × 10⁻⁴).
* **Post hoc two-stage (discovery p < 0.001).** 59 genes pass discovery, fewer than the ~100 expected under the null across ~105k tests. 4 replicate (TBL1X and CHRDL1 in inhibitory neurons, CECR2 in microglia, one astrocytic lncRNA) against ~2.5 expected by chance. **That is no evidence of an excess**, so with 73 + 18 donors, single-gene discovery is exhausted ([summary](docs/discovery_twostage_summary.csv), [genes](docs/discovery_twostage_replicated.csv)).
* **PTPRG and cognition** (`scripts/check_ptprg_resilience.py`). Microglial PTPRG is higher with dementia (r = +0.30, p = 0.01), but not once CPS is included (r = +0.15, p = 0.19), and the same holds for CASI. It marks pathology, not cognitive resilience ([table](docs/ptprg_resilience.csv)).

![f1 generality](docs/f1_generality.png)

**Is the drift axis general?** (`scripts/run_f1_generality.py`). The drift axis in each dataset is PC1 of the excitatory + inhibitory neuron pseudobulks; in MTG it matches MOFA F1 (r = 0.90) ([table](docs/drift_axis_by_dataset.csv)).

* **Within SEA-AD, partly.** PC1 loadings fall with gene length in all 9 regions (ρ = −0.07 to −0.59). The mitochondrial link appears only in MTG, DFC and MEC (r = −0.44 to −0.59), the three regions profiled in all 84 donors, and is near zero elsewhere. This points to a batch- or protocol-specific technical axis.
* **Not in Morabito**: no length dependence (ρ ≈ −0.07) and no miscalibration. The axis is SEA-AD-specific, not a general snRNA-seq property.
* **Adjusting for it is exposure-dependent.** It restores calibration for dementia (random sets 21% / 35% → 3% / 4%) but breaks it for CPS (MTG excitatory 3% → 31%; FI and HIP 0% → 11–14%), probably because the axis carries part of the CPS signal. It is not a universal correction.
* **Expression-matched nulls are not enough when drift is length-dependent.** In MTG, 10 of 50 MSigDB Hallmark sets per neuron class pass the competitive test for dementia without the axis and 0 with it. These "hits" have |r| < 0.2: they pass because they move *less* than the drifting random sets, and set length tracks the set's r (ρ = 0.47). Random sets should be matched on **gene length as well as expression** ([table](docs/hallmark_impact.csv)).

### 20. Large open replication: PsychAD microglia (628 donors), PTPRG is the top AD gene again

![psychad](docs/psychad_microglia.png)

PsychAD's myeloid snRNA-seq is openly downloadable from CZ CELLxGENE without a data-use agreement: "Frozen in silico sorted myeloid single nuclei RNA-seq from human prefrontal cortex" ([Lee et al. 2026 *Nat Genet*](https://doi.org/10.1038/s41588-026-02716-6); 289,279 nuclei, 1,469 donors, DLPFC). No continuous pathology is released, so the pre-specified fallback contrast was used: AD vs control, excluding other neurological diagnoses. That gives 628 donors (254 AD) from the MSSM, RADC (= ROSMAP) and HBCC brain banks. Microglia (PVM excluded) were pseudobulked per donor and adjusted for age, sex, bank, log #nuclei and mitochondrial fraction. Random genes were matched on **expression and gene length** (`scripts/replicate_psychad_microglia.py`, [table](docs/psychad_microglia_replication.csv)).

| Gene | All banks (628) | MSSM (411) | RADC (61) |
|---|---|---|---|
| **PTPRG** | **r = +0.54, p < 10⁻⁴, #1 of 17,750 genes**; vs random genes p = 0.001 | +0.55, #1 | +0.51, #1 |
| DAM program / APOE / GPNMB / CD9 (positive controls) | +0.24 / +0.33 / +0.27 / +0.19, all p < 10⁻⁴ | similar | same sign, n.s. |
| P2RY12 / CX3CR1 (homeostatic) | −0.12 / −0.15 | similar | same sign |
| CECR2 (two-stage hit, result 19) | **−0.37**, p < 10⁻⁴ | −0.35 | −0.21 |

* **PTPRG now replicates in three independent populations** (SEA-AD, Morabito, PsychAD MSSM), three regions (MTG, PFC, DLPFC) and two disease definitions (CPS, diagnosis). It is the top microglial gene in both large cohorts and survives expression- and length-matched nulls. MSSM donors do not overlap ROSMAP, so this is also independent of the Marchi et al. discovery set. RADC is ROSMAP and is not.
* **CECR2 also replicates.** PsychAD's authors use CECR2 to mark a homeostatic microglial subtype (Homeo_CECR2), so its fall most likely reflects loss of homeostatic microglia rather than a separate regulatory change.
* Not yet checked: whether Lee et al. 2026 report PTPRG themselves. PsychAD's 1,042-donor MSSM whole-cortex dataset (36 GB, open) is the only open resource with enough donors to test the neuronal DDR hypothesis for small effects (|r| ≈ 0.1).

### 21. Single-cell-scale plaque proximity (Stereo-seq, App NL-G-F mice): positive control passes, DDR flat within ±8%

[GSE263789](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE263789) (Mallach et al. 2024 *Cell Rep*) is the only open AD spatial dataset found that is whole-transcriptome and has plaque segmentation registered to it. It is mouse data: App NL-G-F at 18 months (2 sections), with 3-month mixed AD/WT hemispheres (2 sections). The plaque staining is on the adjacent section.

**Data audit** (`scripts/audit_stereoseq.py`, `scripts/register_plaque_mask.py`):
* The "aligned" masks are grayscale and sit on a pixel grid that matches neither the transcript coordinates nor the aligned ssDNA image. No transform is deposited, and overlaying them 1:1 fails the positive control.
* The transform was therefore fitted by FFT cross-correlation against plaque-induced microglial transcripts (Cst7, Clec7a, Itgax, Lpl, Spp1, Axl). E3 gives r = 0.29 and E4 gives r = 0.24, against a block-shuffled null maximum of 0.04. The fit is identity orientation, scale ≈ 1.02, shift ≈ 100–125 µm.
* It was validated on genes not used in the fit, within 25 µm of a plaque vs > 200 µm: Trem2 1.59× / 1.64× and Cd68 1.47× / 1.54×.
* Both 3-month sections fail the pre-set QC (held-out Trem2 and Cd68 not enriched; the best fits sit at the search bounds) and are excluded. Registration precision is about 25–50 µm, so "plaque contact" cannot be resolved.
* Depth: 2.6 × 10⁸ UMI per section. A 25 µm bin has a median of 1,781 UMI but only 0.16–1.3 DDR-program counts, and a 10 µm (~1 cell) bin has 263 UMI. Per-cell DDR scores are therefore not possible; ring-pooled estimates have thousands of counts.
* Neuronal transcripts are 1.36× higher near plaques (plaques sit in grey matter), so composition must be controlled.

**Test** (fixed before looking at DDR; `scripts/build_stereoseq_bins.py`, `scripts/run_stereoseq_plaque_ddr.py`):
* Contrast: 25 µm bins within 25 µm of a registered plaque vs bins 100–300 µm away, so both are in the same region.
* Estimate: Mantel–Haenszel rate ratio stratified by neuron × oligodendrocyte × astrocyte marker quintiles, plus microglia for the within-composition estimand.
* Nulls: 200 expression-matched random gene sets, and 200 toroidal shifts of the plaque map by ≥ 1 mm.

| | rate ratio near / far | p_set | p_spatial |
|---|---|---|---|
| Trem2 + Cd68 (held-out positive control) | **1.53** (both sections) | 0.005 | 0.005 |
| 10 DDR programs | 0.99–1.08 | ≥ 0.065 (smallest q = 0.48) | ≥ 0.16 |

The random-set null SD of the pooled log rate ratio is about 0.04, so a local DDR change of about ±10% would have been detected. The largest, non-significant effects are MMR (1.08, same sign in both sections) and Checkpoint (1.05). The within-composition estimand gives the same picture ([pooled](docs/stereoseq_plaque_pooled.csv), [per section](docs/stereoseq_plaque_sections.csv)).

Limits: two sections, possibly from fewer than two animals, so p-values describe spatial structure within these sections, not variation between animals. 25 µm bins mix cell types. Mouse knock-in amyloid models lack human-like tau pathology.

### 22. DAM-specific chromatin: 53 opened and 74 closed peaks, confirmed by RNA, plaques and mouse

> Numbers in results 22–31 come from a single thinning draw. The pipeline now averages 20 draws (result 32): 115 opened and 121 closed peaks; result 32 lists every changed number.

![dam peaks](docs/dam_peaks.png)

Results 16–17 showed that the disease-associated microglial response moves expression and chromatin together. This section asks which regulatory elements carry it.

**State labels.** In the released RNA pseudobulks, `Micro-PVM_3-SEAAD` is the DAM-like state: it has the highest DAM and interferon genes of the main microglial supertypes, and its share of microglia rises with CPS (Spearman 0.48). `Micro-PVM_2` is the homeostatic reference: it has the highest P2RY12 / CX3CR1 / TMEM119 and is the largest supertype.

**Data and test.**
* All 86 MTG ATAC donors were streamed again, this time split by microglial supertype (`scripts/stream_atac_donors.sh 3 data/processed/atac_pb_micro Microglia-PVM`).
* The comparison is within donor and paired. It uses 23 non-severe donors with ≥ 10 DAM-like and ≥ 30 homeostatic nuclei (582 DAM-like nuclei) and 32,481 peaks with ≥ 5 CPM (`scripts/run_dam_peaks.py`).
* FDR comes from donor-level sign flips, with all peaks of a donor flipped together.
* **Depth matching is necessary.** Without it, 502 peaks were called "closed", mostly low-count peaks. This is an artefact: the DAM-like pseudobulks are much shallower, and log2(CPM + 1) is pulled toward 0 at low counts. After binomially thinning the deeper pseudobulk to the shallower one, 53 peaks are DAM-open and 74 are DAM-closed (q < 0.05, |log2FC| ≥ 0.5; 87% distal).
* The results agree across chemistries: significant peaks have the same sign in 100% of cases with ATAC-only nuclei and 91% with multiome-only nuclei.

**What the peaks are.**
* DAM-open peaks include an enhancer 1.5 kb from **CD9** (a canonical DAM gene), and peaks near **VIM**, **ANXA2**, **HBEGF**, **RGCC**, **PDE4B** and **SEMA4A**.
* A distal **PTPRG** enhancer is just below threshold (log2FC +0.91, q = 0.062). Microglial PTPRG is the project's replicated RNA finding (results 12 and 20).
* Enhancers of homeostatic genes trend closed: P2RY12 (−1.33), CSF1R (−1.23), CX3CR1 (−0.58) and TMEM119 (−0.39), with q between 0.16 and 0.42.
* [Peak table](docs/dam_peaks_significant.csv).

**Three checks** (`scripts/validate_dam_peaks.py`; the RNA and plaque checks use data not used for peak calling; the mouse check re-uses published mouse data, see result 17):

| Check | Result |
|---|---|
| RNA (66 donors, released pseudobulks, paired) | Genes nearest DAM-open peaks are up (median log2FC +0.22 vs −0.10 for other genes; 67% up; p = 7 × 10⁻¹⁰). Genes nearest DAM-closed peaks are down (−0.18; only 8% up; p = 5 × 10⁻⁴). [table](docs/dam_peaks_validation_rna.csv) |
| Plaques: does the *homeostatic* state move along the DAM chromatin axis? | In Micro-PVM_2 nuclei, the DAM-open minus DAM-closed accessibility score rises with grey-matter 6E10 density: r = +0.34 in 66 donors (random matched peak sets: null mean 0.05, p = 0.018). In the 43 donors **not used for peak discovery** it is r = +0.46 (p = 0.006). [table](docs/dam_peaks_validation_pathology.csv) |
| Mouse (lifted to mm10; 5xFAD CD11c+ vs CD11c− microglia, GSE296025) | Lifted DAM-open peaks are more open in plaque-associated microglia (median rank difference 0.135 vs 0.054 for other peaks; p = 0.0014; 17 peaks with a mouse peak). DAM-closed peaks: not significant (p = 0.11), and only 25% have a mouse peak vs 49% background. [table](docs/dam_peaks_validation_mouse.csv) |

**Motifs** (`scripts/motif_dam_peaks.py`; JASPAR 2024, GC- and promoter/distal-matched background, own PWM scanner). No motif passes FDR, because there are only 53 and 74 peaks. The leading motifs in DAM-open peaks are the CACGTG E-box family (ARNTL OR 3.4, p = 0.0002; BHLHE40 2.5; TFE3 1.8; USF1 2.0), then AP-1 (FOS / JUNB) and IRF8. The MiT/TFE E-box and BHLHE40 fit published DAM / lipid-associated microglia regulators, but this is a trend, not a result ([table](docs/dam_peaks_motifs_top.csv)).

**Reading.** The DAM state has a reproducible set of regulatory elements that are opened or closed. They agree with RNA, they are partly conserved in mouse plaque-associated microglia, and homeostatic microglia in plaque-rich brains are shifted partway along this chromatin axis. The last point is the closest the data come to "a pathology-associated chromatin state". Unlike the DDR hypothesis, it is supported. Limits: only 23 donors have enough DAM-like nuclei for discovery; supertype labels come from RNA label transfer; causality needs perturbation (for example CRISPRi of the CD9 or PTPRG enhancers in iPSC microglia).

### 23. AD genetic risk in DAM-specific chromatin: microglial chromatin is enriched, the DAM-specific subset is too small to tell

Summary statistics: Bellenguez et al. 2022 (GCST90027158, GRCh38, 21.1 M SNPs). No LD reference is available locally, so this is a SNP-in-peak enrichment rather than a heritability partition (S-LDSC). A peak is a "hit" if it contains a SNP with p < 1e-5. Background peaks are matched on the number of SNPs in the peak and on promoter/distal class (1,000 draws). The analysis is repeated without the APOE region (`scripts/gwas_dam_peaks.py`, [table](docs/dam_peaks_gwas_enrichment.csv)).

| Peak set | peaks | hit fraction | matched null | fold | p | loci |
|---|---|---|---|---|---|---|
| Microglia-specific (vs neurons; positive control) | 6,246 | 1.18% | 0.40% | **2.98** | 0.001 | 36 |
| Neuron-specific | 15,520 | 0.39% | 0.70% | 0.56 | 1.0 | 29 |
| All microglia-accessible (tested) | 31,303 | 1.18% | 0.72% | 1.63 | 0.001 | 92 |
| DAM-open | 52 | 1.9% | 1.3% | 1.53 | 0.48 | 1 |
| DAM-closed | 73 | 1.4% | 1.2% | 1.18 | 0.58 | 1 |

* **The positive control passes.** AD risk concentrates in microglia-specific chromatin (3×; 2.8× without APOE) and is depleted from neuron-specific chromatin, matching published partitioning results.
* **The DAM-specific sets are too small.** With 52 and 73 peaks, about one hit is expected by chance, so not even a 3-fold enrichment could be detected.
* **Whole-axis test.** This uses all 31k tested peaks: one lead peak per 500 kb AD locus (100 loci), placed on the DAM-vs-homeostatic t statistic and compared with matched non-risk peaks. AD-risk peaks are not shifted toward DAM-open or DAM-closed chromatin (mean t −0.22 vs −0.40 null, z = 1.45, p = 0.15; [table](docs/dam_peaks_gwas_dam_axis.csv)). AD risk sits in microglial regulatory DNA broadly, not specifically in the elements that change with the DAM state.

**Candidate elements** (differential, containing an AD-associated SNP; [table](docs/dam_peaks_gwas_candidates.csv)):
* **RASGEF1C distal enhancer** (chr5:180,201,040–180,201,876). It is DAM-closed (log2FC −1.55, q = 0.043) and contains rs113706587 (p = 3.4 × 10⁻¹²). RASGEF1C is one of the loci newly reported by Bellenguez et al.
* **DAPK2 promoter** (chr15:64,070,898–64,072,145). It is DAM-open (log2FC +1.36, q = 0.027) and contains rs332248 (p = 2.0 × 10⁻⁶, below genome-wide significance).
* Below threshold, the peaks carrying the **BIN1** lead SNP rs6733839 (t = −2.6, q = 0.26) and an **SPI1** peak (rs10838702, t = −1.8) lean DAM-closed ([all lead peaks](docs/dam_peaks_gwas_lead_peaks_axis.csv)). The BIN1 risk allele is known to sit in a microglia-specific enhancer (Nott et al. 2019 *Science*).

A SNP inside a peak is not evidence that the SNP is causal: LD means the causal variant may lie elsewhere at the locus. The two candidates are where fine-mapping, allele-specific accessibility or CRISPRi in iPSC microglia would start.

### 24. Beyond single peaks: mouse anchoring does not rescue peaks, but whole gene regulatory domains carry the DAM state

![dam regulatory](docs/dam_regulatory.png)

Result 22 was limited by having enough DAM-like nuclei in only 23 donors. Two ways around single-peak testing were tried (`scripts/run_dam_regulatory.py`). The human and mouse data are independent, so selecting on one and testing on the other is not double dipping.

**A. Mouse-anchored peaks.**
* 7,663 human tested peaks lift to a mouse peak present in ≥ 4 of the 6 5xFAD CD11c+ / CD11c− samples. Of these, 1,626 change consistently in all 3 mouse replicates.
* Human p-values were then corrected within this set only. **This does not rescue near-threshold peaks.**
  * The human direction agrees with mouse in 42.1% of anchored peaks, against 42.0% expected from each species' share of up/down peaks (p = 0.92).
  * Human t and mouse change are uncorrelated across all lifted peaks (Spearman −0.01).
  * Only 4 peaks pass (LONRF3, VIM, TGFBI, PLXNC1), and all were already found in result 22.
* At single-peak resolution, rank-normalised mouse peak calls do not track the human DAM-vs-homeostatic contrast. Possible reasons: the mouse contrast is a sorting marker (CD11c), the mouse data are bulk, and orthologous enhancers turn over between species ([table](docs/dam_regulatory_anchored_peaks.csv)).

**B. Gene regulatory domains.** For each gene, all accessible peaks within 50 kb of the TSS were summed per donor and state (depth-matched), and the domain was tested as one unit. Gene sets were defined in RNA from 66 donors, which is a separate modality from the ATAC used for testing.

| Gene set | genes | mean domain t | matched-null mean (SD) | z | p | 5xFAD PAM vs CD11c− (z) |
|---|---|---|---|---|---|---|
| RNA DAM-up, top 200 | 200 | **+1.27** | −0.19 (0.10) | **+14.6** | 0.001 | **+3.4** |
| RNA DAM-down, top 200 | 200 | **−1.27** | −0.22 (0.10) | **−10.7** | 0.001 | +1.4 |
| Canonical DAM (Keren-Shaul) | 15 | +0.83 | −0.18 (0.38) | +2.7 | 0.007 | +2.8 |
| Homeostatic (P2RY12, CX3CR1, TMEM119…) | 8 | −2.33 | −0.20 (0.51) | −4.2 | 0.001 | — |

* **Domains pick up what single peaks missed.** 504 gene domains change at q < 0.05 (275 opened, 229 closed), against 127 single peaks.
* **Named genes** ([table](docs/dam_regulatory_named_genes.csv)):
  * Opened: ANXA2 (t = 6.2, q = 0.002), RGCC (6.3, q = 0.002), CD9 (4.7, q = 0.016), VIM (4.5, q = 0.02), and **PTPRG** (4.0, q = 0.043; one accessible peak, mouse + in 2/3).
  * Closed: **RASGEF1C** (−5.9, q = 0.003; RNA down 1.2 log2; down in all 3 mouse replicates) and P2RY12 (−5.0, q = 0.01). BIN1 is −3.8 (q = 0.057).
  * TREM2, APOE, SPP1, GPNMB, LPL and ITGAX rise strongly in RNA (GPNMB +2.5 log2) but show no domain change. These genes are induced from elements that are already open, consistent with DAM promoters being constitutively open in mouse (result 17).
* **Cross-species agreement is enriched among significant domains.** Of 274 human domains at q < 0.1 with a mouse ortholog, 40 change in the same direction in all 3 mouse replicates. Chance predicts 13 (binomial p = 3.6 × 10⁻¹⁰). Examples: PLXNC1, RASGEF1C, DNASE2B, CTSH, LPIN1, CXCR4, AQP9, SLC47A1 and MELTF, mostly lysosomal, lipid and migration genes ([table](docs/dam_regulatory_conserved_gene_domains.csv)). Genome-wide, across all genes, human and mouse domain changes are uncorrelated (Spearman 0.00): the conserved signal is concentrated in the genes that change.
* **Caveats.**
  * Some conserved domains belong to oligodendrocyte or neuronal genes (OLIG1, PAX8, CHRNA1, NTSR2, RHO) and have little RNA change. These may reflect ambient or doublet chromatin in the small DAM-like pseudobulks, or in CD11c+ sorts that contain phagocytosed material, so they are not interpreted.
  * Human RNA and ATAC come from overlapping donors. The ATAC test uses 23 donors.

**Reading.** The DAM state is written into chromatin at the level of whole regulatory domains, not just a handful of strong peaks. RNA-defined DAM genes open their domains and homeostatic genes close theirs. The DAM-up domains, canonical DAM domains and a set of 40 genes, including RASGEF1C, also move the same way in 5xFAD plaque-associated microglia. Peak-level mouse anchoring adds nothing; aggregating peaks over the gene adds a lot.

### 25. Robustness of the homeostatic shift: survives label, depth, chemistry and APOE checks; cannot be separated from CPS

The most novel claim in result 22 is that homeostatic (Micro-PVM_2) microglia move along the DAM chromatin axis with amyloid load. A literature check found no prior report of this, and it also identified the obvious objections. Each was tested in turn (`scripts/robust_homeostatic_shift.py`, [table](docs/dam_peaks_homeostatic_shift_robustness.csv)). The score is DAM-open minus DAM-closed accessibility in Micro-PVM_2, the exposure is grey-matter 6E10, and every row is compared with 500 accessibility-matched random peak sets (age, sex, PMI, log nuclei always adjusted).

| Challenge | donors | r | p_set | leave-one-out range |
|---|---|---|---|---|
| Baseline (result 22) | 66 | 0.34 | 0.018 | 0.30–0.41 |
| Donors not used for peak calling | 43 | 0.46 | 0.012 | 0.37–0.52 |
| + DAM-like share of microglia (label contamination) | 66 | 0.27 | 0.040 | 0.24–0.34 |
| + DAM-like share, held-out donors | 43 | 0.42 | 0.008 | 0.37–0.48 |
| + fragment depth and multiome fraction | 66 | 0.29 | 0.020 | 0.25–0.37 |
| ATAC-only nuclei (one chemistry) | 57 | 0.47 | 0.004 | 0.43–0.51 |
| + APOE ε4 dosage | 66 | 0.29 | 0.048 | 0.25–0.35 |
| All of the above covariates together | 66 | 0.21 | 0.088 | 0.14–0.29 |
| 6E10 adjusted for AT8 (tau) | 66 | 0.25 | 0.014 | 0.19–0.30 |
| AT8 adjusted for 6E10 | 66 | 0.05 | 0.95 | −0.01–0.11 |
| **Dense-core plaque area** as exposure | 66 | **0.55** | **0.002** | 0.53–0.59 |
| Activated Iba1 cells as exposure | 66 | −0.09 | 0.62 | |
| CPS as exposure | 66 | 0.41 | 0.026 | 0.37–0.47 |
| 6E10 adjusted for CPS | 66 | −0.08 | 0.93 | |

* **What the shift is not.**
  * It is not DAM-like cells hiding in the homeostatic label: controlling the DAM-like share leaves r = 0.27 (0.42 in held-out donors). The DAM-like share itself correlates only weakly with 6E10 (Spearman 0.18).
  * It is not depth or chemistry: the ATAC-only chemistry gives r = 0.47.
  * It is not APOE.
  * It is not driven by one donor: the leave-one-out minimum stays ≥ 0.19 in every single-challenge row.
* **What it tracks.**
  * Amyloid rather than tau: it follows 6E10 after adjusting for AT8, but not AT8 after adjusting for 6E10.
  * Dense-core plaques most of all (r = 0.55), the plaque type that recruits microglia.
* **What cannot be separated.**
  * Adjusting for CPS removes the 6E10 effect. CPS is built from these same quantitative neuropathology measures, so it is collinear with plaque load by construction, and "amyloid" cannot be distinguished from "progression" with these data.
  * With all covariates together the effect shrinks to r = 0.21 (p = 0.09) in 66 donors.
* **What remains open.** An independent cohort (for example ROSMAP multiome) and confidence-filtered labels: the supertype confidence score needs another pass over the ATAC objects.

### 26. Head-to-head with published "DNA damage" claims: the cohesin rise replicates, the p53/DDR modules do not beat random genes

Mathys et al. 2023 (*Cell*) report a coordinated rise of the cohesin complex and DNA damage response factors in excitatory neurons and oligodendrocytes. Mathys et al. 2024 (*Nature*) report a p53/DNA-damage module (M22) in immune cells. Fancy et al. 2024 report DNA-break biology in senescent microglia. These are positive claims next to the null results above, so their own gene sets were retrieved and tested in SEA-AD:
* Mathys 2023's DDR-factor list sits in non-open supplements, so only the cohesin complex (CORUM SA1/SA2) is tested from that paper.
* Gene lists and provenance are in [data/meta/published_sets](data/meta/published_sets/README.md).
* Method (`scripts/run_published_sets.py --match-length`): donor-level pseudobulks, local CPS in each of 9 regions, and dementia vs no dementia in MTG. Covariates are age, sex, PMI and log nuclei. Random gene sets are matched on expression **and gene length**, because SEA-AD has a gene-length drift axis (results 18–19).

| Set (claimed cells) | MTG, CPS: r | p_perm | p_set | MTG, dementia: r | p_set | 9 regions: median r (null) |
|---|---|---|---|---|---|---|
| **Mathys 2023 cohesin, excitatory neurons** | **+0.48** | 0.0005 | **0.005** | +0.28 | 0.035 | +0.31 (0.01) |
| **Mathys 2023 cohesin, oligodendrocytes** | **+0.41** | 0.0005 | **0.010** | +0.34 | 0.025 | +0.30 (0.02) |
| Mathys 2024 M22 p53/DDR (24 core), microglia | +0.20 | 0.08 | 0.76 | −0.06 | 0.25 | +0.19 (0.14) |
| Mathys 2024 M22 (58 all), microglia | +0.29 | 0.013 | 0.28 | +0.06 | 0.88 | +0.22 (0.19) |
| Fancy 2024 microglia module 8 | −0.04 | 0.73 | 0.010 (below null) | −0.12 | 0.020 (below null) | −0.19 (0.14) |

* **The cohesin rise replicates** in an independent cohort, at the donor level, beyond expression- and length-matched random genes, along CPS and with dementia. It holds in 3–4 of 9 regions at p_set < 0.05.
  * It is coordinated across the complex, not driven by one gene. In MTG excitatory neurons, CPS partial r is RAD21 +0.38, SMC1A +0.43, SMC3 +0.31, STAG1 +0.28 and STAG2 +0.48, with the loader NIPBL +0.44 and PDS5B +0.33. The unloader WAPL (+0.10) and CTCF (0.00) do not rise. Oligodendrocytes show the same pattern (RAD21 +0.44, STAG2 +0.30).
  * Across all published-set tests, q_set is 0.09, so the claim is replication-level evidence, not a new discovery.
* **The p53/DDR modules do not.** M22 rises with CPS about as much as random microglial genes do (p_set 0.28–0.76). That is the same pattern as the DDR programs throughout this project. Fancy module 8 moves less than random genes.
* **Reconciling with the null.** Canonical repair pathways (HR, NHEJ, BER, NER, MMR, FA, checkpoint, p53 targets) do not change specifically (results 1–2 and 13). The cohesin–loader axis does, in the cell types Mathys reported.
  * Cohesin works in DNA double-strand-break repair and sister-chromatid cohesion, but in post-mitotic neurons its main job is 3D genome organisation (loop extrusion with NIPBL).
  * The specific rise of the loading machinery, with no rise in WAPL or CTCF, points to genome architecture rather than a repair program. This fits reports that DNA breaks in neurodegeneration go with 3D genome disruption (Dileep et al. 2023 *Cell*).
  * This is the closest the data come to the project's original idea of a damage-linked chromatin state, and it is a lead worth following (for example cohesin-associated loop or accessibility changes at NIPBL/RAD21 targets in the multiome data).
* [Full table](docs/published_sets_lenmatched.csv), [summary](docs/published_sets_summary.csv).

### 27. Chromatin at cohesin-bound sites: in oligodendrocytes cohesin RNA rises while cohesin-site accessibility falls

This follows up result 26: does chromatin at cohesin-bound sites change where cohesin expression rises?

**Sites and classes.**
* Cohesin sites are RAD21 ChIP-Atlas "Neural" peaks (62 experiments, mostly RPE, SK-N-SH and fetal neural cells). They were merged across experiments and kept if seen in ≥ 2 (37,491 regions); "robust" sites are seen in ≥ 10.
* SEA-AD snATAC peaks on these sites were split by whether they contain a CTCF motif (JASPAR MA0139, own scanner). This separates CTCF-anchored loop sites from CTCF-free cohesin sites; 66% of robust sites carry the motif (`scripts/run_cohesin_sites.py`).

**Test.**
* Per donor and cell group: accessibility of the site set minus a matched background (3 non-cohesin peaks per site peak, matched on accessibility and promoter/distal class).
* This difference is correlated with MTG CPS and with the same cell group's cohesin RNA score (RAD21, SMC1A, SMC3, STAG1, STAG2, NIPBL).
* Covariates: fragments, multiome fraction, nuclei, a TSS-enrichment proxy, age, sex, PMI. p comes from permuting the exposure; BH over 40 tests.
* **A first version was miscalibrated.** It compared set scores with random peak sets, and with thousands of peaks per set that null ignores donor sampling error, so almost every test came out significant, including the control cell types. The per-donor contrast fixes this: microglia show nothing.

| Cells | Site set | vs CPS: r (q) | vs cohesin RNA: r (p) |
|---|---|---|---|
| **Oligodendrocytes** | CTCF-free (robust) | **−0.35 (0.04)** | −0.08 (0.50) |
| **Oligodendrocytes** | CTCF-anchored (robust) | **−0.34 (0.04)** | −0.26 (0.037) |
| Excitatory neurons | CTCF-free (robust) | +0.21 (p 0.08, q 0.21) | +0.27 (0.022, q 0.11) |
| Excitatory neurons | CTCF-anchored (robust) | +0.16 (p 0.17) | +0.19 (0.11) |
| Inhibitory neurons | CTCF-free | −0.27 (p 0.02, q 0.11) | −0.12 (0.30) |
| Astrocytes | CTCF-free (robust) | −0.03 (0.83) | +0.29 (0.019, q 0.11) |
| Microglia (control) | all sets | −0.09 to +0.02 (≥ 0.48) | −0.21 to −0.05 (≥ 0.11) |

* **Oligodendrocytes show a cohesin mismatch.** Cohesin genes rise with CPS (result 26, r = +0.41), while accessibility at cohesin-bound sites falls relative to matched peaks (r ≈ −0.35, q = 0.04). This holds for both CTCF-anchored and CTCF-free sites, and in donors with higher cohesin RNA the CTCF-anchored sites are less, not more, accessible.
* **Excitatory neurons lean the other way.** Cohesin-site accessibility tends to rise with CPS and with cohesin RNA (CTCF-free robust sites r = +0.27 with RNA), but nothing passes FDR.
* **Caveats.**
  * The RAD21 sites come from non-brain cell lines and fetal neural cells, so oligodendrocyte- or neuron-specific cohesin sites are missed.
  * ATAC accessibility at a cohesin site mostly reflects CTCF or other factor occupancy, not cohesin itself.
  * The site sets overlap, so the 40 tests are not independent.
* **Reading.** Of all the analyses in this project, this is the closest to the original "repair / chromatin mismatch" idea. The mismatch shows up in oligodendrocytes and involves the genome-architecture machinery rather than DNA repair programs. It is a lead, not a result: it needs brain-specific cohesin/CTCF maps (for example Hi-C or CUT&Tag from sorted human oligodendrocytes) and an independent cohort.

### 28. Donor-split replication inside SEA-AD: the main positive claims reproduce in donor-disjoint halves

No independent human snATAC cohort could be obtained. ROSMAP needs a Synapse DUC, and the de-identified Xiong et al. 2023 files on the authors' portal could not be downloaded. As an interim check, every main claim was re-estimated in 100 random donor splits: discovery or estimation in half A, test in the donor-disjoint half B (`scripts/split_replication.py`, [summary](docs/split_replication_summary.csv), [fractions](docs/split_replication_summary_fractions.csv)).

| Claim | Split test | Result over 100 splits (median, 5–95%) |
|---|---|---|
| DAM peaks (result 22) | Top 100 DAM-open peaks in A (11 donors): sign and p in B (12 donors) | 72% positive in B (63–79%; background 39%); 28% at p < 0.05 (expected 5%) |
| | Top 100 DAM-closed peaks in A | 81% negative in B (75–88%; background 61%); 29% at p < 0.05 |
| | Per-peak t, A vs B, all 32k peaks | Spearman 0.18: single peaks are noisy at 11 donors, hence the domain analysis |
| DAM regulatory domains (result 24) | RNA DAM-up domains in B vs matched random genes | z = +13.0 (11.1 to 15.4), every split |
| Homeostatic shift (results 22, 25) | DAM axis from A's peaks only; tested in the ~50 donors not in A | r = +0.33 (0.18 to 0.46), positive in 100% of splits; p_set < 0.05 in 52% |
| Cohesin RNA, excitatory (result 26) | Halves of the 73 MTG donors | r = +0.48 in each half; both halves positive in 100%, both p_set < 0.05 in 69% |
| Cohesin RNA, oligodendrocytes | Halves of 73 donors | r = +0.41 in each half; both positive in 100%, both p_set < 0.05 in 20% |
| Oligodendrocyte cohesin-site mismatch (result 27) | Halves of 68 donors | CTCF-free sites r = −0.33 / −0.33; both halves negative in 98%. CTCF-anchored: both negative in 94% |

* **Every main positive claim keeps its direction in donor-disjoint halves in ≥ 94% of splits.**
* **The strongest are set- and domain-level claims:** RNA DAM-up domains, the cohesin rise in excitatory neurons, and the oligodendrocyte cohesin mismatch.
* **Weaker claims:**
  * The homeostatic shift is always positive but reaches p < 0.05 in only half of the splits, because each half discovers the axis from just 11 donors.
  * The oligodendrocyte cohesin RNA rise is consistent in direction but underpowered in halves.
* **What this does not replace.** Splits share the cohort, region (MTG), protocol and label transfer, so they test sampling stability, not generalisation. An independent cohort is still required before publication.

### 29. The main hypothesis at scale: PsychAD MSSM neurons (402 donors), DDR is not distinct from the global AD shift

![psychad neurons](docs/psychad_neurons.png)

PsychAD's MSSM cohort is openly downloadable from CZ CELLxGENE: 1,042 donors, 4.14M nuclei, DLPFC, 36 GB ([Lee et al., medRxiv 2024](https://doi.org/10.1101/2024.10.31.24316513)). It is the only open dataset with enough donors to test the neuronal DDR hypothesis for small effects. No continuous pathology is released, so the pre-specified contrast was AD (`AD_status` = Yes, with no Lewy body, FTD, tauopathy, vascular, schizophrenia or Parkinson diagnosis) vs control (`disease` = normal). That gives 429 donors (215 AD), of which 402 have ≥ 50 nuclei per neuron class (340k excitatory, 241k inhibitory nuclei). Donor pseudobulks were adjusted for age, sex, log #nuclei and mitochondrial fraction. The ten pre-specified tests (5 programs × 2 classes) were compared with 500 random sets matched on **expression and gene length**. 80% power is reached at |r| ≈ 0.14 (`scripts/run_psychad_neurons.py`, [table](docs/psychad_neurons_ddr.csv)).

* **A self-contained analysis would report "DNA repair is down in AD neurons".** 8 of 10 tests pass q < 0.1, e.g. inhibitory NER, p53 targets and BER at r ≈ −0.21 to −0.22 (p ≈ 10⁻⁵).
* **But random genes move the same way.** Random 20-gene sets reach p < 0.05 for AD in **62%** (excitatory) and **94%** (inhibitory) of draws, with matched random sets averaging r = −0.07 to −0.20. Against matched random sets, **none of the 10 tests is significant** (smallest q = 0.64). DDR programs fall exactly as much as arbitrary genes in AD neurons, no more. A DDR-specific deviation beyond the global shift larger than about 0.12–0.18 in r is unlikely.
* **With the neuronal PC1 as a covariate**, DDR effects shrink towards zero and remain null against random sets.
* **Positive controls.** Microglial DAM passes (r = +0.25, p vs random = 0.012). The Sst share of inhibitory neurons does not fall (r = −0.05, p = 0.29). This is a DLPFC binary contrast without a continuous stage, whereas SEA-AD's Sst loss is in MTG along CPS, so a neuronal composition control is not reproduced here.

The neuronal DDR null now holds in SEA-AD (73 donors), Morabito (18) and PsychAD MSSM (402). The global-shift miscalibration is far worse at this scale: 62–94% of random sets "significant" vs 21–35% in SEA-AD. For AD neuron gene-set analyses, a competitive null is not optional.

### 30. Independent cohort: the cohesin rise replicates in PsychAD (≈ 410 donors, DLPFC)

PsychAD MSSM (open, CELLxGENE) comes from a different brain bank (Mount Sinai), region (DLPFC) and protocol, and has no donor overlap with SEA-AD. Its snRNA was used to re-test the cohesin result (`scripts/replicate_cohesin_psychad.py`).
* Design, fixed before looking: AD vs control (other neurological diagnoses excluded, as in result 20), donor pseudobulks with ≥ 50 nuclei, covariates age, sex, log nuclei and mitochondrial fraction.
* The competitive null uses 1,000 random gene sets matched on expression decile × gene-length decile ([table](docs/cohesin_psychad.csv)).

| Cells | donors (AD) | r with AD | p_perm | vs matched random sets |
|---|---|---|---|---|
| Excitatory neurons | 402 (202) | **+0.26** | 0.0002 | z = 2.7, **p = 0.003** |
| Oligodendrocytes | 418 (212) | **+0.25** | 0.0002 | z = 2.5, **p = 0.006** |

* **Per gene, the pattern repeats SEA-AD** ([genes](docs/cohesin_psychad_genes.csv)):
  * Excitatory neurons: STAG1 +0.29, NIPBL +0.24, PDS5B +0.24, STAG2 +0.21, SMC3 +0.19.
  * Oligodendrocytes: STAG1 +0.33, PDS5B +0.23, RAD21 +0.18.
  * The unloader WAPL does not rise (+0.07 in excitatory neurons, −0.13 in oligodendrocytes), and neither does CTCF (0.00 / +0.08).
* **The cohesin–loader rise is therefore replicated three times**: Mathys 2023 (ROSMAP PFC), SEA-AD (MTG; result 26) and PsychAD (DLPFC). It holds in both cell types and beyond expression- and length-matched random genes. (Result 29 tests the canonical DDR programs in the same PsychAD neurons.)
* The chromatin side (result 27) and the DAM chromatin results cannot be tested in PsychAD, which has no ATAC. They are being re-tested in an open hippocampus multiome cohort (GSE288063 + GSE278576: 22 donors aged 75–97, Braak 1–6).

### 31. Independent chromatin cohort (hippocampus multiome, 22 donors): DAM chromatin and the homeostatic shift replicate; the oligodendrocyte cohesin mismatch does not

**Cohort.** GSE288063 (5 AD, 3 high pathology without dementia) and GSE278576 (14 age-matched normals) are human hippocampus 10x Multiome, made by the same lab with the same protocol. The 22 donors are aged 75–97, with Braak stages from the study metadata. This is a different lab, region and assay from SEA-AD (MTG, snATAC + snRNA), with no donor overlap.

**Data processing** (`scripts/stream_hippo_multiome.sh`, `scripts/extract_hippo_multiome.py`).
* All 23 fragment files (≈ 54 GB) were streamed, reduced to Tn5 cut sites on the SEA-AD peak set, and deleted.
* Cells and labels are the study's own annotation.
* RNA and ATAC come from the same nuclei.

**Tests** (`scripts/run_hippo_replication.py`). SEA-AD-defined elements are tested as fixed hypotheses, so there is no new discovery and no genome-wide FDR.

| Claim (SEA-AD result) | Hippocampus test | Result |
|---|---|---|
| **DAM-specific chromatin** (22, 24) | Microglial state from RNA in the same nucleus (SEA-AD RNA DAM-up minus DAM-down genes); top vs bottom third within donor, depth-matched | DAM-open peaks +0.67 log2 (z = 14, p_set = 0.001); DAM-closed peaks −0.39 (z = −11). Opened gene domains +0.34 (z = 34); closed domains −0.25 (z = −21). **Same direction in 21 of 21 donors** for every set |
| **Homeostatic shift** (22, 25, 28) | Microglia below the cohort-median DAM RNA score, per donor; SEA-AD DAM axis vs pathology; adjusted for the high-score share, log fragments, age, sex | **Braak: r = +0.60** (20 donors, p_perm = 0.006, p_set = 0.04). **AD / high pathology vs normal: r = +0.57** (21 donors, p_perm = 0.007, p_set = 0.022) |
| Oligodendrocyte cohesin RNA (26, 30) | Oligodendrocyte RNA pseudobulk, cohesin set vs Braak | r = +0.36 (p = 0.11): same direction, underpowered |
| Oligodendrocyte cohesin-site mismatch (27) | Cohesin sites minus matched background in oligodendrocyte ATAC vs Braak / group | r between −0.03 and −0.15 (p ≥ 0.50): **not replicated** |

([tables](docs/hippo_dam_chromatin.csv), [shift](docs/hippo_homeostatic_shift.csv), [oligodendrocytes](docs/hippo_oligo_cohesin.csv))

* **The two microglial claims replicate in an independent cohort, region and assay.**
  * The DAM chromatin elements and gene domains found in SEA-AD separate DAM-high from DAM-low microglia in every hippocampus donor.
  * Homeostatic microglia move along the SEA-AD DAM chromatin axis with Braak stage and with AD / high-pathology status. This is consistent with the SEA-AD effect (r ≈ 0.34–0.46) and somewhat larger.
  * Here the state is defined from RNA in the same nucleus rather than by label transfer, which addresses the "label contamination" objection directly.
* **The oligodendrocyte cohesin-site mismatch does not replicate.** It stays a SEA-AD-only lead. The cohesin RNA rise itself is now seen in SEA-AD, PsychAD and, in direction, the hippocampus.
* **Limits.**
  * 22 donors, with only 8 on the pathology side.
  * Braak is the only pathology measure; no amyloid quantification.
  * The microglial state is a within-cohort RNA score, not the SEA-AD supertype.

### 32. Audit of the DAM differential tests: a single thinning draw made the peak list unstable; d is now averaged over 20 draws

**Why.** Figs 4a/4c rest on within-donor depth matching, a paired t over 23 donors and a sign-flip FDR. All three were audited before strengthening the downstream claims (`scripts/audit_dam_de.py`, `scripts/audit_dam_domains_thinning.py`; log in `results/dam_peaks/audit/log.txt`).

| Check | Result |
|---|---|
| `flip_test` vs a loop-by-loop re-implementation (same sign matrix) | identical q (max difference 0) |
| Technical null: homeostatic pool split binomially at each donor's real DAM/homeostatic depth ratio | 0 calls with thinning (0.2 without) |
| Nucleus-level null: hippocampus microglia split at random 1:4 / 1:9 within donor (real nucleus-to-nucleus variation) | 0 and 0.2 calls; FDR is calibrated |
| Normalisation: per-donor median centring of d | 53/53 open and 73/74 closed calls unchanged |
| Chemistry-stratified d (difference within chemistry, then averaged) | r = 0.85 with the published effects; every published call same sign |
| **Single thinning draw: 10 independent draws** | **call counts stable (open 44–62, closed 47–85), no sign flips, but only 49% of the 127 published peaks recur in ≥ 5 of 10 draws; 397 peaks are called in at least one draw. Gene domains: 43% of the 504 recur in ≥ 3 of 5 single-draw runs** |
| Set test of Fig. 4c with genes as the unit | z = 14.6 is inflated (between-donor correlation ignored, as in result 27) |

Two further findings:
* **Fewer nuclei bias log CPM down even at matched depth.** In the nucleus-level null, the smaller pool sits 0.18 log2 lower at low-count peaks and 0.07 at high-count peaks. It does not create calls, but it inflates closed and shrinks open effect sizes. Abundance-bin centring over-corrects (13 false "open" calls in the null) and was not adopted.
* Of the named candidates, **PTPRG's domain call was a lucky draw** (called in 0 of 5 single-draw runs).

**Fix, now in the pipeline** (`thin_mean_diff` in `scripts/run_dam_peaks.py`, used by `run_dam_regulatory.py`, `split_replication.py`, `run_hippo_replication.py`): the within-donor difference is averaged over 20 thinning draws. In the null this calls 0 open / 0.3 closed; two independent sets of 20 draws share 190 of 221 calls. Fig. 4c now reports the donor-unit set test (per-donor set minus matched genes, sign flips over donors).

**Re-run results** (all downstream scripts and figures; previous outputs replaced):

| Result | Single draw (before) | 20-draw average (now) |
|---|---|---|
| DAM-open / DAM-closed peaks | 53 / 74 | **115 / 121** (102 of the 127 retained, none reversed; 86% distal) |
| Nearest-gene RNA, open / closed peaks | p = 7e-10 / 5e-4 | p = 3e-15 / 4e-4 |
| Gene domains q < 0.05 | 504 | **655** (378 opened, 277 closed) |
| RNA DAM-up genes' domains, donor unit | – | 23/23 donors, t = 14.4, p_flip = 1e-4 (DAM-down: 23/23, t = −9.4) |
| Hippocampus, four SEA-AD element sets | 21/21 donors | 21/21 donors (z = 20, −13, 39, −19) |
| Homeostatic shift, SEA-AD (66 / 43 held-out) | r = 0.34 / 0.46 | r = 0.33 / 0.46 (p_set 0.012 / 0.012) |
| Homeostatic shift, hippocampus, Braak | r = 0.60, p_set 0.04 | r = 0.55, p_perm 0.012, **p_set 0.13** |
| Split replication of the shift (100 splits) | r > 0 in 100% | r > 0 in 100%, median 0.33, p < 0.05 in 54% |
| Candidates | RASGEF1C, PTPRG, CD9, DAPK2 | RASGEF1C (two enhancers), CD9, DAPK2, ANXA2; **PTPRG domain q = 0.18, dropped** |
| Motifs (none at FDR) | E-box (ARNTL, BHLHE40, TFE3), AP-1, IRF8 | open: E-box ARNTL (OR 2.1), MAF/NFE2, AP-1; closed: bHLH (ASCL2) |

### 33. The homeostatic shift: selection bias, confidence intervals, feature overlap and state continuum

`scripts/homeostatic_shift_selection.py` (SEA-AD), `scripts/hippo_continuous_state.py` and `scripts/check_hippo_batch.py` (hippocampus); figure `docs/figures/FigS2`. Every row: partial r with plaques, donor-bootstrap 95% CI, p_perm, p_set against accessibility-matched random axes.

| Question | Test | r (95% CI) | p_set |
|---|---|---|---|
| Baseline | published axis, 66 donors / 43 held-out | 0.33 (0.09–0.52) / 0.46 (0.20–0.66) | 0.022 / 0.010 |
| **Selection: are the scored donors also the peak-callers?** | cross-fitted axis (each discovery donor scored with peaks called without them) | 0.34 (0.09–0.56) | 0.020 |
| | **axis called in the hippocampus** (other cohort, same-nucleus RNA state) | **0.35 (0.12–0.56)**; held-out 0.44 | 0.012 / 0.004 |
| **Thresholds** | all 32,481 peaks weighted by cross-fitted SEA-AD t / by hippocampus t | 0.30 / 0.26 | 0.005 / 0.010 |
| **Feature overlap** | without peaks in ±50 kb of the 400 RNA genes that separate the labels | 0.31 (0.05–0.51) | 0.028 |
| | distal only / promoter only / open only / closed only | 0.33 / 0.23 / 0.27 / 0.26 | 0.02 / 0.07 / 0.002 / 0.036 |
| | 200 random halves of the axis | median 0.32 (5–95%: 0.26–0.36), all > 0 | – |
| | genome-wide, no threshold: each peak's plaque r in held-out homeostatic donors vs its DAM t | Spearman 0.11 (null 0.00 ± 0.04) | p = 0.005 |
| **State continuum (SEA-AD supertypes)** | Micro-PVM_2 / 2_3 / 3, each alone | 0.31 / 0.27 / 0.41 | 0.05 / 0.14 / 0.11 |
| | three states pooled, state fixed effect | 0.28 (0.08–0.47) | 0.016 |
| | labels coarsened (2 + 2_3) | 0.30 | 0.052 |
| | within-donor contrast DAM-like − homeostatic | 0.27 (p_perm 0.20) | – |

* **In SEA-AD the shift is not a selection or labelling artefact.** It survives an axis defined in another cohort, cross-fitting, a threshold-free axis, removal of the label-defining genes, coarsened labels, and it is seen in all three microglial states with the same sign. The DAM-like state moves too and the contrast between states does not shrink, so this is a shift of the whole microglial population along the axis, not label leakage at a boundary.
* **In the hippocampus the picture is different and weaker.**
  * Data quality (fragments per nucleus) falls with Braak (ρ = −0.50). With quality covariates r = 0.42 but p_set = 0.18 (results 31, `check_hippo_batch.py`); within control donors only (Braak 1–3, 12 donors) r = 0.80, p_set = 0.004.
  * By RNA-score quintile, the lowest-score nuclei move toward DAM with Braak (Q1: r = 0.71, p = 0.045) but the highest-score nuclei move away (Q5: r = −0.48, p_set = 0.04); pooled with quintile as a fixed effect r = 0.04. In the 9 donors with both extremes, the Q5 − Q1 contrast falls with Braak (ρ = −0.74). Here the pattern is convergence of states rather than a population shift.
  * Threshold sweep (20th–60th percentile, ± pool mean RNA score): r 0.39–0.65, no p_set < 0.05.
([table](docs/homeostatic_shift_selection_ci_features_continuum.csv))

* **Conclusion.** The shift is a SEA-AD finding that holds against selection, threshold and labelling objections; the hippocampus agrees in direction for the least-activated nuclei but does not replicate it as a population shift, and cannot separate it from state convergence or quality drift with 20 donors.

### 34. Candidate elements: from nearest gene to an element–gene link (fine-mapping, same-nucleus links, eQTL, rE2G)

`scripts/fetch_eqtl_regions.py`, `scripts/candidate_links.py` (results in `results/candidate_links/`); Fig. 6b,c.

| Evidence | Method | RASGEF1C e1 / e2 (DAM-closed) | chr5:87.1 Mb (open) | DAPK2 promoter (open) | CD9 / ANXA2 enhancers (open) |
|---|---|---|---|---|---|
| **GWAS fine-mapping** | Wakefield ABF, one causal variant, lead ± 500 kb (Bellenguez 2022) | **95% credible set = 4 SNPs; 79% of the posterior inside the two enhancers** (rs113706587 PIP 0.32, rs116347724 0.24); microglial peaks cover 19% of the window's bases | PIP in element ≈ 0 (lead rs62375397 lies elsewhere) | 86-SNP credible set; PIP 0.05 | no GWAS signal |
| **Same-nucleus link** | hippocampus multiome microglia; element accessibility vs gene expression, donor and depth regressed; z vs GC/detection-matched peaks (z_peak) and vs state-matched trans genes (z_state) | **RASGEF1C: z_state = 6.0 / 4.7** (z_peak 7.1 / 6.0); no other gene in 500 kb passes | best gene RASA1, z = 1.4 | DAPK2 detected in 0.5% of nuclei: not testable | ANXA2 z_state = 4.4; CD9 1.4 (CD9 detected in 3.7%) |
| **eQTL** (eQTL Catalogue) | element SNPs; SuSiE sets; coloc-ABF | microglia (Young 2019, n = 104, MAF 0.08): risk allele **lowers RASGEF1C**, β = −0.20, p = 0.16 (underpowered); ROSMAP bulk RASGEF1C eQTL is a distinct signal (coloc PP3 = 1.0); in no SuSiE set | ROSMAP: risk allele lowers RASA1 (p = 4e-6) but coloc PP3 = 0.92 (distinct) | DAPK2 / APH1B coloc PP4 ≤ 0.02 | – |
| **ENCODE-rE2G** (CD14+ monocyte, inflammatory macrophage; no microglia model exists) | thresholded predictions overlapping the element | no prediction | none | DAPK2 (0.82) | CD9 (0.97), ANXA2 (0.98) |

([fine-mapping](docs/candidate_gwas_finemap.csv), [links](docs/candidate_same_nucleus_links.csv), [eQTL](docs/candidate_element_snp_eqtl.csv), [coloc](docs/candidate_coloc.csv), [rE2G](docs/candidate_encode_re2g.csv))

* **RASGEF1C is the one element–gene pair with converging evidence.** The AD signal fine-maps into two microglial enhancers that close in the DAM state; in the same nuclei their accessibility tracks RASGEF1C expression beyond what shared cell state produces; RASGEF1C RNA falls in DAM-like microglia; and the risk allele points the same way in microglia eQTL data, though not significantly. Testable predictions: CRISPRi of e1/e2 in iPSC-derived microglia lowers RASGEF1C; the risk alleles of rs113706587 / rs116347724 reduce enhancer activity (allele-specific reporter or base editing).
* **CD9 and ANXA2** have element–gene support (ANXA2 same-nucleus z = 4.4; both predicted by rE2G in myeloid cells) but no genetic signal; they are mechanistic, not genetic, candidates.
* **Dropped:** the chr5:87.1 Mb element (GWAS posterior is elsewhere); DAPK2 stays weak (sub-threshold GWAS, untestable link). PTPRG lost its chromatin support in result 32.
* **Limits.** No LD reference, so fine-mapping assumes one causal variant per locus; the microglia eQTL cohort is small; rE2G uses monocyte/macrophage chromatin.

### 35. Which TFs drive DAM chromatin, and a TF → enhancer → gene network

`scripts/dam_tf_grn.py` (results in `results/dam_tf/`); Fig. 7. Motifs: 392 JASPAR 2024 motifs whose TF is expressed in microglia, scanned with a per-motif p < 1e-4 threshold (exact score distribution). The earlier 85%-of-range rule is too lenient for short motifs (MEF2C, TFEB, BHLHE40 hit 60–90% of peaks) and was replaced here.

**Motif activity, donor as the unit.** Per donor, the mean within-donor DAM − homeostatic difference over a motif's peaks minus the mean expected from GC × accessibility-matched peaks (all 32,481 tested peaks), paired t over 23 donors, sign-flip FDR. 111 motifs at q < 0.05 (98 up, 13 down). Across motifs, SEA-AD t agrees with multiome-only nuclei (ρ = 0.72) and with the hippocampus (ρ = 0.69, 21 donors).

| Family | SEA-AD t | Hippocampus t (donors same sign) | TF whose RNA moves with the activity (SEA-AD RNA t) | Reading |
|---|---|---|---|---|
| AP-1 | +10.7 | +8.3 (21/21) | none clearly (FOS/JUN flat) | activity without expression change; TF unresolved |
| MAF / NFE2 (bZIP) | +10.1 | +6.0 (20/21) | NFE2L2 +7.3, MAFG +6.4 | NRF2 / small-MAF |
| C/EBP | +8.8 | +3.2 | CEBPA +4.7; CEBPB −4.5 | CEBPA |
| **MiT/TFE** | +8.4 | **+10.0 (21/21)** | **MITF +17.5**, TFEC +5.3; same-nucleus coupling r = 0.36 | lysosomal / lipid program |
| E-box (BHLHE41) | +4.7 | +4.1 | **BHLHE41 −14.7** | repressor released: shares E-box with MiT/TFE |
| GR (NR3C1), NF-κB, PAR bZIP, SREBF, SP/KLF | +3.9 to +4.9 | +1 to +3 | NR3C1 +5.9, KLF6 +7.9; RELA −2.9 | weaker |
| **MEF2** | **−4.4** (MEF2C motif q = 0.003) | −1.5 (not replicated) | **MEF2C −16.9** | homeostatic TF lost; SEA-AD only |

**Network.** 491 DAM elements (q < 0.1, |log2FC| ≥ 0.5); element → gene by same-nucleus link in hippocampus microglia (tier 1; z_state and z_peak ≥ 2.5, mirrored-tail FDR ≈ 0.10; 42 links) or by domain proximity (tier 2; gene TSS ≤ 50 kb, domain q < 0.05 and RNA moving with the element; 82 pairs): 102 elements → 106 genes. TF family → element when a supported motif is present and the element moves in the family's direction. Core regulons: MiT/TFE → GRAMD1B, MYO1E, WIPI1, LGALS3, DNASE2B; MAF/NFE2 → ACER3, EMSY, EPB41L3, WIPI1, LGALS3; NF-κB → RGCC, CLIP4; MEF2 → ASTN1, ST6GALNAC3 (closing). Regulon check in hippocampus metacells (TF expression vs mean target expression, against targets matched on DAM RNA t and expression): MITF z = 1.7 (p = 0.09), KLF6 z = 2.0 (p = 0.05), others near 0.

**Homeostatic shift (66 donors).** No motif's activity in homeostatic microglia tracks plaques at q < 0.05. In the 43 held-out donors the main DAM families lean the expected way (MAF/NFE2 r = +0.17, AP-1 +0.15, MEF2C −0.29) but across all motifs the agreement with DAM activity is nil (ρ = 0.03).

**RASGEF1C risk alleles.** Motif gain or loss at the four credible-set SNPs occurs at the background rate of random transitions in microglial peaks (1, 0, 1, 0 events vs null mean 1.7); the only change (a TFAP2 site lost with the risk allele of rs113706587) is not a DAM-changing family. No TF mechanism for the variants is supported.

([families](docs/dam_tf_families.csv), [network edges](docs/dam_tf_grn_edges.csv), [regulons](docs/dam_tf_regulons.csv))

* **Robust:** the DAM chromatin state is written mainly through AP-1, NRF2/MAF, C/EBP and MiT/TFE sites, replicated in an independent cohort; MITF is the clearest single driver (expression, activity and same-nucleus coupling agree). A switch at E-box sites — BHLHE41 down, MITF/TFEC up — fits reports that BHLHE40/41 restrain the lysosomal / DAM program. Loss of MEF2C activity marks the closing side but is SEA-AD only.
* **Weak:** the gene-level network is small (42 high-confidence links) and its regulons are only marginally supported by same-nucleus co-expression; it is a hypothesis map, not a validated GRN. No TF explains the homeostatic shift, and the RASGEF1C variants do not hit a driver motif.
* **Limits:** motif families cannot separate paralogues; no footprinting (base-level fragments were not kept); links depend on genes detected in ≥ 2% of 6,302 nuclei.

### 36. LD-aware fine-mapping (SuSiE-RSS, 1000 Genomes EUR): the RASGEF1C credible set is unchanged

`scripts/susie_finemap.py` (results `results/candidate_links/susie_*.csv`). LD from 503 EUR samples of 1000 Genomes phase 3 on GRCh38 (remote tabix), SNVs with EUR MAF ≥ 1% matched to Bellenguez 2022 by position and alleles; `susie_rss`, L = 10, n_eff = 283,145.

| Locus | SNPs | LD consistency s | Credible sets | Result |
|---|---|---|---|---|
| RASGEF1C | 3,379 | 0.09, no kriging outliers | 1 | **same 4 SNPs as the ABF set** (purity 1.0, perfect LD); 79% of posterior in the two DAM-closed enhancers. One further variant, rs4700716 (p = 4 × 10^−5^, PIP 0.94, no 95% set), lies outside microglial peaks |
| chr5:87.1 Mb | 1,984 | 0.03 | 1 | 20 SNPs, none in DAM elements (as with ABF) |
| DAPK2 | 2,268 | 0.02 | 0 | no credible set |

* The single-signal assumption of result 34 did not distort the RASGEF1C set. The four SNPs are in perfect LD in EUR, so genetics cannot choose between e1 and e2; both need testing.

### 37. Microglial states beyond DAM

`scripts/microglia_states.py`, figure `docs/figures/FigS3`. Ten canonical programs (homeostatic, DAM, interferon, inflammatory/NF-κB, MHC-II, lysosomal, lipid, perivascular, proliferation, ex vivo immediate-early).

* **States.** Micro-PVM_2 is homeostatic and MHC-II-high; Micro-PVM_2_1 is proliferative; Micro-PVM_2_3 is intermediate; Micro-PVM_3 (DAM-like) combines DAM, interferon, MHC-II and lysosomal programs; Micro-PVM_4 (406 nuclei) is DAM/lipid/inflammatory with the highest immediate-early score (possible ex vivo activation); Micro-PVM_1 is perivascular macrophage with interferon and lysosomal programs.
* **Pathology.** In parenchymal microglia per donor (73 donors), only DAM nears significance against expression-matched random sets (r = 0.37 with CPS, p_set = 0.055); lysosomal and lipid programs rise (r = 0.30, 0.28; p_perm 0.01–0.02) but no more than random genes. Only the DAM-like share rises with CPS (ρ = 0.48).
* **Chromatin.** Motif families of each state against Micro-PVM_2 (within donor): Micro-PVM_3 reproduces the DAM pattern (AP-1 +11.3, MAF/NFE2 +10.4, MiT/TFE +9.1, C/EBP +8.3); Micro-PVM_2_3 is close to homeostatic (largest changes |t| ≤ 4.2); perivascular Micro-PVM_1 is dominated by C/EBP and SP/KLF.
* **Hippocampus.** Per-nucleus interferon and MHC-II scores are independent of the DAM RNA score (r = 0.06, −0.05); lipid tracks it (r = 0.33).
* The pathology-associated state in these data is DAM; interferon, inflammatory and MHC-II states do not track progression beyond random genes.

### 38. TF footprinting in hippocampus microglia: not calibrated with these data, so no binding claim

`scripts/stream_hippo_cuts.sh` + `scripts/extract_microglia_cuts.py` (second pass over the 23 fragment files, base-level cut sites of 6,302 microglia near tested peaks, 274 MB kept), `scripts/footprint_dam_tfs.py` (results `results/dam_tf/footprints/`). Cuts aggregated around the stronger half of each motif's p < 1e-4 sites, 6-mer Tn5 bias correction, DAM-high vs DAM-low thirds per donor (21 donors, ~15,000–65,000 cuts per motif, donor and group).

| Motif | footprint ratio (centre / flank; < 1 = protected) | flank accessibility, DAM-high vs low |
|---|---|---|
| CTCF (positive control) | 0.93 | lower in DAM-high (p = 0.03) |
| PU.1 (positive control) | 0.77 | unchanged |
| column-shuffled CTCF / MITF (negative controls) | 0.85 / 0.88; shuffled MITF differs between groups (p = 0.006) | unchanged |
| MITF, TFEC, BHLHE41 (E-box) | 0.39–0.41 | TFEC +, p = 0.05; others ns |
| AP-1, NRF2, CEBPA | 0.75–1.05 | **higher in DAM-high** (p = 2 × 10^−5^, 1 × 10^−4^, 0.003) |

* **The calibration fails.** CTCF, which leaves a deep footprint in most ATAC data, is no deeper than its shuffled control, and a shuffled motif shows a "significant" group difference. The deep E-box "footprints" are most likely a Tn5 sequence-preference artefact at CACGTG rather than protection. The cut sites were stored without fragment strand, and Tn5 bias is strand-specific, so the 6-mer correction cannot be done properly; depth per donor is also low.
* **What holds:** flank accessibility, which does not depend on the footprint model, rises in DAM-high microglia at AP-1, NRF2/MAF and C/EBP sites, the same families as result 35, now at base resolution within ± 100 bp of the motifs.
* **No claim of TF binding is made.** A proper footprint analysis needs strand-aware cut sites (a third pass over the fragment files) and ideally a naked-DNA Tn5 bias model.

### 39. How small a DDR change is excluded: equivalence tests and leave-one-gene-out

`scripts/ddr_equivalence.py` (results `results/ddr_equivalence/`), figure `docs/figures/FigS4`. Effect = excess r over 200 random sets matched on expression × gene length; 90% donor-bootstrap CI (500 resamples, program and its null resampled together); "equivalent" if the 90% CI lies inside the bound (two one-sided tests at α = 0.05), "different" if the 95% CI excludes 0. Because a random gene set also deviates from the mean of other random sets, every rate is compared with a **benchmark**: the same procedure applied to 20 of each program's own random sets treated as programs.

| Scale | DDR tests | Equivalent (bound) | Different | Random-set benchmark (equiv / diff) |
|---|---|---|---|---|
| SEA-AD MTG (all cell groups) | 234 | 41% (± 0.20); 4% (± 0.10) | 11% | 39% / 13% |
| SEA-AD other 8 regions | 1,725 | 24% (± 0.20) | 5% | 17% / 5% |
| PsychAD EN + Oligo (≈ 410 donors) | 20 | **100% (± 0.20)**; 30% (± 0.10); every 90% CI within ± 0.15 | 0% at ± 0.20 | 93% / 7% |
| GeoMx P vs PP (28 donors) | 10 | 0% (± 0.25 s.d.); 90% CIs ± 0.35 s.d. | 0% | – |
| Stereo-seq (2 sections) | 10 | **80% (± 10%)**; MMR, Checkpoint inconclusive | 0% | – |

References: DAM in MTG microglia, excess 0.21 (90% CI 0.003–0.42); cohesin "different" in every cohort (SEA-AD L2/3 IT 0.39, oligodendrocytes 0.37, PsychAD EN 0.24); GeoMx DAM 0.57 s.d.; Stereo-seq Trem2 + Cd68 log RR 0.42.

**Leave-one-gene-out (MTG, 234 tests, 2,996 variants).** 3.2% of variants reach p_set < 0.05 and 7% of tests have at least one such variant, against 13% when the same procedure is applied to random gene sets; the median largest change in excess r is 0.05, and larger changes occur only in 3-gene programs or the 13-donor Sst Chodl group. No single gene hides a DDR signal. The L5 ET HR lead is not driven by one gene (all 16 variants p_set ≤ 0.02), and the cohesin result keeps p_set < 0.05 in all five leave-one-out versions in L2/3 IT and oligodendrocytes.

* **What this adds.** DDR programs pass and fail equivalence at the same rates as matched random gene sets in every cohort: they are statistically indistinguishable from arbitrary genes, which is the claim of results 13 and 29, now stated as a bounded effect. With ≈ 410 PsychAD donors, a DDR change larger than ± 0.15 in excess r is excluded for every program in both cell types; at the plaque scale in mouse, 8 of 10 programs are within ± 10%.
* **What it does not add.** With 73 SEA-AD donors per cell group the 90% CI half-width is ≈ 0.14, so equivalence at ± 0.20 holds for only 41% of tests and at ± 0.10 for almost none; the GeoMx data cannot establish equivalence at all. Even the DAM positive control's competitive excess is not significant by bootstrap in MTG microglia, so the donor-level competitive test is conservative at this sample size.

### 40. Pre-specified DDR endpoints: effect sizes, 95% CIs and multiple testing in two cohorts

`scripts/psychad_extra_pb.py` (PsychAD IN, Astro, Micro and EN_L2_3_IT pseudobulks), `scripts/ddr_endpoints.py` (results `results/ddr_endpoints/`), figure `docs/figures/FigS5`. The pathway scores average 10–150 genes; here eight narrow endpoints were fixed from the literature before this analysis (but after the pathway results were known): DSB sensing (ATM, MDC1, TP53BP1), p53 response (CDKN1A, MDM2, GADD45A, BBC3), NHEJ core (XRCC4, LIG4, PRKDC, XRCC5, XRCC6), BER core (OGG1, APEX1, XRCC1, PARP1), senescence (CDKN2A, CDKN1A), cGAS–STING (CGAS, STING1), and CDKN1A and GADD45A alone; six cell types (excitatory, L2/3 IT, inhibitory, microglia, oligodendrocytes, astrocytes); 48 primary tests per cohort, of which 42 (SEA-AD) and 44 (PsychAD) had the genes expressed (CDKN1A is below threshold in neurons). Per test: partial r with donor-bootstrap 95% CI, permutation p, covariate-adjusted log2 change, and the competitive excess over 1,000 expression × length-matched gene sets with 95% CI; Holm and BH over the primary tests; random-effects meta-analysis of the two cohorts with the matched-set spread added to the variance (without it, arbitrary gene sets reach "significance", result 39).

| | SEA-AD (73 donors) | PsychAD (362–425 donors) | Meta-analysis |
|---|---|---|---|
| p_perm < 0.05 (self-contained) | 3 / 42 | 13 / 44 (mostly decreases shared with matched genes) | – |
| Holm / BH < 0.05, self-contained | 0 / 0 | 1 / 1 (microglial cGAS–STING, r = −0.22) | – |
| p_set < 0.05 (competitive) | 2 / 42 | 2 / 44 | 1 / 42 at p < 0.05 |
| Holm / BH < 0.05, competitive | 0 / 0 | 0 / 0 | 0 / 0 (min BH q = 0.87) |
| median upper 95% bound of \|r\| | 0.32 | 0.17 | excess: median 0.22, max 0.35 |
| references (excess, meta) | | | cohesin 0.26–0.30 in Exc / L2/3 IT / Oligo (p ≤ 0.006); DAM in microglia 0.23 (p = 0.006) |

* **No pre-specified endpoint changes beyond matched genes in either cohort or in the meta-analysis after correction**, while the cohesin and DAM references do. The single self-contained hit, a fall of microglial cGAS–STING in PsychAD, is shared with matched genes (p_set = 0.013, BH 0.62); its meta-analytic excess is −0.19 (95% CI −0.35 to −0.03, p = 0.02, BH 0.87). If anything, it goes against the damage → cGAS–STING activation model.
* The narrow endpoints agree with the pathway scores: the null is not an artefact of averaging many genes.
* Bounds: meta-analytic excess effects beyond ≈ ±0.22 are excluded for a typical endpoint; single-cohort SEA-AD intervals are wide (≈ ±0.3).
* SEA-AD names STING1 as TMEM173; the endpoint analysis maps the alias, but the cGAS_STING_IFN pathway score used since result 13 lacked STING1 in SEA-AD (1 of 14 genes).

### 41. Intrinsic shift or contamination? A mixture bound in SEA-AD and nucleus-level tests in the hippocampus

`scripts/homeostatic_mixture.py` (results `results/homeostatic_shift/mixture_*.csv`).

**(a) Contamination bound, SEA-AD (66 donors).** Treating each homeostatic pseudobulk as (1 − f) homeostatic + f DAM-like (pooled DAM-like profile), the axis rises by 2.37 units per unit f; the observed slope is 0.18 per log-plaque unit. To produce the shift across the 5–95% plaque range, the DAM-like fraction hidden in the homeostatic label would have to rise by **17% (95% CI 4–29%)**, whereas the labelled DAM-like share of microglia rises by only **4.3% (−0.1 to 8.2%)** over the same range (median share 7.9%). Contamination would therefore need about four times more mislabelled DAM-like nuclei than the entire labelled increase; the lower confidence limits touch, so this argues against contamination without excluding it.

**(a2) Composition, SEA-AD.** Adjusting for the share of every microglial supertype leaves the shift intact: none r = 0.33; + DAM-like share 0.27; + DAM-like and intermediate (2_3) 0.27; + all three 0.33; + total non-homeostatic share 0.30 (all p_perm ≤ 0.03).

**(b) Nucleus level, hippocampus (6,302 nuclei, 20 donors with Braak).** A per-nucleus chromatin DAM score (mean SEA-AD DAM t of the peaks hit, depth-corrected) tracks the same nucleus' RNA DAM score (r = 0.55), so it measures state. Within below-median-RNA nuclei, no quantile of its per-donor distribution moves with Braak (r between −0.13 and −0.07), and the score at a fixed RNA state does not either (r = 0.03). The answer, however, depends on the score and on depth: fragments per nucleus fall with Braak (r = −0.41), and a log(open/closed) DAM-peak score gives r = 0.18 (below median) to 0.58 (lowest quintile) with depth as covariate and 0.41–0.80 without it. The hippocampus cannot separate a shift from quality drift.

* **Reading.** In SEA-AD, composition and labelled contamination do not explain the shift, and contamination would need an implausibly large hidden DAM-like fraction. The nucleus-level hippocampus data are uninformative because of depth confounding. The decisive test is a nucleus-level analysis in SEA-AD (per-nucleus counts of the 86 ATAC objects, with same-nucleus RNA for multiome nuclei), which needs re-streaming the objects.

### 42. Nucleus-level SEA-AD: the shift is seen only in donors whose labels are transferred through chromatin

`scripts/stream_atac_micro_cells.sh` + `scripts/extract_atac_micro_cells.py` (per-nucleus microglia of the 86 ATAC objects, tested peaks only, with supertype, supertype confidence, chemistry and MultiVI coordinates), `scripts/seaad_nucleus_shift.py` (results `results/homeostatic_shift/nucleus_*.csv`). 9,572 microglia; per-nucleus score = log(DAM-open / DAM-closed counts), depth-corrected (sensitivity: mean DAM t over all tested peaks). DAM-like nuclei score 1.2 units above homeostatic ones, so the score reads state.

| Test (Micro-PVM_2 nuclei, vs plaques) | r | p |
|---|---|---|
| per-donor mean, 66 donors (reproduces the pseudobulk shift) | 0.31 | 0.012 |
| quantiles q10 / q25 / q50 / q75 / q90 | 0.30 / 0.29 / 0.33 / 0.32 / 0.21 | 0.008–0.10 |
| simulated contamination matching the shift (quantiles) | 0.39 / 0.40 / 0.54 / 0.62 / 0.65 | – |
| sensitivity score (all-peak t), quantiles | 0.14 / 0.15 / 0.22 / 0.27 / 0.31 | 0.01–0.28 |
| **ATAC-only donors (41; every label transferred through chromatin)** | **0.50 (95% CI 0.23–0.72)** | 0.001 |
| **multiome donors (25; part of the nuclei labelled from their own RNA)** | **−0.04 (−0.60 to 0.45)** | 0.85 |
| heterogeneity between the two donor sets | Fisher z = 2.0 | 0.04 |
| multiome donors: their ATAC-only nuclei / their multiome nuclei | 0.08 / −0.11 | 0.73 / 0.60 |
| multiome nuclei with supertype confidence ≥ 0.9 (24 donors) | −0.25 | 0.26 |

* **Distribution shape is ambiguous.** With the primary score every quantile moves about equally, unlike the rising profile expected from contamination; with the all-peak score the upper quantiles move more. The shape cannot decide.
* **The shift is confined to ATAC-only donors.** In the 25 donors with multiome data it is absent in both their multiome and their ATAC-only nuclei, and the two donor sets differ (p = 0.04). In ATAC-only donors the homeostatic label of every nucleus is inferred from chromatin, so a chromatin shift within the label cannot be separated from where the label boundary falls. Where state is read from RNA in the same nucleus (SEA-AD multiome donors, the hippocampal cohort, result 41) a robust shift is not seen, though both sets are small (25 and 20 donors).
* **Revised conclusion.** The homeostatic shift is not established as an intrinsic change of homeostatic microglia. It is a robust feature of chromatin-labelled homeostatic nuclei in SEA-AD that composition at the level of labelled supertypes does not explain (results 33, 41), but it is not reproduced where labels come from RNA. A label-transfer or donor-set explanation remains open; resolving it needs RNA-labelled nuclei in a larger cohort (for example ROSMAP multiome).

### 43. The core question: a program shared by all cell types, or remodelling concentrated in some?

`scripts/global_vs_specific.py` (results `results/global_specific/`; Fig. 1d–f). For every MTG cell group, each gene's (RNA, 21 groups, 12,648 genes expressed in all) or peak's (ATAC, 16 subclasses, 22,613 peaks accessible in all) partial correlation with local CPS (age, sex, PMI, log nuclei; ATAC also fragments and multiome share; severe donors excluded). **Shared fraction**: over 20 donor split halves, corr(mean profile of the other cell types in one half, the cell type's profile in the other half)² / the cell type's split-half reliability (not reported when reliability < 0.1). **Specific features**: |r − mean r of the others| beyond the 99.5th percentile of |r| under 100 CPS permutations of that cell type (expected false count 0.5%). Sensitivity: "others" weighted so that excitatory, inhibitory and non-neuronal classes count equally.

| | Neurons (13–16 types) | Microglia | Oligodendrocytes | Astrocytes |
|---|---|---|---|---|
| RNA shared fraction | 0.13–0.29 (median 0.25) | 0.07 | 0.12 | 0.07 |
| RNA specific genes (observed / expected 63) | 10–97 (0.2–1.5×; Chandelier 195, 3.1×) | 354 (5.6×) | 238 (3.8×) | 212 (3.4×) |
| ATAC specific peaks (observed / expected 113) | 71–223 (0.6–2.0×) | 422 (3.7×) | 773 (6.8×) | 421 (3.7×) |
| class-balanced "others": RNA / ATAC specific | similar | 307 / 351 | 111 / 601 | 165 / 400 |

* **No cell type is dominated by a shared program**: even in neurons only about a quarter of the reproducible CPS profile is predicted by the other cell types. But the neuronal profiles are weak and diffuse, so in most neuron types almost no single gene departs from the others beyond chance (Chandelier cells are the exception). Gene- and element-level departures (focused remodelling) concentrate in glia: microglia, VLMC, oligodendrocytes and astrocytes in RNA; oligodendrocytes, astrocytes, microglia and OPCs in chromatin. Class balancing does not change this.
* **Programs.** DDR programs track neither the shared change nor anything specific: observed r ≈ 0 in every cell type, close to the prediction from the other cell types (median |observed − predicted| 0.04). The cohesin-loading set is shared: predicted 0.22 from the other cell types in every group, observed 0.24–0.50 in neurons and glia alike. DAM genes are microglia-specific: r 0.37 in microglia against 0.11 predicted.
* **Neuronal chromatin.** Within each neuronal subclass many accessible peaks track CPS (up to 6.6× the permutation expectation in L5 IT, 6.0× in Vip), but they are shared across neuron types and follow accessibility (r vs mean accessibility ≈ −0.15; promoters negative, distal peaks positive): a diffuse, drift-like axis rather than element-specific remodelling. Microglia: 1.5×.
* **Answer.** The pathology-associated change is not one transcriptional program running in all cells. Neurons carry a weak, diffuse change that is partly common to all neuron types (the DDR genes ride it and do not exceed it). Specific remodelling of genes and regulatory elements is concentrated in glia, of which microglia (the DAM program, results 30–37) are the best resolved. (Result 46: in PsychAD, with ~430 donors, neurons also show replicable specific genes; glia remain the most specific.) Caveat: pseudobulk associations include composition within a cell type (for microglia, more DAM-like nuclei with disease).

### 44. RASGEF1C: the genetic-regulatory chain, link by link

`scripts/fetch_rasgef1c_qtls.py` (eQTL Catalogue, remote tabix, chr5:179.95–180.45 Mb) and `scripts/rasgef1c_chain.py` (results `results/rasgef1c/`, `chain_summary.csv`; Fig. S6).

| Link | Evidence | Verdict |
|---|---|---|
| variant → element | SuSiE 4-SNP credible set (purity 1.0), 79% of PIP in e1 (rs113706587) and e2 (rs116347724, rs111274391); the 4 SNPs are in complete LD | supported; e1 vs e2 not separable |
| conservation | phyloP 100-way −2.1 to 0.6, 30-way primate −3.5 to 0.6 at the SNPs (0–84th percentile of random positions in microglial peaks); element means at the 18th–46th percentile; e1 does not lift over to mouse, the e2 orthologue has no peak in 5xFAD microglia | not conserved: a human (primate-poor) element, so mouse models cannot test it directly |
| motif | rs113706587 and rs111274391 risk alleles lose a TFAP2E site (no DAM activity change for that motif; event rate not above random transitions) | no mechanism identified |
| element is microglial | e1 15.5 CPM in microglia vs ≤ 3.0 in any other subclass; e2 11.8 vs 7.8 (L6 IT Car3) | e1 microglia-specific; e2 mostly |
| element closes in DAM | SEA-AD log2FC −1.48 (q 0.046) / −1.19 (q 0.08); hippocampus t −2.7 / −2.4 | supported, replicated in direction |
| element → gene | same-nucleus links, z_state 6.0 / 4.7 with RASGEF1C; no other gene within 500 kb passes (best other z_state 2.0) | supported (correlative) |
| gene is microglial and falls in DAM | RASGEF1C 320 CPM in microglia, 2.6× the next cell group; DAM-like vs homeostatic log2FC −1.20 (t −14.6); lower in DAM-high than DAM-low nuclei in 20/21 hippocampal donors | supported |
| genotype → gene (microglia, n = 104) | risk allele z −1.4 (p 0.16); transcripts ±1.1–1.6; exon / txrevise / leafcutter: RASGEF1C not tested; coloc PP4 0.09 | direction consistent, underpowered |
| genotype → gene (bulk brain) | the primary RASGEF1C eQTL in ROSMAP, CommonMind, BrainSeq and GTEx is a different signal (lead rs10078112 / rs10078173 at 180.15–180.16 Mb, r² < 0.005 with rs113706587; coloc PP3 0.42–1.00). After stepwise conditioning on it (1000 Genomes EUR LD): **CommonMind DLPFC (n = 586) risk allele z −4.2 (p 2.8 × 10⁻⁵), conditional coloc PP4 0.92**; ROSMAP −0.7, GTEx cortex −0.5, frontal cortex +0.1, BrainSeq +1.1 | one cohort supports a secondary eQTL; not replicated (bulk-brain meta z −2.3, p 0.02, driven by CommonMind; without it z 0.0) |
| all eQTL sets (Stouffer, √n weights) | z −2.7 (p 0.008); myeloid sets −1.5 (p 0.13) | suggestive, heterogeneous |
| microglial single-nucleus eQTL (Haglund 2025, 391 donors; result 47) | lead rs76792388 (credible set), t 11.6; coloc with AD PP.H4 0.997; MR: risk allele lowers RASGEF1C | **supported** |

* **The chain is complete at the level of association, with one weak link.** Risk variants sit in two microglial enhancers that close in DAM; the enhancers track RASGEF1C in the same nuclei, and RASGEF1C is a microglial gene that falls in DAM. The risk allele lowers RASGEF1C in every myeloid dataset (not significantly) and, as a secondary eQTL distinct from the strong primary one, in CommonMind brain, which colocalises with the GWAS after conditioning (PP4 0.92). It does not replicate in ROSMAP, GTEx or BrainSeq. A microglial eQTL resource larger than n = 104 is the missing link.
* **Proposed model.** AD risk allele → weaker e1 / e2 activity → less RASGEF1C in microglia, i.e. the risk allele mimics, in homeostatic microglia, the closure that happens in the DAM state. Direction is consistent across links; causality needs CRISPRi of e1 / e2 and allelic tests in human microglia, as the elements are not conserved in mouse.
* Bryois et al. single-nucleus brain eQTLs (Zenodo 7276971) still time out for chr5.

### 45. Ranking candidate driver TFs: MITF first on eight evidence lines, stable under donor resampling

`scripts/tf_ranking.py` (results `results/tf_ranking/`; Fig. S7). 327 candidate TFs (every TF with a JASPAR motif kept in result 35), each represented by its strongest motif. Eight evidence lines, signed so that an activator moves with its motif: L1 motif activity |t| (SEA-AD, 23 donors); L2 replication in SEA-AD multiome nuclei (15 donors); L3 replication in the hippocampus (21 donors); L4 the TF's own RNA, DAM-like vs homeostatic (66 donors); L5 TF-specific coupling in hippocampal metacells (correlation of TF RNA with its own motif, as z against motifs of other families); L6 abundance in microglia; L7 share of the family's RNA (motifs cannot separate paralogs, expression can); L8 CollecTRI targets' DAM RNA change vs random sets. Aggregates: mean percentile rank and robust rank aggregation (RRA), with a permutation null (lines shuffled independently over TFs).

| TF | L1 | L2 | L3 | L4 | L5 | L7 | L8 | rank (mean / RRA) | permutation p (mean / RRA) | bootstrap median rank (95%) | P(rank 1) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **MITF** | 8.4 | 3.8 | 9.9 | 17.5 | 3.1 | 0.36 | 4.9 | **1 / 1** | **0.002 / 0.0005** | **1 (1–1)** | **0.98** |
| NFE2L2 | 8.9 | 4.5 | 7.2 | 7.3 | 1.1 | 0.29 | 6.2 | 2 / 4 | 0.015 / 0.02 | 2 (2–3) | 0.02 |
| BNC2 | 8.6 | 4.9 | 7.6 | 8.2 | 2.5 | 0.36 | – | 3 / 2 | 0.19 / 0.0005 | 3 (3–5) | 0 |
| CEBPA | 8.5 | 5.1 | 3.6 | 4.7 | 0.7 | 0.17 | 4.6 | 4 / 14 | 0.31 / 0.74 | 5 (3–11) | 0 |
| TFEC | 6.1 | 3.2 | 5.9 | 5.3 | 1.0 | 0.37 | – | 8 / 8 | 0.77 / 0.38 | 10 (5–25) | 0 |
| TFE3 / TFEB | 6.2 / 7.6 | 2.7 / 3.9 | 5.9 / 5.7 | 0.8 / 1.1 | 0.1 / −1.3 | 0.03 / 0.12 | 5.8 / – | 30 / 59 (mean rank, each) | 1 | – | 0 |

* **MITF is the top candidate on every aggregate**: mean rank, RRA and one vote per evidence group (chromatin, replication, TF RNA, coupling, targets). Dropping any single line keeps it first, except dropping the CollecTRI targets (then BNC2 first, MITF second). In 200 donor bootstraps (all lines recomputed) it ranks first in 98% and in the top 3 in 100%. Its motif activity alone ranks only 24th (AP-1 motifs are stronger), so its lead comes from the agreement of the lines that resolve the paralog: MITF RNA rises (t 17.5; rank 1), its expression couples to its own motif in the same nuclei (z 3.1; rank 1), and its motif replicates most strongly in the hippocampus (rank 1). Within MiT/TFE, MITF and TFEC each carry ~36% of the family's RNA, TFEB 12%, TFE3 3% (the share line is uninformative across families, as single-member families score 1). TFE3 and TFEB, with the same motif activity, rank 30 and 59 because their RNA does not change and does not couple.
* The next candidates are NFE2L2 (NRF2/MAF sites) and BNC2 (AP-1-like sites), consistent with the families of result 35. A repressor-like ranking (TF RNA, coupling and targets sign-reversed) puts MAF and BHLHE41 at the top: E-box activity rises while BHLHE41 RNA falls (t −14.7).
* **Limits.** All lines except L8 come from the same two cohorts; motif-based lines cannot prove binding (footprinting was uncalibrated, result 38), and CollecTRI targets of MITF come mostly from melanocytes. The ranking orders candidates for perturbation (MITF knock-down in iPSC microglia); it does not establish causality.

### 46. The core question replicated in PsychAD (DLPFC, AD vs control, ~430 donors)

`scripts/psychad_subclass_pb.py` (one pass over the 36 GB MSSM object: donor pseudobulks of 24 subclasses for the 437 AD / control donors, `data/processed/psychad_pb/sub_*.npz`) and `scripts/psychad_global_vs_specific.py` (results `results/global_specific/psychad_*.csv`; Fig. S8). Same estimators as result 43; exposure AD vs control (age, sex, log nuclei, mitochondrial fraction); 24 subclasses with ≥ 50 donors of ≥ 20 nuclei (VLMC 127, PVM 70; others 380–437 donors); 10,572 genes expressed in all. `global_vs_specific.py` now also saves the SEA-AD profiles (`rna_profiles.npz`) and tests each program's cell-type-specific component against expression-matched random gene sets.

| | Neurons (16 subclasses) | Microglia | Oligodendrocytes | Astrocytes | OPC / Endo / VLMC |
|---|---|---|---|---|---|
| shared fraction | 0.33–0.50 (median 0.43) | 0.07 | 0.17 | 0.21 | 0.31 / 0.07 / 0.03 |
| specific genes (expected 53) | 62–650 (1.2–12×) | 1,177 (22×) | 794 (15×) | 1,395 (26×) | 293 / 329 / 360 |
| SEA-AD vs PsychAD, specific component r | 0.16–0.57 | 0.52 | 0.58 | 0.55 | OPC 0.35, VLMC 0.13 |
| specific genes in both cohorts, same sign (observed / expected) | 1–52 / 0.1–2.0 | 122 / 14.7 | 93 / 7.1 | 95 / 10.7 | OPC 11 / 0.9 |

Mismatched cell-type pairs give r_specific median −0.04 (95th percentile 0.16); every matched pair except VLMC exceeds it.

* **Glia are again the least shared and the most specific.** With six times more donors than SEA-AD, the ranking is the same: microglia, astrocytes and oligodendrocytes carry the most specific genes, and glia (and endothelial / VLMC cells) the lowest shared fractions; class balancing does not change it.
* **The specific components replicate across cohorts, regions and exposure definitions.** The part of each cell type's profile that departs from the other cell types correlates between SEA-AD (MTG, CPS) and PsychAD (DLPFC, AD diagnosis) at r 0.5–0.6 for the three main glia, and specific genes overlap 7–13× beyond chance.
* **Revision for neurons.** In PsychAD neurons also carry many specific genes (up to 650 in Lamp5-RELN interneurons) whose specific component replicates (Vip r 0.57, Pvalb 0.50); the near-chance counts of SEA-AD neurons (result 43) reflect 73 donors more than an absence of neuron-specific change. Neurons share more (0.33–0.50) than glia (0.03–0.31), so the contrast is one of degree.
* **Programs.** DAM is microglia-specific (r 0.24 vs 0.03 predicted; specific component p 0.008 against matched random sets). Cohesin rises beyond the cross-cell prediction (≈ 0.08) in excitatory neurons (0.17–0.24), oligodendrocytes (0.24), astrocytes (0.20) and mural cells (0.21–0.27), not in interneurons (0.09–0.18) or microglia (0.10). DDR programs fall in neurons (r −0.06 to −0.20) with the neuron-wide drift, but their cell-type-specific component is at chance: p < 0.05 in 9/216 tests (SEA-AD 11/189), none at BH q < 0.1.
* **Answer, revised.** The pathology-associated change is cell-type-specific in every cell class, not one shared program; specificity is strongest in glia, where it is also the most reproducible across cohorts. DDR has neither a shared nor a specific component beyond chance.

### 47. External support for the weakest link: RASGEF1C is a microglial eQTL that colocalises with AD (Haglund et al. 2025)

`scripts/haglund_rasgef1c.py` (published supplementary tables in `data/raw/haglund2025/`; result `results/rasgef1c/F_haglund2025.csv`; Fig. S6e top row). Haglund et al. (*Nat. Genet.* 2025; single-nucleus eQTLs in 8 brain cell types, 391 donors) report RASGEF1C among their AD colocalisations. Their tables give:

| Evidence | Value |
|---|---|
| microglial cis-eQTL lead SNP | **rs76792388**, one of our four credible-set SNPs; t = 11.6, p = 1 × 10⁻²⁵ (391 donors); t = 6.6 in 183 control-only donors |
| colocalisation with AD (Bellenguez 2022) in microglia | PP.H4 = 0.997 (all donors; lead colocalised SNPs rs113706587 / rs116347724) and 0.996 (controls only) |
| cell specificity | the credible-set SNP is an eQTL only in microglia; RASGEF1C eQTLs in OPCs (rs4248878) and excitatory neurons (rs6601086) are different SNPs |
| Mendelian randomisation (authors' harmonised alleles) | IVW β = −0.097 (s.e. 0.014) AD log-odds per unit microglial RASGEF1C: higher expression, lower risk, so the **risk allele lowers RASGEF1C** |

* This closes the genotype → gene link of result 44 with the direction our model predicts (risk allele lowers RASGEF1C, as e1 / e2 close in DAM), and explains why bulk tissue and the 104-donor primary-microglia set were weak: the effect is microglia-specific and needs single-nucleus resolution. The full chain is now supported at every link by association: variant → microglial enhancers (fine-mapping) → enhancer closes in DAM → enhancer tracks RASGEF1C in the same nuclei → risk allele lowers microglial RASGEF1C (external sn-eQTL, coloc PP.H4 0.997) → lower RASGEF1C, higher AD risk (MR).
* **Novelty.** The gene-level link (RASGEF1C microglial eQTL colocalising with AD) is published; what is new here is the element-level resolution (the two enhancers, their DAM-state closure and same-nucleus link) and the model that the risk allele anticipates the DAM closure. Full summary statistics (Zenodo 13343729) were not reachable; allele-level checks at e1 / e2 SNPs await them.
* Related 2025–2026 literature checked (Europe PMC): MITF / MiT-TFE as drivers of human and mouse DAM epigenetic programs (Lee et al. *Nat. Genet.* 2026; Balak et al. and Tejwani et al. *Immunity* 2026), glial over-representation of disease-specific regulation (Han et al. *Nat. Commun.* 2026; Liu et al. *Cell* 2025), TOP1-mediated neuronal genomic damage in AD (Zhou et al. *Cell* 2026), cell-type-specific 3D genome change (Zhang et al. *Science* 2026). Our MITF result is therefore an independent confirmation; the DDR result pairs with Zhou et al. as "damage without a repair-program response".

### 48. Audit of published gene-set claims: well-powered DEGs replicate, module- and pathway-level claims mostly do not

`scripts/published_claims_pilot.py` (results `results/published_claims/pilot_*.csv`) and `scripts/published_claims_power.py` (`power_curve.csv`); Fig. S9. 74 directional claims, each tested in its reported cell type: Mathys 2019 (*Nature*, 48 donors) DEG sets (pathology or early pathology vs none, up / down; 21); Mathys 2024 (*Nature*, 427 donors, 6 regions) pathology-biased DEGs (Supp. Table 10; up / down, NFT- and plaque-biased; 24) and gene-expression modules whose cells are enriched in AD or control individuals (Supp. Tables 6–7, covariate nrad, p < 10⁻³; 24); the published modules of result 26 (5). Also the 50 MSigDB Hallmark sets in 6 cell types. Inputs in `data/raw/published_claims/`. Each tested in SEA-AD (CPS, 73 donors) and PsychAD (AD vs control, 376–437 donors): self-contained permutation test; competitive tests against 500 random sets matched on expression decile, or expression decile × gene-length quintile. A claim holds if r has the claimed sign and p < 0.05.

| Claims holding against expression × length-matched genes in both cohorts | |
|---|---|
| all 74 | 38 (51%) |
| Mathys 2024 pathology-biased DEGs (427 donors) | **21 / 24 (88%)** |
| Mathys 2019 DEGs (48 donors) | 9 / 21 (43%) |
| Mathys 2024 AD-associated modules | **6 / 24 (25%)** |
| DNA-damage / cohesin modules | 2 / 5 (the two cohesin tests) |
| by cell type: oligodendrocytes / astrocytes / excitatory / inhibitory / OPC / microglia | 8/9, 7/9, 11/22, 6/12, 4/9, **2/13** |

| Hallmark sets | SEA-AD | PsychAD |
|---|---|---|
| neurons, self-contained p < 0.05 | 3% | **68%** (68 of 100) |
| … also specific (expression × length-matched, same sign) | 1 of 3 | **5 of 68** |
| glia, self-contained / competitive | 10% / 14% | 37% / 19% |

* **Gene-level DEGs from a well-powered study replicate as specific changes** (88%); those of a 48-donor study about half. **Module-level associations mostly do not** (25%), nor do the p53 / DNA-damage and aged-microglia modules. Microglial claims replicate worst (2 of 13); oligodendrocyte and astrocyte claims best.
* **Self-contained pathway tests are inflated, increasingly so with cohort size.** In PsychAD neurons, 68 of 100 Hallmark tests are significant by permutation, but only 5 change beyond matched genes in the same direction (93% are cell-type-wide drift). Subsampling PsychAD neurons (10 draws per size), self-contained significance rises from 0.20 (50 donors) to 0.48 (402) in excitatory and 0.90 (410) in inhibitory neurons, while specific change stays at 0.06–0.19.
* Caveats: exposures differ from the originals (pathology groups vs CPS or diagnosis; module "AD association" in Mathys 2024 is enrichment of AD individuals' cells, not an expression change), so failure to replicate is not proof that a claim was wrong. Supporting audit for the paper, not a stand-alone study.

### 49. Which factors control the RASGEF1C risk enhancers? No clean answer; e1 tracks MAFB / IRF8, e2 tracks MITF

`scripts/rasgef1c_motifs.py` (results `results/rasgef1c/G_*.csv`). Prompted by the MiT/TFE master-regulator papers (Balak et al., Tejwani et al., *Immunity* 2026): e1 / e2 close in DAM, so are they elements of homeostatic factors that lose activity, rather than MiT/TFE targets?

* **Motif content (392 motifs, p < 1e-4, full length).** Both carry a MEF2 site (the most strongly closing family, DAM t −4.4), but MEF2 sites are common (34% of tested peaks; 38% of DAM-closed peaks, OR 1.2, n.s.), so this is weakly informative. e2 also carries a MiT/TFE E-box (TFEB / TFEC, CACGTG) and e1 a USF E-box. Genome-wide no motif family is significantly enriched in DAM-closed peaks (minimum q 0.31): closure is not attributable to one family by motif content. The only credible-set SNP inside a motif instance remains rs113706587 (TFAP2E site).
* **Same-nucleus coupling (hippocampal microglia, state-adjusted, vs DAM-change-matched peaks).** e1 accessibility tracks the RNA of the microglial identity factors **MAFB** (z 2.9, q 0.07) and **IRF8** (z 2.7, q 0.08); e2 tracks **MITF** (z 3.2, q 0.06). MEF2C shows no coupling with either (z −0.2, 0.6).
* **Reading.** Suggestive only (q 0.06–0.08, 20 factors × 2 elements). It does not support a simple "MEF2 element" model. e1 behaves like a microglial identity element (MAFB / IRF8); e2 carries a MiT/TFE site and, within a given state, is more open where MITF is higher, even though it closes overall in DAM. A direct test needs factor binding (CUT&Tag for MITF, MAFB, IRF8 in human microglia) or perturbation. Not used as a main claim.

### Exploratory leads (not confirmed)

* **L5 ET neurons, HR program**: r = +0.50 (q = 0.01 among the pre-specified tests; q = 0.12 in the full screen, p_set = 0.005). It survives adjustment for glial marker load but replicates in 0 of 6 other regions and rests on a median of 33 nuclei per donor (result 13).
* **Checkpoint / TOPBP1 in plaque-proximal microglia**: rises A < PP < P in GeoMx (result 14) but does not pass the random gene-set FDR, and has no chromatin support in 5xFAD plaque-associated microglia (result 17). A single-cell check needs a 5K-panel dataset.
* Sst Chodl "DAM" (r = 0.88) rests on 13 donors and is almost certainly microglial contamination. It is not interpreted.

### Interpretation

The absence of a bulk neuronal DDR shift does not mean neurons are spared DNA damage. Two explanations fit the data:

1. **Survivor bias.** SEA-AD shows that vulnerable neurons (e.g. Sst interneurons, L2/3 IT) are lost along CPS. Neurons with the heaviest damage may already be gone, so the survivors look unchanged.
2. **Heterogeneity.** DSB-bearing neurons are a minority (Welch & Tsai 2022). Their signature is diluted in class-level pseudobulks. Testing this needs a cell-level "damaged-neuron" score and mixed models, which is the next step.

Microglial activation, by contrast, is a robust donor-level signal across regions, although only partly specific to the DAM gene set. At single-gene level, microglial PTPRG is the strongest and best-replicated change (result 12). Results 4 and 5 make survivor bias harder to argue at the supertype level. The heterogeneity explanation was then tested at the cell level (result 6) and is not supported either, within the resolution of these data.

## What 12 donors got wrong

The first pass used only the 12 multiome donors. It produced confident-looking but wrong results:

* **Reversed biology**: astrocytic GFAP fell with CPS (r = −0.80) and microglial DAM showed no rise. The raw marker genes showed the same thing, so this was not a pipeline bug. In 84 donors both behave as expected. The few low-CPS donors happened to carry other pathology (LATE, Lewy bodies, age 97).
* **A NaN that looked like p = 1e-4**: donors without ATAC produced NaN scores, `abs(r_perm) >= NaN` is always False, and every such test got the minimum permutation p. Fixed and covered by a regression test (`tests/test_stats.py`).
* **Per-cell chromVAR z-scores of 10⁷**: small promoter peak sets in sparse snATAC give zero background variance. Replaced with pseudobulk enrichment.
* **Outdated CPS**: the ATAC objects store the 2024 CPS. The 2026 release values differ by up to 0.4 for some donors.
* **A shifted table**: the stdlib xlsx converter wrote a header 2 fields shorter than the data rows, so pandas silently moved columns into the index (`Age at Death` held sex). Donor selection used `csv.DictReader` and was unaffected (re-verified identical). Found when 0 of 27 MERFISH donors matched; the converter now pads rows.
* **Censored ages**: MERFISH metadata records 14 of 27 ages as "90+", which silently dropped those donors from covariate-adjusted tests. True ages now come from the donor table.

## Reproduce

**Manuscript only:** `./scripts/reproduce_manuscript.sh` runs every analysis behind Figs. 1–7 and S1–S9 in dependency order (stages `data seaad atac hippo psychad spatial genetics figures drafts`); environment, manual data and outputs are described in [docs/REPRODUCIBILITY.md](docs/REPRODUCIBILITY.md); pinned packages in `requirements-lock.txt`; per-figure source data via `python scripts/export_source_data.py`. The full command list below also covers the exploratory analyses.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ../sc-ddr-multiome -e ".[dev]"
pytest -q                                      # 15 tests

# cohort (all donors, ~4 GB)
./scripts/download_pseudobulk.sh
curl -o data/meta/Global_and_Local_CPS.csv \
  "https://sea-ad-single-cell-profiling.s3.amazonaws.com/Multiregion_2026/model_outputs/continuous_pseudo-progression_score/Global_and_Local_CPS.20260105.csv"
python scripts/run_cohort.py --out results/cohort          # ~2 min
python scripts/run_cognition.py                            # cognition / APOE4
python scripts/check_dementia_specificity.py               # RIN + random gene-set controls
python scripts/check_dam_specificity.py
python scripts/run_vulnerability.py                        # supertype loss vs baseline DDR, ~1 min
python scripts/run_cellstate.py                            # multiome subset, ~5 min

# spatial (MERFISH, 498 MB)
curl -o data/raw/merfish/SEAAD_MTG_MERFISH.2024-12-11.h5ad \
  https://sea-ad-spatial-transcriptomics.s3.amazonaws.com/middle-temporal-gyrus/all_donors-h5ad/SEAAD_MTG_MERFISH.2024-12-11.h5ad
python scripts/run_spatial.py                              # ~1.5 min

# independent cohort (GSE174367 snRNA-seq, ~260 MB)
G=https://ftp.ncbi.nlm.nih.gov/geo/series/GSE174nnn/GSE174367/suppl
for f in GSE174367_snRNA-seq_filtered_feature_bc_matrix.h5 GSE174367_snRNA-seq_cell_meta.csv.gz; do
  curl -o data/raw/morabito/$f $G/$f; done
python scripts/run_replication.py                          # ~20 s
python scripts/run_ccc.py                                  # ligand-receptor, ~1 min
python -c "import decoupler as dc; dc.op.collectri(organism='human').to_csv('data/ref/collectri_human.csv', index=False)"
curl -o data/ref/chipatlas/Oth.ALL.50.TP53.AllCell.bed https://chip-atlas.dbcls.jp/data/hg38/assembled/Oth.ALL.50.TP53.AllCell.bed
python scripts/build_chip_consensus.py data/ref/chipatlas/Oth.ALL.50.TP53.AllCell.bed data/ref/chipatlas/TP53_consensus_ge10.bed 10
python scripts/run_tf.py                                   # TF activity + TP53 sites, ~4 min
python scripts/run_microglia_genes.py                      # PTPRG / S100A4 screen
python scripts/check_ptprg_ambient.py                      # contamination + chromatin checks

# whole-transcriptome spatial (GSE233208 human Visium Seurat object, 1.4 GB; needs R + SeuratObject)
curl -o data/raw/miyoshi/GSE233208_Human_visium_ADDS_seurat_processed.rds.gz \
  https://ftp.ncbi.nlm.nih.gov/geo/series/GSE233nnn/GSE233208/suppl/GSE233208_Human_visium_ADDS_seurat_processed.rds.gz
gunzip -k data/raw/miyoshi/GSE233208_Human_visium_ADDS_seurat_processed.rds.gz
Rscript -e 'install.packages("SeuratObject", repos="https://cloud.r-project.org")'
Rscript scripts/export_seurat_visium.R data/raw/miyoshi/GSE233208_Human_visium_ADDS_seurat_processed.rds data/raw/miyoshi/export
python scripts/build_visium_h5ad.py data/raw/miyoshi/export data/raw/miyoshi/miyoshi_visium.h5ad
python scripts/run_visium.py                               # ~1 min
python scripts/run_visium.py --spots grey_matter --out results/visium_greymatter
python scripts/replicate_ptprg.py                          # needs Morabito + Visium data
curl -o data/ref/gwas/GCST90027158_buildGRCh38.tsv.gz \
  https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/GCST90027001-GCST90028000/GCST90027158/GCST90027158_buildGRCh38.tsv.gz
python scripts/check_gwas_locus.py PTPRG APOE BIN1 TREM2    # ~15 s after the 755 MB download
pip install mofapy2
python scripts/run_mofa.py                                 # MOFA+ with permutation null + bootstrap, ~3 min
python scripts/characterize_f1.py                          # F1 drift, gene-length axis, DDR after F1
python scripts/run_discovery_screen.py                     # pre-specified genome-wide screen (~2 min)
python scripts/run_discovery_screen.py --discovery-p 0.001 --out results/discovery_twostage
python scripts/check_ptprg_resilience.py
python -c "import decoupler as dc; dc.op.hallmark(organism='human').to_csv('data/ref/msigdb_hallmark.csv', index=False)"
python scripts/run_f1_generality.py                        # drift axis across regions + Morabito, ~4 min
curl -o data/raw/psychad/myeloid_frozen_snRNA.h5ad \
  https://datasets.cellxgene.cziscience.com/44e42474-0297-463b-92b0-4b47decf699e.h5ad    # 3.0 GB, open
python scripts/replicate_psychad_microglia.py              # ~25 s
curl -C - -o data/raw/psychad/MSSM_cohort.h5ad \
  https://datasets.cellxgene.cziscience.com/0e853475-e298-4b09-881a-ed0b60d5a8c9.h5ad    # 36.1 GB, open (do not add --retry)
python scripts/run_psychad_neurons.py                      # ~4 min
python scripts/plot_psychad_neurons.py
Rscript scripts/export_miyoshi_pseudobulk.R data/raw/miyoshi/GSE233208_Human_visium_ADDS_seurat_processed.rds data/processed/miyoshi   # needs R Seurat
python scripts/run_miyoshi_layers.py                       # layer pseudobulk, ~5 s

# all-cell-type screen with random gene-set null (uses the pseudobulk objects above)
python scripts/run_celltype_screen.py                      # ~6 min
python scripts/check_l5et.py

# plaque-proximal microglia (GSE306381 GeoMx WTA, ~17 MB)
G=https://ftp.ncbi.nlm.nih.gov/geo/series/GSE306nnn/GSE306381
mkdir -p data/raw/geomx_gse306381/raw && cd data/raw/geomx_gse306381 && \
  curl -O $G/suppl/GSE306381_RAW.tar -O $G/suppl/GSE306381_Hs_R_NGS_WTA_v1.0.pkc.gz -O $G/matrix/GSE306381_series_matrix.txt.gz && \
  tar xf GSE306381_RAW.tar -C raw && cd -
python scripts/build_geomx.py data/raw/geomx_gse306381 data/processed/geomx
python scripts/run_geomx_zones.py                          # ~15 s

# same-section Abeta / pTau Visium (Kwon 2023, 482 MB; needs R + SpatialExperiment)
curl -L -o data/raw/visium_kwon/Visium_SPG_AD_spe_wholegenome.Rdata \
  "https://www.dropbox.com/s/ng036m63grykdm6/Visium_SPG_AD_spe_wholegenome.Rdata?dl=1"
Rscript scripts/export_kwon.R data/raw/visium_kwon/Visium_SPG_AD_spe_wholegenome.Rdata data/processed/kwon
python scripts/run_kwon_pathology.py                       # ~15 s

# layer-local pathology vs repair RNA / promoter chromatin (86 ATAC donors streamed, ~30 GB transfer, 1 GB kept)
mkdir -p data/meta/qnp && curl -L -o data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx \
  https://cdn.prod.website-files.com/689cfbd308fa7373b604d290/6a4579d1d67150b0e69ad044_sea-ad-quantitative-neuropathology-063026.xlsx
./scripts/stream_atac_donors.sh 3                          # ~1.5 h
python scripts/run_laminar_mismatch.py                     # ~1 min
python scripts/make_spatial_figures.py                     # docs/screen.png, geomx_zones.png, laminar_mismatch.png

# mouse cross-check (GSE296025 narrowPeaks, 11 MB; GENCODE vM25 GTF, 20 MB)
mkdir -p data/raw/gse296025 && curl -o data/raw/gse296025/RAW.tar \
  https://ftp.ncbi.nlm.nih.gov/geo/series/GSE296nnn/GSE296025/suppl/GSE296025_RAW.tar && tar xf data/raw/gse296025/RAW.tar -C data/raw/gse296025
curl -o data/ref/gencode.vM25.basic.annotation.gtf.gz \
  https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_mouse/release_M25/gencode.vM25.basic.annotation.gtf.gz
python scripts/run_mouse_pam_atac.py                       # promoters
python scripts/run_mouse_pam_atac.py --window 50000 --out results/mouse_pam_50kb

# single-cell-scale plaque proximity (GSE263789 Stereo-seq; 4 gem files ~4.5 GB + plaque masks; barcodeToPos.h5 not needed)
for P in GSM8199179_mSS_18M_AD_E3:180 GSM8199180_mSS_18M_AD_E4:220 GSM8199182_mss_3M_WT_AD_E1:170 GSM8199183_mSS_3M_WT_AD_E2:210; do
  s=${P%%:*}; python scripts/build_stereoseq_bins.py data/raw/gse263789/${s}_bin1_max.gem.txt.gz data/processed/stereoseq/$s
  python scripts/register_plaque_mask.py data/raw/gse263789 $s ${P##*:}      # ~2 min each
done
python scripts/audit_stereoseq.py data/raw/gse263789 GSM8199179_mSS_18M_AD_E3   # depth / coverage audit
python scripts/run_stereoseq_plaque_ddr.py                  # ~20 s

# DAM-specific chromatin peaks (86 ATAC donors streamed again, split by microglial supertype; hg38 FASTA, chain, JASPAR)
./scripts/stream_atac_donors.sh 3 data/processed/atac_pb_micro Microglia-PVM   # ~2 h
curl -o data/ref/hg38.fa.gz https://hgdownload.soe.ucsc.edu/goldenPath/hg38/bigZips/hg38.fa.gz
curl -o data/ref/hg38ToMm10.over.chain.gz https://hgdownload.soe.ucsc.edu/goldenPath/hg38/liftOver/hg38ToMm10.over.chain.gz
curl -o data/ref/motifs/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt \
  https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt
python scripts/run_dam_peaks.py                             # ~10 s
python scripts/validate_dam_peaks.py                        # RNA, plaques, mouse; ~2 min
python scripts/motif_dam_peaks.py                           # ~20 s
python scripts/make_dam_figure.py
python scripts/gwas_dam_peaks.py                            # Bellenguez 2022 GCST90027158 (755 MB), ~5 min
python scripts/run_dam_regulatory.py                        # mouse-anchored peaks + gene regulatory domains, ~1 min
python scripts/robust_homeostatic_shift.py                  # robustness of the homeostatic shift, ~5 s
python scripts/run_published_sets.py --match-length --out results/published_sets_lenmatched   # Mathys / Fancy sets, ~1 min
curl -o data/ref/chipatlas/Oth.Neu.50.RAD21.AllCell.bed https://chip-atlas.dbcls.jp/data/hg38/assembled/Oth.Neu.50.RAD21.AllCell.bed
python scripts/build_chip_consensus.py data/ref/chipatlas/Oth.Neu.50.RAD21.AllCell.bed data/ref/chipatlas/RAD21_neural_ge2.bed 2
python scripts/run_cohesin_sites.py                         # cohesin-site accessibility, ~1.5 min
python scripts/split_replication.py --n-splits 100          # donor-split replication of the main claims, ~1 min
python scripts/replicate_cohesin_psychad.py                 # needs data/raw/psychad/MSSM_cohort.h5ad (36 GB, CELLxGENE); ~40 min
# independent chromatin cohort: hippocampus multiome (GSE288063 + GSE278576 normals; ~54 GB fragments streamed, ~3 GB RNA kept)
curl -o data/raw/hippo_multiome/GSE288063_metadata_humanAD.tsv.gz \
  https://ftp.ncbi.nlm.nih.gov/geo/series/GSE288nnn/GSE288063/suppl/GSE288063_metadata_humanAD.tsv.gz
caffeinate -i ./scripts/stream_hippo_multiome.sh                 # ~6 h
python scripts/run_hippo_replication.py                         # ~20 s
python scripts/make_dam_figure.py                           # also docs/dam_regulatory.png
# audit of the DAM differential tests (result 32), homeostatic-shift checks (33), candidate links (34)
python scripts/audit_dam_de.py                              # ~1 min
python scripts/audit_dam_domains_thinning.py                # ~2 min
python scripts/make_supp_umap.py                            # hippocampus microglia UMAP + per-nucleus score cache (FigS1)
python scripts/check_hippo_batch.py
python scripts/hippo_continuous_state.py                    # also hippocampus-defined DAM peaks
python scripts/homeostatic_shift_selection.py               # ~1.5 min
python scripts/make_supp_fig5.py                            # FigS2
curl -o data/ref/eqtl/tabix_ftp_paths.tsv \
  https://raw.githubusercontent.com/eQTL-Catalogue/eQTL-Catalogue-resources/master/tabix/tabix_ftp_paths.tsv
# SuSiE credible sets (QTD000559, QTD000609, QTD000434) into data/ref/eqtl/susie/ and ENCODE-rE2G
# ENCFF789IHU (CD14+ monocyte), ENCFF463AGD (inflammatory macrophage) into data/ref/e2g/
python scripts/fetch_eqtl_regions.py                        # remote tabix, ~1.5 h
python scripts/candidate_links.py                           # ~40 s
python scripts/dam_tf_grn.py                                # TF motif activity + network (result 35), ~15 min first run
python scripts/susie_finemap.py                             # SuSiE-RSS with 1000 Genomes EUR LD (result 36), ~3 min
python scripts/microglia_states.py && python scripts/make_supp_states.py    # result 37, FigS3
caffeinate -i ./scripts/stream_hippo_cuts.sh                # base-level microglia cut sites, ~6 h
python scripts/footprint_dam_tfs.py                         # Tn5-corrected footprints (result 38)
python scripts/ddr_equivalence.py                           # equivalence + leave-one-gene-out (result 39), ~25 min
python scripts/make_supp_equivalence.py                     # FigS4
python scripts/psychad_extra_pb.py                          # PsychAD IN / Astro / Micro / EN_L2_3_IT pseudobulks, ~25 min
python scripts/ddr_endpoints.py && python scripts/make_supp_endpoints.py    # result 40, FigS5
python scripts/homeostatic_mixture.py                       # result 41, ~15 s
./scripts/stream_atac_micro_cells.sh 3                      # per-nucleus microglia of the 86 ATAC objects, ~2 h
python scripts/seaad_nucleus_shift.py                       # result 42
python scripts/global_vs_specific.py                        # result 43, Fig. 1d-f, ~15 min
python scripts/fetch_rasgef1c_qtls.py QTD000559 QTD000560 QTD000561 QTD000562 QTD000563 QTD000171 QTD000176 QTD000051 QTD000075 QTD000001 QTD000384
python scripts/rasgef1c_chain.py                            # result 44, FigS6
python scripts/tf_ranking.py                                # result 45, FigS7
python scripts/psychad_subclass_pb.py && python scripts/psychad_global_vs_specific.py   # result 46, FigS8
python scripts/haglund_rasgef1c.py                          # result 47 (published supplementary tables in data/raw/haglund2025)
python scripts/published_claims_pilot.py && python scripts/published_claims_power.py    # result 48, FigS9
python scripts/make_paper_figures.py                        # docs/figures/Fig1-7
python scripts/make_supp_chain_tf.py                        # FigS6-S9
python scripts/export_source_data.py                        # docs/source_data/
python scripts/renumber_refs.py && python scripts/build_draft_html.py en && python scripts/build_draft_html.py   # drafts

# multiome subset (12 donors, ~10 GB)
python scripts/select_donors.py 3
./scripts/download_donors.sh
curl -o data/ref/gencode.v32.basic.annotation.gtf.gz \
  https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_32/gencode.v32.basic.annotation.gtf.gz
python scripts/run_analysis.py --out results/v2            # ~2.5 min, ~11 GB RAM
python scripts/concordance_summary.py results/v2
```

`data/meta/donor_table.csv` is SEA-AD Supplementary Table 1, converted with `scripts/read_xlsx.py` (a standard-library reader; openpyxl is not needed). `scripts/diagnose_glia.py` reproduces the 12-donor marker-gene diagnostics.

## Layout

```
src/ad_ddr/
  cohort.py      released pseudobulk -> (region, cell group, donor) counts -> program scores
  vulnerability.py  supertype composition along CPS; baseline program scores per supertype
  cellstate.py   within-nucleus program coherence, donor-centred z, top-fraction labels
  neighborhood.py  depth-matched neighbourhood composition with within-section permutation null
  io.py          per-donor multiome loading, RNA/ATAC pairing, 2026 CPS
  scoring.py     fixed-control RNA scorer, within-donor depth adjustment, streaming ATAC pseudobulk
  stats.py       partial-r permutation tests, RNA-ATAC concordance
  signatures.py  DDR sets (from ddrmulti) + DAM / cGAS-STING / reactive-astrocyte sets
  plotting.py
scripts/         donor selection, downloads, cohort + multiome analyses, diagnostics
tests/           stats, scoring and aggregation tests against known ground truth
docs/            figures and result tables shown here
```

## Limitations

* Expression and accessibility programs are **proxies** for DNA damage. Direct evidence would need γH2AX / 53BP1 imaging or break mapping.
* Cross-sectional post-mortem data cannot separate "damage response fades" from "damaged cells are lost".
* Class-level pseudobulks can hide minority damaged states. Supertype and cell-level analyses are the next step.
* The multiome concordance uses only 10 donors per cell group.

## Next

* Cell-level damaged-neuron score with donor random effects, to test the heterogeneity explanation (a minority damaged state diluted in pseudobulks).
* Use a random gene-set / random-regulon / random-pair null by default for every set-level claim. It changed conclusions in results 2, 4, 9 and 10. Better still, model the dominant neuronal factor (F1, result 18), which removes most of the miscalibration at its source.
* Spatial DDR with plaque proximity at single-cell resolution: the only public candidate found is ROSMAP Xenium Prime 5K (Synapse syn74004858, DUA; 2 AD, 2 controls). Widely used Xenium brain panels contain none of the 22 core DDR genes, and the per-spot Miyoshi amyloid values are not public (result 15).
* Follow the 100 µm × CPS lead with a pre-registered larger-radius analysis in an independent spatial cohort.
