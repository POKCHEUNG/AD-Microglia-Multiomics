# Published gene sets used for the head-to-head test (result 26; kept in data/meta so they are versioned)

| File | Source | Definition |
|---|---|---|
| mathys2023_cohesin_CORUM165_SA1.txt, mathys2023_cohesin_CORUM166_SA2.txt | Mathys et al. 2023 *Cell* (PMID 37774677); code `mathyslab7/ROSMAP_snRNAseq_PFC`, `Code/Cohesin_complex` | CORUM complexes 165 / 166 (cohesin-SA1 / -SA2), members from g:Profiler `hsapiens.CORUM.name.gmt`. The paper's DNA-damage-response factor list is in non-open supplementary tables and was not retrieved |
| mathys2024_Mic_Immune_M22_core.txt / _all.txt | Mathys et al. 2024 *Nature* (PMID 39048816), Supplementary Table 6, sheet `Mic_Immune`, module 22 | "p53 and DNA damage response" module in immune cells (24 core / 58 all genes) |
| mathys2024_EC_nrad_up_shared3plus_celltypes.txt | Mathys et al. 2024, Supplementary Table 9 (`dereg/aggregated_fullset`) | Reconstructed: path = nrad, region = EC, significant up (col_nm == 2) in >= 3 of Ast, Exc, Inh, Mic, Oli, OPC (39 genes); the paper reports DNA-damage enrichment among shared up genes |
| fancy2024_microglia_Module8.txt | Fancy et al. 2024 (PMID 38695952), MOESM15 sheet S13 | Microglia trajectory module 8 (43 genes, includes ATM, "cellular senescence") |

Retrieved 2026-10-15 from the papers' supplementary files and code repositories.
