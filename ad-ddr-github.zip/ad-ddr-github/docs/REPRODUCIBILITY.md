# Reproducing the manuscript

Everything in the manuscript (Figs. 1–7, Supplementary Figs. 1–9, all numbers in the text) is produced by
the scripts in `scripts/` from public data. This file describes the environment, the data, the order of
the analyses and the outputs. The full list of commands, including exploratory analyses not used in the
manuscript, is in the README section "Reproduce".

## Environment

| Component | Version | Notes |
|---|---|---|
| Python | 3.13.3 | all packages pinned in `requirements-lock.txt` (pip freeze of the analysis environment) |
| this repository | `pip install -e .` | package `ad_ddr` (`src/`) |
| `sc-ddr-multiome` | `pip install -e ../sc-ddr-multiome` | companion package (`ddrmulti`: DDR gene sets, genome utilities, BH) |
| R | 4.5.1 | `susieR` 0.14.2 and `jsonlite` 2.0.0 for SuSiE-RSS (`scripts/susie_finemap.py`) |
| shell tools | `curl`, `tar`, `bash` | streaming scripts download one file at a time and delete it after reduction |

```bash
python3.13 -m venv .venv
.venv/bin/pip install -r requirements-lock.txt
.venv/bin/pip install -e ../sc-ddr-multiome -e .
Rscript -e 'install.packages(c("susieR", "jsonlite"), repos = "https://cloud.r-project.org")'
.venv/bin/python -m pytest -q
```

Hardware used: Apple M2, 48 GB RAM, ~200 GB free disk. The PsychAD MSSM object (36 GB) is read in backed
mode; peak memory of the one-pass subclass extraction is ~6 GB.

## One command

```bash
./scripts/reproduce_manuscript.sh                    # all stages, in order (~1.5–2 days, mostly downloads)
./scripts/reproduce_manuscript.sh figures drafts     # only re-draw figures and rebuild drafts from results/
```

| Stage | What | Main outputs | Figures |
|---|---|---|---|
| `data` | SEA-AD pseudobulks, CPS, neuropathology; genome, GTFs, chain, JASPAR, GWAS, eQTL index, ChIP-Atlas, 5xFAD ATAC, Hallmark, CollecTRI | `data/` | — |
| `seaad` | DDR screen across cell types and regions; published sets | `results/screen/`, `results/published_sets_lenmatched/` | 2a, 3a |
| `atac` | three streaming passes over the 86 SEA-AD ATAC objects; laminar mismatch; DAM peaks and domains; homeostatic shift (pseudobulk and per nucleus); split replication; audit | `results/laminar/`, `dam_peaks/`, `dam_regulatory/`, `homeostatic_shift/`, `split_replication/` | 2e–f, 3c, 4, 5, Supp. Note 1 |
| `hippo` | hippocampus multiome streaming; DAM replication; UMAP; continuous state and selection checks; microglial states; TF motif activity and network; TF ranking | `results/hippo_replication/`, `microglia_states/`, `dam_tf/`, `tf_ranking/` | 4c,e, 5d, 7, S1, S2, S3, S7 |
| `psychad` | PsychAD neurons, cohesin, extra and subclass pseudobulks; equivalence; endpoints; shared vs specific (both cohorts); audit of published claims | `results/psychad_neurons/`, `cohesin_psychad/`, `ddr_equivalence/`, `ddr_endpoints/`, `global_specific/`, `published_claims/` | 1d–f, 2b, 3b–c, S4, S5, S8, S9 |
| `spatial` | hippocampal GeoMx zones; Stereo-seq plaque registration and bins | `results/spatial_geomx/`, `stereoseq_plaque/` | 2c, 2d |
| `genetics` | GWAS enrichment; eQTL regions; candidate links; SuSiE; RASGEF1C QTLs and chain; Haglund et al. tables | `results/candidate_links/`, `rasgef1c/` | 6, S6 |
| `figures` | all figure scripts; source data | `docs/figures/`, `docs/source_data/` | all |
| `drafts` | reference renumbering; English and Chinese drafts (Markdown + self-contained HTML) | `docs/manuscript_en.*`, `docs/manuscript_draft_zh.*` | — |

Stages must run in this order the first time (later stages read earlier results). Each analysis script can
also be run on its own; its docstring states inputs, outputs and the README result it supports.

## Data that cannot be fetched by the script

| Data | Where to put it | Source |
|---|---|---|
| eQTL Catalogue SuSiE credible sets QTD000559, QTD000609, QTD000434 | `data/ref/eqtl/susie/` | eQTL Catalogue FTP (`ftp_cs_path` in `tabix_ftp_paths.tsv`) |
| ENCODE-rE2G ENCFF789IHU, ENCFF463AGD | `data/ref/e2g/` | ENCODE portal |
| Stereo-seq gem files and plaque masks (GSE263789) | `data/raw/gse263789/` | GEO supplementary files |
| Mathys et al. 2019 Supp. Table 2; Mathys et al. 2024 Supp. Tables 6, 7, 10 | `data/raw/published_claims/` (file names in `scripts/published_claims_pilot.py`) | article pages (Nature) |
| Haglund et al. 2025 Supp. Tables 1, 2, 4, 6, 8, 9 | `data/raw/haglund2025/` (S4–S12.xlsx; see `scripts/haglund_rasgef1c.py`) | article page (Nat. Genet.) |
| Published gene sets (cohesin, M22, Fancy module 8) | `data/meta/published_sets/` (versioned in the repository) | see that folder's README |

Remote services queried during the run: EBI eQTL Catalogue FTP (tabix), 1000 Genomes FTP (tabix), UCSC
REST API (phyloP). Zenodo was not reachable from the analysis machine; analyses needing full summary
statistics hosted there (Bryois et al., Haglund et al.) use published supplementary tables instead.

## Randomness

Every script fixes its random seed (`numpy.random.default_rng(0)` unless stated); permutation, thinning and
bootstrap results are therefore reproducible exactly with the pinned environment and the same code version
(changing the set of tests in a script changes its random stream). Numbers quoted in the
drafts match the current `results/`.

## Outputs for submission

* `docs/figures/` — Figs. 1–7 and S1–S9 as PDF (vector) and PNG (300 dpi).
* `docs/source_data/` — one folder per figure with the tables each figure script reads, indexed in
  `docs/source_data/INDEX.md` (regenerate with `python scripts/export_source_data.py`; not versioned).
* `docs/manuscript_en/` — submission draft (front matter, main text, methods, legends, references);
  `docs/manuscript_en.html` embeds every figure above its legend.
