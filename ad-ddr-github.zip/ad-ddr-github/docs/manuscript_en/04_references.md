---

## References

*All entries were compiled from memory and must be checked against the primary source (authors, title, journal, volume, pages, year) before submission. Entries marked [verify] are the least certain.*

1. Gabitto, M. I. et al. Integrated multimodal cell atlas of Alzheimer's disease. *Nat. Neurosci.* **27**, 2366–2383 (2024).
2. Mathys, H. et al. Single-cell atlas reveals correlates of high cognitive function, dementia, and resilience to Alzheimer's disease pathology. *Cell* **186**, 4365–4385 (2023).
3. Mathys, H. et al. Single-cell multiregion dissection of Alzheimer's disease. *Nature* **632**, 858–868 (2024).
4. Sun, N. et al. Human microglial state dynamics in Alzheimer's disease progression. *Cell* **186**, 4386–4403 (2023).
5. Morabito, S. et al. Single-nucleus chromatin accessibility and transcriptomic characterization of Alzheimer's disease. *Nat. Genet.* **53**, 1143–1155 (2021).
6. Dileep, V. et al. Neuronal DNA double-strand breaks lead to genome structural variations and 3D genome disruption in neurodegeneration. *Cell* **186**, 4404–4421 (2023).
7. Welch, G. & Tsai, L.-H. Mechanisms of DNA damage-mediated neurotoxicity in neurodegenerative disease. *EMBO Rep.* **23**, e54217 (2022). [verify]
8. Keren-Shaul, H. et al. A unique microglia type associated with restricting development of Alzheimer's disease. *Cell* **169**, 1276–1290 (2017).
9. Krasemann, S. et al. The TREM2–APOE pathway drives the transcriptional phenotype of dysfunctional microglia in neurodegenerative diseases. *Immunity* **47**, 566–581 (2017).
10. Bellenguez, C. et al. New insights into the genetic etiology of Alzheimer's disease and related dementias. *Nat. Genet.* **54**, 412–436 (2022).
11. Nott, A. et al. Brain cell type-specific enhancer–promoter interactome maps and disease-risk association. *Science* **366**, 1134–1139 (2019).
12. Mallach, A. et al. Stereo-seq of App^NL-G-F^ mice with plaque segmentation (GSE263789). *Cell Rep.* (2024). [verify]
13. Ardura-Fabregat, A. et al. Source of GSE296025 (5xFAD CD11c^+^/CD11c^−^ microglia ATAC-seq). *Nat. Neurosci.* (2025). [verify]
14. PsychAD Consortium. PsychAD: single-nucleus transcriptomics of neurodegenerative and neuropsychiatric disease (MSSM cohort; CZ CELLxGENE). [verify citation]
15. Fancy, N. N. et al. Aged-microglia trajectory modules (supplementary gene lists). (2024). [verify]
16. Zhang, Y. et al. Single-cell multiomics connects 3D genome and transcriptome alterations in Alzheimer's disease. *Science* (2026). [verify]
17. Mathys, H. et al. Single-cell transcriptomic analysis of Alzheimer's disease. *Nature* **570**, 332–337 (2019).
18. Teo, A. Y. Y. et al. Benchmarking differential accessibility methods for single-cell ATAC-seq. *Nat. Commun.* (2024). [verify]
19. Müller-Dott, S. et al. Expanding the coverage of regulons from high-confidence prior knowledge for accurate estimation of transcription factor activities. *Nucleic Acids Res.* **51**, 10934–10949 (2023). [verify]
20. Kolde, R., Laur, S., Adler, P. & Vilo, J. Robust rank aggregation for gene list integration and meta-analysis. *Bioinformatics* **28**, 573–580 (2012).
21. Wakefield, J. Bayes factors for genome-wide association studies: comparison with P-values. *Genet. Epidemiol.* **33**, 79–86 (2009).
22. Zou, Y., Carbonetto, P., Wang, G. & Stephens, M. Fine-mapping from summary data with the "Sum of Single Effects" model. *PLoS Genet.* **18**, e1010299 (2022).
23. The 1000 Genomes Project Consortium. A global reference for human genetic variation. *Nature* **526**, 68–74 (2015).
24. Report of RASGEF1C (and PTPRG) as microglial state markers. [verify: identify]
25. Haglund, A. et al. Cell state-dependent allelic effects and contextual Mendelian randomization analysis for human brain phenotypes. *Nat. Genet.* **57**, 358–368 (2025). [verify pages]
26. Young, A. M. H. et al. A map of transcriptional heterogeneity and regulatory variation in human microglia. *Nat. Genet.* **53**, 861–868 (2021).
27. Giambartolomei, C. et al. Bayesian test for colocalisation between pairs of genetic association studies using summary statistics. *PLoS Genet.* **10**, e1004383 (2014).
28. Fromer, M. et al. Gene expression elucidates functional impact of polygenic risk for schizophrenia. *Nat. Neurosci.* **19**, 1442–1453 (2016).
29. Ng, B. et al. An xQTL map integrates the genetic architecture of the human brain's transcriptome and epigenome. *Nat. Neurosci.* **20**, 1418–1426 (2017).
30. The GTEx Consortium. The GTEx Consortium atlas of genetic regulatory effects across human tissues. *Science* **369**, 1318–1330 (2020).
31. Jaffe, A. E. et al. Developmental and genetic regulation of the human cortex transcriptome illuminate schizophrenia pathogenesis. *Nat. Neurosci.* **21**, 1117–1125 (2018). [verify]
32. Pollard, K. S., Hubisz, M. J., Rosenbloom, K. R. & Siepel, A. Detection of nonneutral substitution rates on mammalian phylogenies. *Genome Res.* **20**, 110–121 (2010).
33. Zhou, Z. et al. Recurrent patterns of TOP1-mediated neuronal genomic damage shared by major neurodegenerative disorders. *Cell* (2026). [verify]
34. Han, X. et al. Single-nucleus epigenomic dysregulation unmasks genetic risk-associated neurodegenerative glia states. *Nat. Commun.* (2026). [verify]
35. Liu, Z. et al. Single-cell multiregion epigenomic rewiring in Alzheimer's disease progression and cognitive resilience. *Cell* (2025). [verify]
36. Lee, D. et al. Single-cell atlas of transcriptomic vulnerability across brain disorders. *Nature* (2026). [verify]
37. Deczkowska, A. et al. Mef2C restrains microglial inflammatory response and is lost in brain ageing. *Nat. Commun.* **8**, 717 (2017).
38. Lee, D. et al. Plasticity of human microglia and brain perivascular macrophages in aging and Alzheimer's disease. *Nat. Genet.* (2026). [verify]
39. Balak, C. D. et al. Lysosomal dysfunction drives a transcriptional and epigenetic signature found in disease-associated microglia in neurodegenerative diseases. *Immunity* (2026). [verify]
40. Tejwani, L. et al. Progranulin deficiency-induced lysosomal dysfunction drives maladaptive myeloid cell states through the MITF/TFE transcription factors. *Immunity* (2026). [verify]
41. Primary report of BHLHE40/41 as repressors of the microglial lysosomal / DAM program. [verify: identify]
42. Castellano, T. et al. APOE, ABCA7, and RASGEF1C are associated with earlier onset of amyloid deposition from more than 4000 harmonized positron emission tomography images. *Alzheimers Dement.* (2025). [verify]
43. Rauluseviciute, I. et al. JASPAR 2024: 20th anniversary of the open-access database of transcription factor binding profiles. *Nucleic Acids Res.* **52**, D174–D182 (2024). [verify]
44. Zou, Z., Ohta, T. & Oki, S. ChIP-Atlas 3.0: a data-mining suite to explore chromosome architecture together with large-scale regulome data. *Nucleic Acids Res.* **52**, W45–W53 (2024). [verify]
45. Gschwind, A. R. et al. An encyclopedia of enhancer–gene regulatory interactions in the human genome. *bioRxiv* (2023). [verify]
46. Kerimov, N. et al. A compendium of uniformly processed human gene expression and splicing quantitative trait loci. *Nat. Genet.* **53**, 1290–1299 (2021).
47. Alasoo, K. et al. Shared genetic effects on chromatin and gene expression indicate a role for enhancer priming in immune response. *Nat. Genet.* **50**, 424–431 (2018).
48. Nédélec, Y. et al. Genetic ancestry and natural selection drive population differences in immune responses to pathogens. *Cell* **167**, 657–669 (2016).
49. Stuart, T., Srivastava, A., Madad, S., Lareau, C. A. & Satija, R. Single-cell chromatin state analysis with Signac. *Nat. Methods* **18**, 1333–1341 (2021).
50. Yang, J. et al. Conditional and joint multiple-SNP analysis of GWAS summary statistics identifies additional variants influencing complex traits. *Nat. Genet.* **44**, 369–375 (2012).
51. Grant, C. E., Bailey, T. L. & Noble, W. S. FIMO: scanning for occurrences of a given motif. *Bioinformatics* **27**, 1017–1018 (2011).
52. Schep, A. N., Wu, B., Buenrostro, J. D. & Greenleaf, W. J. chromVAR: inferring transcription-factor-associated accessibility from single-cell epigenomic data. *Nat. Methods* **14**, 975–978 (2017).
53. Benjamini, Y. & Hochberg, Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. *J. R. Stat. Soc. B* **57**, 289–300 (1995).
54. Schuirmann, D. J. A comparison of the two one-sided tests procedure and the power approach for assessing the equivalence of average bioavailability. *J. Pharmacokinet. Biopharm.* **15**, 657–680 (1987).
55. DerSimonian, R. & Laird, N. Meta-analysis in clinical trials. *Control. Clin. Trials* **7**, 177–188 (1986).

---

## Acknowledgements

[to be added; include the SEA-AD, PsychAD, GEO data contributors and eQTL Catalogue]

## Author contributions

[to be added]

## Competing interests

[to be added]
