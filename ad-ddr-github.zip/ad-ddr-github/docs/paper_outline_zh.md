# 论文提纲（草案）

> 依据：README 第 1–28 节；新颖性评估见对话记录（文献检索 2026-10-15）。中括号内为对应 README 节号。

## 标题（候选）

1. **Amyloid-associated chromatin remodelling of human microglia extends to the homeostatic state, while neuronal DNA-repair programs stay flat**
2. Microglial, not DNA-repair, chromatin tracks amyloid in the human Alzheimer's cortex
3. （如果以 cohesin 为主线）Cohesin up, cohesin sites down: a genome-architecture mismatch in Alzheimer's oligodendrocytes

**推荐**：用标题 1 作主线，cohesin 作为第二个正面发现放在后半部分。原因：小胶质细胞部分的证据链最完整（发现、RNA、病理、拆分复现、跨物种一致），cohesin 部分还是线索。

## 摘要结构（约 250 词）

1. **背景**：AD 病理邻域中有哪些分子重塑？DNA 损伤应答（DDR）常被用来读出神经元损伤，但已有报道互相矛盾。
2. **方法**：公开数据的多尺度整合，包括 SEA-AD 的 84–86 个 donor 的 RNA 和 ATAC、分层定量病理、人 GeoMx、小鼠 Stereo-seq、5xFAD ATAC；所有结论都与随机基因集比较、设阳性对照、报告检测力。
3. **结果 1**：DDR 程序在细胞类型、脑区、空间尺度上都没有特异改变；Mathys 2023 报道的 cohesin 上调得到复现。
4. **结果 2**：DAM 小胶质细胞在整个基因调控区的尺度上发生染色质重塑；稳态小胶质细胞随淀粉样负荷（尤其是致密核心斑块）沿 DAM 染色质轴偏移。
5. **结果 3**：DAM 基因分为"预先开放"和"需要打开"两类；候选元件包括 RASGEF1C、PTPRG、CD9。
6. **结论**：病理邻域中的主要重塑是小胶质细胞的染色质和转录协同变化；DDR 表达不适合作为损伤的读出指标。

## 图

| 图 | 内容 | 依据 |
|---|---|---|
| **图 1** | 研究设计与数据总览：数据集、空间尺度、统计框架（donor 为单位、随机基因集、阳性对照） | 新绘制 |
| **图 2** | DDR 在多尺度上的阴性结果：(a) 细胞类型 × 程序热图 (b) GeoMx 分区 (c) Stereo-seq 25 µm (d) 分层失配；每个面板都配阳性对照 | [13][14][16][21] |
| **图 3** | 与已发表结果的直接对比：cohesin 复现（SEA-AD + PsychAD 独立队列），p53/DDR 模块不优于随机基因；cohesin 亚基逐个展示 | [26][30] |
| **图 4** | DAM 染色质：(a) 火山图 (b) RNA 一致性 (c) 基因调控区的集合检验 (d) 指定基因 (e) 海马独立队列复现 | [22][24][31] |
| **图 5** | 稳态小胶质细胞的偏移：(a) 散点图 (b) 稳健性森林图 (c) 拆分复现分布 (d) 致密核心斑块 vs 其他病理指标 (e) 海马独立队列复现 | [22][25][28][31] |
| **图 6** | 两类 DAM 基因与候选元件：预先开放 vs 需要打开；RASGEF1C（GWAS SNP + 人鼠一致）、PTPRG | [23][24] |
| 扩展图 | 方法陷阱：深度偏倚造成的假"关闭"、斑块掩膜配准、大集合下随机 peak 零模型失效、方向一致率的边际期望 | [15][21][22][24][27] |
| 扩展图 | 少突胶质细胞 cohesin 位点失配（SEA-AD 中的线索，海马队列未复现） | [27][28][31] |

## 结果各节

1. **一个以 donor 为单位、带对照的多尺度框架**：数据和统计原则；12 个 donor 时出现的假象。
2. **DNA 修复程序没有随病理特异改变**：[1–2][13][16][21]；检测力；GeoMx 中 Checkpoint 只是线索 [14]。
3. **澄清已发表的阳性结果**：cohesin 复现、p53/DDR 模块不优于随机基因；讨论差异来自统计单位和零模型 [26]。
4. **DAM 状态在整个基因调控区的尺度上写入染色质**：[22][24]；人鼠一致（注明小鼠数据是已发表数据的重新分析）。
5. **稳态小胶质细胞随淀粉样沿 DAM 轴偏移**：[22][25][28]；跟随致密核心斑块，不跟随 tau；和 CPS 分不开。
6. **两类调控方式与候选元件**：[23][24]；AD 风险富集在小胶质细胞染色质中，但 DAM 特异的子集太小，无法检验。
7. （可选）**少突胶质细胞中 cohesin 的转录与染色质失配**：[27][28]。

## 讨论要点

- 和 Sun 2023、Liu 2025、Xiong 2023（人小胶质细胞状态和表观组）的关系：我们新增的是同一 donor 内的配对比较、基因调控区层面的分析、稳态细胞随病理的偏移，以及两类调控方式。
- 和 Mathys 2023/2024、Fancy 2024 的关系：经典修复通路没有变化，cohesin 装载轴有变化，提示变化在基因组结构层面。
- 和 Teo 2024 的关系：浅层 pseudobulk 的深度偏倚是方向特异的。
- **局限**：横断面数据；只有 MTG 一个脑区；状态标签来自 RNA 标签转移；只有 23 个 donor 的 DAM 样核够用；独立队列待补；没有因果实验；"淀粉样"和"整体病程"分不开。

## 投稿前必须补的

| 优先级 | 任务 | 状态 |
|---|---|---|
| 1 | **独立队列复现** | 已完成：PsychAD（cohesin RNA）、人海马 multiome（DAM 染色质、稳态偏移）；少突胶质细胞 cohesin 失配未复现，降为讨论中的线索。ROSMAP 暂不申请 |
| 2 | 只保留标签置信度高的细胞（重新提取时加 Supertype confidence 过滤） | 可做（约 2 小时下载） |
| 3 | 与 Sun 2023 / Xiong 2023 发表的小胶质细胞 peak 或模块做重叠对比 | 需要获取他们的 peak 列表 |
| 4 | 一个元件的 CRISPRi（iPSC 小胶质细胞），比如 CD9 或 PTPRG 增强子 | 需要实验 |

## 目标期刊（按是否有实验分档）

- **只做计算 + 独立复现**：*Genome Medicine*、*Molecular Neurodegeneration*、*Acta Neuropathologica Communications*、*Brain Communications*
- **加一个 CRISPRi**：*Nature Communications*、*Cell Reports*、*Genome Biology*
