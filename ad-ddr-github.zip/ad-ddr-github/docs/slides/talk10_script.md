# 10 分钟报告讲稿 / 10-minute talk script

配合 `talk10_zh.pdf` / `talk10_en.pdf`。每张约 1 分钟（中文约 250 字，英文约 130–150 词）；方括号为提示动作。总时长约 10 分钟，留 1–2 分钟提问时可把第 6 张压缩到 30 秒。

Slides: `talk10_zh.pdf` / `talk10_en.pdf`. About one minute per slide (≈250 Chinese characters or 130–150 English words); brackets are cues. If time is short, slide 6 can be cut to 30 s.

---

## 1｜标题 Title （≈30 s）

**中文**
大家好。今天我想讲的是：阿尔茨海默病在脑细胞中到底改变了什么。我们的答案用一句话概括：**AD 重塑的是胶质细胞中特定的调控元件，而不是所有细胞共同的 DNA 损伤应答。**这项工作全部基于公开的人脑单细胞核数据，并且在独立队列中做了复现。

**English**
Hello everyone. Today I'll ask a simple question: what does Alzheimer's disease actually change inside brain cells? Our answer in one sentence: **AD remodels specific regulatory elements in glia, rather than triggering a DNA-damage response shared by all cells.** Everything is based on public human single-nucleus data, with replication in independent cohorts.

---

## 2｜核心问题 Core question （≈1 min）

**中文**
这项课题的起点是一个流行的设想：斑块旁的细胞发生 DNA 损伤，损伤改变染色质，并留下"记忆"。这个设想隐含着一个判断——病理引起的是**所有细胞共同的应答**，就是左边的图景一。
但还有另一种可能，就是右边的图景二：变化集中在少数细胞中，表现为**特定调控元件的开放或关闭**。
这两种图景决定了完全不同的研究方向。所以我们的核心问题是：AD 相关的变化，到底是共同程序，还是特定细胞中的元件重塑？[指向底部] 为了回答它，我们使用了 SEA-AD、PsychAD、人海马 multiome、空间数据和遗传学数据。

**English**
We started from a popular idea: cells near plaques suffer DNA damage, the damage changes chromatin, and the change leaves a "memory". Hidden in this idea is an assumption — that pathology causes **a response shared by all cells**: model 1 on the left.
But there is an alternative, model 2: change is concentrated in a few cell types, as **specific regulatory elements opening or closing**.
These two models lead to very different research programmes. So our core question is: is AD-associated change a shared program, or element remodelling in specific cells? [point to bottom] We used SEA-AD, PsychAD, a hippocampal multiome cohort, spatial data and genetics.

---

## 3｜关键方法 Key method （≈1 min）

**中文**
在讲结果之前，先讲一个贯穿全文的方法，因为它决定了结论。
这是 PsychAD 中 402 人的兴奋性神经元。圆点是各个 DNA 修复程序与 AD 的相关，都在零的左边——修复基因看起来确实在"下降"，自身的置换检验 p 低到十万分之一。
但请看灰条：它是表达量和基因长度都匹配的**随机基因**的范围。每个修复程序都落在灰条内。也就是说，**所有基因都在一起漂移**，修复基因并没有比随便一组基因下降得更多。
所以在全文中，只有超出匹配随机基因的变化，我们才称为"特异变化"。

**English**
Before the results, one method that runs through the whole study, because it decides the conclusions.
These are excitatory neurons from 402 PsychAD donors. Each dot is a DNA-repair program's correlation with AD — all left of zero. Repair genes do seem to "fall", with permutation p-values as low as 10⁻⁵.
But look at the grey bars: the range of **random genes matched on expression and gene length**. Every repair program sits inside. **All genes drift together**; repair genes fall no more than any random set.
So throughout, we only call a change "specific" when it exceeds matched random genes.

---

## 4｜细胞特异为主 Mostly cell-type-specific （≈1 min 15 s）

**中文**
现在直接回答核心问题。[左图] 我们用其他细胞类型的共同变化去预测每种细胞的变化。纵轴是能被预测的比例：只有 7% 到 29%，胶质细胞最低。也就是说，**没有哪种细胞被共同程序主导**。
[中图] 再看单个基因和元件：特异的基因和元件集中在胶质细胞，右边的红色柱子。例如小胶质细胞有 354 个特异基因，而偶然期望只有 63 个。
[右图] 最关键的一步：这个结论能否在另一个队列复现？我们在 PsychAD 中重复整个分析——三种主要胶质细胞的特异部分在两个队列间相关 0.52 到 0.58，而不对应的细胞配对接近零。所以这些特异变化是**真实、可复现的生物学信号**。

**English**
Now the direct answer. [left] We predicted each cell type's change from the shared change of all other cell types. Only 7–29% is predictable, lowest in glia: **no cell type is dominated by a shared program**.
[middle] At the level of single genes and elements, specific features concentrate in glia — the red bars. Microglia have 354 specific genes where 63 are expected by chance.
[right] The key step: does this replicate? We repeated everything in PsychAD. The specific components of the three main glial types correlate 0.52–0.58 across cohorts, while mismatched pairs are near zero. These specific changes are **real, reproducible biology**.

---

## 5｜DNA 修复没有特异改变 No specific DNA-repair change （≈1 min）

**中文**
那最初设想中的 DNA 修复呢？[左图] 横轴是"随大流"的预测，纵轴是实际变化。灰色的修复程序都在零附近、贴着对角线；绿色的 cohesin 在所有细胞中一起上升，是一个共同变化；只有红色的 DAM 基因在小胶质细胞中远高于预测。
有人会问：是不是被平均掉了？[右图] 我们去到最细的尺度——小鼠空间转录组中斑块 25 微米以内。阳性对照 Trem2、Cd68 富集了 1.5 倍，但 10 个修复程序都在 ±10% 以内。
在大队列中，我们能排除超过 ±0.15 的效应。结合已有研究证明 AD 神经元中确实有 DNA 损伤，我们的概括是：**有损伤，但没有特异的修复应答。**

**English**
What about DNA repair, the heart of the original idea? [left] The x-axis is the change predicted from other cell types; the y-axis is observed. Repair programs in grey sit near zero, on the diagonal. Cohesin, in green, rises in every cell type — a shared change. Only DAM genes, in red, rise far above prediction, in microglia.
Could repair change be averaged away? [right] At the finest scale — within 25 µm of mouse plaques — Trem2 and Cd68 are enriched 1.5-fold, but all ten repair programs stay within ±10%.
In the large cohort we exclude effects beyond ±0.15. Since others have shown DNA damage in AD neurons, our summary is: **damage, without a specific repair response.**

---

## 6｜图谱越大，假的通路变化越多 Larger atlases, more false pathway changes （≈1 min；可压缩到 30 s）

**中文**
这个问题只发生在 DNA 修复上吗？我们把 PsychAD 神经元的供体从 50 人逐步加到约 400 人，看 50 个 Hallmark 通路中有多少"显著"。
实线是自身检验：从 20% 一路上升到 90%。虚线是与匹配随机基因比较：始终只有 6% 到 19%。
也就是说，**图谱越大，假的"通路变化"越多，真正特异的变化却不增加**。我们审计了 74 条已发表结论：大样本研究逐个挑出的差异基因 88% 可以复现，但模块层面的结论只有 25%。这不是说已发表的结论都不可靠，而是提醒：通路层面的结论需要竞争性检验。

**English**
Is this a DNA-repair problem only? We subsampled PsychAD neurons from 50 to ~400 donors and counted how many of 50 Hallmark pathways were "significant".
Solid lines, the self-contained test: from 20% up to 90%. Dashed lines, against matched random genes: flat at 6–19%.
**The larger the atlas, the more false pathway changes, while specific change does not grow.** Auditing 74 published claims, gene-level DEGs from a large study replicate 88% of the time, but module-level claims only 25%. Published results are not unreliable in general — pathway-level claims need a competitive test.

---

## 7｜DAM 改写数百个元件 DAM rewrites hundreds of elements （≈1 min）

**中文**
否定了共同程序之后，我们转向特异变化最清楚的地方：小胶质细胞的 DAM 状态。它的优势是同一个人体内同时有 DAM 样细胞和稳态细胞，可以**在供体内部**比较。
[左图] 23 名供体中，115 个元件开放、121 个关闭，大多是远端增强子，包括 ANXA2、CD9 的增强子。这里有一个技术要点：DAM 样细胞测序浅，必须做深度匹配，否则会出现几百个假"关闭"。
[右图] 在完全独立的人海马队列中，我们用**同一个细胞核的 RNA** 判断状态，不依赖转移来的标签。21 名供体中，四类元件**全部方向一致**。
请记住一个细节：RASGEF1C 的调控区在 DAM 中关闭——下一张会用到。

**English**
Having ruled out a shared program, we turned to the clearest specific change: the microglial DAM state. Its advantage is that DAM-like and homeostatic cells coexist in the same person, so we compare **within donors**.
[left] Across 23 donors, 115 elements open and 121 close — mostly distal enhancers, including at ANXA2 and CD9. A technical point: DAM-like cells are shallowly sequenced, and without depth matching hundreds of elements falsely appear "closed".
[right] In an independent hippocampal cohort, state was defined from **each nucleus's own RNA**, with no transferred labels. All 21 donors agree in direction for all four element classes.
Keep one detail in mind: the RASGEF1C domain closes in DAM.

---

## 8｜RASGEF1C 增强子 The RASGEF1C enhancer pair （≈1 min 15 s）

**中文**
这是全文最新颖的发现。[上层] AD 的 GWAS 信号在 RASGEF1C 附近被精细定位到 4 个 SNP，红点是可信集。
[中层] 每个元件在 DAM 中的变化。**79% 的遗传后验概率落在两个增强子 e1、e2 中**，而它们恰好是在 DAM 中关闭的小胶质细胞增强子。作为对照，小胶质细胞元件只覆盖这个区域 19% 的序列。
[下层] 那这两个增强子调控谁？在同一个细胞核中，它们的开放程度与 RASGEF1C 的表达相关，z 值 6.0 和 4.7，而且 500 kb 内只有 RASGEF1C 通过检验。
所以，**疾病状态和遗传风险作用在同一对元件上**。

**English**
This is our most novel finding. [top] The AD GWAS signal near RASGEF1C fine-maps to four SNPs — the red credible set.
[middle] Each element's change in DAM. **79% of the genetic posterior falls in two enhancers, e1 and e2** — exactly the microglial enhancers that close in DAM. For comparison, microglial elements cover only 19% of this window.
[bottom] Which gene do they control? Within the same nucleus, their accessibility tracks RASGEF1C expression, z = 6.0 and 4.7, and RASGEF1C is the only gene within 500 kb that passes.
So **disease state and genetic risk act on the same pair of elements**.

---

## 9｜风险等位基因降低 RASGEF1C The risk allele lowers RASGEF1C （≈1 min）

**中文**
把证据串起来，就是这条链：AD 风险变异 → 两个小胶质细胞增强子 → 它们在 DAM 中关闭 → 与 RASGEF1C 相关 → 风险等位基因降低 RASGEF1C。
最后一环来自独立数据：391 人的单细胞核 eQTL 中，小胶质细胞 RASGEF1C 的主 eQTL 正是我们可信集中的 SNP，与 AD 共定位概率 0.997，方向是风险等位基因降低表达。
由此我们提出一个可检验的模型：[指向红框] **风险等位基因在稳态小胶质细胞中"提前"削弱了原本只有 DAM 才会关闭的增强子。**
上游，DAM 染色质主要由 MITF 等因子写入：在 327 个候选中排第一，这是对 2026 年报道的独立确认。

**English**
Put together, the chain is: AD risk variants → two microglial enhancers → which close in DAM → which track RASGEF1C → and the risk allele lowers RASGEF1C.
The last link comes from independent data: in single-nucleus eQTL from 391 donors, the lead microglial RASGEF1C eQTL is a credible-set SNP, colocalising with AD at PP 0.997, with the risk allele lowering expression.
This gives a testable model: [red box] **the risk allele weakens, in homeostatic microglia, enhancers that normally close only in DAM.**
Upstream, DAM chromatin is written mainly by MITF and partners — ranked first of 327 candidates, independently confirming 2026 reports.

---

## 10｜结论与下一步 Conclusions and next steps （≈1 min）

**中文**
总结三点。
第一，AD 相关的变化是**细胞特异的**，胶质细胞最强，并能跨队列复现。
第二，**有损伤，无修复应答**：DNA 修复在所有尺度上都没有特异改变；而大图谱中通路层面的结论容易随样本量虚高。
第三，**RASGEF1C 的一对增强子承载 AD 风险**，把疾病状态和遗传风险连在同一对元件上。
需要强调的是，这些都是尸检数据中的相关性证据。下一步最关键的实验是在人 iPSC 来源的小胶质细胞中：用 CRISPRi 关闭 e1、e2，看 RASGEF1C 是否下降；再逐个编辑 4 个 SNP，找出因果变异。因为这些元件在小鼠中不保守，必须用人源细胞。
谢谢大家，欢迎提问。

**English**
Three conclusions.
First, AD-associated change is **cell-type-specific**, strongest in glia and replicated across cohorts.
Second, **damage without a repair response**: DNA repair shows no specific change at any scale, and pathway-level claims inflate with atlas size.
Third, **a pair of RASGEF1C enhancers carries AD risk**, linking disease state and genetic risk on the same elements.
These are associations from post-mortem tissue. The key next experiment is in human iPSC-derived microglia: CRISPRi of e1 and e2 to see whether RASGEF1C falls, then editing the four SNPs to find the causal one. The elements are not conserved in mouse, so human cells are required.
Thank you — happy to take questions.

---

## 可能的提问 Likely questions（备用）

| 问题 Question | 简答 Short answer |
|---|---|
| 没有显著是不是样本不够？ / Is the null just low power? | PsychAD 400+ 人排除了 ±0.15 以上的效应；每层都有阳性对照被检出。 / 400+ donors exclude effects beyond ±0.15; positive controls are detected at every level. |
| 你们是说 AD 没有 DNA 损伤吗？ / No DNA damage in AD? | 不是。我们测的是修复程序的应答，不是损伤本身。 / No — we measure the repair-program response, not damage itself. |
| MITF 不是已经发表了吗？ / Isn't MITF already known? | 是，我们是独立的人脑染色质证据，并具体到家族成员 MITF 和 BHLHE41 的此消彼长。 / Yes; ours is independent human-chromatin evidence, resolved to MITF, with reciprocal BHLHE41. |
| RASGEF1C 是因果吗？ / Is RASGEF1C causal? | 目前只是相关性证据链；4 个 SNP 完全连锁，需要 CRISPRi 和等位基因编辑。 / Association only; the four SNPs are in full LD — CRISPRi and allele editing are needed. |
| 为什么不用小鼠？ / Why not mouse? | e1 在小鼠中没有对应序列，e2 的同源区不开放。 / e1 has no mouse ortholog; the e2 ortholog is not accessible. |
