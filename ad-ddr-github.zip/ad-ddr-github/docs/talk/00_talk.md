# 演讲稿（中英双语）｜Talk script (Chinese / English)

> **用法 / How to use**：每一页对应一张幻灯片：先放图，再是中文讲稿和英文讲稿，两种语言内容一致，可以任选一种讲。主体 14 页约 25–30 分钟；标为"备用"的补充图页用于答问或延长版。 / One section per slide: figure, then the Chinese and the English script with the same content. The 14 main slides take about 25–30 minutes; slides marked "backup" are for Q&A or a longer version.
>
> 数字来自 `results/`（README 第 1–49 节）。/ Numbers are from `results/` (README results 1–49).

---

## 第 1 页｜标题 · Slide 1 | Title

**题目 / Title**：阿尔茨海默病重塑胶质细胞的调控元件，而非全细胞共同的 DNA 损伤应答 / *Alzheimer's disease remodels glial regulatory elements rather than a shared DNA-damage response*

**中文**

大家好。今天我想和大家分享的问题是：阿尔茨海默病的病理，究竟是让大脑里所有的细胞都启动同一种"损伤应答"，还是只在某些细胞里，有针对性地改写特定的基因调控元件？

先说结论：我们的数据支持第二种。最常被认为是"共同应答"的 DNA 修复程序，在任何尺度上都没有特异的变化；而真正被改写的调控元件，集中在胶质细胞，尤其是小胶质细胞。在小胶质细胞中，这种改写由 MITF 等转录因子承载，并且在 RASGEF1C 基因旁边的一对增强子上，和阿尔茨海默病的遗传风险交汇在了一起。

接下来我按照"问题、方法、结果、结论"的顺序展开。

**English**

Hello everyone. The question I want to address today is this: does Alzheimer's pathology make every cell in the brain switch on the same kind of damage response, or does it selectively rewrite particular regulatory elements in particular cells?

Let me give you the answer up front: our data support the second view. The DNA-repair program, the response most often assumed to be shared, shows no specific change at any scale. The regulatory elements that are truly rewritten are concentrated in glia, above all in microglia. In microglia, this rewriting is carried by transcription factors such as MITF, and at a pair of enhancers next to the gene RASGEF1C it converges with the genetic risk for Alzheimer's disease.

I'll go through the question, the methods, the results and the conclusions in that order.

---

## 第 2 页｜研究背景与核心问题 · Slide 2 | Background and the core question

**中文**

这个课题的起点是一个很流行的设想。大家知道，阿尔茨海默病患者的神经元里 DNA 断裂是增多的。于是有人提出：斑块和 tau 病理附近的细胞经历了 DNA 损伤；损伤改变了染色质，也就是改变了哪些基因的调控元件是开着的、哪些是关着的；而且即使刺激消失，染色质也恢复不了，形成一种"记忆"，最终导致细胞功能障碍。

这个设想很吸引人，但它背后藏着一个更基本的判断：病理引起的，是一种**所有细胞都会启动的共同应答**。可是另一种可能同样合理：病理相关的变化只集中在少数细胞中，表现为特定调控元件的重塑。

这两种图景会把研究带向完全不同的方向。所以我们把核心问题定为：**AD 病理相关的细胞状态变化，是所有细胞共同的程序，还是集中在特定细胞中的调控元件重塑？**

**English**

The starting point of this project was a popular idea. We know that neurons in Alzheimer's disease carry more DNA breaks. So it was proposed that cells near plaques and tau pathology experience DNA damage; that the damage changes chromatin, that is, which regulatory elements of genes are open or closed; and that this state persists after the insult, forming a kind of "memory" that eventually impairs the cell.

The idea is attractive, but it rests on a more basic assumption: that pathology triggers a **response shared by all cells**. The alternative is equally plausible: that pathology-associated change is concentrated in a few cell types and takes the form of remodelling of specific regulatory elements.

These two pictures lead research in completely different directions. So we framed our core question as: **is the change in cell state associated with Alzheimer's pathology a program shared by all cells, or regulatory-element remodelling concentrated in specific cells?**

---

## 第 3 页｜数据与方法原则 · Slide 3 | Data and methodological principles

**中文**

我们用的全部是公开数据，一共 8 个数据集。发现队列是 SEA-AD：84 名供体、10 个脑区的单细胞核 RNA，86 名供体的单细胞核染色质，再加上分层的定量病理。空间数据来自人海马的 GeoMx 和小鼠的 Stereo-seq。独立复现用两个队列：大约 430 名供体的 PsychAD，以及同一个细胞核里同时测了 RNA 和染色质的人海马 multiome。最后还整合了 AD 遗传学和 11 个 eQTL 数据集。

方法上有四条原则贯穿全文。第一，以"人"为统计单位，因为同一个人的几千个细胞并不是独立样本。第二，也是最关键的一条：每一组基因都要和**表达量、基因长度都匹配的随机基因**比较。因为 AD 大脑里几千个基因会一起漂移，"某条通路在变"并不等于"这条通路特有地在变"。第三，每一层分析都设阳性对照，证明方法看得见真实的变化。第四，在独立队列中只检验已经确定的结论，不重新挑选。

**English**

All our data are public, eight datasets in total. The discovery cohort is SEA-AD: single-nucleus RNA from 84 donors across 10 brain regions, single-nucleus chromatin from 86 donors, and layer-resolved quantitative neuropathology. Spatial data come from human hippocampal GeoMx and mouse Stereo-seq. For independent replication we used two cohorts: PsychAD, with about 430 donors, and a human hippocampal multiome dataset in which RNA and chromatin are measured in the same nucleus. We also integrated Alzheimer's genetics and eleven eQTL datasets.

Four principles run through the whole study. First, the donor is the statistical unit, because thousands of cells from one person are not independent samples. Second, and most important, every gene set is compared with **random genes matched on expression and gene length**. Thousands of genes drift together in the Alzheimer's brain, so "this pathway changes" does not mean "this pathway changes specifically". Third, every level of analysis carries a positive control, to show the method can see real change. Fourth, in independent cohorts we only test conclusions fixed in advance; we do not re-select.

---

## 第 4 页｜图 1：核心问题的直接回答 · Slide 4 | Figure 1: a direct answer to the core question

![图1](figures/Fig1.png)

**中文**

图 1 的上半部分是研究设计，下半部分直接回答核心问题。

先看 **1a 到 1c**。1a 把数据分成三类：蓝色是发现队列，灰色是空间和小鼠数据，绿色是独立复现队列，发现和验证用的是不同的数据。1b 是我们检验的五个空间尺度，从"供体 × 细胞类型"一直到"单个细胞核"。为什么要从粗到细？因为粗尺度上没看到变化，可能只是斑块旁少数细胞的变化被平均掉了，越往细看，这种解释就越站不住。1c 是统计原则。

再看 **1d**。我们计算了每种细胞随病程变化的模式里，有多大比例能被其他细胞的共同变化解释，我们叫它"共享比例"。为了公平比较噪声不同的细胞，我们把供体随机分成两半，并用每种细胞自身的可重复程度做了校正。结果是：神经元大约 25%，而小胶质细胞、星形胶质细胞只有 7% 左右。也就是说，**没有哪种细胞被一个共同程序主导**，胶质细胞几乎完全是"自成一格"的。

**1e** 换个角度，看单个基因和元件。我们数了每种细胞里偏离共同变化、并且超出偶然水平的基因和元件。小胶质细胞有 354 个特异基因，而偶然情况下只期望 63 个；它还有 422 个特异的调控元件。少突胶质细胞和星形胶质细胞也很多，而大多数神经元接近偶然水平。所以，**真正被改写的基因和元件集中在胶质细胞**。

最后 **1f** 直接回应最初的设想。横轴是"如果只是随大流，预期会有多大变化"，纵轴是实际变化。灰色的 DNA 修复程序都在 0 附近，并且贴着对角线，说明它既没有特异变化，也不是共同变化的重要部分；绿色的 cohesin 在几乎所有细胞中一起上升，是共同变化；红色的 DAM，也就是疾病相关的小胶质细胞程序，只在小胶质细胞中远远高于预期。

那么，这个答案在另一个更大的队列里还成立吗？

**English**

The top half of Figure 1 is the study design; the bottom half answers the core question directly.

Panels **a to c** first. Panel a groups the data: blue is discovery, grey is spatial and mouse data, green is independent replication; discovery and validation never share data. Panel b shows the five spatial scales we test, from donor-by-cell-type down to single nuclei. Why go from coarse to fine? If a change is absent at a coarse scale, it might simply be diluted, coming from a few cells near plaques. The finer we look, the less tenable that explanation becomes. Panel c lists the statistical principles.

Now panel **d**. For each cell type we asked what fraction of its disease-associated profile can be explained by the change shared with the other cell types; we call it the shared fraction. To compare cell types with different noise fairly, we split donors at random into halves and corrected for each cell type's own reproducibility. Neurons come out around 25%, while microglia and astrocytes are only about 7%. In other words, **no cell type is dominated by a shared program**, and glia are almost entirely their own.

Panel **e** takes another angle and looks at individual genes and elements. We counted those that depart from the shared change beyond chance. Microglia have 354 specific genes, against 63 expected by chance, and 422 specific regulatory elements. Oligodendrocytes and astrocytes also have many, while most neurons are close to chance. So **the genes and elements that are truly rewritten are concentrated in glia**.

Finally, panel **f** speaks directly to the original idea. The x-axis is the change you would expect if a program only followed the crowd; the y-axis is the observed change. The DNA-repair programs in grey sit near zero and along the diagonal: no specific change. Cohesin, in green, rises together in almost all cell types, a shared change. DAM, the disease-associated microglia program in red, rises far above expectation, and only in microglia.

So does this answer hold in a larger, independent cohort?

---

## 第 5 页｜图 S8（备用）：在 PsychAD 中复现 · Slide 5 (backup) | Figure S8: replication in PsychAD

![图S8](figures/FigS8.png)

**中文**

我们在 PsychAD 里完整重复了这个分析。这是一个独立的队列：不同的脑库、不同的脑区（前额叶）、用的是 AD 诊断而不是病程评分，样本量是 SEA-AD 的 6 倍。

**S8a** 和 **S8b** 显示，胶质细胞仍然共享最少、特异基因最多，排序和 SEA-AD 完全一致。有一点修正：在大样本下，神经元也出现了不少特异基因。所以 SEA-AD 里"神经元接近偶然"，主要是因为每种细胞只有七十多名供体。神经元和胶质细胞的差别是"程度"，而不是"有无"。

最有力的是 **S8c**。我们比较了两个队列中"同一种细胞偏离其他细胞的方式"。三种主要胶质细胞的相关达到 0.52 到 0.58，而不对应的细胞配对只有 0 左右。**S8d** 显示，两个队列都判为特异、方向也相同的基因远超偶然，比如小胶质细胞有 122 个，偶然只期望 15 个。这说明特异变化不是噪声，而是真实、可复现的生物学信号。

**English**

We repeated the whole analysis in PsychAD, an independent cohort: a different brain bank, a different region (the prefrontal cortex), Alzheimer's diagnosis instead of a progression score, and six times as many donors.

Panels **a** and **b** show that glia again share the least and carry the most specific genes, in the same order as in SEA-AD. One correction: with this sample size, neurons also show many specific genes. So the near-chance neuronal counts in SEA-AD mostly reflect its roughly 70 donors per cell type. The difference between neurons and glia is one of degree, not of presence or absence.

The strongest evidence is panel **c**. We compared, between the two cohorts, the way each cell type departs from the others. For the three main glial types the correlation is 0.52 to 0.58, whereas mismatched cell-type pairs sit around zero. Panel **d** shows that genes called specific in both cohorts, with the same sign, far exceed chance: 122 in microglia, against about 15 expected. Specific change is therefore not noise; it is a real, reproducible biological signal.

---

## 第 6 页｜图 2：DNA 修复在所有尺度上都没有特异改变 · Slide 6 | Figure 2: no specific change in DNA repair at any scale

![图2](figures/Fig2.png)

**中文**

既然变化以细胞特异为主，那最被看好的"共同程序"DNA 修复，会不会只是在粗尺度上被平均掉了？图 2 从五个尺度严格检验这一点，每一层都配有阳性对照。

**2a** 是 SEA-AD 的热图：24 种细胞乘 10 个修复程序。在 9 个脑区共 1,959 个检验中，没有一个通过多重校正，名义显著的比例和偶然一样。而作为阳性对照的 DAM 程序清楚可见。73 名供体已经足以检出中等以上的效应。

**2b** 是我最想请大家注意的一个小图。在 PsychAD 的 402 名供体中，修复程序看起来都在下降，置换检验的 p 值低到 10 的负 5 次方。但每个点都落在灰条里，灰条是匹配的随机基因的范围。也就是说，**修复基因确实在下降，但所有基因都在以相似的幅度下降**。如果只做自身检验，就会得出"AD 神经元修复程序显著下调"的错误结论。

**2c** 和 **2d** 把尺度推到斑块旁边。在人海马的 GeoMx 中，接触斑块的区域 DAM 升高了 0.57 个标准差，修复程序不变。在小鼠 Stereo-seq 中，我们先重新配准了斑块的位置，阳性对照 Trem2 和 Cd68 在斑块 25 微米以内富集 1.5 倍，而 10 个修复程序都在正负 10% 以内。在接近单个细胞的尺度上，"被平均掉了"这个解释基本被排除了。

**2e** 检验最初设想里"染色质没恢复"的那个部分。在快照数据中，它最接近的表现是修复基因的 RNA 和染色质"对不上"。我们用同一个人不同皮层的病理来比，没有发现任何失配。**2f** 是阳性对照：DAM 的 RNA 和染色质随斑块一起上升，两者之差约为 0。这说明真实的病理反应是 RNA 和染色质**一起变化**，而不是对不上。

**English**

If change is mostly cell-type-specific, could the favourite shared program, DNA repair, simply be diluted at coarse scales? Figure 2 tests this rigorously at five scales, each with a positive control.

Panel **a** is the SEA-AD heatmap: 24 cell types by 10 repair programs. Of 1,959 tests across nine regions, none passes multiple-testing correction, and the nominal hit rate equals chance. The positive control, the DAM program, is clearly visible. With 73 donors we had good power for moderate effects.

Panel **b** is the one I'd most like you to remember. In 402 PsychAD donors, the repair programs all seem to fall, with permutation p values as low as ten to the minus five. But every point lies inside the grey bar, the range of matched random genes. **Repair genes do fall, but all genes fall by about as much.** With a self-contained test alone you would conclude, wrongly, that DNA repair is down-regulated in Alzheimer's neurons.

Panels **c** and **d** take us next to plaques. In human hippocampal GeoMx, DAM rises by 0.57 standard deviations in plaque-contacting regions, while repair programs do not move. In mouse Stereo-seq, after re-registering the plaque masks, the positive controls Trem2 and Cd68 are enriched 1.5-fold within 25 microns of plaques, while the ten repair programs stay within plus or minus 10%. At almost single-cell resolution, the dilution explanation is largely ruled out.

Panel **e** tests the "chromatin does not recover" part of the original idea. In snapshot data its closest form is a mismatch between repair-gene RNA and chromatin. Comparing layers within the same person, we found no mismatch. Panel **f** is the positive control: DAM RNA and chromatin rise together with plaques, and their difference is about zero. A genuine pathological response appears as RNA and chromatin **changing together**, not as a mismatch.

---

## 第 7 页｜图 S4、S5（备用）：排除了多大的效应 · Slide 7 (backup) | Figures S4–S5: how large an effect is excluded

![图S4](figures/FigS4.png)

**中文**

"不显著"并不等于"没有变化"，所以我们又做了两件事。

图 **S4** 是等效性检验：不是问"是否不为零"，而是问"能不能确定变化落在一个很小的范围内"。关键在于，我们对随机基因组也做了同样的判断，作为基准。结果是，DNA 修复程序"确认不变"和"确认改变"的比例，和随机基因组完全一样。在 PsychAD 中，每个修复程序都可以排除超过正负 0.15 的特异效应；在小鼠斑块旁，10 个程序中有 8 个可以排除超过 10% 的变化。逐个去掉基因也不改变结论。

![图S5](figures/FigS5.png)

图 **S5** 回应另一个质疑：通路分数把很多基因平均，会不会稀释了信号？我们像临床试验那样，事先固定了 8 个最直接的窄终点，比如 DNA 断裂感知、p53 反应和 cGAS-STING，在 6 种细胞、两个队列中检验，并做了多重校正和荟萃分析。没有一个终点超出匹配基因，而 cohesin 和 DAM 参照都明显超出。

**English**

"Not significant" is not the same as "no change", so we did two more things.

Figure **S4** is an equivalence test. Instead of asking whether the effect differs from zero, it asks whether we can show it lies within a small range. The key is that we applied the same judgement to random gene sets as a benchmark. DNA-repair programs are "equivalent" and "different" at exactly the rates of random gene sets. In PsychAD every repair program excludes specific effects beyond plus or minus 0.15; next to mouse plaques, eight of ten programs exclude changes beyond 10%. Leaving out one gene at a time does not change the conclusion.

Figure **S5** answers another objection: does averaging many genes into a pathway score dilute the signal? Like a clinical trial, we fixed eight narrow endpoints in advance, such as DNA-break sensing, the p53 response and cGAS–STING, and tested them in six cell types and two cohorts, with multiple-testing correction and meta-analysis. No endpoint exceeds matched genes, whereas the cohesin and DAM references clearly do.

---

## 第 8 页｜图 3：已发表信号中能复现的是 cohesin · Slide 8 | Figure 3: of published signals, cohesin replicates

![图3](figures/Fig3.png)

**中文**

这个阴性结论和几项大型研究的报道表面上矛盾，它们报道过 AD 中"DNA 损伤相关基因上调"。矛盾从哪里来？最直接的办法，就是拿原文公布的基因清单，放进我们的框架里重新检验。

**3a** 是结果。Mathys 2023 报道的 cohesin 基因集，在兴奋性神经元和少突胶质细胞中确实特异地上升，红点都在灰条外面。但 Mathys 2024 报道的 p53/DNA 损伤模块，虽然看起来在上升，随机基因也上升了差不多的幅度；另一个衰老小胶质细胞模块甚至比随机基因变化得更少。所以，已报道的信号分成两类：cohesin 是真信号，p53/DNA 损伤模块的"上升"和刚才修复程序的"下降"是同一回事，都是随整体漂移。

**3b** 把 cohesin 拆到单个基因。核心亚基和装载因子在两个队列、两种细胞中都一起上升，而负责卸载的 WAPL 和决定停靠位置的 CTCF 不变。这不是一两个基因带动的，而是整个装载机器在协同上升。cohesin 在不分裂的神经元里主要负责折叠三维基因组，所以这条线索指向的是**基因组结构，而不是修复本身**。**3c** 显示它在 SEA-AD 的 9 个脑区和 PsychAD 中都能复现。

**English**

This negative result seems to contradict several large studies that reported "up-regulation of DNA-damage genes" in Alzheimer's disease. Where does the contradiction come from? The most direct test is to take the published gene lists and re-test them in our framework.

Panel **a** shows the result. The cohesin set of Mathys 2023 truly and specifically rises in excitatory neurons and oligodendrocytes; the red points sit outside the grey bars. The p53/DNA-damage module of Mathys 2024 also seems to rise, but random genes rise by about as much; an aged-microglia module changes even less than random genes. So the published signals fall into two kinds: cohesin is real, while the "rise" of the p53/DNA-damage module is the same thing as the "fall" of repair programs we just saw, namely the global drift.

Panel **b** breaks cohesin down gene by gene. Core subunits and loading factors rise together in both cohorts and both cell types, while the unloader WAPL and the boundary factor CTCF do not change. This is not one or two genes; the whole loading machinery moves together. In post-mitotic neurons cohesin's main job is folding the three-dimensional genome, so this lead points to **genome architecture, not repair itself**. Panel **c** shows it replicates across nine SEA-AD regions and in PsychAD.

---

## 第 9 页｜图 S9：这个问题有多普遍 · Slide 9 | Figure S9: how widespread is the problem?

![图S9](figures/FigS9.png)

**中文**

如果 DNA 修复的"变化"只是整体漂移，那其他已发表的通路结论是不是也有同样的问题？图 S9 做了一个审计。

**S9a** 我认为是这项研究里最有警示意义的一张小图。我们把 PsychAD 神经元的供体从 50 名逐步增加到约 400 名。实线是常规自身检验下"显著改变"的通路比例，它从 20% 一路升到 48%，在抑制性神经元中甚至升到 90%。虚线是和匹配随机基因比较后仍然显著的比例，它始终停在 6% 到 19%。也就是说，**图谱越大，假的"通路变化"越多，真正的特异变化却不增加**。**S9b** 更直观：自身检验"显著"的 68 个通路，只有 5 个是真正特异的。

**S9c** 审计了两篇大型图谱中的 74 条已发表结论。大样本研究逐个基因挑出的差异基因，88% 能在两个独立队列中复现；而模块层面的结论只有 25%。所以我们并不是说已发表的结论都不可靠：**逐个基因的结论基本可靠，通路和模块层面的结论最容易虚高**。**S9d** 按细胞类型看，少突胶质细胞和星形胶质细胞的结论最可靠，小胶质细胞最差。

**English**

If the "changes" in DNA repair are just the global drift, do other published pathway claims share the problem? Figure S9 is an audit.

Panel **a** is, I think, the most cautionary result of this study. We subsampled PsychAD neurons from 50 to about 400 donors. The solid lines show the share of pathways "significantly changed" by the usual self-contained test: it climbs from 20% to 48%, and to 90% in inhibitory neurons. The dashed lines show the share that remains significant against matched random genes: it stays at 6 to 19%. **The larger the atlas, the more false pathway changes, while genuinely specific changes do not increase.** Panel **b** makes it concrete: of 68 pathways "significant" by the self-contained test, only 5 are specific.

Panel **c** audits 74 published claims from two large atlases. Gene-level DEG sets from the well-powered study replicate in both independent cohorts 88% of the time; module-level claims only 25%. So we are not saying published claims are unreliable: **gene-level claims hold up; pathway- and module-level claims are the ones most prone to inflation.** Panel **d** shows that oligodendrocyte and astrocyte claims are the most reliable and microglial claims the least.

---

## 第 10 页｜图 4：DAM 改写了大量调控元件 · Slide 10 | Figure 4: DAM rewrites many regulatory elements

![图4](figures/Fig4.png)

**中文**

到这里，"共同程序"的图景基本被否定了。那么，与病理最直接相关的特异变化是什么？前面每一层的阳性对照都指向同一个答案：小胶质细胞的疾病相关状态，DAM。它的 RNA 和染色质还会一起变化。所以我们把最初的问题，"病理相关的染色质状态由哪些调控元件承载"，转到 DAM 上来研究。小胶质细胞还有一个独特的优势：同一个人体内既有 DAM 样细胞，又有稳态细胞，可以在同一个人内部比较两种状态，把"元件被改写"和"细胞组成改变"分开。

**4a** 是火山图。我们在 23 名供体体内分别比较这两种状态，找到 115 个开放、121 个关闭的元件，86% 是远端元件，大多是增强子。这里有一个重要的技术细节：DAM 样细胞少、测序浅，浅样本里的低计数元件会被误判成"关闭"，不处理的话会多出 502 个假的"关闭"。所以我们把深样本下采样到相同深度，重复 20 次取平均。

**4b** 用独立的 RNA 数据验证：开放元件附近的基因 RNA 上调，关闭元件附近的下调，三条曲线清楚分开。**4c** 把每个基因上下游 50 kb 的元件合起来，发现 655 个调控区改变。更重要的是复现：在另一个实验室、另一个脑区的海马数据中，**我们用同一个细胞核自己的 RNA 来判断它的状态**，不依赖任何转移来的标签，这些元件全部显著复现。**4d** 是具体基因：ANXA2、CD9 的调控区打开，P2RY12 和 **RASGEF1C** 的调控区关闭，请大家记住 RASGEF1C。**4e** 显示，海马队列 21 名供体中，四类元件全部方向一致。

**English**

At this point the shared-program picture is essentially ruled out. So what is the most direct pathology-specific change? Every positive control so far points to the same answer: the disease-associated state of microglia, DAM, whose RNA and chromatin change together. So we moved the original question, which regulatory elements carry the pathology-associated chromatin state, onto DAM. Microglia have a unique advantage: each person has both DAM-like and homeostatic cells, so we can compare the two states within the same person and separate element rewriting from changes in cell composition.

Panel **a** is the volcano plot. Comparing the two states within each of 23 donors, we found 115 opened and 121 closed elements, 86% of them distal, mostly enhancers. One important technical detail: DAM-like cells are few and shallowly sequenced, and low-count elements in shallow samples get falsely called "closed"; without correction we would have 502 false closings. So we thinned the deeper sample to the same depth and averaged over 20 draws.

Panel **b** validates with independent RNA data: genes near opened elements go up, genes near closed elements go down, and the three curves separate clearly. Panel **c** sums elements within 50 kb of each gene and finds 655 regulatory domains that change. More important is the replication: in hippocampal data from another lab and another region, **we defined each nucleus's state from its own RNA**, without any transferred label, and all element classes replicated. Panel **d** shows named genes: ANXA2 and CD9 open their domains, P2RY12 and **RASGEF1C** close theirs. Please keep RASGEF1C in mind. Panel **e** shows that in all 21 hippocampal donors, all four element classes move in the expected direction.

---

## 第 11 页｜图 S1、S3（备用）：状态定义与其他小胶质细胞状态 · Slide 11 (backup) | Figures S1, S3: state definition and other microglial states

![图S1](figures/FigS1.png)

**中文**

**S1** 展示了海马小胶质细胞是怎样用同一个核的 RNA 定义"DAM 高"和"DAM 低"的。DAM 得分在 UMAP 上是连续变化的，没有分成两群，所以按三分位切分是合理的；标志基因的方向也正确；只用染色质算出来的 UMAP，也能大致把两种状态分开。

![图S3](figures/FigS3.png)

**S3** 回答一个自然的问题：DAM 是不是唯一与病理相关的状态？我们检查了干扰素、炎症、抗原呈递、增殖等程序。它们是独立存在的状态，但都不随病程变化。所以把重点放在 DAM 上是合理的。

**English**

Figure **S1** shows how we defined DAM-high and DAM-low hippocampal microglia from RNA in the same nucleus. The DAM score varies continuously on the UMAP rather than splitting into two clusters, so cutting it into thirds is reasonable; marker genes move in the right directions; and a UMAP built from chromatin alone also roughly separates the two states.

Figure **S3** answers a natural question: is DAM the only state linked to pathology? We examined interferon, inflammatory, antigen-presentation and proliferation programs. They exist as separate states, but none tracks disease progression. Focusing on DAM is therefore justified.

---

## 第 12 页｜图 5：一个被我们自己修正的发现 · Slide 12 | Figure 5: a finding we corrected ourselves

![图5](figures/Fig5.png)

**中文**

DAM 改写的元件是稳健的。但 DAM 样细胞只是小胶质细胞的一部分。最初的设想说"病理邻域塑造染色质状态"，那么，还没有激活、仍处于稳态的细胞，是否也在随病理向 DAM 方向移动？如果是，就说明病理影响的是整个群体。

**5a** 一开始给了一个很令人兴奋的结果：在 SEA-AD 的 66 名供体中，标为稳态的小胶质细胞随斑块向 DAM 染色质状态偏移，相关 0.33；在没参与元件发现的供体中更强，达到 0.46。**5b** 显示它不受测序深度和 APOE 影响，跟随淀粉样而不是 tau，与致密核心斑块关系最强。**5c** 中 100 次随机拆分，100 次方向为正。

但是 **5d** 给出了第一个警告信号：在海马队列中，结果没有干净地复现。

于是我们在 **5e** 做了一件更彻底的事：重新下载全部 9,572 个小胶质细胞核的数据，在单个细胞核层面检查。结果发现，这个偏移**只出现在 41 名只做了 ATAC 的供体中**，在 25 名做了 multiome、细胞标签来自自身 RNA 的供体中完全不存在。这是关键：在只做了 ATAC 的供体中，每个核的"稳态"标签本身就是根据染色质推断的，所以"标签内部的染色质在移动"和"标签的边界在移动"在逻辑上无法区分。**5f** 的分布形状也无法给出定论。

所以我们把它降级为"稳健但尚未解释的观察"。我想强调，主动推翻自己的发现，也是这项研究严谨性的一部分。它还带来一个方法学教训：**用转移来的标签分析"状态内部的变化"，必须在标签来自细胞自身 RNA 的细胞中验证。**

**English**

The elements rewritten in DAM are robust. But DAM-like cells are only part of the microglia. The original idea was that the pathological neighbourhood shapes chromatin, so are microglia that are still homeostatic also drifting toward DAM with pathology? If so, pathology would be acting on the whole population.

Panel **a** first gave an exciting result: across 66 SEA-AD donors, homeostatic-labelled microglia shift toward the DAM chromatin state with plaque burden, r = 0.33, and more strongly, 0.46, in donors not used to discover the elements. Panel **b** shows the shift is not explained by sequencing depth or APOE, follows amyloid rather than tau, and is strongest for dense-core plaques. In panel **c**, 100 random donor splits give a positive shift 100 times out of 100.

But panel **d** gave a first warning: the hippocampal cohort did not replicate it cleanly.

So in panel **e** we went further: we re-downloaded all 9,572 microglial nuclei and looked at single nuclei. The shift is present **only in the 41 donors profiled by ATAC alone**, and absent in the 25 donors with multiome data, whose labels come from the cells' own RNA. This is the key point: in ATAC-only donors every homeostatic label is itself inferred from chromatin, so a chromatin shift inside the label cannot be separated from a moving label boundary. The distribution shapes in panel **f** cannot decide either.

We therefore downgraded it to a robust but unexplained observation. I want to stress that correcting our own finding is part of the rigour of this work. It also carries a methodological lesson: **within-state chromatin changes defined with transferred labels must be checked in cells labelled from their own RNA.**

---

## 第 13 页｜图 S2（备用）：pseudobulk 层面的检验 · Slide 13 (backup) | Figure S2: pseudobulk-level checks

![图S2](figures/FigS2.png)

**中文**

在发现 5e 的问题之前，我们在 pseudobulk 层面做了很多检验。**S2a** 用不包含被打分供体的方式定义元件，比如交叉拟合、用海马队列定义，偏移仍在。**S2b、c** 显示偏移不依赖少数元件，在全基因组层面也存在。**S2d** 显示所有亚型都朝同一方向移动。这些检验都成立，但它们都用了 SEA-AD 的标签，所以排除不了 5e 揭示的标签问题。**S2e、f** 显示，在海马队列中，最稳态的细胞靠近 DAM，最激活的反而远离，是一种"趋同"，和 SEA-AD 的模式不同。

**English**

Before finding the problem in Figure 5e, we ran many pseudobulk-level checks. Panel **a** defines the axis without the scored donors, by cross-fitting or using the hippocampal cohort, and the shift persists. Panels **b** and **c** show it does not depend on a few elements and appears genome-wide. Panel **d** shows all supertypes move in the same direction. These checks all hold, but they all use SEA-AD labels, so none can exclude the label problem revealed in 5e. Panels **e** and **f** show that in the hippocampus the most homeostatic cells move toward DAM while the most activated move away, a convergence unlike the SEA-AD pattern.

---

## 第 14 页｜图 6：疾病状态与遗传风险交汇于 RASGEF1C · Slide 14 | Figure 6: disease state meets genetic risk at RASGEF1C

![图6](figures/Fig6.png)

**中文**

我们已经知道 DAM 改写了哪些元件。下一个问题是：这些被改写的元件和疾病风险有没有关系？如果某个元件既随疾病状态改变、又承载遗传风险，我们就从"疾病的伴随现象"走向了"可能的致病机制"。

**6a** 先看一个有意思的现象：DAM 基因有两种激活方式。TREM2、APOE、SPP1 的 RNA 大幅上升，但调控区不变，它们的元件本来就开着，DAM 只是"调高了音量"；ANXA2、CD9、VIM 则需要先打开调控区，这才是真正的"元件重塑"。

**6b** 是全文最关键的交汇点。AD 的遗传信号精细定位到 4 个 SNP，**79% 的后验概率落在两个在 DAM 中关闭的小胶质细胞增强子里**，我们叫它们 e1 和 e2。要知道，小胶质细胞元件只占这个区域 19% 的序列。在同一个细胞核中，这两个增强子的开放程度与 RASGEF1C 的表达相关，而 500 kb 范围内只有 RASGEF1C 通过检验。还记得吗？图 4 中 RASGEF1C 的调控区在 DAM 中是关闭的。所以，**疾病状态和遗传风险作用在了同一对元件上**。

**6c** 是证据矩阵。在所有含 AD 风险 SNP 的 DAM 元件中，只有 RASGEF1C 的证据在遗传、染色质、基因表达三个层面汇合。**6d** 提醒我们，从全基因组看，AD 风险分布在小胶质细胞的调控 DNA 中，并不专门集中在 DAM 元件上。所以 RASGEF1C 是一个个例，而不是普遍规律，这也正是它值得单独深入研究的原因。

**English**

We now know which elements DAM rewrites. The next question is whether any of them relates to disease risk. If an element both changes with the disease state and carries genetic risk, we move from a phenomenon accompanying the disease to a possible mechanism.

Panel **a** first shows something interesting: DAM genes are activated in two ways. TREM2, APOE and SPP1 rise strongly in RNA without any change in their regulatory domains; their elements are already open and DAM just turns up the volume. ANXA2, CD9 and VIM have to open their domains first; that is true element remodelling.

Panel **b** is the key convergence point of the study. The Alzheimer's genetic signal fine-maps to four SNPs, and **79% of the posterior falls inside two microglial enhancers that close in DAM**, which we call e1 and e2, although microglial elements cover only 19% of the region. In the same nuclei, their accessibility tracks RASGEF1C expression, and RASGEF1C is the only gene within 500 kb that passes. Remember that in Figure 4 the RASGEF1C domain closes in DAM. So **the disease state and the genetic risk act on the same pair of elements**.

Panel **c** is the evidence matrix. Among all DAM elements carrying Alzheimer's risk SNPs, only RASGEF1C has evidence converging at the genetic, chromatin and expression levels. Panel **d** reminds us that genome-wide, Alzheimer's risk lies in microglial regulatory DNA broadly, not specifically in DAM elements. RASGEF1C is an instance, not a rule, which is exactly why it deserves a closer look.

---

## 第 15 页｜图 S6：RASGEF1C 证据链逐环检验 · Slide 15 | Figure S6: testing the RASGEF1C chain link by link

![图S6](figures/FigS6.png)

**中文**

要把 RASGEF1C 推荐给实验，链条上的每一环都必须单独站得住。图 S6 逐环检验。

**S6a**：e1 基本只在小胶质细胞中开放，在其他细胞中最高只有它的五分之一，这是小胶质细胞自己的元件。**S6b**：RASGEF1C 也是在小胶质细胞中表达最高，是第二名的 2.6 倍。**S6c**：500 kb 内可以检验的 9 个基因中，只有 RASGEF1C 和这两个元件相关。**S6d**：这 4 个 SNP 在脊椎动物和灵长类中都不保守，e1 在小鼠中甚至没有对应的序列。这意味着**不能用小鼠模型验证**，必须用人源细胞。

**S6e** 是原来最薄弱的一环：风险等位基因到底会不会影响 RASGEF1C 的表达？第一行来自一项 391 人的单细胞核 eQTL 研究：小胶质细胞中 RASGEF1C 的主 eQTL，正好是我们可信集中的一个 SNP，与 AD 共定位的概率达到 0.997；孟德尔随机化显示，**风险等位基因降低 RASGEF1C**。下面几行是我们自己查的 bulk 组织数据，方向一致但信号弱，因为这个效应只存在于小胶质细胞，在组织中被稀释了。

于是证据链在相关性层面完整了：风险变异、两个小胶质细胞增强子、增强子在 DAM 中关闭、它们与 RASGEF1C 相关、风险等位基因降低 RASGEF1C。由此我们提出一个可检验的模型：**风险等位基因在稳态小胶质细胞中，"提前"削弱了 DAM 状态才会关闭的增强子。**这是本研究最新颖的发现。

**English**

To recommend RASGEF1C for experiments, every link of the chain has to stand on its own. Figure S6 tests them one by one.

Panel **a**: e1 is open almost only in microglia; in any other cell type it reaches at most a fifth of that. This is a microglial element. Panel **b**: RASGEF1C is also expressed most highly in microglia, 2.6 times the next cell type. Panel **c**: of the nine testable genes within 500 kb, only RASGEF1C links to the two elements. Panel **d**: the four SNPs are not conserved in vertebrates or primates, and e1 has no mouse counterpart at all. This means **mouse models cannot test it**; we need human cells.

Panel **e** addresses what used to be the weakest link: does the risk allele actually change RASGEF1C expression? The top row comes from a single-nucleus eQTL study of 391 people. The lead microglial eQTL for RASGEF1C is one of our credible-set SNPs; it colocalizes with Alzheimer's risk with posterior probability 0.997, and Mendelian randomization shows that **the risk allele lowers RASGEF1C**. The rows below are bulk-tissue datasets we checked ourselves: the direction agrees but the signal is weak, because the effect is specific to microglia and diluted in tissue.

So the chain is complete at the level of association: risk variants, two microglial enhancers, enhancer closure in DAM, a link to RASGEF1C, and a risk allele that lowers RASGEF1C. From this we propose a testable model: **the risk allele weakens, in homeostatic microglia, the enhancers that would normally close only in the DAM state.** This is the most novel finding of the study.

---

## 第 16 页｜图 7：哪些转录因子写入了 DAM 染色质 · Slide 16 | Figure 7: which transcription factors write DAM chromatin

![图7](figures/Fig7.png)

**中文**

我们知道了哪些元件被改写，也知道了其中哪一对承载遗传风险。最后一个问题是：**谁改写了这些元件？**找到上游的转录因子，才能说明这是一次"有组织的改写"，也能为实验提供更上游的干预靶点。

**7a** 用全部约 3.2 万个元件，估计每类转录因子的结合位点在 DAM 中整体是更开还是更关。为什么用全部元件？因为一个转录因子的作用分散在成千上万个位点上，每个位点的变化都很小，合起来才看得清。结果是：AP-1、NRF2/MAF、C/EBP、MiT/TFE 的位点更开放，MEF2 的位点更关闭，海马队列也复现了。这些因子的功能很说得通：MiT/TFE 管溶酶体和自噬，NRF2 管抗氧化，C/EBP 和 AP-1 参与激活，这些都和 DAM 吞噬、清除的表型一致；而 MEF2C 是维持小胶质细胞稳态的因子。

**7b** 回答"具体是哪一个"。motif 只能告诉我们"哪一类"，因为同一家族的因子识别几乎相同的序列，所以我们看因子自身的表达。MITF 的 RNA 大幅上升，和它的位点活性同向，是激活因子。有意思的是 BHLHE41：它的 RNA 下降，而它识别的 E-box 位点反而更开放。BHLHE41 和 MITF 识别相似的序列，一个下降、一个上升，提示一种"开关"：**抑制因子撤出，激活因子进入**。

**7c** 显示 392 个 motif 的活性在两个队列中相关 0.69。**7d** 把转录因子、元件和基因连成网络，例如 MiT/TFE 连到溶酶体和自噬基因。不过高可信度的连接只有 42 条，所以它更适合作为下一步扰动实验的假设。**7e** 显示，没有单个转录因子能解释稳态细胞的偏移，这和图 5 的修正一致。

**English**

We know which elements are rewritten and which pair carries genetic risk. The last question is: **who rewrites them?** Finding the upstream transcription factors shows the change is organised, and gives more upstream targets for experiments.

Panel **a** uses all 32,000 elements to estimate, for each family of transcription-factor binding sites, whether its sites open or close in DAM overall. Why use all elements? Because a factor acts at thousands of sites, each changing only a little; only together do they become visible. AP-1, NRF2/MAF, C/EBP and MiT/TFE sites open, MEF2 sites close, and the hippocampal cohort replicates this. The functions fit: MiT/TFE controls lysosomes and autophagy, NRF2 the antioxidant response, C/EBP and AP-1 activation, all consistent with the phagocytic, clearing phenotype of DAM, while MEF2C maintains microglial homeostasis.

Panel **b** asks which family member it is. A motif only tells us the family, because members recognise nearly the same sequence, so we look at each factor's own expression. MITF RNA rises strongly, in the same direction as its site activity: an activator. BHLHE41 is interesting: its RNA falls while the E-box sites it recognises become more open. BHLHE41 and MITF recognise similar sequences, one falling and one rising, which suggests a switch: **the repressor leaves and the activator comes in**.

Panel **c** shows that the activities of 392 motifs correlate at 0.69 between the two cohorts. Panel **d** links factors, elements and genes into a network, for example MiT/TFE to lysosomal and autophagy genes. But only 42 links are high-confidence, so it is best read as a set of hypotheses for perturbation. Panel **e** shows that no single factor explains the homeostatic shift, consistent with the correction in Figure 5.

---

## 第 17 页｜图 S7：MITF 的系统排序 · Slide 17 | Figure S7: systematic ranking of MITF

![图S7](figures/FigS7.png)

**中文**

为了更严格地回答"MITF 在所有候选中排第几、这个排名稳不稳"，我们把 327 个候选转录因子放在 8 条证据上综合排序，包括位点活性、两个独立复现、因子自身表达、同一个核中的特异耦合、表达量、家族份额和已知靶基因。

**S7a** 显示 MITF 综合排第一。值得注意的是，它的领先并不来自位点活性本身，这一项它只排第 24；而是来自能区分同家族成员的几条证据同时成立：自身表达上升、在同一个核中与自身位点特异耦合、在海马中复现最强。**S7b** 中 200 次供体重抽样，98% 排第一。**S7c** 中去掉任何一条证据，MITF 仍在前两名。

需要说明的是，2026 年已有研究在小鼠中用扰动实验确立了 MiT/TFE 是 DAM 程序的主调控因子，人脑大队列中也有类似证据。所以我们的结果是**完全独立的路线得到的同一答案**，并且具体到了家族成员 MITF，同时发现了 BHLHE41 的此消彼长。

**English**

To ask more rigorously where MITF ranks among all candidates and how stable that rank is, we ranked 327 candidate factors on eight lines of evidence: site activity, two independent replications, the factor's own expression, factor-specific coupling in the same nuclei, abundance, share within its family and known targets.

Panel **a** shows MITF ranked first overall. Notably, its lead does not come from site activity itself, on which it ranks only 24th, but from the lines that tell family members apart holding together: its own expression rises, it couples specifically to its own sites in the same nuclei, and it replicates most strongly in the hippocampus. In panel **b**, it ranks first in 98% of 200 donor bootstraps. In panel **c**, removing any single line keeps it in the top two.

I should add that in 2026, perturbation studies in mice established MiT/TFE factors as master regulators of the DAM program, with supporting evidence in a large human cohort. Our result is therefore **the same answer reached by a completely independent route**, resolved down to the family member MITF, together with the reciprocal change of BHLHE41.

---

## 第 18 页｜结论 · Slide 18 | Conclusions

**中文**

最后总结一下。

第一，回到核心问题：**AD 病理相关的变化以细胞特异为主，而不是所有细胞共同的程序**。胶质细胞最突出，而且这种特异变化在两个独立队列中高度一致。

第二，最典型的"共同程序"DNA 修复，在从供体到 25 微米的所有尺度上都没有特异改变，在大队列中排除了超过正负 0.15 的效应。结合别人证明 AD 神经元确实有 DNA 损伤，我们可以概括为：**有损伤，但没有特异的修复应答**。已报道的共同信号中，只有 cohesin 装载轴是真实的，它指向三维基因组。

第三，一个对领域的提醒：**图谱越大，通路层面的假阳性越多**；逐个基因的结论则基本可靠。

第四，在小胶质细胞中，DAM 状态改写了数百个调控元件，在独立队列中逐个供体复现；这种改写由 MITF 等因子承载，与 BHLHE41 此消彼长。

第五，也是最新颖的发现：**疾病状态和遗传风险交汇于 RASGEF1C 的一对增强子**。风险等位基因可能在稳态细胞中"提前"削弱了 DAM 才会关闭的增强子，从而降低 RASGEF1C。

当然，我们也要清楚哪些不能说：我们不能说 AD 中没有 DNA 损伤，我们测的是应答，而不是损伤本身；我们的证据都是相关性的；RASGEF1C 增强子的作用还需要实验验证。

**English**

To sum up.

First, back to the core question: **Alzheimer's-associated change is mostly cell-type-specific, not a program shared by all cells**. Glia stand out, and their specific changes agree closely between two independent cohorts.

Second, the archetypal shared program, DNA repair, shows no specific change at any scale from donors to 25 microns, and large cohorts exclude effects beyond plus or minus 0.15. Since others have shown that Alzheimer's neurons do carry DNA damage, we can summarise this as **damage without a specific repair response**. Of the published shared signals, only the cohesin-loading axis is real, and it points to the three-dimensional genome.

Third, a caution for the field: **the larger the atlas, the more false positives at the pathway level**, while gene-level claims are largely reliable.

Fourth, in microglia the DAM state rewrites hundreds of regulatory elements, replicated donor by donor in an independent cohort; this rewriting is carried by factors such as MITF, with a reciprocal fall of BHLHE41.

Fifth, and most novel: **the disease state and genetic risk converge on a pair of enhancers at RASGEF1C**. The risk allele may weaken, already in homeostatic cells, enhancers that would otherwise close only in DAM, lowering RASGEF1C.

We should also be clear about what we cannot claim. We cannot say there is no DNA damage in Alzheimer's disease, since we measured the response, not the damage. Our evidence is correlational. And the role of the RASGEF1C enhancers still needs to be tested experimentally.

---

## 第 19 页｜下一步与致谢 · Slide 19 | Next steps and acknowledgements

**中文**

下一步最关键的实验，是在 iPSC 来源的人小胶质细胞中，分别用 CRISPRi 关闭 e1 和 e2，看 RASGEF1C 是否下降；再逐个编辑 4 个风险 SNP，确定是哪一个起作用。因为这两个元件在小鼠中不保守，必须用人源细胞。我们还想敲低 RASGEF1C，看细胞是否向 DAM 状态转变，并直接测量 MITF、MAFB、IRF8 在这两个增强子上的结合。

最后，感谢 SEA-AD、PsychAD 以及所有公开数据的贡献者，没有他们，这项研究不可能完成。谢谢大家，欢迎提问。

**English**

The most important next experiment is to silence e1 and e2 separately with CRISPRi in human iPSC-derived microglia and ask whether RASGEF1C falls, and then to edit the four risk SNPs one at a time to find the causal one. Because these elements are not conserved in mice, this has to be done in human cells. We would also like to knock down RASGEF1C to see whether cells shift toward the DAM state, and to measure directly whether MITF, MAFB and IRF8 bind these two enhancers.

Finally, thank you to SEA-AD, PsychAD and everyone who made their data public; this work would not have been possible without them. Thank you, and I'm happy to take questions.

---

## 附：常见问题（中英） · Appendix: likely questions

**问 1：你们的阴性结果是不是只是样本量不够？ / Q1: Isn't your negative result just low power?**
- 中文：不是。在 PsychAD 约 400 名供体中，我们排除了超过正负 0.15 的特异效应（图 S4）；而且同样的方法能清楚看到 DAM、cohesin、Trem2/Cd68 这些阳性对照。
- English: No. In about 400 PsychAD donors we exclude specific effects beyond plus or minus 0.15 (Figure S4), and the same methods clearly detect the positive controls: DAM, cohesin, Trem2 and Cd68.

**问 2：为什么要匹配基因长度？ / Q2: Why match on gene length?**
- 中文：在 SEA-AD 中，AD 相关的整体漂移与基因长度相关。只匹配表达量时，随机基因组的假阳性率高达 21–34%；再匹配长度后降到约 1%。
- English: In SEA-AD the disease-associated global drift depends on gene length. Matching on expression alone gives random sets a 21–34% false-positive rate; adding length brings it to about 1%.

**问 3：MITF 已经被别人报道了，你们的贡献是什么？ / Q3: MITF has been reported; what is new here?**
- 中文：我们用完全独立的路线（人脑染色质、两个队列、以人为单位）得到同一答案，并把家族精确到 MITF 而不是 TFEB 或 TFE3，同时发现了 BHLHE41 的此消彼长。
- English: We reached the same answer by a fully independent route (human brain chromatin, two cohorts, donor-level), resolved the family to MITF rather than TFEB or TFE3, and found the reciprocal fall of BHLHE41.

**问 4：RASGEF1C 的证据够强吗？ / Q4: How strong is the RASGEF1C evidence?**
- 中文：在相关性层面每一环都有支持，基因型到表达的一环有 391 人单细胞核 eQTL 的独立证据；但 4 个 SNP 完全连锁，元件在小鼠中不保守，因果需要人源细胞的 CRISPRi 和等位基因编辑。
- English: Every link is supported at the level of association, and the genotype-to-expression link has independent support from a 391-person single-nucleus eQTL study. But the four SNPs are in perfect linkage and the elements are not conserved in mice, so causality needs CRISPRi and allelic editing in human cells.

**问 5：稳态细胞的偏移会不会其实是真的？ / Q5: Could the homeostatic shift still be real?**
- 中文：有可能，但现有数据无法确认：它只出现在标签由染色质推断的供体中。要回答，需要更大的、用 RNA 定义状态的单细胞多组学队列，例如 ROSMAP 的 multiome 数据。
- English: Possibly, but current data cannot confirm it: it appears only in donors whose labels are inferred from chromatin. Answering it needs a larger single-nucleus multiome cohort with RNA-defined states, such as the ROSMAP multiome.
