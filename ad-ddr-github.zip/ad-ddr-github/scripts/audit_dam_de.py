"""Audit of the DAM-vs-homeostatic differential tests (Fig. 4a peaks, Fig. 4c gene domains).

    python scripts/audit_dam_de.py              # writes results/dam_peaks/audit/

Re-uses paired() / flip_test() from scripts/run_dam_peaks.py unchanged and checks:
 1. flip_test against a slow, loop-by-loop re-implementation (same sign matrix).
 2. Technical null: each donor's homeostatic pseudobulk is binomially split into a fake
    "DAM" part with that donor's real DAM/homeostatic depth ratio and a remainder; the
    full pipeline is run with and without thinning (expected: ~0 calls with thinning).
 3. Thinning seed: 10 independent thinning draws; stability of the 53 / 74 calls.
 4. Normalisation: global offset of d; composition of the DAM pool (share of fragments in
    tested peaks, promoter share, chemistry share); calls after per-donor median centring
    of d over tested peaks (a TMM-like scaling).
 5. Peak filter on mean pooled CPM instead of "either state".
 6. Chemistry: within-donor chemistry mismatch between the two pools and a
    chemistry-stratified d (difference computed within each chemistry, then averaged).
 7. Gene domains: (a) set test with donor as the unit (per-donor mean domain log2FC of the
    set minus matched random genes, sign-flip over donors); (b) the same on donors' 10x
    Multiome nuclei only, whose supertype labels come from their own RNA; (c) number of
    independent loci among the significant domains (overlapping +/- 50 kb windows merged).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from ddrmulti.genome import parse_peak_names, peaks_near_genes, read_gtf_genes
from run_dam_peaks import DAM, HOM, flip_test, load

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/dam_peaks/audit"
OUT.mkdir(parents=True, exist_ok=True)
N_FLIP = 2000


def calls(mean, q):
    return np.select([(q < 0.05) & (mean >= 0.5), (q < 0.05) & (mean <= -0.5)], [1, -1], 0)


def lcpm(c):
    return np.log2(c / c.sum() * 1e6 + 1)


def thin(cs, rng):
    tot = [c.sum() for c in cs]
    k = int(np.argmax(tot))
    cs = list(cs)
    cs[k] = rng.binomial(cs[k].astype(np.int64), min(tot) / tot[k]).astype(float)
    return cs


def slow_flip(D, S):
    n = D.shape[0]
    t = D.mean(0) / (D.std(0, ddof=1) / np.sqrt(n))
    a = np.abs(t)
    null = np.zeros(len(a))
    for s in S:
        Df = D * s[:, None]
        tf = np.abs(Df.mean(0) / (Df.std(0, ddof=1) / np.sqrt(n)))
        tf.sort()
        null += len(tf) - np.searchsorted(tf, a, side="left")
    null /= len(S)
    obs = (a[None, :] <= a[:, None]).sum(0)          # number of peaks with |t| >= own |t|
    fdr = np.minimum(null / obs, 1)
    order = np.argsort(a)
    q = np.empty_like(fdr)
    q[order] = np.minimum.accumulate(fdr[order])       # min over thresholds <= own |t|
    return q


def main():
    rng = np.random.default_rng(1)
    d = ROOT / "data/processed/atac_pb_micro"
    peaks = parse_peak_names((d / "peaks.txt").read_text().split())
    rows, M = load(d)
    donors = pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"].tolist()
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    keep = peaks.index.get_indexer(res["peak"])
    prom = (res["class"] == "promoter").to_numpy()
    pub = np.select([res["call"] == "DAM-open", res["call"] == "DAM-closed"], [1, -1], 0)
    log, rep = [], {}

    def say(s=""):
        print(s)
        log.append(s)

    # raw per-donor count vectors, total and by chemistry
    raw, chem = {}, {}
    for dn in donors:
        for st in (DAM, HOM):
            for meth in ("10xMulti", "10xATAC_v1.1"):
                ix = rows.index[(rows["donor"] == dn) & (rows["subclass"] == st) & (rows["method"] == meth)].to_numpy()
                chem[dn, st, meth] = np.asarray(M[ix].sum(0)).ravel() if len(ix) else np.zeros(M.shape[1])
            raw[dn, st] = chem[dn, st, "10xMulti"] + chem[dn, st, "10xATAC_v1.1"]

    def D_from(pairs_, centre=False):
        D = []
        for a, b in pairs_:
            x = lcpm(a)[keep] - lcpm(b)[keep]
            D.append(x - np.median(x) if centre else x)
        return np.array(D)

    # ---- 1. implementation check
    sub = rng.choice(len(keep), 3000, replace=False)
    D0 = D_from([thin((raw[dn, DAM], raw[dn, HOM]), np.random.default_rng(0)) for dn in donors])[:, sub]
    r1, r2 = np.random.default_rng(5), np.random.default_rng(5)
    _, _, _, q_fast = flip_test(D0, 300, r1)
    S = r2.choice([-1.0, 1.0], size=(300, D0.shape[0]))
    q_slow = slow_flip(D0, S)
    say(f"1. flip_test vs slow re-implementation (3,000 peaks, 300 flips): max |q diff| = {np.abs(q_fast - q_slow).max():.2e}")

    # ---- 2. technical null
    say("\n2. Technical null (homeostatic pool split binomially at each donor's real DAM/homeostatic depth ratio):")
    for thin_on in (True, False):
        nr = []
        for rep_ in range(5):
            g = np.random.default_rng(100 + rep_)
            pr = []
            for dn in donors:
                h = raw[dn, HOM].astype(np.int64)
                f = raw[dn, DAM].sum() / (raw[dn, DAM].sum() + h.sum())
                fake = g.binomial(h, f).astype(float)
                rest = (h - fake).astype(float)
                pr.append(thin((fake, rest), g) if thin_on else (fake, rest))
            Dn = D_from(pr)
            mn, t, p, q = flip_test(Dn, N_FLIP, g)
            c = calls(mn, q)
            nr.append(((c == 1).sum(), (c == -1).sum(), (q < 0.05).sum(), np.median(mn)))
        nr = np.array(nr)
        say(f"   thinning {'on ' if thin_on else 'off'}: open {nr[:, 0].mean():.1f}, closed {nr[:, 1].mean():.1f}, "
            f"q<0.05 any size {nr[:, 2].mean():.1f}, median d {nr[:, 3].mean():+.3f} (5 replicates)")
        rep[f"null_thin_{thin_on}"] = nr

    # ---- 3. thinning seeds
    say("\n3. Thinning seed stability (10 draws):")
    seeds = []
    for s in range(10):
        g = np.random.default_rng(1000 + s)
        Ds = D_from([thin((raw[dn, DAM], raw[dn, HOM]), g) for dn in donors])
        mn, t, p, q = flip_test(Ds, N_FLIP, g)
        c = calls(mn, q)
        seeds.append(c)
    seeds = np.array(seeds)
    n_open, n_closed = (seeds == 1).sum(1), (seeds == -1).sum(1)
    freq = np.array([(seeds[:, i] == pub[i]).mean() if pub[i] else np.nan for i in range(len(pub))])
    ever = (seeds != 0).any(0)
    stable = (np.abs(seeds.mean(0)) >= 0.5)
    say(f"   open {n_open.min()}-{n_open.max()} (median {np.median(n_open):.0f}); closed {n_closed.min()}-{n_closed.max()} "
        f"(median {np.median(n_closed):.0f}); published calls re-called in >= 5/10 draws: "
        f"{np.nanmean(freq[pub != 0] >= 0.5):.0%}, median re-call rate {np.nanmedian(freq[pub != 0]):.0%}")
    say(f"   called in >= 5/10 draws: {stable.sum()} (published {int((pub != 0).sum())}); ever called: {ever.sum()}; "
        f"sign flips between draws: {int(((seeds == 1).any(0) & (seeds == -1).any(0)).sum())}")
    res["audit_recall_rate"] = freq
    res["audit_call_freq"] = (seeds != 0).mean(0)

    # ---- 4. normalisation / composition
    say("\n4. Normalisation and pool composition (thinned, seed 0):")
    g = np.random.default_rng(0)
    pairs0 = [thin((raw[dn, DAM], raw[dn, HOM]), g) for dn in donors]
    comp = pd.DataFrame([{"donor": dn, "inpeaks_dam": a[keep].sum() / a.sum(), "inpeaks_hom": b[keep].sum() / b.sum(),
                          "prom_dam": a[keep[prom]].sum() / a[keep].sum(), "prom_hom": b[keep[prom]].sum() / b[keep].sum(),
                          "multi_dam": chem[dn, DAM, "10xMulti"].sum() / raw[dn, DAM].sum(),
                          "multi_hom": chem[dn, HOM, "10xMulti"].sum() / raw[dn, HOM].sum(),
                          "nuc_dam": rows.loc[(rows.donor == dn) & (rows.subclass == DAM), "n_nuclei"].sum(),
                          "nuc_hom": rows.loc[(rows.donor == dn) & (rows.subclass == HOM), "n_nuclei"].sum()}
                         for dn, (a, b) in zip(donors, pairs0)])
    comp.to_csv(OUT / "pool_composition.csv", index=False)
    for k in ("inpeaks", "prom", "multi"):
        w = stats.wilcoxon(comp[f"{k}_dam"], comp[f"{k}_hom"])
        say(f"   {k:8s} DAM {comp[f'{k}_dam'].median():.3f} vs homeostatic {comp[f'{k}_hom'].median():.3f} "
            f"(paired Wilcoxon p = {w.pvalue:.2g})")
    Dr = D_from(pairs0)
    med = np.median(Dr, 1)
    say(f"   per-donor median d over tested peaks: {np.median(med):+.3f} (range {med.min():+.2f} to {med.max():+.2f}); "
        f"Spearman with log2 share-in-peaks ratio: "
        f"{stats.spearmanr(med, np.log2(comp['inpeaks_dam'] / comp['inpeaks_hom'])).statistic:.2f}")
    mn, t, p, q = flip_test(D_from(pairs0, centre=True), N_FLIP, g)
    cc = calls(mn, q)
    say(f"   per-donor median-centred d: open {(cc == 1).sum()}, closed {(cc == -1).sum()}; "
        f"overlap with published open {((cc == 1) & (pub == 1)).sum()}/{(pub == 1).sum()}, "
        f"closed {((cc == -1) & (pub == -1)).sum()}/{(pub == -1).sum()}; opposite-sign calls {((cc * pub) < 0).sum()}")
    res["log2fc_centred"], res["q_centred"], res["call_centred"] = mn, q, cc

    # ---- 5. filter
    pooled = {st: sum(raw[dn, st] for dn in donors) for st in (DAM, HOM)}
    cpm = {st: v / v.sum() * 1e6 for st, v in pooled.items()}
    avg = (cpm[DAM] + cpm[HOM]) / 2
    keep_mean = np.flatnonzero(avg >= 5)
    in_both = np.isin(keep, keep_mean)
    say(f"\n5. Filter on mean CPM >= 5: {len(keep_mean)} peaks (vs {len(keep)}); published calls retained: "
        f"open {(in_both & (pub == 1)).sum()}/{(pub == 1).sum()}, closed {(in_both & (pub == -1)).sum()}/{(pub == -1).sum()}")
    Dm = []
    g = np.random.default_rng(0)
    for dn in donors:
        a, b = thin((raw[dn, DAM], raw[dn, HOM]), g)
        Dm.append(lcpm(a)[keep_mean] - lcpm(b)[keep_mean])
    mn, t, p, q = flip_test(np.array(Dm), N_FLIP, g)
    cm = calls(mn, q)
    mp = pd.Series(cm, index=keep_mean).reindex(keep).fillna(0).to_numpy()
    say(f"   calls: open {(cm == 1).sum()}, closed {(cm == -1).sum()}; of published (retained) re-called: "
        f"{((mp == pub) & (pub != 0) & in_both).sum()}/{((pub != 0) & in_both).sum()}")

    # ---- 6. chemistry
    say("\n6. Chemistry:")
    say(f"   multiome share of fragments, DAM vs homeostatic pool: median |difference| "
        f"{np.median(np.abs(comp['multi_dam'] - comp['multi_hom'])):.2f}; donors with |diff| > 0.2: "
        f"{int((np.abs(comp['multi_dam'] - comp['multi_hom']) > 0.2).sum())}/{len(comp)}")
    Ds, g = [], np.random.default_rng(0)
    for dn in donors:
        parts, w = [], []
        for meth in ("10xMulti", "10xATAC_v1.1"):
            a, b = chem[dn, DAM, meth], chem[dn, HOM, meth]
            if a.sum() > 2e4 and b.sum() > 2e4:
                a, b = thin((a, b), g)
                parts.append(lcpm(a)[keep] - lcpm(b)[keep])
                w.append(min(a.sum(), b.sum()))
        if parts:
            Ds.append(np.average(parts, axis=0, weights=w))
    mn, t, p, q = flip_test(np.array(Ds), N_FLIP, g)
    cs_ = calls(mn, q)
    say(f"   chemistry-stratified d ({len(Ds)} donors): open {(cs_ == 1).sum()}, closed {(cs_ == -1).sum()}; "
        f"effect r with published {np.corrcoef(mn, res['log2fc'])[0, 1]:.2f}; published calls same sign "
        f"{(np.sign(mn[pub != 0]) == pub[pub != 0]).mean():.0%}, re-called {((cs_ == pub) & (pub != 0)).sum()}/{(pub != 0).sum()}")
    res["log2fc_chemstrat"], res["q_chemstrat"] = mn, q
    lowc = res["cpm_hom"] < np.median(res["cpm_hom"])
    say(f"   stratified closed calls in low-count half: {(lowc & (cs_ == -1)).mean() / max((cs_ == -1).mean(), 1e-9):.0%}; "
        f"published closed in low-count half: {(lowc & (pub == -1)).sum()}/{(pub == -1).sum()}, open {(lowc & (pub == 1)).sum()}/{(pub == 1).sum()}")

    # ---- 7. gene domains
    say("\n7. Gene domains:")
    G = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz")
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    pooled_t = sum(a + b for a, b in pairs0)
    use = np.flatnonzero(pooled_t / pooled_t.sum() * 1e6 >= 1)
    pr = peaks_near_genes(peaks.iloc[use], genes, 50_000)
    gidx = pd.Index(G["gene"])
    pr = pr[pr["gene"].isin(gidx)]
    P = sp.csr_matrix((np.ones(len(pr)), (peaks.index.get_indexer(pr["peak"]), gidx.get_indexer(pr["gene"]))),
                      shape=(len(peaks), len(gidx)))
    P.data[:] = 1

    def dom_D(pairs_):
        return np.array([np.log2(a @ P / a.sum() * 1e6 + 1) - np.log2(b @ P / b.sum() * 1e6 + 1) for a, b in pairs_])

    expr = G[G["rna_expressed"].astype("boolean").fillna(False).astype(bool)]
    sets = {"RNA DAM-up top 200": expr.nlargest(200, "rna_t")["gene"], "RNA DAM-down top 200": expr.nsmallest(200, "rna_t")["gene"]}
    strat = (pd.qcut(G["n_peaks"].rank(method="first"), 5, labels=False).to_numpy() * 5
             + pd.qcut(G["domain_log2cpm"].rank(method="first"), 5, labels=False).to_numpy())
    by = {s: np.flatnonzero(strat == s) for s in np.unique(strat)}

    def donor_set_test(Dd, label):
        out = []
        for name, gs in sets.items():
            gi = gidx.get_indexer(gs)
            bg = np.array([[g.choice(by[s]) for s in strat[gi]] for _ in range(50)])
            contrast = Dd[:, gi].mean(1) - np.mean([Dd[:, b].mean(1) for b in bg], axis=0)
            Sf = g.choice([-1.0, 1.0], size=(10000, len(contrast)))
            nl = np.abs(Sf @ contrast)
            pf = (np.sum(nl >= abs(contrast.sum())) + 1) / (len(nl) + 1)
            tt = stats.ttest_1samp(contrast, 0)
            out.append({"data": label, "set": name, "n_donors": len(contrast), "mean_contrast": contrast.mean(),
                        "donors_same_sign": int((np.sign(contrast) == np.sign(contrast.mean())).sum()),
                        "t": tt.statistic, "p_t": tt.pvalue, "p_flip": pf})
        return out

    g = np.random.default_rng(7)
    rows7 = donor_set_test(dom_D(pairs0), "all nuclei (23 donors)")
    pm = []
    for dn in donors:
        a, b = chem[dn, DAM, "10xMulti"], chem[dn, HOM, "10xMulti"]
        if (rows.loc[(rows.donor == dn) & (rows.subclass == DAM) & (rows.method == "10xMulti"), "n_nuclei"].sum() >= 5
                and b.sum() > 0):
            pm.append(thin((a, b), g))
    rows7 += donor_set_test(dom_D(pm), f"10x Multiome nuclei only ({len(pm)} donors)")
    T7 = pd.DataFrame(rows7)
    T7.to_csv(OUT / "domain_set_tests_donor_unit.csv", index=False)
    say(T7.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    sig = G[G["q"] < 0.05].join(genes[["chrom", "tss"]], on="gene").dropna(subset=["tss"]).sort_values(["chrom", "tss"])
    loci = 0
    for (_, sgn), s in sig.groupby(["chrom", np.sign(sig["t"])]):
        tss = s["tss"].to_numpy()
        loci += 1 + int((np.diff(tss) > 100_000).sum())
    say(f"   significant domains {len(sig)} -> independent loci (same direction, TSS > 100 kb apart): {loci}")

    # ---- 8. biological null with real nucleus-to-nucleus variation (hippocampus multiome, per-nucleus ATAC)
    say("\n8. Nucleus-level null (hippocampus microglia, random within-donor split, ~1:4 nuclei as in SEA-AD):")
    from run_hippo_replication import load_libs
    L, _ = load_libs()
    byd = {}
    for lib, Dl in L.items():
        m = (Dl["cells"]["subclass"] == "Microglia").to_numpy()
        if m.sum():
            byd.setdefault(Dl["cells"]["donor"].iat[0], []).append(Dl["atac_cells"][m])
    byd = {k: sp.vstack(v).tocsr() for k, v in byd.items() if sum(x.shape[0] for x in v) >= 50}
    lowk = (res["cpm_hom"] < np.median(res["cpm_hom"])).to_numpy()
    for frac in (0.2, 0.1):
        nr = []
        for rep_ in range(5):
            g = np.random.default_rng(200 + rep_)
            pr = []
            for X in byd.values():
                k = max(int(round(frac * X.shape[0])), 5)
                o = g.permutation(X.shape[0])
                pr.append(thin((np.asarray(X[o[:k]].sum(0)).ravel(), np.asarray(X[o[k:]].sum(0)).ravel()), g))
            Dn = D_from(pr)
            mn, t, p, q = flip_test(Dn, N_FLIP, g)
            c = calls(mn, q)
            nr.append(((c == 1).sum(), (c == -1).sum(), (q < 0.05).sum(), np.mean(mn[lowk]), np.mean(mn[~lowk])))
        nr = np.array(nr)
        say(f"   fake-DAM share {frac:.0%} ({len(byd)} donors): open {nr[:, 0].mean():.1f}, closed {nr[:, 1].mean():.1f}, "
            f"q<0.05 any size {nr[:, 2].mean():.1f}; mean d low-count peaks {nr[:, 3].mean():+.3f}, "
            f"high-count {nr[:, 4].mean():+.3f}")

    # ---- 9. remedy: average d over thinning draws + per-donor abundance-bin centring
    say("\n9. Remedies: (A) d averaged over 20 thinning draws; (B) A + per-donor centring within 20 abundance bins")

    def avg_D(pairs_raw, n_draw, g):
        acc_ = []
        for a, b in pairs_raw:
            ds, ab = [], []
            for _ in range(n_draw):
                x, y = thin((a, b), g)
                ds.append(lcpm(x)[keep] - lcpm(y)[keep])
                ab.append((lcpm(x)[keep] + lcpm(y)[keep]) / 2)
            acc_.append((np.mean(ds, 0), np.mean(ab, 0)))
        return acc_

    def centre_bins(acc_):
        out_ = []
        for dd, ab in acc_:
            bins = pd.qcut(pd.Series(ab).rank(method="first"), 20, labels=False).to_numpy()
            off = np.array([stats.trim_mean(dd[bins == b_], 0.2) for b_ in range(20)])
            out_.append(dd - off[bins])
        return np.array(out_)

    def plain(acc_):
        return np.array([dd for dd, _ in acc_])

    prr_all = []
    for rep_ in range(3):
        g = np.random.default_rng(300 + rep_)
        prr = []
        for X in byd.values():
            k = max(int(round(0.2 * X.shape[0])), 5)
            o = g.permutation(X.shape[0])
            prr.append((np.asarray(X[o[:k]].sum(0)).ravel(), np.asarray(X[o[k:]].sum(0)).ravel()))
        prr_all.append((g, avg_D(prr, 20, g)))
    for lab, fn in (("A", plain), ("B", centre_bins)):
        nr = []
        for g, acc_ in prr_all:
            mn, t, p, q = flip_test(fn(acc_), N_FLIP, g)
            c = calls(mn, q)
            nr.append(((c == 1).sum(), (c == -1).sum(), np.mean(mn[lowk]), np.mean(mn[~lowk])))
        nr = np.array(nr)
        say(f"   null {lab} (hippocampus split, 3 reps): open {nr[:, 0].mean():.1f}, closed {nr[:, 1].mean():.1f}; "
            f"mean d low-count {nr[:, 2].mean():+.3f}, high-count {nr[:, 3].mean():+.3f}")
    g = np.random.default_rng(11)
    acc0 = avg_D([(raw[dn, DAM], raw[dn, HOM]) for dn in donors], 20, g)
    acc1 = avg_D([(raw[dn, DAM], raw[dn, HOM]) for dn in donors], 20, np.random.default_rng(12))
    prof = np.mean([[stats.trim_mean(dd[pd.qcut(pd.Series(ab).rank(method="first"), 5, labels=False).to_numpy() == b_], 0.2)
                     for b_ in range(5)] for dd, ab in acc0], 0)
    say("   SEA-AD trimmed-mean d by within-donor abundance quintile: " + ", ".join(f"{v:+.3f}" for v in prof))
    for lab, fn in (("A", plain), ("B", centre_bins)):
        v2 = [flip_test(fn(a_), N_FLIP, np.random.default_rng(13)) for a_ in (acc0, acc1)]
        c1, c2 = calls(v2[0][0], v2[0][3]), calls(v2[1][0], v2[1][3])
        say(f"   {lab}: open {(c1 == 1).sum()}, closed {(c1 == -1).sum()} (2nd thinning set: open {(c2 == 1).sum()}, "
            f"closed {(c2 == -1).sum()}; shared calls {((c1 == c2) & (c1 != 0)).sum()}); vs published: open "
            f"{((c1 == 1) & (pub == 1)).sum()}/{(pub == 1).sum()}, closed {((c1 == -1) & (pub == -1)).sum()}/{(pub == -1).sum()}, "
            f"opposite {((c1 * pub) < 0).sum()}")
        if lab == "A":
            res["v2_log2fc"], res["v2_t"], res["v2_p"], res["v2_q"] = v2[0]
            res["v2_call"], res["v2_call_seed2"] = c1, c2
    for lab, reg in (("CD9", ("chr12", 6199532)), ("PTPRG", ("chr3", 61558990)), ("RASGEF1C", ("chr5", 180201040)),
                     ("DAPK2", ("chr15", 64070898))):
        r_ = res[(res["chrom"] == reg[0]) & (res["start"] <= reg[1] + 2000) & (res["end"] >= reg[1] - 2000)]
        for _, x in r_.iterrows():
            say(f"   {lab:9s} {x['peak']}: published log2FC {x['log2fc']:+.2f} q {x['q']:.3f} ({x['call']}); "
                f"A {x['v2_log2fc']:+.2f} q {x['v2_q']:.3f}; called in {x['audit_call_freq']:.0%} of single-draw runs")
    c1 = res["v2_call"].to_numpy()
    from run_dam_regulatory import rna_lfc
    rna, _ = rna_lfc()
    rl = res["nearest_gene"].str.upper().map(rna["rna_log2fc"])
    for lab, cv in (("published", pub), ("A", c1)):
        o_, c_, ns_ = rl[cv == 1].dropna(), rl[cv == -1].dropna(), rl[cv == 0].dropna()
        say(f"   RNA of nearest gene ({lab}): open median {o_.median():+.2f} (MW p {stats.mannwhitneyu(o_, ns_).pvalue:.1g}), "
            f"closed {c_.median():+.2f} (p {stats.mannwhitneyu(c_, ns_).pvalue:.1g}), other {ns_.median():+.2f}")

    res.to_csv(OUT / "dam_peaks_audit.csv.gz", index=False)
    (OUT / "log.txt").write_text("\n".join(log) + "\n")
    print(f"\nwrote {OUT}")


if __name__ == "__main__":
    main()
