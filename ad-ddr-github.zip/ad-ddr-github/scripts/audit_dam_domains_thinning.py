"""Audit, gene domains (Fig. 4c): stability of domain calls across thinning draws.

    python scripts/audit_dam_domains_thinning.py    # writes results/dam_peaks/audit/gene_domain_thinning.csv.gz

Same domains as results/dam_regulatory/gene_domains.csv.gz; five single-draw runs (as published)
versus d averaged over 20 thinning draws (two independent sets).
"""
import numpy as np, pandas as pd, scipy.sparse as sp
from pathlib import Path
from audit_dam_de import thin, ROOT
from run_dam_peaks import DAM, HOM, flip_test, load
from ddrmulti.genome import parse_peak_names, peaks_near_genes, read_gtf_genes
d = ROOT / "data/processed/atac_pb_micro"
peaks = parse_peak_names((d / "peaks.txt").read_text().split())
rows, M = load(d)
donors = pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"].tolist()
raw = {(dn, st): np.asarray(M[rows.index[(rows.donor == dn) & (rows.subclass == st)].to_numpy()].sum(0)).ravel() for dn in donors for st in (DAM, HOM)}
G = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz")
genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
pooled = sum(raw.values()); use = np.flatnonzero(pooled / pooled.sum() * 1e6 >= 1)
pr = peaks_near_genes(peaks.iloc[use], genes, 50_000); gidx = pd.Index(G.gene); pr = pr[pr.gene.isin(gidx)]
P = sp.csr_matrix((np.ones(len(pr)), (peaks.index.get_indexer(pr.peak), gidx.get_indexer(pr.gene))), shape=(len(peaks), len(gidx))); P.data[:] = 1
def run(nd, seed):
    g = np.random.default_rng(seed); D = []
    for dn in donors:
        ds = []
        for _ in range(nd):
            a, b = thin((raw[dn, DAM], raw[dn, HOM]), g)
            ds.append(np.log2(a @ P / a.sum() * 1e6 + 1) - np.log2(b @ P / b.sum() * 1e6 + 1))
        D.append(np.mean(ds, 0))
    m, t, p, q = flip_test(np.array(D), 2000, g)
    return np.sign(t) * (q < 0.05)
pub = np.sign(G.t.to_numpy()) * (G.q.to_numpy() < 0.05)
singles = np.array([run(1, 50 + s) for s in range(5)])
print("published domains", int((pub != 0).sum()), "single-draw runs:", (singles != 0).sum(1), "published recalled in >=3/5:", ((singles == pub).sum(0)[pub != 0] >= 3).mean().round(2))
A = run(20, 99); A2 = run(20, 98)
print("averaged:", int((A != 0).sum()), "up", int((A > 0).sum()), "down", int((A < 0).sum()), "2nd:", int((A2 != 0).sum()), "shared", int(((A == A2) & (A != 0)).sum()),
      "| published recalled", int(((A == pub) & (pub != 0)).sum()), "opposite", int((A * pub < 0).sum()))
for gname in ["RGCC","ANXA2","CD9","VIM","PTPRG","RASGEF1C","P2RY12","BIN1"]:
    i = gidx.get_loc(gname); print(gname, int(pub[i]), int(A[i]), "singles", singles[:, i].tolist())
pd.DataFrame({"gene": gidx, "call_avg20": A, "call_avg20_seed2": A2, "single_draw_call_freq": (singles != 0).mean(0)}).to_csv(ROOT / "results/dam_peaks/audit/gene_domain_thinning.csv.gz", index=False)
