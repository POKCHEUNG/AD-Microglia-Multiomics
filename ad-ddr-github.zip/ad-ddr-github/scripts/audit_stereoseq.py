"""Data-adequacy audit of one GSE263789 Stereo-seq section (App NL-G-F mouse) for a local DDR test.

    python scripts/audit_stereoseq.py data/raw/gse263789 GSM8199179_mSS_18M_AD_E3 --out results/stereoseq_audit

Answers, before any hypothesis test:
  1. Depth: UMI per 10 um (bin20, ~1 cell) and 25 um (bin50) bin over tissue; genes per bin.
  2. Gene coverage: total counts and per-bin detection of DDR program genes vs markers.
  3. Plaque masks: image size vs transcript coordinates, number / size of plaques.
  4. Registration: the masks come from an adjacent section, so the check is biological -
     plaque-associated microglial genes (Cst7, Clec7a, Itgax, Cd9, Trem2, Apoe) must be
     enriched in bins at the plaque edge relative to far bins. If they are not, the masks
     cannot be used for a local test.
  5. Preliminary signal size: DDR program counts per UMI by distance ring (descriptive only).
Gem coordinates are DNB units (500 nm); this is checked against the mask dimensions.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from scipy import ndimage

from ad_ddr.signatures import all_programs

Image.MAX_IMAGE_PIXELS = None
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
PAM = ["Cst7", "Clec7a", "Itgax", "Cd9", "Trem2", "Apoe", "Lpl", "Spp1", "Axl", "Ctsd"]
OTHER = ["Gfap", "C4b", "Snap25", "Mbp", "P2ry12", "Cx3cr1", "Hexb", "Actb"]
UM_PER_DNB = 0.5


def read_gem(path: Path, chunksize: int = 20_000_000):
    with gzip.open(path, "rt") as fh:
        while True:
            line = fh.readline()
            if not line.startswith("#"):
                header = line.rstrip("\n").split("\t")
                break
    count_col = "MIDCount" if "MIDCount" in header else ("MIDCounts" if "MIDCounts" in header else header[3])
    yield header
    for ch in pd.read_csv(path, sep="\t", comment="#", usecols=["geneID", "x", "y", count_col], chunksize=chunksize,
                          dtype={"geneID": "category", "x": np.int32, "y": np.int32, count_col: np.int32}):
        yield ch.rename(columns={count_col: "n"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data")
    ap.add_argument("prefix")
    ap.add_argument("--out", default="results/stereoseq_audit")
    ap.add_argument("--plaque-grid", help="registered plaque grid (.npy, 25 um bins, y x) from register_plaque_mask.py; "
                                          "without it the mask is assumed to share the gem pixel grid")
    args = ap.parse_args()
    d = Path(args.data)
    out = Path(args.out) / args.prefix
    out.mkdir(parents=True, exist_ok=True)

    progs = {k: [g.capitalize() for g in v] for k, v in all_programs().items() if k in DDR}
    ddr_genes = sorted({g for v in progs.values() for g in v})
    focus = sorted(set(ddr_genes) | set(PAM) | set(OTHER))

    gem = read_gem(d / f"{args.prefix}_bin1_max.gem.txt.gz")
    header = next(gem)
    print("gem columns:", header)
    gene_tot, b20, b50, foc = {}, [], [], []
    xmin = ymin = np.inf
    xmax = ymax = -np.inf
    for ch in gem:
        xmin, xmax = min(xmin, ch["x"].min()), max(xmax, ch["x"].max())
        ymin, ymax = min(ymin, ch["y"].min()), max(ymax, ch["y"].max())
        g = ch.groupby("geneID", observed=True)["n"].sum()
        for k, v in g.items():
            gene_tot[k] = gene_tot.get(k, 0) + int(v)
        ch = ch.assign(bx20=ch["x"] // 20, by20=ch["y"] // 20, bx50=ch["x"] // 50, by50=ch["y"] // 50)
        b20.append(ch.groupby(["bx20", "by20"])["n"].sum())
        b50.append(ch.groupby(["bx50", "by50"])["n"].sum())
        f = ch[ch["geneID"].isin(focus)]
        foc.append(f.groupby(["bx50", "by50", "geneID"], observed=True)["n"].sum())
        print(f"  chunk: {len(ch):,} rows", flush=True)
    gene_tot = pd.Series(gene_tot).sort_values(ascending=False)
    b20 = pd.concat(b20).groupby(level=[0, 1]).sum()
    b50 = pd.concat(b50).groupby(level=[0, 1]).sum()
    foc = pd.concat(foc).groupby(level=[0, 1, 2]).sum().unstack(fill_value=0)
    foc.columns = foc.columns.astype(str)

    rep = {"coords_x": f"{xmin}-{xmax}", "coords_y": f"{ymin}-{ymax}",
           "extent_mm": f"{(xmax - xmin) * UM_PER_DNB / 1000:.1f} x {(ymax - ymin) * UM_PER_DNB / 1000:.1f}",
           "total_umi": int(gene_tot.sum()), "genes_detected": int((gene_tot > 0).sum())}
    # tissue bins: bin50 with >= 200 UMI (empirical floor; reported alongside the distribution)
    tissue50 = b50[b50 >= 200]
    rep |= {"bin50_tissue": len(tissue50), "bin50_median_umi": float(tissue50.median()),
            "bin20_median_umi_in_tissue": float(b20[b20 >= 30].median()), "bin20_tissue": int((b20 >= 30).sum())}
    print(pd.Series(rep).to_string())

    cov = pd.DataFrame({"total": gene_tot.reindex(focus).fillna(0).astype(int)})
    f50 = foc.reindex(tissue50.index).fillna(0)
    cov["frac_bin50_detected"] = [(f50[g] > 0).mean() if g in f50 else 0.0 for g in cov.index]
    cov["set"] = ["PAM" if g in PAM else ("other" if g in OTHER else "DDR") for g in cov.index]
    cov.sort_values(["set", "total"], ascending=[True, False]).to_csv(out / "gene_coverage.csv")
    prog_cov = pd.DataFrame({p: {"genes": len(gs), "genes_with_100_counts": int((cov.reindex(gs)["total"] >= 100).sum()),
                                 "counts_per_bin50": float(f50.reindex(columns=gs).fillna(0).sum(1).mean())}
                             for p, gs in progs.items()}).T
    prog_cov.to_csv(out / "program_coverage.csv")
    print("\nDDR program coverage (bin50 = 25 um):")
    print(prog_cov.to_string(float_format=lambda v: f"{v:.2f}"))

    # plaque masks
    masks = sorted(d.glob(f"{args.prefix}_*PlaqueSegmentation_Binary_Aligned.png.gz"))
    mask_rows = []
    for mf in masks:
        im = np.array(Image.open(gzip.open(mf)))
        if im.ndim == 3:
            im = im[..., 0]
        m = im > 0
        lab, n = ndimage.label(m)
        sizes = np.bincount(lab.ravel())[1:]
        eqd = 2 * np.sqrt(sizes / np.pi) * UM_PER_DNB
        mask_rows.append({"mask": mf.name, "shape_hw": im.shape, "unique_values": np.unique(im)[:6].tolist(),
                          "frac_positive": float(m.mean()), "n_objects": int(n),
                          "n_objects_ge_10um": int((eqd >= 10).sum()),
                          "median_eq_diam_um": float(np.median(eqd)) if n else np.nan})
    mrep = pd.DataFrame(mask_rows)
    mrep.to_csv(out / "mask_summary.csv", index=False)
    print("\nPlaque masks:")
    print(mrep.to_string(index=False))

    # registration check + preliminary rings with the first (lower-threshold) mask
    bx = tissue50.index.get_level_values(0).to_numpy()
    by = tissue50.index.get_level_values(1).to_numpy()
    dd = None
    if args.plaque_grid:
        g = np.load(args.plaque_grid)
        pl = g > 0.25 * g.max()
        dist = ndimage.distance_transform_edt(~pl) * 50 * UM_PER_DNB       # um, 25 um grid
        dd = dist[np.clip(by, 0, g.shape[0] - 1), np.clip(bx, 0, g.shape[1] - 1)]
        dd = np.where(pl[np.clip(by, 0, g.shape[0] - 1), np.clip(bx, 0, g.shape[1] - 1)], 0.0, dd)
    elif masks:
        im = np.array(Image.open(gzip.open(masks[0])))
        m = (im[..., 0] if im.ndim == 3 else im) > 0
        lab, _ = ndimage.label(m)
        sizes = np.bincount(lab.ravel())
        keep = sizes >= np.pi * (5 / UM_PER_DNB) ** 2           # objects >= 10 um diameter
        keep[0] = False
        m = keep[lab]
        dist = ndimage.distance_transform_edt(~m) * UM_PER_DNB    # um to nearest plaque, mask pixel = DNB assumed
        cy = np.clip(by * 50 + 25, 0, m.shape[0] - 1)            # rows = y, cols = x
        cx = np.clip(bx * 50 + 25, 0, m.shape[1] - 1)
        dd = dist[cy, cx]
    if dd is not None:
        rings = pd.cut(dd, [-1, 0.01, 25.01, 50.01, 100.01, 200.01, np.inf], labels=["in", "0-25", "25-50", "50-100", "100-200", ">200"])
        umi = tissue50.to_numpy()
        rows = []
        sets = {"PAM_markers": PAM, **progs, "Hexb": ["Hexb"], "Snap25": ["Snap25"], "Gfap": ["Gfap"], "Actb": ["Actb"]}
        for name, gs in sets.items():
            c = f50.reindex(columns=gs).fillna(0).sum(1).to_numpy()
            r = pd.DataFrame({"ring": rings, "c": c, "u": umi}).groupby("ring", observed=False).sum()
            per10k = r["c"] / r["u"] * 1e4
            rows.append({"set": name, **{f"per10k_{k}": v for k, v in per10k.items()},
                         "ratio_0-25_vs_>200": per10k["0-25"] / per10k[">200"] if per10k[">200"] > 0 else np.nan})
        ringtab = pd.DataFrame(rows)
        counts = pd.Series(rings).value_counts().reindex(rings.categories)
        ringtab.to_csv(out / "rings_preliminary.csv", index=False)
        print("\nbin50 per ring:", counts.to_dict())
        print("\nCounts per 10k UMI by distance to plaque (descriptive; registration check = PAM markers):")
        print(ringtab.to_string(index=False, float_format=lambda v: f"{v:.2f}"))
    pd.Series(rep).to_csv(out / "depth_summary.csv")
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
