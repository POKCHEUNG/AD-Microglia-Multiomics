"""Consensus TF binding sites from a ChIP-Atlas 'assembled' BED (one line per peak per
experiment): merge overlapping peaks and keep regions seen in >= MIN_EXP experiments.

    python scripts/build_chip_consensus.py in.bed out.bed [MIN_EXP]
"""
import re
import sys

import numpy as np
import pandas as pd

src, dst = sys.argv[1], sys.argv[2]
min_exp = int(sys.argv[3]) if len(sys.argv) > 3 else 10
df = pd.read_csv(src, sep="\t", header=None, skiprows=1, usecols=[0, 1, 2, 3], names=["chrom", "start", "end", "info"])
df["exp"] = df["info"].str.extract(r"ID=([^;]+)")[0]
df["cell"] = df["info"].str.extract(r"Name=[^%;]+%20\(@%20([^)]*)\)")[0].str.replace("%20", " ")
df = df[df.chrom.str.match(r"^chr[0-9XY]+$")].sort_values(["chrom", "start"])
rows = []
for chrom, d in df.groupby("chrom", sort=False):
    s, e, ex = d.start.to_numpy(), d.end.to_numpy(), d.exp.to_numpy()
    new = np.r_[True, s[1:] > np.maximum.accumulate(e)[:-1]]     # start of a merged cluster
    cid = np.cumsum(new) - 1
    g = pd.DataFrame({"cid": cid, "s": s, "e": e, "exp": ex}).groupby("cid")
    m = pd.DataFrame({"start": g.s.min(), "end": g.e.max(), "n_exp": g.exp.nunique()})
    m["chrom"] = chrom
    rows.append(m)
out = pd.concat(rows)
print(f"experiments: {df.exp.nunique()}, cell types: {df.cell.nunique()}, raw peaks: {len(df):,}, merged regions: {len(out):,}")
keep = out[out.n_exp >= min_exp][["chrom", "start", "end", "n_exp"]]
print(f"regions in >= {min_exp} experiments: {len(keep):,}; median width {int((keep.end - keep.start).median())} bp")
print("top cell types:", df.cell.value_counts().head(8).to_dict())
keep.to_csv(dst, sep="\t", header=False, index=False)
