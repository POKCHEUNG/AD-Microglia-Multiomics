"""Assemble the drafts and render each as one self-contained HTML file with the figures embedded.

    python scripts/build_draft_html.py          # Chinese: docs/manuscript_draft_zh.{md,html}
    python scripts/build_draft_html.py en       # English submission draft: docs/manuscript_en.{md,html}
    python scripts/build_draft_html.py guide    # figure guide (Chinese): docs/figure_guide_zh.{md,html}
    python scripts/build_draft_html.py story    # narrative walk-through (Chinese): docs/story_zh.{md,html}
    python scripts/build_draft_html.py talk     # bilingual talk script: docs/talk_script.{md,html}

Chinese: concatenation of docs/draft_parts/*_zh.md in file-name order (figures are placed in the text).
English: concatenation of docs/manuscript_en/*.md; each figure is placed above its legend, as in a
submission with figures embedded for review. The HTML converter is
deliberately minimal (headings, paragraphs, nested bullet / numbered lists, tables, block quotes, bold,
italic, inline code, images, rules) so that it needs no third-party package; figures are inlined as
base64 PNG, so the HTML can be opened, shared or printed to PDF on its own.
"""

from __future__ import annotations

import base64
import html
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"

CSS = """
body { font-family: -apple-system, "PingFang SC", "Helvetica Neue", Arial, sans-serif; max-width: 960px;
       margin: 2em auto; padding: 0 1.5em; line-height: 1.7; color: #1a1a1a; font-size: 15px; }
h1 { font-size: 1.6em; line-height: 1.4; } h2 { border-bottom: 1px solid #ddd; padding-bottom: .2em; margin-top: 2em; }
h3 { margin-top: 1.8em; } h4 { margin-top: 1.4em; color: #3C5488; }
table { border-collapse: collapse; margin: 1em 0; font-size: 13px; display: block; overflow-x: auto; }
th, td { border: 1px solid #ccc; padding: 4px 8px; vertical-align: top; } th { background: #f3f3f3; }
blockquote { border-left: 4px solid #3C5488; margin: 1em 0; padding: .3em 1em; background: #f7f8fb; }
img { max-width: 100%; display: block; margin: 1em auto; border: 1px solid #eee; }
figcaption { text-align: center; font-size: 13px; color: #555; margin-bottom: 1.5em; }
code { background: #f3f3f3; padding: 0 3px; border-radius: 3px; font-size: 90%; }
pre { background: #f7f7f7; padding: 1em; font-size: 13px; overflow-x: auto; line-height: 1.5; }
hr { border: 0; border-top: 1px solid #ddd; margin: 2em 0; }
"""


def inline(t: str) -> str:
    t = html.escape(t, quote=False)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<![\*\w])\*(?!\s)(.+?)(?<!\s)\*(?![\*\w])", r"<em>\1</em>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
    t = re.sub(r"\^([^\s^]+)\^", r"<sup>\1</sup>", t)                       # 10^−5^, App^NL-G-F^
    t = re.sub(r"\[(\d+(?:[–,]\d+)*)\]", r"<sup>\1</sup>", t)               # numbered citations
    return t


def image(alt: str, src: str) -> str:
    f = DOCS / src
    if not f.exists():
        return f"<p>[missing figure {html.escape(src)}]</p>"
    b64 = base64.b64encode(f.read_bytes()).decode()
    return f'<figure><img alt="{html.escape(alt)}" src="data:image/png;base64,{b64}"><figcaption>{html.escape(alt)}</figcaption></figure>'


def to_html(md: str) -> str:
    lines = md.split("\n")
    out, i = [], 0
    list_stack: list[tuple[int, str]] = []          # (indent, "ul"/"ol")

    def close_lists(to_indent=-1):
        while list_stack and list_stack[-1][0] > to_indent:
            out.append(f"</li></{list_stack.pop()[1]}>")

    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        m_img = re.match(r"!\[([^\]]*)\]\(([^)]+)\)", s)
        m_li = re.match(r"^(\s*)([-*]|\d+\.)\s+(.*)$", ln)
        if s.startswith("```"):                          # fenced code block
            close_lists()
            buf = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                buf.append(html.escape(lines[i]))
                i += 1
            out.append("<pre>" + "\n".join(buf) + "</pre>")
            i += 1
            continue
        if not s:
            close_lists()
            i += 1
            continue
        if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\s*\|[\s:|-]+\|\s*$", lines[i + 1]):
            close_lists()
            head = [c.strip() for c in s.strip("|").split("|")]
            out.append("<table><thead><tr>" + "".join(f"<th>{inline(c)}</th>" for c in head) + "</tr></thead><tbody>")
            i += 2
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in re.split(r"(?<!\\)\|", lines[i].strip().strip("|"))]
                out.append("<tr>" + "".join(f"<td>{inline(c.replace(chr(92) + '|', '|'))}</td>" for c in cells) + "</tr>")
                i += 1
            out.append("</tbody></table>")
            continue
        if m_img:
            close_lists()
            out.append(image(m_img.group(1), m_img.group(2)))
        elif s.startswith("#"):
            close_lists()
            k = len(s) - len(s.lstrip("#"))
            out.append(f"<h{k}>{inline(s[k:].strip())}</h{k}>")
        elif s == "---":
            close_lists()
            out.append("<hr>")
        elif s.startswith(">"):
            close_lists()
            buf = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                buf.append(lines[i].strip()[1:].strip())
                i += 1
            out.append("<blockquote><p>" + "<br>".join(inline(b) for b in buf) + "</p></blockquote>")
            continue
        elif m_li:
            indent = len(m_li.group(1).replace("\t", "    "))
            kind = "ol" if m_li.group(2)[0].isdigit() else "ul"
            if list_stack and indent < list_stack[-1][0]:
                close_lists(indent)
            if not list_stack or indent > list_stack[-1][0]:
                out.append(f"<{kind}><li>")
                list_stack.append((indent, kind))
            else:
                out.append("</li><li>")
            out.append(inline(m_li.group(3)))
        elif list_stack and ln.startswith(" "):
            out.append("<br>" + inline(s))                 # continuation line inside a list item
        else:
            close_lists()
            buf = [s]
            while i + 1 < len(lines) and lines[i + 1].strip() and not re.match(r"^\s*([-*#>|]|\d+\.\s|!\[|---)", lines[i + 1]):
                i += 1
                buf.append(lines[i].strip())
            out.append("<p>" + " ".join(inline(b) for b in buf) + "</p>")
        i += 1
    close_lists()
    return "\n".join(out)


def embed_figures_above_legends(md: str) -> str:
    def fig(m):
        kind, n = m.group(1), m.group(2)
        f = f"figures/Fig{'S' if kind.startswith('Supplementary') else ''}{n}.png"
        return f"![{kind} {n}]({f})\n\n" + m.group(0)
    return re.sub(r"^\*\*(Fig\.|Supplementary Fig\.) (\d+) \|", fig, md, flags=re.M)


def main():
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "en":
        parts, stem = sorted((DOCS / "manuscript_en").glob("*.md")), "manuscript_en"
        md = embed_figures_above_legends("\n\n".join(p.read_text() for p in parts))
    elif len(sys.argv) > 1 and sys.argv[1] == "talk":
        parts, stem = sorted((DOCS / "talk").glob("*.md")), "talk_script"
        md = "\n\n".join(p.read_text() for p in parts)
    elif len(sys.argv) > 1 and sys.argv[1] == "story":
        parts, stem = sorted((DOCS / "story_zh").glob("*.md")), "story_zh"
        md = "\n\n".join(p.read_text() for p in parts)
    elif len(sys.argv) > 1 and sys.argv[1] == "guide":
        parts, stem = sorted((DOCS / "figure_guide_zh").glob("*.md")), "figure_guide_zh"
        md = "\n\n".join(p.read_text() for p in parts).replace("](../figures/", "](figures/")
    else:
        parts, stem = sorted((DOCS / "draft_parts").glob("*_zh.md")), "manuscript_draft_zh"
        md = "\n\n".join(p.read_text() for p in parts)
    (DOCS / f"{stem}.md").write_text(md)
    title = re.search(r"^# (.+)$", md, re.M).group(1)
    body = to_html(md)
    (DOCS / f"{stem}.html").write_text(
        f'<!DOCTYPE html><html><head><meta charset="utf-8"><title>{html.escape(title)}</title>'
        f"<style>{CSS}</style></head><body>{body}</body></html>")
    n = body.count("<img")
    print(f"wrote {stem}.md ({len(md.split())} words) and {stem}.html ({n} figures)")


if __name__ == "__main__":
    main()
