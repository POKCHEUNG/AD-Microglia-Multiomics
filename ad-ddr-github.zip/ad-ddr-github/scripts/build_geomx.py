"""Build a gene x AOI count matrix and AOI metadata for GSE306381 (GeoMx WTA, microglia AOIs
around Abeta plaques, human hippocampus).

    python scripts/build_geomx.py data/raw/geomx_gse306381 data/processed/geomx

DCC files hold deduplicated counts per probe (RTS_ID); the WTA PKC maps probes to genes
(one probe per gene except the negative-control probes, which are kept separately).
GEO gives no donor ID, so donors are reconstructed from the per-sample clinical fields
(age, sex, Braak, PMD, pH, brain weight, APOE, CSF).
"""

from __future__ import annotations

import gzip
import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

DONOR_FIELDS = ["group", "age", "Sex", "braak", "pmd", "ph", "weight", "apoe", "csf"]


def read_dcc(path: Path) -> tuple[str, dict, dict]:
    txt = gzip.open(path, "rt").read()
    attrs = dict(l.split(",", 1) for l in re.search(r"<NGS_Processing_Attributes>(.*?)</", txt, re.S).group(1).split()
                 if "," in l)
    counts = dict(l.split(",") for l in re.search(r"<Code_Summary>(.*?)</", txt, re.S).group(1).split())
    return re.search(r"ID,(\S+)", txt).group(1), attrs, {k: int(v) for k, v in counts.items()}


def series_meta(path: Path) -> pd.DataFrame:
    rows = {}
    for line in gzip.open(path, "rt"):
        if not line.startswith("!Sample_"):
            continue
        key, *vals = line.rstrip("\n").split("\t")
        vals = [v.strip('"') for v in vals]
        if key == "!Sample_characteristics_ch1":
            k = vals[0].split(": ", 1)[0]
            rows[k] = [v.split(": ", 1)[1] if ": " in v else v for v in vals]
        elif key in ("!Sample_geo_accession", "!Sample_title"):
            rows[key[8:]] = vals
    return pd.DataFrame(rows)


def main():
    raw, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    pkc = json.load(gzip.open(raw / "GSE306381_Hs_R_NGS_WTA_v1.0.pkc.gz", "rt"))
    probe = pd.DataFrame([{"rts": p["RTS_ID"], "gene": t["DisplayName"], "code_class": t["CodeClass"]}
                          for t in pkc["Targets"] for p in t["Probes"]]).set_index("rts")

    cols, attrs = {}, []
    for f in sorted((raw / "raw").glob("*.dcc.gz")):
        gsm = f.name.split("_")[0]
        _, a, c = read_dcc(f)
        cols[gsm] = pd.Series(c)
        attrs.append({"geo_accession": gsm, **{k: float(v) for k, v in a.items() if k != "SeqSetId"}})
    probes = pd.DataFrame(cols).fillna(0).astype(int)
    probes = probes.reindex(probe.index).fillna(0).astype(int)
    neg = probe["code_class"].str.startswith("Negative")
    genes = probes[~neg.to_numpy()].groupby(probe.loc[~neg, "gene"]).sum()
    negs = probes[neg.to_numpy()]

    meta = series_meta(raw / "GSE306381_series_matrix.txt.gz").merge(pd.DataFrame(attrs), on="geo_accession")
    meta = meta.rename(columns={"treatment": "zone"})
    meta["donor"] = "D" + pd.Series(pd.factorize(meta[DONOR_FIELDS].astype(str).agg("|".join, axis=1))[0] + 1).astype(str)
    meta["total_counts"] = genes.sum(0).reindex(meta["geo_accession"]).to_numpy()
    meta["neg_geomean"] = np.exp(np.log(negs + 1).mean(0)).reindex(meta["geo_accession"]).to_numpy()
    meta["genes_above_neg"] = (genes > meta.set_index("geo_accession")["neg_geomean"]).sum(0).reindex(meta["geo_accession"]).to_numpy()
    genes.to_csv(out / "counts_genes_x_aoi.csv.gz")
    meta.to_csv(out / "aoi_meta.csv", index=False)
    print(f"{genes.shape[0]} genes x {genes.shape[1]} AOIs; {negs.shape[0]} negative probes")
    print(meta.groupby(["group", "zone"]).agg(n_aoi=("donor", "size"), n_donor=("donor", "nunique")).to_string())
    print(meta.groupby("group")["donor"].nunique().to_string())
    print(meta[["total_counts", "neg_geomean", "genes_above_neg", "area"]].astype(float).describe().round(1).to_string())


if __name__ == "__main__":
    main()
