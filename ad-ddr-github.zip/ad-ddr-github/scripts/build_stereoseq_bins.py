"""Sum a Stereo-seq bin1 gem file into a 25 um (bin50) x gene sparse count matrix.

    python scripts/build_stereoseq_bins.py data/raw/gse263789/<prefix>_bin1_max.gem.txt.gz data/processed/stereoseq/<prefix>

Writes counts.npz (bins x genes, CSR), genes.txt and bins.csv (bx, by in 50-DNB units,
total UMI). Bins are indexed bx * 1000 + by, so they can be matched to the registered
plaque grid (y = by, x = bx).
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

BIN = 50


def main():
    gem, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    genes: dict[str, int] = {}
    parts = []
    for ch in pd.read_csv(gem, sep="\t", comment="#", usecols=["geneID", "x", "y", "MIDCount"], chunksize=20_000_000,
                          dtype={"geneID": str, "x": np.int32, "y": np.int32, "MIDCount": np.int32}):
        codes = np.array([genes.setdefault(g, len(genes)) for g in pd.unique(ch["geneID"])])
        gmap = dict(zip(pd.unique(ch["geneID"]), codes))
        gi = ch["geneID"].map(gmap).to_numpy()
        b = (ch["x"].to_numpy() // BIN) * 1000 + ch["y"].to_numpy() // BIN
        df = pd.DataFrame({"b": b, "g": gi, "n": ch["MIDCount"].to_numpy()}).groupby(["b", "g"])["n"].sum()
        parts.append(df)
        print(f"  {len(ch):,} rows, {len(genes)} genes so far", flush=True)
    s = pd.concat(parts).groupby(level=[0, 1]).sum()
    bins = pd.Index(np.unique(s.index.get_level_values(0)))
    M = sp.csr_matrix((s.to_numpy().astype(np.float32), (bins.get_indexer(s.index.get_level_values(0)),
                                                         s.index.get_level_values(1))), shape=(len(bins), len(genes)))
    sp.save_npz(out / "counts.npz", M)
    (out / "genes.txt").write_text("\n".join(sorted(genes, key=genes.get)) + "\n")
    pd.DataFrame({"bx": bins // 1000, "by": bins % 1000, "umi": np.asarray(M.sum(1)).ravel()}).to_csv(out / "bins.csv",
                                                                                                    index=False)
    print(f"{M.shape[0]} bins x {M.shape[1]} genes, {M.nnz:,} nonzeros")


if __name__ == "__main__":
    main()
