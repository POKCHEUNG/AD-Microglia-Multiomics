"""Assemble the exported Miyoshi 2024 Visium data (scripts/export_seurat_visium.R) into one h5ad.

    python scripts/build_visium_h5ad.py data/raw/miyoshi/export data/raw/miyoshi/miyoshi_visium.h5ad
"""
import sys
from pathlib import Path

import anndata as ad
import pandas as pd
import scipy.io
import scipy.sparse as sp

src, dst = Path(sys.argv[1]), sys.argv[2]
X = sp.csr_matrix(scipy.io.mmread(src / "counts.mtx").T)          # spots x genes
genes = (src / "genes.txt").read_text().split("\n")[: X.shape[1]]
spots = (src / "spots.txt").read_text().split("\n")[: X.shape[0]]
obs = pd.read_csv(src / "obs.csv", index_col=0).loc[spots]
coords = pd.read_csv(src / "coords.csv").set_index("cell").reindex(spots)
obs["image"] = coords["image"].to_numpy()
obs["donor"] = obs["Case.Year"].astype(int).astype(str) + "_" + obs["Case.Num"].astype(int).astype(str)
for c in obs.columns:
    if obs[c].dtype == object:
        obs[c] = obs[c].astype(str)
a = ad.AnnData(X, obs=obs, var=pd.DataFrame(index=pd.Index(genes, name="gene")))
a.var_names_make_unique()
a.obsm["grid"] = obs[["row", "col"]].to_numpy()
a.write_h5ad(dst, compression="gzip")
print(a)
