"""Candidate DAM elements (Fig. 6): from nearest-gene annotation to testable element-gene links.

    python scripts/fetch_eqtl_regions.py       # first; remote tabix, ~1 h
    python scripts/candidate_links.py          # writes results/candidate_links/

Elements: DAM-differential peaks carrying an AD GWAS SNP (p < 1e-5; results/dam_peaks/
gwas_candidates.csv) plus the CD9 and ANXA2 enhancers (strongest opened domains, no GWAS signal).

1. Same-nucleus element-gene co-variation (hippocampus multiome microglia, 6,302 nuclei).
   Element accessibility (fragments > 0) and gene log-normalised expression, both residualised
   on donor and log depth of their modality; Pearson r for every gene expressed in >= 2% of
   nuclei (CD9 3.7%, ANXA2 2.4%; DAPK2 0.5% is not testable) with TSS within 500 kb. Two nulls:
     z_peak   the gene against 200 background peaks on other chromosomes matched on GC and
              detection rate (as in Signac LinkPeaks)
     z_state  the element against 200 genes on other chromosomes matched on DAM-state RNA t
              and expression, so a link has to beat what shared cell state alone produces.
2. GWAS fine-mapping (Bellenguez 2022): Wakefield approximate Bayes factors, one causal
   variant, prior sd 0.2 on log OR, lead SNP +/- 500 kb; 95% credible set and the posterior
   mass inside the element, inside any microglia-accessible peak and inside any SEA-AD peak.
   (No LD reference here, so no multi-signal fine-mapping.)
3. eQTL (eQTL Catalogue: primary microglia Young 2019, OneK1K CD14+ monocytes, ROSMAP DLPFC):
   the element's GWAS SNPs looked up for every gene in the window (risk allele aligned), SuSiE
   credible sets containing them, and coloc (ABF, one causal variant, p1 = p2 = 1e-4,
   p12 = 1e-5) for every gene with eQTL p < 1e-4 in the window.
4. ENCODE-rE2G predicted target genes (CD14+ monocyte and inflammatory macrophage; no microglia
   predictions exist) for elements overlapping a predicted enhancer.
"""

from __future__ import annotations

import gzip
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from ddrmulti.genome import parse_peak_names, read_gtf_genes
from motif_dam_peaks import fetch
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/candidate_links"
OUT.mkdir(parents=True, exist_ok=True)
EXTRA = {"CD9 enhancer": "chr12:6199532-6202852", "ANXA2 enhancer": "chr15:60397094-60399674"}
LOCUS = {"chr5": {180: "RASGEF1C", 87: "chr5_87.1M"}, "chr15": {64: "DAPK2", 60: "ANXA2"}, "chr12": {6: "CD9"}}
EQTL = ["microglia_Young2019", "CD14mono_OneK1K", "brain_ROSMAP"]
SUSIE = {"microglia_Young2019": "QTD000559", "CD14mono_OneK1K": "QTD000609", "brain_ROSMAP": "QTD000434"}


def locus_of(chrom, start):
    return LOCUS.get(chrom, {}).get(start // 1_000_000)


def resid(X, C):
    return X - C @ np.linalg.lstsq(C, X, rcond=None)[0]


def lnabf(z, V, W):
    r = W / (W + V)
    return 0.5 * (np.log(1 - r) + r * z ** 2)


def logsum(x):
    m = np.max(x)
    return m + np.log(np.sum(np.exp(x - m)))


def coloc(l1, l2, p1=1e-4, p2=1e-4, p12=1e-5):
    s1, s2, s12 = logsum(l1), logsum(l2), logsum(l1 + l2)
    h = np.array([0.0, np.log(p1) + s1, np.log(p2) + s2,
                  np.log(p1) + np.log(p2) + s1 + s2 + np.log1p(-np.exp(min(s12 - s1 - s2, -1e-12))),
                  np.log(p12) + s12])
    return np.exp(h - logsum(h))


def main():
    rng = np.random.default_rng(0)
    peaks = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz").set_index("peak")
    cand = pd.read_csv(ROOT / "results/dam_peaks/gwas_candidates.csv")
    cand = cand[~cand["peak"].str.startswith("chr19:45")]                   # APOE region: handled elsewhere
    els = {f"{r.nearest_gene} {r['class']} ({r.peak})": r.peak for _, r in cand.iterrows()}
    els.update({f"{k} ({v})": v for k, v in EXTRA.items()})
    E = pd.DataFrame({"element": list(els), "peak": list(els.values())})
    E[["chrom", "start", "end"]] = peaks.loc[E["peak"], ["chrom", "start", "end"]].to_numpy()
    E["call"] = res.reindex(E["peak"])["call"].to_numpy()
    E["log2fc"] = res.reindex(E["peak"])["log2fc"].to_numpy()
    E["q"] = res.reindex(E["peak"])["q"].to_numpy()
    E["locus"] = [locus_of(c, int(s)) for c, s in zip(E["chrom"], E["start"])]
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))

    # ---------- 1. same-nucleus links
    L, gnames = load_libs()
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    A, R_ = [], []
    for lib in cache["library"].unique():
        m = (L[lib]["cells"]["subclass"] == "Microglia").to_numpy()
        A.append(L[lib]["atac_cells"][m])
        R_.append(L[lib]["rna_cells"][m])
    A, R_ = sp.vstack(A).tocsc(), sp.vstack(R_).tocsr()
    n = A.shape[0]
    det = np.asarray((A > 0).mean(0)).ravel()
    use_pk = np.flatnonzero(det >= 0.01)
    tot = np.asarray(R_.sum(1)).ravel()
    Ln = (sp.diags(1e4 / np.maximum(tot, 1)) @ R_).tocsc()
    Ln.data = np.log1p(Ln.data)
    gdet = np.asarray((R_ > 0).mean(0)).ravel()
    gi_use = np.flatnonzero(gdet >= 0.02)
    C = np.column_stack([pd.get_dummies(cache["donor"]).to_numpy(float), np.log10(np.maximum(tot, 1)),
                         np.log10(np.asarray(A.sum(1)).ravel() + 1)])
    Yg = resid(Ln[:, gi_use].toarray(), C)
    Yg = (Yg - Yg.mean(0)) / np.where(Yg.std(0) > 0, Yg.std(0), 1)
    gsym = pd.Index(gnames.str.upper())[gi_use]

    def peak_cols(ix):
        X = resid((A[:, ix] > 0).toarray().astype(float), C)
        return (X - X.mean(0)) / np.where(X.std(0) > 0, X.std(0), 1)

    pk_sub = peaks.iloc[use_pk].reset_index()
    seq = fetch(ROOT / "data/ref/hg38.fa.gz", pk_sub[["chrom", "start", "end"]])
    gc = np.array([(s.upper().count("G") + s.upper().count("C")) / max(len(s), 1) for s in seq])
    gc_bin = pd.qcut(pd.Series(gc).rank(method="first"), 10, labels=False).to_numpy()
    det_bin = pd.qcut(pd.Series(det[use_pk]).rank(method="first"), 10, labels=False).to_numpy()
    G = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz").set_index("gene")
    rt = G["rna_t"].groupby(G.index.str.upper()).first().reindex(gsym)
    g_state = pd.qcut(rt.rank(method="first").fillna(rt.rank(method="first").median()), 10, labels=False).to_numpy()
    g_expr = pd.qcut(pd.Series(gdet[gi_use]).rank(method="first"), 10, labels=False).to_numpy()
    gchrom = genes["chrom"].groupby(genes.index.str.upper()).first().reindex(gsym).to_numpy()
    gtss = genes["tss"].groupby(genes.index.str.upper()).first().reindex(gsym).to_numpy()

    link_rows = []
    for _, e in E.iterrows():
        j = peaks.index.get_loc(e["peak"])
        k = np.flatnonzero(use_pk == j)
        if not len(k):
            print("element not detected in >= 1% of hippocampus microglia:", e["element"])
            continue
        k = k[0]
        xe = peak_cols([j])[:, 0]
        mid = (int(e["start"]) + int(e["end"])) // 2
        cis = np.flatnonzero((gchrom == e["chrom"]) & (np.abs(gtss - mid) <= 500_000))
        same = (gc_bin == gc_bin[k]) & (det_bin == det_bin[k]) & (pk_sub["chrom"].to_numpy() != e["chrom"])
        bg = rng.choice(np.flatnonzero(same), min(200, same.sum()), replace=False)
        Xb = peak_cols(use_pk[bg])
        r_bg = Xb.T @ Yg[:, cis] / n                                            # bg peaks x cis genes
        r_cis = xe @ Yg[:, cis] / n
        r_all = xe @ Yg / n
        for c_i, g in enumerate(cis):
            trans = np.flatnonzero((g_state == g_state[g]) & (g_expr == g_expr[g]) & (gchrom != e["chrom"]))
            tr = rng.choice(trans, min(200, len(trans)), replace=False)
            zp = (r_cis[c_i] - r_bg[:, c_i].mean()) / r_bg[:, c_i].std()
            zs = (r_cis[c_i] - r_all[tr].mean()) / r_all[tr].std()
            link_rows.append({"element": e["element"], "gene": gsym[g], "dist_kb": (gtss[g] - mid) / 1e3,
                              "r": r_cis[c_i], "z_peak": zp, "p_peak": 2 * stats.norm.sf(abs(zp)), "z_state": zs,
                              "p_state": 2 * stats.norm.sf(abs(zs)), "gene_rna_dam_t": rt.iloc[g]})
    LK = pd.DataFrame(link_rows)
    LK["q_peak"] = LK.groupby("element")["p_peak"].transform(lambda p: stats.false_discovery_control(p))
    LK.to_csv(OUT / "same_nucleus_links.csv", index=False)
    print("1. Same-nucleus links (hippocampus microglia), best 4 genes per element by z_peak:")
    print(LK.sort_values("z_peak", ascending=False).groupby("element").head(4).sort_values(["element", "z_peak"],
          ascending=[True, False]).to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- 2. GWAS fine-mapping
    cols = ["variant_id", "p_value", "chromosome", "base_pair_location", "effect_allele", "other_allele", "beta",
            "standard_error"]
    want = {c.replace("chr", "") for c in E.loc[E["locus"].notna(), "chrom"]}
    parts = []
    for ch in pd.read_csv(ROOT / "data/ref/gwas/GCST90027158_buildGRCh38.tsv.gz", sep="\t", usecols=cols,
                          dtype={"chromosome": str}, chunksize=2_000_000):
        parts.append(ch[ch["chromosome"].isin(want)])
    gw = pd.concat(parts).dropna(subset=["beta", "standard_error"])
    gw["chrom"] = "chr" + gw["chromosome"]
    tested = parse_peak_names(res.index.tolist())
    fm_rows, cs_tabs, gwin = [], [], {}
    for locus, sub in E[E["locus"].notna() & E["peak"].isin(cand["peak"])].groupby("locus"):
        ch = sub["chrom"].iat[0]
        g = gw[gw["chrom"] == ch]
        near = g[(g["base_pair_location"] > sub["start"].min() - 250_000) & (g["base_pair_location"] < sub["end"].max() + 250_000)]
        lead = near.loc[near["p_value"].idxmin()]
        w = g[(g["base_pair_location"] - lead["base_pair_location"]).abs() <= 500_000].copy()
        w["lnabf"] = lnabf(w["beta"] / w["standard_error"], w["standard_error"] ** 2, 0.2 ** 2)
        w["pip"] = np.exp(w["lnabf"] - logsum(w["lnabf"].to_numpy()))
        w = w.sort_values("pip", ascending=False)
        w["in_cs95"] = w["pip"].cumsum().shift(fill_value=0) < 0.95
        pos = w["base_pair_location"].to_numpy()

        def mass(iv):
            ins = np.zeros(len(w), bool)
            for s_, e_ in iv:
                ins |= (pos >= s_) & (pos <= e_)
            return ins
        tp = tested[tested["chrom"] == ch]
        ap = peaks[peaks["chrom"] == ch]
        in_mg, in_any = mass(zip(tp["start"], tp["end"])), mass(zip(ap["start"], ap["end"]))
        span = 1_000_001
        for _, e in sub.iterrows():
            in_el = mass([(int(e["start"]), int(e["end"]))])
            fm_rows.append({"locus": locus, "element": e["element"], "lead_snp": lead["variant_id"], "lead_p": lead["p_value"],
                            "n_snps": len(w), "cs95_size": int(w["in_cs95"].sum()), "pip_in_element": w.loc[in_el, "pip"].sum(),
                            "top_snp_in_element": w.loc[in_el, "variant_id"].iloc[0] if in_el.any() else "",
                            "top_pip_in_element": w.loc[in_el, "pip"].max() if in_el.any() else 0.0,
                            "pip_in_microglia_peaks": w.loc[in_mg, "pip"].sum(),
                            "bp_share_microglia_peaks": (tp["end"] - tp["start"]).clip(lower=0)[
                                (tp["start"] > lead["base_pair_location"] - 500_000) & (tp["end"] < lead["base_pair_location"] + 500_000)].sum() / span,
                            "pip_in_any_seaad_peak": w.loc[in_any, "pip"].sum()})
        cs_tabs.append(w[w["in_cs95"]].assign(locus=locus, in_microglia_peak=in_mg[w["in_cs95"].to_numpy()]))
        gwin[locus] = w
        w[["variant_id", "base_pair_location", "p_value", "pip", "in_cs95"]].to_csv(OUT / f"gwas_window_{locus}.csv.gz",
                                                                                index=False)
    FM = pd.DataFrame(fm_rows)
    FM.to_csv(OUT / "gwas_finemap.csv", index=False)
    pd.concat(cs_tabs).to_csv(OUT / "gwas_credible_sets.csv.gz", index=False)
    print("\n2. GWAS fine-mapping (ABF, one causal variant):")
    print(FM.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- 3. eQTL lookup, SuSiE sets, coloc
    ens2sym = {}
    with gzip.open(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz", "rt") as fh:
        for line in fh:
            if line.startswith("#") or "\tgene\t" not in line:
                continue
            a = line.split("\t")[8]
            gid = a.split('gene_id "')[1].split('"')[0].split(".")[0]
            ens2sym[gid] = a.split('gene_name "')[1].split('"')[0]
    eq_rows, co_rows, cs_rows = [], [], []
    for ds in EQTL:
        csf = ROOT / f"data/ref/eqtl/susie/{SUSIE[ds]}.credible_sets.tsv.gz"
        cs = pd.read_csv(csf, sep="\t") if csf.exists() else pd.DataFrame()
        for locus, w in gwin.items():
            f = ROOT / f"data/processed/eqtl_regions/{ds}_{locus}.tsv.gz"
            if not f.exists():
                print(f"   missing {f.name}")
                continue
            q = pd.read_csv(f, sep="\t", dtype={"chromosome": str})
            q = q[q["type"] == "SNP"].copy()
            q["gene"] = q["gene_id"].map(ens2sym).fillna(q["gene_id"])
            q["key"] = q["position"].astype(int)
            w = w.assign(key=w["base_pair_location"].astype(int))
            els_here = E[(E["locus"] == locus) & E["peak"].isin(cand["peak"])]
            for _, e in els_here.iterrows():
                snps = w[(w["base_pair_location"] >= int(e["start"])) & (w["base_pair_location"] <= int(e["end"])) &
                         (w["p_value"] < 1e-5)]
                for _, s_ in snps.iterrows():
                    hit = q[q["key"] == s_["key"]]
                    for _, h in hit.iterrows():
                        risk = s_["effect_allele"] if s_["beta"] > 0 else s_["other_allele"]
                        if risk == h["alt"]:
                            b_risk = h["beta"]
                        elif risk == h["ref"]:
                            b_risk = -h["beta"]
                        else:
                            b_risk = np.nan
                        eq_rows.append({"dataset": ds, "element": e["element"], "snp": s_["variant_id"], "gwas_p": s_["p_value"],
                                        "risk_allele": risk, "gene": h["gene"], "eqtl_p": h["pvalue"],
                                        "beta_risk_allele": b_risk, "maf": h["maf"]})
                    if len(cs):
                        inc = cs[cs["rsid"] == s_["variant_id"]]
                        for _, c_ in inc.iterrows():
                            cs_rows.append({"dataset": ds, "element": e["element"], "snp": s_["variant_id"],
                                            "gene": ens2sym.get(c_["gene_id"].split(".")[0], c_["gene_id"]),
                                            "cs_id": c_["cs_id"], "cs_size": c_["cs_size"], "pip": c_["pip"]})
            m = w.merge(q, on="key")
            for gname, d_ in m.groupby("gene"):
                if d_["pvalue"].min() >= 1e-4:
                    continue
                l1 = lnabf(d_["beta_x"] / d_["standard_error"], d_["standard_error"] ** 2, 0.2 ** 2).to_numpy()
                l2 = lnabf(d_["beta_y"] / d_["se"], d_["se"] ** 2, 0.15 ** 2).to_numpy()
                pp = coloc(l1, l2)
                co_rows.append({"dataset": ds, "locus": locus, "gene": gname, "n_snps": len(d_), "min_eqtl_p": d_["pvalue"].min(),
                                "min_gwas_p": d_["p_value"].min(), "PP3_distinct": pp[3], "PP4_shared": pp[4]})
    EQ, CO, CSR = pd.DataFrame(eq_rows), pd.DataFrame(co_rows), pd.DataFrame(cs_rows)
    EQ.to_csv(OUT / "element_snp_eqtl.csv", index=False)
    CO.to_csv(OUT / "coloc.csv", index=False)
    CSR.to_csv(OUT / "element_snp_in_eqtl_credible_sets.csv", index=False)
    print("\n3a. Element GWAS SNPs as eQTLs (p < 0.01 shown):")
    if len(EQ):
        print(EQ[EQ["eqtl_p"] < 0.01].sort_values("eqtl_p").to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\n3b. Element SNPs inside eQTL SuSiE credible sets:")
    print(CSR.to_string(index=False) if len(CSR) else "   none")
    print("\n3c. coloc (genes with eQTL p < 1e-4 in the window), PP4 >= 0.1 or best per locus:")
    if len(CO):
        best = CO.sort_values("PP4_shared", ascending=False)
        print(best[(best["PP4_shared"] >= 0.1) | ~best.duplicated(["dataset", "locus"])].to_string(index=False,
              float_format=lambda v: f"{v:.3g}"))

    # ---------- 4. ENCODE-rE2G
    e2g_rows = []
    for lab, f in (("CD14+ monocyte", "CD14_monocyte_ENCFF789IHU_thresholded.bed.gz"),
                   ("inflammatory macrophage", "inflam_macrophage_ENCFF463AGD_thresholded.bed.gz")):
        z = pd.read_csv(ROOT / f"data/ref/e2g/{f}", sep="\t", usecols=["#chr", "start", "end", "TargetGene", "Score", "class"])
        for _, e in E.iterrows():
            o = z[(z["#chr"] == e["chrom"]) & (z["end"] > int(e["start"])) & (z["start"] < int(e["end"]))]
            for _, r in o.iterrows():
                e2g_rows.append({"element": e["element"], "cell_type": lab, "target_gene": r["TargetGene"],
                                 "score": r["Score"], "class": r["class"]})
    E2 = pd.DataFrame(e2g_rows).drop_duplicates()
    E2.to_csv(OUT / "encode_re2g.csv", index=False)
    print("\n4. ENCODE-rE2G predicted targets (thresholded):")
    print(E2.sort_values(["element", "score"], ascending=[True, False]).to_string(index=False) if len(E2) else "   none")
    E.to_csv(OUT / "elements.csv", index=False)


if __name__ == "__main__":
    main()
