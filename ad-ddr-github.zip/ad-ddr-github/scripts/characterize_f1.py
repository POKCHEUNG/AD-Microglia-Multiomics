"""What is the dominant neuronal MOFA factor (F1), and does it hide a DDR signal? (README result 18)

    python scripts/characterize_f1.py

Run after scripts/run_mofa.py (reads results/mofa/factor_scores.csv).
1. F1 vs donor covariates and neuronal technical metrics (mitochondrial fraction, multiome share)
2. random 20-gene neuronal sets vs dementia, with and without F1 as covariate (calibration)
3. gene-length axis: gene-F1 correlation and per-gene dementia effect vs log10 gene length
4. neuronal DDR programs vs CPS and dementia, with and without F1, vs 500 random sets
Writes results/mofa/{f1_covariates,f1_calibration,gene_length_axis,ddr_after_F1}.csv, docs/f1.png.
"""
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats as sst

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402
from run_mofa import VIEWS, residual_views  # noqa: E402

from ad_ddr import cohort
from ad_ddr.signatures import NEURONAL_REPAIR, all_programs
from ddrmulti.genome import read_gtf_genes
from ddrmulti.stats import bh

OUT = ROOT / "results/mofa"
rng = np.random.default_rng(0)
Z = pd.read_csv(OUT / "factor_scores.csv", index_col=0)
s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
d = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")
info = d.loc[Z.index, ["cps", "dementia", "age", "sex", "pmi", "rin"]].copy()
for c in ("cps", "dementia", "age", "pmi", "rin"):
    info[c] = pd.to_numeric(info[c], errors="coerce")
paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
idx, C, genes, _ = cohort.aggregate(paths, regions=["MTG"])
g = pd.Index(genes)
sel, full, means = residual_views(idx, C, genes, info[["cps", "age", "sex", "pmi"]])
Zc = pd.get_dummies(info[["age", "sex", "pmi"]], drop_first=True, dtype=float).to_numpy()
f1 = Z.F1.to_numpy()

# 1. covariates and technical metrics
rows = [{"variable": c, "r_with_F1": np.corrcoef(f1, info[c].astype(float))[0, 1]} for c in ("cps", "dementia", "age", "pmi", "rin")]
for v in ("Exc", "Inh"):
    lvl, grp = VIEWS[v]
    m = ((idx.level == lvl) & (idx.group == grp)).to_numpy()
    dd = idx[m].set_index("donor")
    r_ = dd.index.get_indexer(Z.index)
    M = C[np.flatnonzero(m)[r_]]
    rows.append({"variable": f"mito_fraction_{v}", "r_with_F1": np.corrcoef(f1, M[:, g.str.startswith("MT-")].sum(1) / M.sum(1))[0, 1]})
    rows.append({"variable": f"multiome_share_{v}", "r_with_F1": np.corrcoef(f1, (dd.multiome_nuclei / dd.n_nuclei).iloc[r_])[0, 1]})
cov = pd.DataFrame(rows)
cov.to_csv(OUT / "f1_covariates.csv", index=False)
print("1. F1 vs donor covariates / technical metrics\n", cov.to_string(index=False, float_format=lambda x: f"{x:+.2f}"))

# 2. calibration of random neuronal gene sets vs dementia
cal = []
for v in ("Exc", "Inh"):
    R = full[v]
    sets = [rng.choice(R.columns, 20, replace=False) for _ in range(300)]
    sc = np.column_stack([R[list(st)].mean(1) for st in sets])
    for tag, Zx in (("without F1", Zc), ("with F1", np.column_stack([Zc, f1]))):
        r, p = partial_r(sc, info.dementia.to_numpy(float), Zx)
        cal.append({"cells": v, "model": tag, "mean_r": r.mean(), "frac_p05": float((p < 0.05).mean())})
cal = pd.DataFrame(cal)
cal.to_csv(OUT / "f1_calibration.csv", index=False)
print("\n2. 300 random 20-gene sets vs dementia\n", cal.to_string(index=False, float_format=lambda x: f"{x:+.3f}"))

# 3. gene-length axis
gtf = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
glen = np.log10((gtf.end - gtf.start).clip(lower=1))
zs = (f1 - f1.mean()) / f1.std()
lrows, curves = [], {}
for v in ("Exc", "Inh", "Micro", "Astro", "Oligo"):
    R = full[v]
    genes_ok = [x for x in R.columns if not x.startswith("MT-") and x in glen.index]
    load = pd.Series(R[genes_ok].to_numpy().T @ zs / len(zs), index=genes_ok)
    rd = pd.Series(partial_r(R[genes_ok].to_numpy(), info.dementia.to_numpy(float), Zc)[0], index=genes_ok)
    q = pd.qcut(glen[genes_ok], 5, labels=False)
    curves[v] = rd.groupby(q).mean()
    lrows.append({"view": v, "n_genes": len(genes_ok), "rho_F1loading_length": sst.spearmanr(load, glen[genes_ok]).statistic,
                  "rho_dementia_length": sst.spearmanr(rd, glen[genes_ok]).statistic,
                  "dementia_r_shortest20": curves[v].iloc[0], "dementia_r_longest20": curves[v].iloc[-1]})
lt = pd.DataFrame(lrows)
lt.to_csv(OUT / "gene_length_axis.csv", index=False)
print("\n3. gene-length axis\n", lt.to_string(index=False, float_format=lambda x: f"{x:+.3f}"))

# 4. DDR programs with / without F1
progs = {p: gs for p, gs in all_programs().items() if p in NEURONAL_REPAIR + ["p53_targets"]}
drows = []
for v in ("Exc", "Inh"):
    R = full[v]
    bins = pd.qcut(means[v].reindex(R.columns).rank(method="first"), 10, labels=False)
    for prog, gs in progs.items():
        gi = [x for x in gs if x in R.columns]
        sets = [gi] + [[rng.choice(R.columns[(bins == bins[x]).to_numpy()]) for x in gi] for _ in range(500)]
        sc = np.column_stack([R[st].mean(1) for st in sets])
        for x in ("cps", "dementia"):
            for tag, Zx in (("without F1", Zc), ("with F1", np.column_stack([Zc, f1]))):
                r, p = partial_r(sc, info[x].to_numpy(float), Zx)
                null = r[1:]
                drows.append({"cells": v, "program": prog, "exposure": x, "model": tag, "r": r[0], "p": p[0],
                              "null_frac_p05": float((p[1:] < 0.05).mean()),
                              "p_vs_random": (np.sum(np.abs(null - null.mean()) >= abs(r[0] - null.mean())) + 1) / 501})
dt = pd.DataFrame(drows)
dt["q"] = dt.groupby(["exposure", "model"])["p"].transform(lambda p: bh(p.to_numpy()))
dt.to_csv(OUT / "ddr_after_F1.csv", index=False)
summ = dt.groupby(["exposure", "model"]).agg(random_frac_p05=("null_frac_p05", "mean"), ddr_p05=("p", lambda p: int((p < 0.05).sum())),
                                             min_q=("q", "min"), beyond_random=("p_vs_random", lambda p: int((p < 0.05).sum())))
print("\n4. neuronal DDR programs (10 tests per row)\n", summ.to_string(float_format=lambda x: f"{x:.2f}"))

# figure
fig, ax = plt.subplots(1, 3, figsize=(14, 3.8))
c2 = cal.pivot(index="cells", columns="model", values="frac_p05")[["without F1", "with F1"]]
c2.plot.bar(ax=ax[0], color=["0.6", "#3b6fb6"], rot=0)
ax[0].axhline(0.05, color="#c0392b", ls="--", lw=1)
ax[0].set_ylabel("random gene sets with p < 0.05")
ax[0].set_title("Random neuronal gene sets vs dementia", fontsize=9)
ax[0].legend(fontsize=7, frameon=False)
for v, col in (("Exc", "#d9822b"), ("Inh", "#3b6fb6"), ("Micro", "#2e8b57")):
    ax[1].plot(range(5), curves[v].to_numpy(), marker="o", color=col, label=v)
ax[1].axhline(0, color="0.6", lw=0.8)
ax[1].set_xticks(range(5), ["shortest", "", "", "", "longest"])
ax[1].set_xlabel("gene length quintile")
ax[1].set_ylabel("mean per-gene r with dementia")
ax[1].set_title("Dementia effect by gene length", fontsize=9)
ax[1].legend(fontsize=7, frameon=False)
dd_ = dt[dt.exposure == "dementia"].pivot_table(index=["cells", "program"], columns="model", values="r")
y = np.arange(len(dd_))
ax[2].scatter(dd_["without F1"], y, color="0.5", label="without F1")
ax[2].scatter(dd_["with F1"], y, color="#c0392b", label="with F1")
ax[2].axvline(0, color="0.6", lw=0.8)
ax[2].set_yticks(y, [f"{a} {b}" for a, b in dd_.index], fontsize=7)
ax[2].invert_yaxis()
ax[2].set_xlabel("partial r with dementia")
ax[2].set_title("Neuronal DDR programs vs dementia", fontsize=9)
ax[2].legend(fontsize=7, frameon=False)
fig.tight_layout()
fig.savefig(ROOT / "docs/f1.png", dpi=160)
print("\nwrote results/mofa/*.csv and docs/f1.png")
