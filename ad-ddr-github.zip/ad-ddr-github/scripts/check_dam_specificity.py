"""Positive-control specificity: is microglial DAM ~ CPS stronger than for random
expression-matched microglial gene sets? Also checks the neuronal programs vs CPS."""
from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr import cohort, stats
from ad_ddr.signatures import all_programs

ROOT = Path(__file__).resolve().parents[1]
COV = ["age", "sex", "pmi", "log_nuclei"]
s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
info = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]]
info[["age", "pmi"]] = info[["age", "pmi"]].apply(pd.to_numeric, errors="coerce")
paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
tests = [("group", "Microglia-PVM", "DAM", ["Immune"]), ("group", "Microglia-PVM", "cGAS_STING_IFN", ["Immune"]),
         ("class", cohort.EXC, "BER", None), ("class", cohort.INH, "BER", None)]
neuro = [p for p in paths if not any(k in p.stem for k in
         ("Astrocyte", "Immune", "Oligo", "OPC", "Endothelial", "VLMC", "Ependymal"))]
cache = {}
rng = np.random.default_rng(1)
progs = all_programs()
rows = []
for level, grp, prog, files in tests:
    key = tuple(files or ["neuro"])
    if key not in cache:
        ps = [p for p in paths if p.stem in files] if files else neuro
        cache[key] = cohort.aggregate(ps, regions=["MTG"])
    idx, C, genes, _ = cache[key]
    m = ((idx.level == level) & (idx.group == grp) & (idx.n_nuclei >= 20)).to_numpy()
    d, M = idx[m].reset_index(drop=True), C[m]
    cpm = M / M.sum(1, keepdims=True) * 1e6
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    Z = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
    bins = pd.qcut(pd.Series(L.mean(0)).rank(method="first"), 10, labels=False).to_numpy()
    base = d[["donor", "n_nuclei"]].join(info, on="donor").assign(log_nuclei=lambda x: np.log10(x.n_nuclei))
    ok = base[["cps", "age", "pmi"]].notna().all(1).to_numpy()
    base, Zk = base[ok].reset_index(drop=True), Z[ok]
    upper = pd.Series(np.arange(len(genes)), index=genes.str.upper())
    upper = upper[~upper.index.duplicated()]
    gi = upper.reindex([g.upper() for g in progs[prog]]).dropna().astype(int).to_numpy()
    gi = gi[expressed[gi]]
    pool = np.flatnonzero(expressed)
    sets = [gi] + [np.concatenate([rng.choice(pool[bins[pool] == b], 1) for b in bins[gi]]) for _ in range(500)]
    sc = pd.DataFrame({f"s{i}": Zk[:, g].mean(1) for i, g in enumerate(sets)})
    dd = pd.concat([base, sc], axis=1).assign(k=grp)
    r = stats.cps_association(dd, list(sc.columns), groupby="k", covariates=COV, n_perm=200,
                              min_donors=10).set_index("score")["r"]
    obs, null = r["s0"], r.drop("s0").to_numpy()
    rows.append({"cells": grp, "program": prog, "n_donors": len(base), "r_obs": obs, "null_mean": null.mean(),
                 "null_95": f"{np.quantile(null, .025):.2f}..{np.quantile(null, .975):.2f}",
                 "empirical_p_two_sided": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / 501})
res = pd.DataFrame(rows)
res.to_csv(ROOT / "results/cognition/cps_specificity.csv", index=False)
print(res.round(3).to_string(index=False))
