"""Is the neuronal repair-program / dementia association (a) robust to RIN and
(b) specific to DDR genes rather than a global shift in neuronal expression?

(b) compares each program with 500 random gene sets of the same size, drawn from genes
expressed in the cell class and matched on mean expression (10 bins).
"""
from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr import cohort, stats
from ad_ddr.signatures import all_programs

ROOT = Path(__file__).resolve().parents[1]
BASE = ["age", "sex", "pmi", "log_nuclei"]
PROGS = ["NHEJ", "BER", "NER", "Checkpoint", "p53_targets"]

s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
s = s[(s.region == "MTG") & ~s.severe].copy()
for c in ("age", "pmi", "rin"):
    s[c] = pd.to_numeric(s[c], errors="coerce")
print("RIN vs dementia (donor level):",
      s.drop_duplicates("donor").groupby("dementia")["rin"].mean().round(2).to_dict())

# (a) RIN
print("\n(a) partial r with dementia, adding RIN / RIN + CPS")
rows = []
for cls in (cohort.EXC, cohort.INH):
    d = s[(s.level == "class") & (s.group == cls)].dropna(subset=["rin"])
    for cov, tag in ((BASE, "base"), (BASE + ["rin"], "+RIN"), (BASE + ["rin", "cps"], "+RIN+CPS")):
        r = stats.cps_association(d.assign(k=cls), [f"rna_{p}" for p in PROGS], groupby="k", x="dementia",
                                  covariates=cov, n_perm=5000, min_donors=10)
        for _, row in r.iterrows():
            rows.append({"class": cls.split(": ")[1], "program": row.score[4:], "model": tag, "r": row.r, "p": row.p_perm})
t = pd.DataFrame(rows).pivot_table(index=["class", "program"], columns="model", values=["r", "p"])
print(t.round(3).to_string())

# (b) random expression-matched gene sets, on the released pseudobulk counts
print("\n(b) DDR programs vs 500 expression-matched random gene sets (model: +RIN+CPS)")
paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
neuro = [p for p in paths if not any(k in p.stem for k in
         ("Astrocyte", "Immune", "Oligo", "OPC", "Endothelial", "VLMC", "Ependymal"))]
idx, C, genes, meta = cohort.aggregate(neuro, regions=["MTG"])
keep = (idx.level == "class").to_numpy()
idx, C = idx[keep].reset_index(drop=True), C[keep]
info = s.drop_duplicates("donor").set_index("donor")[["dementia", "cps", "age", "sex", "pmi", "rin"]]
rng = np.random.default_rng(0)
upper = pd.Series(np.arange(len(genes)), index=genes.str.upper())
upper = upper[~upper.index.duplicated()]
progs = all_programs()
out = []
for cls in (cohort.EXC, cohort.INH):
    m = (idx.group == cls).to_numpy()
    d = idx[m].reset_index(drop=True)
    M = C[m]
    cpm = M / M.sum(1, keepdims=True) * 1e6
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    Z = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
    bins = pd.qcut(pd.Series(L.mean(0)).rank(method="first"), 10, labels=False).to_numpy()
    base = d[["donor", "n_nuclei"]].join(info, on="donor").assign(log_nuclei=lambda x: np.log10(x.n_nuclei))
    ok = base[["dementia", "cps", "age", "pmi", "rin"]].notna().all(1).to_numpy() & base.donor.isin(info.index).to_numpy()
    base, Zk = base[ok].reset_index(drop=True), Z[ok]
    pool = np.flatnonzero(expressed)
    for p in PROGS:
        gi = upper.reindex([g.upper() for g in progs[p]]).dropna().astype(int).to_numpy()
        gi = gi[expressed[gi]]
        sets = [gi] + [np.concatenate([rng.choice(pool[bins[pool] == b], 1) for b in bins[gi]]) for _ in range(500)]
        sc = pd.DataFrame({f"s{i}": Zk[:, g].mean(1) for i, g in enumerate(sets)})
        dd = pd.concat([base, sc], axis=1).assign(k=cls)
        r = stats.cps_association(dd, list(sc.columns), groupby="k", x="dementia",
                                  covariates=BASE + ["rin", "cps"], n_perm=200, min_donors=10).set_index("score")["r"]
        obs, null = r["s0"], r.drop("s0").to_numpy()
        out.append({"class": cls.split(": ")[1], "program": p, "n_genes": len(gi), "r_obs": obs,
                    "null_mean": null.mean(), "null_sd": null.std(),
                    "empirical_p_lower": (np.sum(null <= obs) + 1) / (len(null) + 1)})
res = pd.DataFrame(out)
res.to_csv(ROOT / "results/cognition/dementia_specificity.csv", index=False)
print(res.round(3).to_string(index=False))
