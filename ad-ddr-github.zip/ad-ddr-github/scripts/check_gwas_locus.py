"""Is there an AD GWAS signal at PTPRG? (Bellenguez et al. 2022, GCST90027158, GRCh38)

    python scripts/check_gwas_locus.py [GENE ...]

For each gene: minimum p-value over SNPs within the gene body +/- 100 kb. Because long
genes contain more SNPs, the minimum p is compared with 500 random protein-coding genes of
similar length (+/- 25%). Positive controls: APOE, BIN1, TREM2 (known AD loci).
"""
import gzip
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from ddrmulti.genome import read_gtf_genes

ROOT = Path(__file__).resolve().parents[1]
GWAS = ROOT / "data/ref/gwas/GCST90027158_buildGRCh38.tsv.gz"
FLANK = 100_000
genes_query = sys.argv[1:] or ["PTPRG", "APOE", "BIN1", "TREM2"]

with gzip.open(GWAS, "rt") as fh:
    header = fh.readline().rstrip("\n").split("\t")
print("columns:", header[:12])
chrom_col = next(c for c in header if c.lower() in ("chromosome", "chr", "hm_chrom"))
pos_col = next(c for c in header if c.lower() in ("base_pair_location", "pos", "bp", "hm_pos"))
p_col = next(c for c in header if c.lower() in ("p_value", "p", "pval"))
g = pd.read_csv(GWAS, sep="\t", usecols=[chrom_col, pos_col, p_col], dtype={chrom_col: str})
# usecols keeps the file's column order, so select by name before renaming
g = g[[chrom_col, pos_col, p_col]].set_axis(["chrom", "pos", "p"], axis=1)
g["chrom"] = "chr" + g["chrom"].str.replace("chr", "", regex=False)
g = g.dropna()
print(f"SNPs: {len(g):,}; genome-wide significant (p<5e-8): {(g.p < 5e-8).sum():,}")
by_chrom = {c: d.sort_values("pos") for c, d in g.groupby("chrom")}

genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
genes = genes[genes.chrom.isin(by_chrom) & genes.index.str.match(r"^[A-Z][A-Z0-9-]+$")]
genes["length"] = genes.end - genes.start


def min_p(chrom, start, end):
    d = by_chrom[chrom]
    lo, hi = np.searchsorted(d.pos.to_numpy(), [start - FLANK, end + FLANK])
    sub = d.iloc[lo:hi]
    return (sub.p.min() if len(sub) else np.nan), len(sub), (sub.pos.iloc[int(np.argmin(sub.p.to_numpy()))] if len(sub) else None)


rng = np.random.default_rng(0)
rows = []
for name in genes_query:
    r = genes.loc[name]
    mp, n, at = min_p(r.chrom, r.start, r.end)
    pool = genes[(genes.length.between(r.length * 0.75, r.length * 1.25)) & (genes.index != name)]
    null = np.array([min_p(x.chrom, x.start, x.end)[0] for _, x in pool.sample(min(500, len(pool)), random_state=0).iterrows()])
    null = null[~np.isnan(null)]
    rows.append({"gene": name, "chrom": r.chrom, "length_kb": round(r.length / 1e3), "n_snps": n, "min_p": mp,
                 "lead_pos": at, "matched_genes": len(null), "frac_matched_genes_with_lower_min_p": float((null <= mp).mean()),
                 "matched_median_min_p": float(np.median(null))})
res = pd.DataFrame(rows)
print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
out = ROOT / "results/genetics"
out.mkdir(parents=True, exist_ok=True)
res.to_csv(out / "gwas_locus_check.csv", index=False)
