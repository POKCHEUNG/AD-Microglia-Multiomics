"""Batch / data-quality check of the hippocampus homeostatic-shift replication (Fig. 5d).

    python scripts/check_hippo_batch.py         # writes results/hippo_replication/homeostatic_shift_batch.csv

Same construction as scripts/run_hippo_replication.py part 2 (microglia with a DAM RNA score
below the cohort median, pseudobulked per donor; SEA-AD DAM axis = DAM-open minus DAM-closed
peaks, z over donors; base covariates age, sex, log fragments, share of high-score microglia).
Added, one at a time and together:
  prom      fraction of the pool's fragments in promoter peaks (TSS-enrichment proxy)
  cellfrag  log10 median fragments-in-peaks per nucleus
  mixing    mean share of each nucleus' 30 RNA-PC neighbours from its own library
            (from scripts/make_supp_umap.py; library separation)
plus two designs that a library/diagnosis batch cannot produce: Braak within control donors
only, and leave-one-donor-out. p_set: 500 random axes from accessibility-matched non-DAM peaks.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.genome import parse_peak_names
from run_hippo_replication import assoc, load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/hippo_replication"


def main():
    rng = np.random.default_rng(0)
    L, _ = load_libs()
    peaks = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    pix = peaks.index.get_indexer(res["peak"])
    call = res["call"].to_numpy()
    open_i, clos_i, ns_i = (pix[call == c] for c in ("DAM-open", "DAM-closed", "ns"))
    prom = (pd.read_csv(ROOT / "results/cohesin_sites/peak_cohesin_classes.csv.gz")["class"] == "promoter").to_numpy()

    # per-nucleus DAM score, library mixing: reuse the cache written by make_supp_umap.py
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    med = np.median(cache["score"])
    A = {}
    for lib, D in L.items():
        m = (D["cells"]["subclass"] == "Microglia").to_numpy()
        if m.sum():
            A[lib] = D["atac_cells"][m]
    rows = []
    for dn_, cd in cache.groupby("donor", sort=False):
        X = sp.vstack([A[l] for l in cd["library"].unique()]).tocsr()
        cd = pd.concat([cache[(cache["library"] == l)] for l in cd["library"].unique()])
        low = (cd["score"] < med).to_numpy()
        if low.sum() < 20:
            continue
        c = np.asarray(X[low].sum(0)).ravel()
        rows.append({"donor": dn_, "L": np.log2(c / c.sum() * 1e6 + 1), "pool": c, "share_high": (~low).mean(),
                     "logfrag": np.log10(c.sum()), "prom": c[prom].sum() / c.sum(),
                     "cellfrag": np.log10(np.median(np.asarray(X[low].sum(1)).ravel())),
                     "mixing": cd.loc[low, "same_lib_nn"].mean(), "age": cd["age"].iat[0], "sex": cd["sex"].iat[0],
                     "Braak": cd["Braak"].iat[0], "group": cd["group"].iat[0]})
    HL = np.array([r["L"] for r in rows])
    HZ = (HL - HL.mean(0)) / np.where(HL.std(0) > 0, HL.std(0), 1)
    info = pd.DataFrame([{k: v for k, v in r.items() if k not in ("L", "pool")} for r in rows])
    info["path"] = info["group"].isin(["AD", "HP"]).astype(float)

    pool = sum(r["pool"] for r in rows)
    cpm = pool / pool.sum() * 1e6
    pb = np.full(len(cpm), -1)
    pb[cpm >= 1] = pd.qcut(pd.Series(np.log2(cpm[cpm >= 1] + 1)).rank(method="first"), 20, labels=False).to_numpy()
    ppool = {b: np.intersect1d(np.flatnonzero(pb == b), ns_i) for b in range(20)}
    rand = [(np.array([rng.choice(ppool[b]) for b in pb[open_i] if b >= 0]),
             np.array([rng.choice(ppool[b]) for b in pb[clos_i] if b >= 0])) for _ in range(500)]

    def axis(o, c, m):
        return HZ[m][:, o].mean(1) - HZ[m][:, c].mean(1)

    def test(label, expo, covs, m):
        I = info[m].reset_index(drop=True)
        Z = _covar_matrix(I, covs)
        x = I[expo].to_numpy(float)
        r, p = assoc(axis(open_i, clos_i, m), x, Z, rng, 2000)
        nl = np.array([np.corrcoef(_resid(x, Z), _resid(axis(o, c, m), Z))[0, 1] for o, c in rand])
        return {"model": label, "exposure": expo, "n": int(m.sum()), "r": r, "p_perm": p, "null_mean": nl.mean(),
                "p_set": (np.sum(np.abs(nl - nl.mean()) >= abs(r - nl.mean())) + 1) / (len(nl) + 1)}

    base = ["age", "sex", "logfrag", "share_high"]
    out = []
    for expo in ("Braak", "path"):
        m = info[[expo, "age"]].notna().all(1).to_numpy()
        for lab, extra in (("base", []), ("+ promoter share", ["prom"]), ("+ median fragments / nucleus", ["cellfrag"]),
                           ("+ library mixing", ["mixing"]), ("+ all three", ["prom", "cellfrag", "mixing"])):
            out.append(test(lab, expo, base + extra, m))
    m = (info["group"] == "Normal").to_numpy() & info["Braak"].notna().to_numpy()
    out.append(test("controls only (Braak 1-3)", "Braak", base, m))
    out.append(test("controls only + all three", "Braak", base + ["prom", "cellfrag", "mixing"], m))
    T = pd.DataFrame(out)

    # leave-one-donor-out, base model, Braak
    m0 = info[["Braak", "age"]].notna().all(1).to_numpy()
    loo = []
    for i in np.flatnonzero(m0):
        m = m0.copy()
        m[i] = False
        I = info[m].reset_index(drop=True)
        Z = _covar_matrix(I, base)
        loo.append(np.corrcoef(_resid(I["Braak"].to_numpy(float), Z), _resid(axis(open_i, clos_i, m), Z))[0, 1])
    T["loo_min"] = np.nan
    T.loc[(T["model"] == "base") & (T["exposure"] == "Braak"), "loo_min"] = min(loo)

    # how strongly do the quality covariates themselves track diagnosis?
    q = info[["prom", "cellfrag", "mixing", "logfrag", "share_high", "path"]].corr()["path"].drop("path")
    T.to_csv(OUT / "homeostatic_shift_batch.csv", index=False)
    info.to_csv(OUT / "homeostatic_shift_batch_donors.csv", index=False)
    print(T.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\nleave-one-out r range (Braak, base):", f"{min(loo):.2f} - {max(loo):.2f}")
    print("\ncorrelation of quality covariates with AD/HP vs control:\n", q.round(2).to_string())


if __name__ == "__main__":
    main()
