"""Is the MTG L5 ET HR ~ CPS lead real or ambient / doublet contamination?

    python scripts/check_l5et.py

L5 ET is a rare subclass (few nuclei per donor), so its pseudobulk is easily dominated by
ambient RNA from abundant glia. Checks, all in MTG non-severe donors:
  1. glial / proliferation marker load in the L5 ET pseudobulk vs CPS and vs the HR score
  2. HR ~ CPS after additionally adjusting for each contamination score
  3. per-gene: which HR genes drive the signal, and are they glia-enriched genes?
  4. library chemistry (fraction of multiome nuclei) as a confounder
"""

from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr import cohort
from ad_ddr.signatures import all_programs
from ad_ddr.stats import _covar_matrix, _resid

ROOT = Path(__file__).resolve().parents[1]
COV = ["age", "sex", "pmi", "log_nuclei"]
MARKERS = {
    "microglia": ["CSF1R", "P2RY12", "CX3CR1", "C1QB", "DOCK8"],
    "oligodendrocyte": ["MBP", "PLP1", "MOBP", "ST18", "MOG"],
    "astrocyte": ["GFAP", "AQP4", "SLC1A2", "GJA1", "ALDH1L1"],
    "OPC": ["PDGFRA", "VCAN", "OLIG1"],
    "proliferation": ["MKI67", "TOP2A", "CENPF", "PCNA"],
    "L5ET_identity": ["FEZF2", "POU3F1", "EYA4", "NPSR1"],
}


def partial_r(d, y, extra=()):
    Z = _covar_matrix(d, COV + list(extra))
    xr, yr = _resid(d["cps"].to_numpy(float), Z), _resid(d[y].to_numpy(float), Z)
    return np.corrcoef(xr, yr)[0, 1]


def perm_p(d, y, extra=(), n=5000, seed=0):
    rng = np.random.default_rng(seed)
    Z = _covar_matrix(d, COV + list(extra))
    xr, yr = _resid(d["cps"].to_numpy(float), Z), _resid(d[y].to_numpy(float), Z)
    r = np.corrcoef(xr, yr)[0, 1]
    null = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(n)])
    return (np.sum(np.abs(null) >= abs(r)) + 1) / (n + 1)


def main():
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")[["Donor ID", "Brain Region", "CPS_Local"]]
    cps.columns = ["donor", "region", "cps"]
    files = ["L5-ET", "Astrocyte", "Immune", "Oligodendrocyte", "OPC", "L5-IT"]
    idx, C, genes, meta = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{f}.h5ad" for f in files], regions=["MTG"])
    meta = meta.assign(age=pd.to_numeric(meta["age"], errors="coerce"), pmi=pd.to_numeric(meta["pmi"], errors="coerce"),
                       severe=meta["severe"].astype(str).eq("Y"))
    idx = idx.merge(cps, on=["donor", "region"], how="left").join(meta[["age", "sex", "pmi", "severe"]], on="donor")
    upper = pd.Series(np.arange(len(genes)), index=genes.str.upper())
    upper = upper[~upper.index.duplicated()]
    cpm_all = C / C.sum(1, keepdims=True) * 1e6

    # mean CPM per group across MTG donors: is a gene glia-enriched relative to L5 ET?
    grp_mean = pd.DataFrame({g: cpm_all[(idx["level"] == "group").to_numpy() & (idx["group"] == g).to_numpy()].mean(0)
                             for g in ["L5 ET", "L5 IT", "Microglia-PVM", "Oligodendrocyte", "Astrocyte", "OPC"]},
                            index=genes.str.upper())
    grp_mean = grp_mean[~grp_mean.index.duplicated()]

    m = ((idx["level"] == "group") & (idx["group"] == "L5 ET") & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool)
         & idx[["cps", "age", "pmi"]].notna().all(1)).to_numpy()
    d = idx[m].reset_index(drop=True).assign(log_nuclei=lambda x: np.log10(x["n_nuclei"]),
                                             frac_multiome=lambda x: x["multiome_nuclei"] / x["n_nuclei"])
    cpm = cpm_all[m]
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    Z = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
    print(f"L5 ET, MTG: {len(d)} donors, nuclei per donor median {d['n_nuclei'].median():.0f} "
          f"(range {d['n_nuclei'].min():.0f}-{d['n_nuclei'].max():.0f})")

    hr = upper.reindex(all_programs()["HR"]).dropna().astype(int).to_numpy()
    hr = hr[expressed[hr]]
    d["HR"] = Z[:, hr].mean(1)
    for k, gs in MARKERS.items():
        gi = upper.reindex(gs).dropna().astype(int).to_numpy()
        d[k] = L[:, gi].mean(1)        # log2 CPM, not z: keep absolute level

    print("\n1. Contamination load: Spearman with CPS and with the HR score")
    rows = []
    for k in MARKERS:
        rows.append({"marker_set": k, "mean_log2cpm": d[k].mean(),
                     "rho_cps": d[[k, "cps"]].corr("spearman").iloc[0, 1],
                     "rho_HR": d[[k, "HR"]].corr("spearman").iloc[0, 1]})
    for k in ["frac_multiome", "log_nuclei"]:
        rows.append({"marker_set": k, "mean_log2cpm": np.nan, "rho_cps": d[[k, "cps"]].corr("spearman").iloc[0, 1],
                     "rho_HR": d[[k, "HR"]].corr("spearman").iloc[0, 1]})
    t1 = pd.DataFrame(rows)
    print(t1.to_string(index=False, float_format=lambda v: f"{v:.2f}"))

    print("\n2. HR ~ CPS partial r with extra adjustment")
    adj = [(), ("microglia",), ("oligodendrocyte",), ("astrocyte",), ("OPC",), ("proliferation",), ("frac_multiome",),
           ("microglia", "oligodendrocyte", "astrocyte", "OPC", "frac_multiome")]
    t2 = pd.DataFrame([{"extra_covariates": "+".join(a) or "(base)", "r": partial_r(d, "HR", a),
                        "p_perm": perm_p(d, "HR", a)} for a in adj])
    print(t2.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    print("\n3. Per-gene HR ~ CPS (partial r) and glia enrichment (mean CPM in glia / in L5 ET)")
    g_rows = []
    for gi in hr:
        name = genes[gi].upper()
        d["_g"] = Z[:, gi]
        gm = grp_mean.loc[name]
        g_rows.append({"gene": name, "r": partial_r(d, "_g"), "cpm_L5ET": gm["L5 ET"], "cpm_L5IT": gm["L5 IT"],
                       "max_glia_over_L5ET": gm[["Microglia-PVM", "Oligodendrocyte", "Astrocyte", "OPC"]].max() / gm["L5 ET"],
                       "top_glia": gm[["Microglia-PVM", "Oligodendrocyte", "Astrocyte", "OPC"]].idxmax()})
    t3 = pd.DataFrame(g_rows).sort_values("r", ascending=False)
    print(t3.to_string(index=False, float_format=lambda v: f"{v:.2f}"))
    print(f"\nSpearman(per-gene r, glia enrichment) = "
          f"{t3[['r', 'max_glia_over_L5ET']].corr('spearman').iloc[0, 1]:.2f}")

    print("\n4. Same HR test in the abundant neighbour L5 IT (same layer, many more nuclei)")
    m2 = ((idx["level"] == "group") & (idx["group"] == "L5 IT") & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool)
          & idx[["cps", "age", "pmi"]].notna().all(1)).to_numpy()
    d2 = idx[m2].reset_index(drop=True).assign(log_nuclei=lambda x: np.log10(x["n_nuclei"]))
    c2 = cpm_all[m2]
    L2 = np.log2(c2 + 1)
    Z2 = (L2 - L2.mean(0)) / np.where(L2.std(0) > 0, L2.std(0), 1)
    e2 = (c2 >= 1).mean(0) >= 0.5
    hr2 = upper.reindex(all_programs()["HR"]).dropna().astype(int).to_numpy()
    d2["HR"] = Z2[:, hr2[e2[hr2]]].mean(1)
    print(f"L5 IT: {len(d2)} donors, r = {partial_r(d2, 'HR'):.3f}, p_perm = {perm_p(d2, 'HR'):.3g}")

    out = ROOT / "results/screen"
    out.mkdir(parents=True, exist_ok=True)
    t1.to_csv(out / "l5et_contamination.csv", index=False)
    t2.to_csv(out / "l5et_adjusted.csv", index=False)
    t3.to_csv(out / "l5et_hr_genes.csv", index=False)


if __name__ == "__main__":
    main()
