"""Check RNA/ATAC barcode pairing for multiome nuclei and ATAC X contents."""
import sys
import anndata as ad
import numpy as np

rna = ad.read_h5ad(sys.argv[1], backed="r")
atac = ad.read_h5ad(sys.argv[2], backed="r")
for name, a in [("rna", rna), ("atac", atac)]:
    print(name, a.obs["method"].value_counts().to_dict(), "| X_normalization:", a.uns.get("X_normalization"))
r = set(rna.obs_names[rna.obs["method"] == "10xMulti"])
t = set(atac.obs_names[atac.obs["method"] == "10xMulti"])
both = r & t
print(f"multiome RNA={len(r)} ATAC={len(t)} shared ids={len(both)}")
ids = sorted(both)[:2000]
same = (rna.obs.loc[ids, "Supertype"].astype(str).values == atac.obs.loc[ids, "Supertype"].astype(str).values).mean()
print(f"Supertype agreement on shared nuclei: {same:.3f}")
print("RNA has CPS:", "Continuous Pseudo-progression Score" in rna.obs)
x = atac.X[:200]
x = x.toarray() if hasattr(x, "toarray") else x
v = np.unique(x)
print("ATAC X unique values (first 10):", v[:10], "n_unique:", len(v))
