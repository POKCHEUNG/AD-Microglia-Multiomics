"""Is microglial PTPRG ~ CPS real or ambient-RNA / technical drift? (MTG, SEA-AD)

1. Where is PTPRG expressed? log2 CPM per cell class (if neurons express far more, ambient
   neuronal RNA could inflate microglial PTPRG).
2. Contamination scores in the microglial pseudobulk: neuronal markers, mitochondrial
   fraction, oligodendrocyte markers. Their r with CPS, and PTPRG ~ CPS after adjusting for each.
3. Chromatin (cannot be ambient): PTPRG promoter / gene-body accessibility in microglia from
   the 12-donor multiome, vs CPS and vs microglial PTPRG RNA in the same donors.
"""
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402

from ad_ddr import cohort, io, scoring
from ddrmulti import atac as datac
from ddrmulti.genome import read_gtf_genes

COV = ["age", "sex", "pmi", "log_nuclei"]
NEURONAL = ["SNAP25", "SYT1", "RBFOX3", "GRIN2B", "NRGN", "CAMK2A", "GAD1"]
OLIGO = ["MBP", "PLP1", "MOBP", "ST18"]

s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
info = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]]
info[["age", "pmi"]] = info[["age", "pmi"]].apply(pd.to_numeric, errors="coerce")
info = info.dropna()

# 1. expression by class
paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
idx, C, genes, _ = cohort.aggregate(paths, regions=["MTG"])
g = pd.Index(genes)
pt = np.flatnonzero(g == "PTPRG")[0]
print("1. PTPRG log2 CPM (pooled over MTG donors):")
for (lvl, grp), d in idx.groupby(["level", "group"]):
    if lvl == "class" or grp in ("Microglia-PVM", "Astrocyte", "Oligodendrocyte", "OPC", "L2/3 IT", "Sst"):
        M = C[d.index.to_numpy()].sum(0)
        print(f"   {grp:28} {np.log2(M[pt] / M.sum() * 1e6 + 1):.2f}")

# 2. contamination scores in microglia
m = ((idx.level == "group") & (idx.group == "Microglia-PVM") & idx.donor.isin(info.index) & (idx.n_nuclei >= 20)).to_numpy()
d = idx[m].reset_index(drop=True)
M = C[m]
cpm = M / M.sum(1, keepdims=True) * 1e6
L = pd.DataFrame(np.log2(cpm + 1), columns=g).T.groupby(level=0).first().T
mito = M[:, g.str.startswith("MT-")].sum(1) / M.sum(1)
D = info.loc[d.donor].reset_index().assign(log_nuclei=np.log10(d.n_nuclei.to_numpy()))
D["PTPRG"] = L["PTPRG"].to_numpy()
D["neuronal_ambient"] = L[NEURONAL].mean(1).to_numpy()
D["oligo_ambient"] = L[OLIGO].mean(1).to_numpy()
D["mito_frac"] = mito
x = D.cps.to_numpy(float)
Zb = pd.get_dummies(D[COV], drop_first=True, dtype=float)
print("\n2. microglial pseudobulk (73 donors): r with CPS | age+sex+pmi+log_nuclei")
for c in ["PTPRG", "neuronal_ambient", "oligo_ambient", "mito_frac"]:
    r, p = partial_r(D[[c]].to_numpy(float), x, Zb.to_numpy())
    print(f"   {c:18} r = {r[0]:+.3f}  p = {p[0]:.2g}")
for extra in ["neuronal_ambient", "oligo_ambient", "mito_frac"]:
    Z = pd.concat([Zb, D[[extra]]], axis=1).to_numpy(float)
    r, p = partial_r(D[["PTPRG"]].to_numpy(float), x, Z)
    print(f"   PTPRG adjusted also for {extra:16}: r = {r[0]:+.3f}  p = {p[0]:.2g}")
Z = pd.concat([Zb, D[["neuronal_ambient", "oligo_ambient", "mito_frac"]]], axis=1).to_numpy(float)
r, p = partial_r(D[["PTPRG"]].to_numpy(float), x, Z)
print(f"   PTPRG adjusted for all three:                r = {r[0]:+.3f}  p = {p[0]:.2g}")

# 3. chromatin in microglia (multiome)
gtf = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
acc = scoring.AtacAccumulator()
rna_pt = {}
for dn in io.selected_donors(ROOT / "data/meta/selected_donors.csv"):
    rna, atac = io.load_donor(*io.donor_paths(ROOT / "data/raw", dn))
    grp = scoring.cell_groups(rna.obs)
    mic = (grp == "Microglia-PVM").to_numpy()
    xg = rna[mic, "PTPRG"].X
    rna_pt[dn] = float(np.log2(np.asarray(xg.sum()) / rna.obs.loc[mic, "n_umi"].sum() * 1e6 + 1)) if mic.sum() else np.nan
    if atac.n_obs >= 500:
        gm = grp.reindex(atac.obs_names)
        k = (gm == "Microglia-PVM").to_numpy()
        if k.sum() >= 20:
            acc.add(atac[k], gm[k], dn)
    del rna, atac
holder = ad.AnnData(np.zeros((1, len(acc.var)), np.float32), var=acc.var)
row = gtf.loc["PTPRG"]
prom = pd.DataFrame({"chrom": [row.chrom], "start": [max(row.tss - 1000, 0)], "end": [row.tss + 1000]})
body = pd.DataFrame({"chrom": [row.chrom], "start": [row.start], "end": [row.end]})
res = []
for (grp_, dn), cnt in acc.counts.items():
    tot = cnt.sum()
    for name, reg in (("promoter", prom), ("gene_body", body)):
        mk = datac.peakset_mask(holder, reg)
        res.append({"donor": dn, "region": name, "n_peaks": int(mk.sum()), "n_cells": acc.n_cells[(grp_, dn)],
                    "cpm": cnt[mk].sum() / tot * 1e6})
R = pd.DataFrame(res).pivot(index="donor", columns="region", values="cpm")
R["rna_PTPRG"] = pd.Series(rna_pt)
cps_all = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv").query("`Brain Region`=='MTG'").set_index("Donor ID")["CPS_Local"]
R["cps"] = cps_all.reindex(R.index)
print(f"\n3. multiome microglia ({len(R)} donors): PTPRG peaks promoter={int(pd.DataFrame(res).query('region==\"promoter\"').n_peaks.iloc[0])}, "
      f"gene body={int(pd.DataFrame(res).query('region==\"gene_body\"').n_peaks.iloc[0])}")
for c in ["promoter", "gene_body"]:
    print(f"   {c:9} accessibility: r with CPS = {np.corrcoef(R[c], R.cps)[0,1]:+.2f}; "
          f"r with microglial PTPRG RNA = {np.corrcoef(R[c], R.rna_PTPRG)[0,1]:+.2f}  (n={len(R)}, descriptive)")
print(f"   microglial PTPRG RNA in these donors: r with CPS = {np.corrcoef(R.rna_PTPRG, R.cps)[0,1]:+.2f}")
R.to_csv(ROOT / "results/microglia_genes/ptprg_multiome.csv")
