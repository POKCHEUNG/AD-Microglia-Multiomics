"""Does microglial PTPRG relate to dementia / cognition beyond AD pathology (CPS)?

    python scripts/check_ptprg_resilience.py

SEA-AD MTG, non-severely-affected donors. Partial r of microglial PTPRG (log2 CPM) with
dementia (and CASI) adjusting for age, sex, PMI, log #nuclei, mitochondrial fraction and
CPS; permutation p; compared with 1,000 expression-matched random microglial genes.
"""
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402

rng = np.random.default_rng(0)
s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
info = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")
info = info[["cps", "dementia", "casi", "casi_interval", "age", "sex", "pmi"]].copy()
for c in ("cps", "dementia", "casi", "casi_interval", "age", "pmi"):
    info[c] = pd.to_numeric(info[c], errors="coerce")
a = ad.read_h5ad(ROOT / "data/raw/pseudobulk/Immune.h5ad")
a = a[(a.obs["Brain Region"] == "MTG") & a.obs.Supertype.astype(str).str.startswith("Micro-PVM")]
cat = pd.Categorical(a.obs["Donor ID"].astype(str))
A = sp.csr_matrix((np.ones(a.n_obs), (cat.codes, np.arange(a.n_obs))))
M = np.asarray((A @ sp.csr_matrix(a.X)).todense())
n = a.obs.groupby(cat, observed=False)["Number of nuclei"].sum().to_numpy()
donors = pd.Index(cat.categories)
keep = donors.isin(info.dropna(subset=["cps", "dementia", "age", "pmi"]).index) & (n >= 20)
g = pd.Index(a.var_names)
cpm = M[keep] / M[keep].sum(1, keepdims=True) * 1e6
expressed = (cpm >= 1).mean(0) >= 0.5
L = pd.DataFrame(np.log2(cpm[:, expressed] + 1), columns=g[expressed], index=donors[keep])
L = L.loc[:, ~L.columns.duplicated()]
D = info.loc[L.index].assign(log_nuclei=np.log10(n[keep]),
                             mito=M[keep][:, g.str.startswith("MT-")].sum(1) / M[keep].sum(1))
bins = pd.qcut(L.mean().rank(method="first"), 10, labels=False)
rows = []
for x, extra in (("dementia", []), ("casi", ["casi_interval"])):
    d = D.dropna(subset=[x] + extra)
    Lx = L.loc[d.index]
    for tag, cov in (("without CPS", []), ("with CPS", ["cps"])):
        Z = pd.get_dummies(d[["age", "sex", "pmi", "log_nuclei", "mito"] + extra + cov], drop_first=True, dtype=float).to_numpy()
        r, p = partial_r(Lx.to_numpy(), d[x].to_numpy(float), Z)
        rs = pd.Series(r, index=Lx.columns)
        obs = rs["PTPRG"]
        pool = rs.index[(bins == bins["PTPRG"]).to_numpy() & (rs.index != "PTPRG")]
        null = rs.loc[rng.choice(pool, 1000)].to_numpy()
        y = Lx["PTPRG"].to_numpy()
        Z1 = np.column_stack([np.ones(len(y)), Z]); H = Z1 @ np.linalg.pinv(Z1)
        xr, yr = d[x].to_numpy(float) - H @ d[x].to_numpy(float), y - H @ y
        perm = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(20000)])
        rows.append({"outcome": x, "model": tag, "n_donors": len(d), "r_PTPRG": obs,
                     "p_perm_two_sided": (np.sum(np.abs(perm) >= abs(obs)) + 1) / 20001,
                     "genome_rank_pct": float((rs.abs() >= abs(obs)).mean() * 100),
                     "p_vs_random_genes": (np.sum(np.abs(null - np.median(null)) >= abs(obs - np.median(null))) + 1) / 1001,
                     "random_genes_median_r": float(np.median(null))})
res = pd.DataFrame(rows)
print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
out = ROOT / "results/microglia_genes"
res.to_csv(out / "ptprg_resilience.csv", index=False)
