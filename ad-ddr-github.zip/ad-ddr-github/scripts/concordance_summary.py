"""RNA vs promoter-accessibility concordance across donors (12-donor multiome subset),
with a null from shuffling donors' ATAC values within each cell group."""
import sys
import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")

from ad_ddr.plotting import concordance_null
from ad_ddr.stats import rna_atac_concordance

out = sys.argv[1] if len(sys.argv) > 1 else "results/v2"
pb = pd.read_csv(f"{out}/pseudobulk_group.csv")
progs = [c[5:] for c in pb if c.startswith("atac_")]
rna = pb[["group", "donor"] + [f"rna_{p}" for p in progs]]
atac = pb[["group", "donor"] + [f"atac_{p}" for p in progs]]
obs = rna_atac_concordance(rna, atac, progs, groupby="group")
obs.to_csv(f"{out}/rna_atac_concordance.csv", index=False)

rng = np.random.default_rng(0)
null = []
for _ in range(1000):
    sh = atac.copy()
    for g, idx in sh.groupby("group").groups.items():
        sh.loc[idx, sh.columns[2:]] = sh.loc[idx, sh.columns[2:]].to_numpy()[rng.permutation(len(idx))]
    null.append(rna_atac_concordance(rna, sh, progs, groupby="group")["r"].median())
null = np.array(null)
med = obs["r"].median()
print(f"concordance tests: {len(obs)} (cell group x program, {obs['n_donors'].min()}-{obs['n_donors'].max()} donors)")
print(f"median r = {med:.3f}; fraction r>0 = {(obs['r'] > 0).mean():.2f}")
print(f"null median r: {null.mean():.3f} (95% {np.quantile(null, .025):.3f}..{np.quantile(null, .975):.3f}); "
      f"p = {(np.sum(null >= med) + 1) / (len(null) + 1):.4f}")
print("\nby program (median r across cell groups):")
print(obs.groupby("program")["r"].median().sort_values().round(2).to_string())
print("\nselected:")
print(obs[obs["group"].isin(["Microglia-PVM", "Astrocyte", "Oligodendrocyte", "L2/3 IT", "Pvalb"])]
      .pivot(index="program", columns="group", values="r").round(2).to_string())

concordance_null(obs["r"].to_numpy(), null, f"{out}/concordance_null.png")
pd.DataFrame({"null_median_r": null}).to_csv(f"{out}/concordance_null.csv", index=False)
