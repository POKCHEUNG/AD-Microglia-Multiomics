"""Which TFs drive DAM chromatin, and a TF -> enhancer -> gene network (README 35, Fig. 7).

    python scripts/dam_tf_grn.py                # writes results/dam_tf/; motif hits cached

Motifs: JASPAR 2024 CORE non-redundant, kept if any of its TFs is expressed in microglia (SEA-AD
RNA, or detected in >= 1% of hippocampus microglia). A peak has a motif if a window in the 500 bp
around its centre passes the motif's p < 1e-4 log-odds threshold (exact score distribution under a
uniform background, as in FIMO / MOODS). A fixed fraction of the score range (85%, as in
scripts/motif_dam_peaks.py) is too lenient for short, low-information motifs: MEF2C, TFEB, BHLHE40
would hit 60-90% of peaks. Motifs are grouped into families by overlap of their peak sets
(Jaccard >= 0.3), since one motif family is bound by several TFs.

1. TF motif activity, donor as the unit. For each donor's within-donor difference d (DAM-like
   minus homeostatic, depth-matched, mean of 20 thinning draws; all 32,481 tested peaks), the
   motif's score = mean d over its peaks minus the mean d expected from peaks matched on GC and
   accessibility (deciles x deciles, exact expectation). Paired t over donors, FDR from donor sign
   flips. Replications: SEA-AD 10x Multiome nuclei only (labels from own RNA); hippocampus
   multiome (DAM-high vs DAM-low third within donor, state from same-nucleus RNA).
2. Which TF. Motifs are grouped into families; a family is supported if a member motif has
   q < 0.05 and the same sign in SEA-AD multiome-only nuclei and the hippocampus ("replicated" if
   hippocampus |t| >= 2). Within a family, a TF is an activator if its own RNA changes with the motif
   activity in the same comparison (SEA-AD, 66 donors, |t| >= 2), repressor-like if opposite. The
   hippocampus metacell (25 nuclei of similar RNA DAM score within a donor) correlation of TF expression
   with motif score is reported alongside.
3. Network. Elements: peaks at q < 0.1 and |log2FC| >= 0.5. TF family -> element: a supported motif of
   the family is present and the element moves in the family's direction. Element -> gene, tier 1: same-nucleus link
   in hippocampus microglia (scripts/candidate_links.py logic; z_state >= 2.5 and z_peak >= 2.5, r > 0;
   mirrored-tail FDR ~ 0.1); tier 2: the gene's TSS is within 50 kb and its regulatory domain (q < 0.05) and
   RNA (|t| >= 2) move with the element. Regulon check: in hippocampus metacells, TF expression against
   the mean expression of its targets, vs random targets matched on DAM RNA t and expression.
   for genes within 500 kb, and the gene's RNA moves with the element.
4. Homeostatic shift. The same motif score in homeostatic (Micro-PVM_2) pseudobulks of 66 donors
   against grey-matter 6E10 (age, sex, PMI, log nuclei), permutation p; which TFs carry it.
5. RASGEF1C risk alleles. For the four 95% credible-set SNPs, motifs whose p < 1e-4 site is gained or
   lost with the risk allele (windows overlapping the SNP, both strands), against the same count for
   3,000 random transitions placed in microglia-accessible peaks.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.genome import parse_peak_names, read_gtf_genes
from ddrmulti.stats import bh
from motif_dam_peaks import CODE, fetch, onehot, read_jaspar
from run_dam_peaks import DAM, HOM, flip_test, load, paired, thin_mean_diff
from run_dam_regulatory import rna_lfc
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/dam_tf"
OUT.mkdir(parents=True, exist_ok=True)
JASPAR = ROOT / "data/ref/motifs/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt"
BASE = ["age", "sex", "pmi", "lognuc"]
CS_SNPS = {"rs113706587": ("chr5", 180201150, "A", "G"), "rs116347724": ("chr5", 180197032, "A", "G"),
           "rs111274391": ("chr5", 180196966, "A", "G"), "rs76792388": ("chr5", 180202485, "C", "A")}  # (risk, other)


def log_odds(pfm: np.ndarray) -> np.ndarray:
    p = (pfm + 0.2) / (pfm + 0.2).sum(1, keepdims=True)
    return np.log2(p / 0.25)


def pwm_threshold(pw: np.ndarray, pval: float = 1e-4, scale: int = 100) -> float:
    """Smallest log-odds score with P(score >= s) <= pval for a random uniform-background window."""
    ints = np.round(pw * scale).astype(int)
    off = ints.min(1)
    dist = np.array([1.0])
    for row, o in zip(ints, off):
        step = np.zeros(row.max() - o + 1)
        np.add.at(step, row - o, 0.25)
        dist = np.convolve(dist, step)
    tail = np.cumsum(dist[::-1])[::-1]                          # P(score >= k + sum(off))
    k = np.flatnonzero(tail <= pval)
    return (k[0] + off.sum()) / scale if len(k) else np.inf


def scan(X: np.ndarray, pw: np.ndarray, thr: float) -> np.ndarray:
    w, L = len(pw), X.shape[1]
    hit = np.zeros(len(X), bool)
    for m in (pw, pw[::-1, ::-1]):
        mat = np.vstack([m.T, np.full((1, w), -10.0)]).astype(np.float32)
        sc = np.zeros((len(X), L - w + 1), np.float32)
        for k in range(w):
            sc += mat[X[:, k:k + L - w + 1], k]
        hit |= (sc >= thr).any(1)
    return hit


def families(hits: np.ndarray, order: np.ndarray, jac: float = 0.3) -> np.ndarray:
    """Greedy grouping: in order of |t|, each motif joins the first family whose leader overlaps it."""
    H = hits.astype(np.float32)
    inter = H.T @ H
    n = np.diag(inter)
    J = inter / (n[:, None] + n[None, :] - inter)
    fam = np.full(hits.shape[1], -1)
    for i in order:
        if fam[i] >= 0:
            continue
        fam[(J[i] >= jac) & (fam < 0)] = i
    return fam


def motif_genes(name: str) -> list[str]:
    tf = re.sub(r"\(var\.\d+\)", "", name.split(" ", 1)[1])
    return [t.strip().upper() for t in tf.split("::") if t.strip()]


def lcpm(c):
    return np.log2(c / c.sum() * 1e6 + 1)


def resid(X, C):
    return X - C @ np.linalg.lstsq(C, X, rcond=None)[0]


class MotifScorer:
    """Mean of a peak-level matrix over each motif's peaks minus its GC x accessibility-matched expectation."""

    def __init__(self, hits: np.ndarray, bins: np.ndarray):
        self.M = sp.csc_matrix(hits.astype(float))
        self.n = np.asarray(self.M.sum(0)).ravel()
        self.B = sp.csc_matrix((np.ones(len(bins)), (np.arange(len(bins)), bins)), shape=(len(bins), bins.max() + 1))
        self.nb = np.asarray(self.B.sum(0)).ravel()
        self.W = (self.B.T @ self.M).toarray() / self.n                       # bins x motifs

    def __call__(self, X: np.ndarray) -> np.ndarray:
        mot = np.asarray(X @ self.M) / self.n
        binm = (X @ self.B) / np.maximum(self.nb, 1)
        return np.asarray(mot) - np.asarray(binm) @ self.W


def main():
    rng = np.random.default_rng(0)
    peaks = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    pix = peaks.index.get_indexer(res["peak"])
    rna, n_rna = rna_lfc()

    # ---------- motif hits on the tested peaks (cached)
    motifs = read_jaspar(JASPAR)
    L, gnames = load_libs()
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    R_ = sp.vstack([L[l]["rna_cells"][(L[l]["cells"]["subclass"] == "Microglia").to_numpy()]
                    for l in cache["library"].unique()]).tocsr()
    A_ = sp.vstack([L[l]["atac_cells"][(L[l]["cells"]["subclass"] == "Microglia").to_numpy()]
                    for l in cache["library"].unique()]).tocsr()[:, pix]
    gsym = pd.Index(gnames.str.upper())
    hdet = pd.Series(np.asarray((R_ > 0).mean(0)).ravel(), index=gsym).groupby(level=0).max()
    expressed = set(rna.index[rna["rna_expressed"].astype("boolean").fillna(False).astype(bool)]) | set(hdet.index[hdet >= 0.01])
    keepm = [m for m in motifs if any(g in expressed for g in motif_genes(m))]
    hf = OUT / "motif_hits_p1e4.npz"
    if hf.exists():
        z = np.load(hf, allow_pickle=True)
        hits, mnames, gc = z["hits"], list(z["names"]), z["gc"]
    else:
        mid = ((res["start"] + res["end"]) // 2).to_numpy()
        reg = pd.DataFrame({"chrom": res["chrom"], "start": np.maximum(mid - 250, 0), "end": mid + 250})
        seqs = fetch(ROOT / "data/ref/hg38.fa.gz", reg)
        gc = np.array([(s.upper().count("G") + s.upper().count("C")) / max(len(s), 1) for s in seqs])
        X = onehot(seqs, 500)
        hits = np.zeros((len(res), len(keepm)), bool)
        for j, m in enumerate(keepm):
            pw = log_odds(motifs[m])
            hits[:, j] = scan(X, pw, pwm_threshold(pw))
            if j % 50 == 0:
                print(f"   scanned {j}/{len(keepm)} motifs", flush=True)
        mnames = keepm
        np.savez_compressed(hf, hits=hits, names=np.array(mnames, dtype=object), gc=gc)
    frac = hits.mean(0)
    use = (frac >= 0.005) & (frac <= 0.6)
    hits, mnames = hits[:, use], [m for m, u in zip(mnames, use) if u]
    acc = np.log2((res["cpm_dam"] + res["cpm_hom"]).to_numpy() / 2 + 1)
    bins = (pd.qcut(pd.Series(gc).rank(method="first"), 10, labels=False).to_numpy() * 10
            + pd.qcut(pd.Series(acc).rank(method="first"), 10, labels=False).to_numpy())
    S = MotifScorer(hits, bins)
    print(f"motifs kept: {len(mnames)} (TF expressed in microglia, present in 0.5-60% of peaks)")

    # ---------- 1. motif activity, SEA-AD and replications
    rows, Mx = load(ROOT / "data/processed/atac_pb_micro")
    disc = pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"].tolist()
    D, _ = paired(rows, Mx, disc, pix, rng=rng)
    C = S(D)
    mean, t, p, q = flip_test(C, 5000, rng)
    Dm, um = paired(rows, Mx, disc, pix, method="10xMulti", rng=rng)
    Cm = S(Dm)
    tm = Cm.mean(0) / (Cm.std(0, ddof=1) / np.sqrt(len(Cm)))
    # hippocampus: DAM-high vs DAM-low third within donor
    score = cache["score"].to_numpy()
    donor = cache["donor"].to_numpy()
    Dh = []
    for dn in np.unique(donor):
        m = np.flatnonzero(donor == dn)
        if len(m) < 30:
            continue
        lo, hi = np.quantile(score[m], [1 / 3, 2 / 3])
        Dh.append(thin_mean_diff(np.asarray(A_[m[score[m] >= hi]].sum(0)).ravel(),
                                 np.asarray(A_[m[score[m] <= lo]].sum(0)).ravel(), rng, lcpm))
    Ch = S(np.array(Dh))
    th = Ch.mean(0) / (Ch.std(0, ddof=1) / np.sqrt(len(Ch)))
    T = pd.DataFrame({"motif": mnames, "tfs": ["/".join(motif_genes(m)) for m in mnames], "n_peaks": S.n.astype(int),
                      "seaad_delta": mean, "seaad_t": t, "seaad_p": p, "seaad_q": q, "multiome_t": tm,
                      "hippo_delta": Ch.mean(0), "hippo_t": th,
                      "hippo_donors_same_sign": (np.sign(Ch) == np.sign(mean)).sum(0), "hippo_n": len(Ch)})
    fam = families(hits, np.argsort(-np.abs(t)))
    T["family"] = [T["tfs"].iat[f] for f in fam]
    print(f"1. motif activity: {len(D)} SEA-AD donors; q < 0.05: {(T.seaad_q < 0.05).sum()} "
          f"(up {((T.seaad_q < 0.05) & (T.seaad_t > 0)).sum()}, down {((T.seaad_q < 0.05) & (T.seaad_t < 0)).sum()}); "
          f"Spearman with multiome-only t {stats.spearmanr(t, tm).statistic:.2f} ({len(Dm)} donors), "
          f"with hippocampus t {stats.spearmanr(t, th).statistic:.2f} ({len(Ch)} donors)")

    # ---------- 2. which TF: RNA change and same-nucleus expression-activity coupling
    order = np.lexsort((score, donor))
    mc_rows, mc_atac, mc_rna = [], [], []
    tot_r = np.asarray(R_.sum(1)).ravel()
    for dn in np.unique(donor):
        m = order[donor[order] == dn]
        for k in range(0, len(m) - 14, 25):
            cells = m[k:k + 25]
            mc_atac.append(np.asarray(A_[cells].sum(0)).ravel())
            r_ = np.asarray(R_[cells].sum(0)).ravel()
            mc_rna.append(np.log1p(r_ / r_.sum() * 1e4))
            mc_rows.append({"donor": dn, "score": score[cells].mean(), "n": len(cells),
                            "logfrag": np.log10(mc_atac[-1].sum() + 1), "logumi": np.log10(r_.sum() + 1)})
    MC = pd.DataFrame(mc_rows)
    LA = np.array([lcpm(a) for a in mc_atac])
    ZA = (LA - LA.mean(0)) / np.where(LA.std(0) > 0, LA.std(0), 1)
    Cmc = S(ZA)
    Cv = np.column_stack([pd.get_dummies(MC["donor"]).to_numpy(float), MC["logfrag"], MC["logumi"]])
    Cmc_r = resid(Cmc, Cv)
    Emc = np.array(mc_rna)
    tf_rows = []
    for j, mname in enumerate(mnames):
        for g in motif_genes(mname):
            gi = np.flatnonzero(gsym == g)
            r_ea = np.nan
            if len(gi) and hdet.get(g, 0) >= 0.01:
                e = resid(Emc[:, gi[0]][:, None], Cv)[:, 0]
                r_ea = np.corrcoef(e, Cmc_r[:, j])[0, 1]
            tf_rows.append({"motif": mname, "tf": g, "tf_rna_t": rna["rna_t"].get(g, np.nan),
                            "tf_rna_log2fc": rna["rna_log2fc"].get(g, np.nan), "tf_hippo_detect": hdet.get(g, np.nan),
                            "r_expr_activity": r_ea})
    TF = pd.DataFrame(tf_rows).merge(T, on="motif")
    sm = np.sign(TF["seaad_t"])
    same_h = np.sign(TF["hippo_t"]) == sm
    TF["status"] = np.select([(TF["seaad_q"] < 0.05) & same_h & (TF["hippo_t"].abs() >= 2),
                              (TF["seaad_q"] < 0.05) & same_h & (np.sign(TF["multiome_t"]) == sm)],
                             ["replicated", "SEA-AD (hippocampus same sign)"], "not supported")
    ex = TF["tf_rna_t"].abs() >= 2
    TF["role"] = np.where(TF["status"] == "not supported", "",
                          np.select([ex & (np.sign(TF["tf_rna_t"]) == sm), ex & (np.sign(TF["tf_rna_t"]) == -sm)],
                                    ["activator", "repressor-like"], "unresolved"))
    TF.to_csv(OUT / "tf_activity.csv", index=False)
    T.to_csv(OUT / "motif_activity.csv", index=False)
    MC.to_csv(OUT / "hippo_metacells.csv", index=False)
    sup = TF[TF["status"] != "not supported"]
    FAM = []
    for f, d in sup.groupby("family"):
        b = d.loc[d["seaad_t"].abs().idxmax()]
        roles = d[d["role"].isin(["activator", "repressor-like"])].sort_values("tf_rna_t", key=np.abs, ascending=False)
        FAM.append({"family": f, "n_motifs": d["motif"].nunique(), "best_motif": b["motif"], "seaad_t": b["seaad_t"],
                    "seaad_q": b["seaad_q"], "multiome_t": b["multiome_t"], "hippo_t": b["hippo_t"],
                    "hippo_donors_same_sign": b["hippo_donors_same_sign"],
                    "status": "replicated" if (d["status"] == "replicated").any() else "SEA-AD (hippocampus same sign)",
                    "activators": ",".join(dict.fromkeys(roles.loc[roles["role"] == "activator", "tf"])),
                    "repressor_like": ",".join(dict.fromkeys(roles.loc[roles["role"] == "repressor-like", "tf"])),
                    "tf_rna_t": ";".join(f"{r.tf} {r.tf_rna_t:+.1f}" for r in roles.drop_duplicates("tf").itertuples()),
                    "members": ",".join(dict.fromkeys(d["tf"]))})
    FAM = pd.DataFrame(FAM).sort_values("seaad_t", key=np.abs, ascending=False)
    FAM.to_csv(OUT / "tf_families.csv", index=False)
    print("\n2. Motif families with DAM activity change (q < 0.05, same sign in multiome-only and hippocampus):")
    print(FAM.drop(columns=["members"]).to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- 4. homeostatic cells vs plaque, per motif
    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")["number of 6e10 positive objects per area"]
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    hr = rows[rows["subclass"] == HOM]
    hn = hr.groupby("donor")["n_nuclei"].sum()
    hd = [x for x in hn.index[hn >= 30] if x in gm.index and x in meta.index]
    LH = np.array([lcpm(np.asarray(Mx[hr.index[hr["donor"] == x].to_numpy()].sum(0)).ravel())[pix] for x in hd])
    ZH = (LH - LH.mean(0)) / np.where(LH.std(0) > 0, LH.std(0), 1)
    IH = pd.DataFrame({"donor": hd, "age": pd.to_numeric(meta.loc[hd, "Age at Death"], errors="coerce").to_numpy(),
                       "sex": meta.loc[hd, "Sex"].astype(str).to_numpy(),
                       "pmi": pd.to_numeric(meta.loc[hd, "PMI"], errors="coerce").to_numpy(),
                       "lognuc": np.log10(hn.loc[hd].to_numpy(float)),
                       "plaque": np.log10(pd.to_numeric(gm.reindex(hd), errors="coerce").to_numpy() * 1e6 + 1)})
    ok = IH.notna().all(1).to_numpy()
    held = ~IH["donor"].isin(disc).to_numpy()
    Cb = _covar_matrix(IH[ok], BASE)
    xr = _resid(IH.loc[ok, "plaque"].to_numpy(float), Cb)
    SH = resid(S(ZH[ok]), Cb)
    xs = (xr - xr.mean()) / xr.std()
    SHs = (SH - SH.mean(0)) / np.where(SH.std(0) > 0, SH.std(0), 1)
    r_pl = xs @ SHs / len(xs)
    null = np.array([np.abs(rng.permutation(xs) @ SHs / len(xs)) for _ in range(2000)])
    p_pl = (np.sum(null >= np.abs(r_pl), 0) + 1) / 2001
    mh = held[ok]
    r_held = ((xs[mh] - xs[mh].mean()) / xs[mh].std()) @ ((SH[mh] - SH[mh].mean(0)) / SH[mh].std(0)) / mh.sum()
    T["homeo_plaque_r"], T["homeo_plaque_p"], T["homeo_plaque_q"], T["homeo_plaque_r_heldout"] = r_pl, p_pl, bh(p_pl), r_held
    rho = stats.spearmanr(T["seaad_t"], T["homeo_plaque_r"])
    rho_h = stats.spearmanr(T["seaad_t"], T["homeo_plaque_r_heldout"])
    print(f"\n4. homeostatic microglia ({ok.sum()} donors): motif activity vs plaque; q < 0.05: "
          f"{(T.homeo_plaque_q < 0.05).sum()}; across motifs Spearman(DAM t, plaque r) = {rho.statistic:.2f} "
          f"(p = {rho.pvalue:.1g}); held-out donors {rho_h.statistic:.2f} (p = {rho_h.pvalue:.1g})")
    T.to_csv(OUT / "motif_activity.csv", index=False)
    TF = TF.merge(T[["motif", "homeo_plaque_r", "homeo_plaque_p", "homeo_plaque_q", "homeo_plaque_r_heldout"]], on="motif")
    TF.to_csv(OUT / "tf_activity.csv", index=False)
    print(T.sort_values("homeo_plaque_p").head(15)[["motif", "seaad_t", "hippo_t", "homeo_plaque_r", "homeo_plaque_q",
          "homeo_plaque_r_heldout"]].to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- 3. network
    el = np.flatnonzero((res["q"] < 0.1).to_numpy() & (res["log2fc"].abs() >= 0.5).to_numpy())
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    gu = genes.groupby(genes.index.str.upper()).first()
    tot = np.asarray(R_.sum(1)).ravel()
    Ln = (sp.diags(1e4 / np.maximum(tot, 1)) @ R_).tocsc()
    Ln.data = np.log1p(Ln.data)
    gdet = np.asarray((R_ > 0).mean(0)).ravel()
    gi_use = np.flatnonzero(gdet >= 0.02)
    Cc = np.column_stack([pd.get_dummies(cache["donor"]).to_numpy(float), np.log10(np.maximum(tot, 1)),
                          np.log10(np.asarray(A_.sum(1)).ravel() + 1)])
    Yg = resid(Ln[:, gi_use].toarray(), Cc)
    Yg = (Yg - Yg.mean(0)) / np.where(Yg.std(0) > 0, Yg.std(0), 1)
    ysym = gsym[gi_use]
    gchrom = gu["chrom"].reindex(ysym).to_numpy()
    gtss = gu["tss"].reindex(ysym).to_numpy()
    rt = rna["rna_t"].reindex(ysym)
    g_state = pd.qcut(rt.rank(method="first").fillna(rt.rank(method="first").median()), 10, labels=False).to_numpy()
    g_expr = pd.qcut(pd.Series(gdet[gi_use]).rank(method="first"), 10, labels=False).to_numpy()
    det = np.asarray((A_ > 0).mean(0)).ravel()
    det_bin = pd.qcut(pd.Series(det).rank(method="first"), 10, labels=False).to_numpy()
    gc_bin = pd.qcut(pd.Series(gc).rank(method="first"), 10, labels=False).to_numpy()
    n = A_.shape[0]
    A_c = A_.tocsc()

    def pcols(ix):
        X = resid((A_c[:, ix] > 0).toarray().astype(float), Cc)
        return (X - X.mean(0)) / np.where(X.std(0) > 0, X.std(0), 1)
    link_rows = []
    chroms = res["chrom"].to_numpy()
    mids = ((res["start"] + res["end"]) // 2).to_numpy()
    for k in el:
        if det[k] < 0.01:
            continue
        cis = np.flatnonzero((gchrom == chroms[k]) & (np.abs(gtss - mids[k]) <= 500_000))
        if not len(cis):
            continue
        xe = pcols([k])[:, 0]
        same = np.flatnonzero((gc_bin == gc_bin[k]) & (det_bin == det_bin[k]) & (chroms != chroms[k]))
        Xb = pcols(rng.choice(same, min(100, len(same)), replace=False))
        r_bg = Xb.T @ Yg[:, cis] / n
        r_all = xe @ Yg / n
        r_cis = r_all[cis]
        for ci, g in enumerate(cis):
            trans = np.flatnonzero((g_state == g_state[g]) & (g_expr == g_expr[g]) & (gchrom != chroms[k]))
            tr = rng.choice(trans, min(100, len(trans)), replace=False)
            link_rows.append({"peak": res["peak"].iat[k], "element_log2fc": res["log2fc"].iat[k], "gene": ysym[g],
                              "dist_kb": (gtss[g] - mids[k]) / 1e3, "r": r_cis[ci],
                              "z_peak": (r_cis[ci] - r_bg[:, ci].mean()) / r_bg[:, ci].std(),
                              "z_state": (r_cis[ci] - r_all[tr].mean()) / r_all[tr].std(), "gene_rna_t": rt.iloc[g]})
    LK = pd.DataFrame(link_rows)
    # threshold from the mirrored tail: negative links estimate false positive ones
    for zt in (3.0, 2.5, 2.0):
        pos = ((LK["z_state"] >= zt) & (LK["z_peak"] >= zt) & (LK["r"] > 0)).sum()
        neg = ((LK["z_state"] <= -zt) & (LK["z_peak"] <= -zt) & (LK["r"] < 0)).sum()
        print(f"   link threshold z >= {zt}: {pos} positive, {neg} mirrored negative (FDR ~ {neg / max(pos, 1):.2f})")
    ZT = 2.5
    LK["link"] = (LK["z_state"] >= ZT) & (LK["z_peak"] >= ZT) & (LK["r"] > 0) & \
        (np.sign(LK["gene_rna_t"].fillna(0)) == np.sign(LK["element_log2fc"]))
    LK.to_csv(OUT / "element_gene_links.csv.gz", index=False)
    links = LK[LK["link"]]
    print(f"\n3. elements: {len(el)}; detected in hippocampus: {LK['peak'].nunique()}; element-gene links: {len(links)} "
          f"({links['peak'].nunique()} elements -> {links['gene'].nunique()} genes)")
    # tier 2: element within 50 kb of a gene whose regulatory domain and RNA move the same way
    G = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz")
    G = G[(G["q"] < 0.05) & (G["rna_t"].abs() >= 2) & (np.sign(G["t"]) == np.sign(G["rna_t"]))]
    G = G.assign(gu=G["gene"].str.upper()).join(gu[["chrom", "tss"]], on="gu").dropna(subset=["tss"])
    tier2 = []
    for k in el:
        sgn = np.sign(res["log2fc"].iat[k])
        g = G[(G["chrom"] == chroms[k]) & ((G["tss"] - mids[k]).abs() <= 50_000) & (np.sign(G["t"]) == sgn)]
        for _, r in g.iterrows():
            tier2.append({"peak": res["peak"].iat[k], "element_log2fc": res["log2fc"].iat[k], "gene": r["gu"],
                          "dist_kb": (r["tss"] - mids[k]) / 1e3, "gene_rna_t": r["rna_t"], "tier": 2})
    EG = pd.concat([links.assign(tier=1)[["peak", "element_log2fc", "gene", "dist_kb", "gene_rna_t", "tier"]],
                    pd.DataFrame(tier2)]).sort_values("tier").drop_duplicates(["peak", "gene"])
    print(f"   element-gene pairs: tier 1 (same-nucleus link) {(EG.tier == 1).sum()}, tier 2 (domain-proximal) "
          f"{(EG.tier == 2).sum()}; {EG['peak'].nunique()} elements -> {EG['gene'].nunique()} genes")
    pk_i = pd.Series(np.arange(len(res)), index=res["peak"])
    edges = []
    for _, f in FAM.iterrows():
        ms = sup.loc[sup["family"] == f["family"], "motif"].unique()
        cols = [mnames.index(m) for m in ms]
        sgn = np.sign(f["seaad_t"])
        node = f["activators"] or f["repressor_like"] or f["family"]
        for _, l in EG.iterrows():
            k = pk_i[l["peak"]]
            if hits[k, cols].any() and np.sign(l["element_log2fc"]) == sgn:
                edges.append({"family": f["family"], "tf_node": node, "peak": l["peak"],
                              "element_log2fc": l["element_log2fc"], "gene": l["gene"], "tier": l["tier"],
                              "gene_rna_t": l["gene_rna_t"]})
    E = pd.DataFrame(edges)
    E.to_csv(OUT / "grn_edges.csv", index=False)
    EG.to_csv(OUT / "element_gene_pairs.csv", index=False)
    # regulon check in hippocampus metacells: TF expression vs mean target expression, against matched random targets
    Emc_r = resid(Emc[:, gi_use], Cv)
    Emc_r = (Emc_r - Emc_r.mean(0)) / np.where(Emc_r.std(0) > 0, Emc_r.std(0), 1)
    ypos = pd.Series(np.arange(len(ysym)), index=ysym)
    ypos = ypos[~ypos.index.duplicated()]
    reg_rows = []
    for (fam_, node), d in E.groupby(["family", "tf_node"]):
        tg = [g for g in d["gene"].unique() if g in ypos.index]
        row = {"family": fam_, "tf_node": node, "n_elements": d["peak"].nunique(), "n_genes": d["gene"].nunique(),
               "n_tier1": int((d.drop_duplicates(["peak", "gene"])["tier"] == 1).sum()),
               "genes": ",".join(sorted(d["gene"].unique()))}
        tfs = [x for x in node.split(",") if x in ypos.index]
        if tfs and len(tg) >= 3:
            ti = ypos[tg].to_numpy()
            score_ = Emc_r[:, ti].mean(1)
            e_tf = Emc_r[:, ypos[tfs[0]]]
            r_obs = np.corrcoef(e_tf, score_)[0, 1]
            nl = []
            for _ in range(500):
                rs = [rng.choice(np.flatnonzero((g_state == g_state[x]) & (g_expr == g_expr[x]))) for x in ti]
                nl.append(np.corrcoef(e_tf, Emc_r[:, rs].mean(1))[0, 1])
            nl = np.array(nl)
            row.update(tf_tested=tfs[0], r_tf_targets=r_obs, null_mean=nl.mean(), z=(r_obs - nl.mean()) / nl.std(),
                       p=(np.sum(np.abs(nl - nl.mean()) >= abs(r_obs - nl.mean())) + 1) / 501)
        reg_rows.append(row)
    REG = pd.DataFrame(reg_rows)
    REG.to_csv(OUT / "regulons.csv", index=False)
    print("\n   regulons (TF -> elements -> genes); hippocampus metacells: TF expression vs target expression, "
          "null = state- and expression-matched random targets:")
    print(REG.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- 5. RASGEF1C credible-set SNPs: motif gain / loss, against random transitions in microglial peaks
    def centre_scores(X: np.ndarray, pw: np.ndarray) -> np.ndarray:
        """Best score over windows (both strands) that overlap the centre base of 61-bp sequences."""
        w = len(pw)
        best = np.full(len(X), -np.inf, np.float32)
        for m in (pw, pw[::-1, ::-1]):
            mat = np.vstack([m.T, np.full((1, w), -10.0)]).astype(np.float32)
            for st in range(max(0, 30 - w + 1), min(30, 61 - w) + 1):
                sc = mat[X[:, st:st + w], np.arange(w)].sum(1)
                best = np.maximum(best, sc)
        return best

    thr = {m: pwm_threshold(log_odds(motifs[m])) for m in mnames}
    reg_ = pd.DataFrame([{"chrom": c, "start": pos - 31, "end": pos + 30} for c, pos, _, _ in CS_SNPS.values()])
    seqs = [x.upper() for x in fetch(ROOT / "data/ref/hg38.fa.gz", reg_)]
    pick = rng.choice(len(res), 3000, replace=False)
    off = rng.integers(-100, 101, len(pick))
    pos_n = ((res["start"] + res["end"]) // 2).to_numpy()[pick] + off
    nreg = pd.DataFrame({"chrom": res["chrom"].to_numpy()[pick], "start": pos_n - 31, "end": pos_n + 30})
    nseq = [x.upper() for x in fetch(ROOT / "data/ref/hg38.fa.gz", nreg)]
    swap = {"A": "G", "G": "A", "C": "T", "T": "C"}
    nseq = [x for x in nseq if len(x) == 61 and x[30] in swap and "N" not in x]
    n_ref = onehot(nseq, 61)
    n_alt = onehot([x[:30] + swap[x[30]] + x[31:] for x in nseq], 61)
    r_ref = onehot([x[:30] + CS_SNPS[k][2] + x[31:] for k, x in zip(CS_SNPS, seqs)], 61)       # risk allele
    r_oth = onehot([x[:30] + CS_SNPS[k][3] + x[31:] for k, x in zip(CS_SNPS, seqs)], 61)
    ev, null_ev = [], np.zeros(len(nseq))
    fam_of = dict(zip(T["motif"], T["family"]))
    for mname in mnames:
        pw = log_odds(motifs[mname])
        a, b = centre_scores(n_ref, pw), centre_scores(n_alt, pw)
        null_ev += ((a >= thr[mname]) != (b >= thr[mname]))
        sr, so = centre_scores(r_ref, pw), centre_scores(r_oth, pw)
        for k, snp in enumerate(CS_SNPS):
            if (sr[k] >= thr[mname]) != (so[k] >= thr[mname]):
                ev.append({"snp": snp, "motif": mname, "tfs": "/".join(motif_genes(mname)), "family": fam_of[mname],
                           "effect_of_risk_allele": "gain" if sr[k] >= thr[mname] else "loss",
                           "score_risk": sr[k], "score_other": so[k], "threshold": thr[mname],
                           "dam_activity_t": T.set_index("motif").at[mname, "seaad_t"],
                           "dam_activity_q": T.set_index("motif").at[mname, "seaad_q"]})
    MB = pd.DataFrame(ev)
    MB.to_csv(OUT / "rasgef1c_motif_break.csv", index=False)
    cnt = MB.groupby("snp").size().reindex(list(CS_SNPS)).fillna(0)
    print(f"\n5. RASGEF1C credible-set SNPs: motif gain/loss events (p < 1e-4 sites) vs {len(nseq)} random transitions "
          f"in microglial peaks (null mean {null_ev.mean():.2f}, 95th pct {np.percentile(null_ev, 95):.0f})")
    for snp, c in cnt.items():
        print(f"   {snp}: {int(c)} events (null percentile {(null_ev < c).mean() * 100:.0f})")
    if len(MB):
        print(MB.sort_values(["snp", "dam_activity_q"]).to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
