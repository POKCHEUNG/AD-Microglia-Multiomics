"""Pre-specified DDR endpoints: effect sizes, 95% CIs, multiple testing, two cohorts (README 40, FigS5).

    python scripts/psychad_extra_pb.py          # first: PsychAD IN / Astro / Micro / EN_L2_3_IT pseudobulks
    python scripts/ddr_endpoints.py             # writes results/ddr_endpoints/

The pathway scores of results 13 and 29 average 10-150 genes each. Here eight narrow endpoints, fixed
from the literature before this analysis (after the pathway results had been seen), are tested in six
cell types, 48 primary tests per cohort:

  DSB sensing        ATM, MDC1, TP53BP1
  p53 response       CDKN1A, MDM2, GADD45A, BBC3
  NHEJ core          XRCC4, LIG4, PRKDC, XRCC5, XRCC6
  BER core           OGG1, APEX1, XRCC1, PARP1
  senescence         CDKN2A, CDKN1A
  cGAS-STING         CGAS, STING1
  CDKN1A (p21)       single gene
  GADD45A            single gene

References: DAM (Keren-Shaul) and cohesin (Mathys 2023). Cell types: excitatory neurons (all
cortical excitatory subclasses), L2/3 IT, inhibitory neurons, microglia, oligodendrocytes, astrocytes.
Cohorts: SEA-AD MTG (local CPS; age, sex, PMI, log nuclei; severe donors excluded) and PsychAD MSSM
(AD vs control; age, sex, log nuclei, mitochondrial fraction).

Per test: endpoint score = mean z (across donors) of log2 CPM of its expressed genes; partial r with the
exposure, donor-bootstrap 95% CI (2,000), permutation p (5,000); raw effect = covariate-adjusted change
of the mean log2 CPM (SEA-AD: across CPS 0 -> 1; PsychAD: AD minus control) with bootstrap 95% CI;
competitive: the endpoint's r against 1,000 random gene sets of the same size matched on expression
decile x gene length (percentile, p_set), and excess r = r - their mean with bootstrap 95% CI.
Multiplicity: Holm and BH over the 48 primary tests of each cohort, separately for p_perm and p_set.
Meta-analysis of the two cohorts: inverse-variance on Fisher z (raw r) and on excess r, fixed and
DerSimonian-Laird random effects, with I^2. For excess r the variance adds the spread of the matched
random sets (null s.d.) to the donor-bootstrap variance: a random gene set deviates from the mean of its
peers by that much, so the bootstrap alone would make arbitrary genes "significant" (README 39). The exposures differ (continuous CPS vs AD status), so
pooled r is a direction-and-size summary, not a single estimand.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from ad_ddr import cohort
from ad_ddr.signatures import DAM as DAM_GENES
from ddrmulti.genome import read_gtf_genes
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/ddr_endpoints"
OUT.mkdir(parents=True, exist_ok=True)
ENDPOINTS = {
    "DSB sensing": ["ATM", "MDC1", "TP53BP1"],
    "p53 response": ["CDKN1A", "MDM2", "GADD45A", "BBC3"],
    "NHEJ core": ["XRCC4", "LIG4", "PRKDC", "XRCC5", "XRCC6"],
    "BER core": ["OGG1", "APEX1", "XRCC1", "PARP1"],
    "senescence": ["CDKN2A", "CDKN1A"],
    "cGAS-STING": ["CGAS", "STING1"],
    "CDKN1A (p21)": ["CDKN1A"],
    "GADD45A": ["GADD45A"],
}
REFS = {"DAM (reference)": list(DAM_GENES), "cohesin (reference)": ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2"]}
EXC = ["L23-IT", "L4-IT", "L5-IT", "L5-ET", "L56-NP", "L6-IT", "L6-IT-Car3", "L6-CT", "L6b"]
INH = ["Chandelier", "Lamp5", "Lamp5-Lhx6", "Pax6", "Pvalb", "Sncg", "Sst", "Sst-Chodl", "Vip"]
SEA_CELLS = {"Excitatory": ("class", cohort.EXC, EXC), "L2/3 IT": ("group", "L2/3 IT", ["L23-IT"]),
             "Inhibitory": ("class", cohort.INH, INH), "Microglia": ("group", "Microglia-PVM", ["Immune"]),
             "Oligodendrocyte": ("group", "Oligodendrocyte", ["Oligodendrocyte"]),
             "Astrocyte": ("group", "Astrocyte", ["Astrocyte"])}
PSY_CELLS = {"Excitatory": "EN", "L2/3 IT": "EN_L2_3_IT", "Inhibitory": "IN", "Microglia": "Micro",
             "Oligodendrocyte": "Oligo", "Astrocyte": "Astro"}
N_BOOT, N_PERM, N_SETS = 2000, 5000, 1000
ALIAS = {"STING1": "TMEM173"}           # SEA-AD uses the older symbol


def design(df, cov):
    D = pd.get_dummies(df[cov], drop_first=True, dtype=float).to_numpy(float)
    return np.column_stack([np.ones(len(df)), D])


def resid(Y, C):
    return Y - C @ np.linalg.lstsq(C, Y, rcond=None)[0]


def corr_cols(x, Y):
    x = x - x.mean()
    Y = Y - Y.mean(0)
    return (x @ Y) / (np.linalg.norm(x) * np.linalg.norm(Y, axis=0) + 1e-12)


def analyse(cohort_name, cell, M, genes, base, cov, expo, glen, rng):
    cpm = M / M.sum(1, keepdims=True) * 1e6
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    up = pd.Series(np.arange(len(genes)), index=pd.Index(genes).str.upper())
    up = up[~up.index.duplicated()]
    gl = glen.reindex(pd.Index(genes).str.upper()).to_numpy()
    ok = expressed & np.isfinite(gl)
    eb = pd.qcut(pd.Series(L.mean(0)).rank(method="first"), 10, labels=False).to_numpy()
    lb = np.full(len(gl), -1)
    lb[ok] = pd.qcut(pd.Series(gl[ok]).rank(method="first"), 5, labels=False).to_numpy()
    strat = np.where(ok, eb * 5 + lb, -1)
    by = {s: np.flatnonzero(strat == s) for s in np.unique(strat[ok])}
    sd = L.std(0)
    Z = (L - L.mean(0)) / np.where(sd > 0, sd, 1)
    C = design(base, cov)
    x = base[expo].to_numpy(float)
    rows = []
    for name, gs in {**ENDPOINTS, **REFS}.items():
        gi = up.reindex([g if g in up.index else ALIAS.get(g, g) for g in gs]).dropna().astype(int).to_numpy()
        gi = gi[ok[gi]]
        row = {"cohort": cohort_name, "cell": cell, "endpoint": name, "primary": name in ENDPOINTS,
               "genes_expressed": ",".join(pd.Index(genes)[gi]), "n_genes": len(gi), "n_donors": len(base)}
        if len(gi) == 0:
            rows.append({**row, "status": "not expressed"})
            continue
        score = Z[:, gi].mean(1)
        raw = L[:, gi].mean(1)
        rand = np.stack([np.array([rng.choice(by[s]) for s in strat[gi]]) for _ in range(N_SETS)])
        S = np.column_stack([score, Z[:, rand].mean(2)])
        xr = resid(x, C)
        Sr = resid(S, C)
        r_all = corr_cols(xr, Sr)
        r, null = r_all[0], r_all[1:]
        perm = np.array([corr_cols(rng.permutation(xr), Sr[:, :1])[0] for _ in range(N_PERM)])
        beta = np.linalg.lstsq(np.column_stack([x, C]), raw, rcond=None)[0][0]
        bR, bE, bB = [], [], []
        for _ in range(N_BOOT):
            ix = rng.choice(len(x), len(x))
            Cb = C[ix]
            if np.linalg.matrix_rank(Cb) < Cb.shape[1]:
                continue
            rb = corr_cols(resid(x[ix], Cb), resid(S[ix][:, :201], Cb))
            bR.append(rb[0])
            bE.append(rb[0] - rb[1:].mean())
            bB.append(np.linalg.lstsq(np.column_stack([x[ix], Cb]), raw[ix], rcond=None)[0][0])
        bR, bE, bB = map(np.array, (bR, bE, bB))
        z_b = np.arctanh(np.clip(bR, -0.999, 0.999))
        rows.append({**row, "status": "tested", "r": r, "r_lo": np.percentile(bR, 2.5), "r_hi": np.percentile(bR, 97.5),
                     "z": np.arctanh(r), "z_se": z_b.std(),
                     "p_perm": (np.sum(np.abs(perm) >= abs(r)) + 1) / (N_PERM + 1),
                     "effect_log2": beta, "effect_lo": np.percentile(bB, 2.5), "effect_hi": np.percentile(bB, 97.5),
                     "null_mean": null.mean(), "null_sd": null.std(), "percentile_vs_matched": (null < r).mean() * 100,
                     "p_set": (np.sum(np.abs(null - null.mean()) >= abs(r - null.mean())) + 1) / (N_SETS + 1),
                     "excess": r - null.mean(), "excess_lo": np.percentile(bE, 2.5), "excess_hi": np.percentile(bE, 97.5),
                     "excess_se": bE.std(), "excess_se_total": np.sqrt(bE.std() ** 2 + null.std() ** 2)})
    return rows


def holm(p):
    p = np.asarray(p, float)
    o = np.argsort(p)
    adj = np.empty(len(p))
    run = 0
    for k, i in enumerate(o):
        run = max(run, min(1, (len(p) - k) * p[i]))
        adj[i] = run
    return adj


def meta(est, se):
    w = 1 / se ** 2
    fe = np.sum(w * est) / w.sum()
    fe_se = np.sqrt(1 / w.sum())
    Q = np.sum(w * (est - fe) ** 2)
    df = len(est) - 1
    tau2 = max(0, (Q - df) / (w.sum() - np.sum(w ** 2) / w.sum())) if df > 0 else 0
    wr = 1 / (se ** 2 + tau2)
    re = np.sum(wr * est) / wr.sum()
    re_se = np.sqrt(1 / wr.sum())
    i2 = max(0, (Q - df) / Q) * 100 if Q > 0 else 0
    return fe, fe_se, re, re_se, i2


def main():
    rng = np.random.default_rng(0)
    g = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    glen = np.log10((g["end"] - g["start"]).clip(lower=1))
    glen.index = glen.index.str.upper()
    glen = glen[~glen.index.duplicated()]
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    rows = []
    for cell, (level, grp, files) in SEA_CELLS.items():
        idx, Cnt, genes, mt = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{f}.h5ad" for f in files], regions=["MTG"])
        mt = mt.assign(age=pd.to_numeric(mt["age"], errors="coerce"), pmi=pd.to_numeric(mt["pmi"], errors="coerce"),
                       severe=mt["severe"].astype(str).eq("Y"))
        idx = idx.join(mt[["age", "sex", "pmi", "severe"]], on="donor").assign(cps=lambda d: cps.reindex(d["donor"]).to_numpy())
        k = ((idx["level"] == level) & (idx["group"] == grp) & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool)
             & idx[["cps", "age", "pmi"]].notna().all(1)).to_numpy()
        d = idx[k].reset_index(drop=True).assign(log_nuclei=lambda z: np.log10(z["n_nuclei"]))
        rows += analyse("SEA-AD", cell, Cnt[np.flatnonzero(k)], genes, d, ["age", "sex", "pmi", "log_nuclei"], "cps", glen, rng)
        print(f"  SEA-AD {cell}: {len(d)} donors", flush=True)
    pc = ROOT / "data/processed/psychad_pb"
    meta_ = pd.read_csv(pc / "meta.csv", index_col=0)
    con = meta_[((meta_["ad"] & ~meta_["other"]) | (meta_["control"] & ~meta_["ad"])) & meta_["age"].notna()]
    glen_p = pd.read_csv(pc / "gene_length.csv", index_col=0).iloc[:, 0]
    for cell, name in PSY_CELLS.items():
        f = pc / f"{name}.npz"
        if not f.exists():
            print(f"  PsychAD {name}: missing cache")
            continue
        z = np.load(f, allow_pickle=True)
        cats, M, genes = pd.Index(z["cats"].astype(str)), z["M"], np.array(z["genes"].astype(str))
        n = z["n_nuclei"] if "n_nuclei" in z.files else con[f"n_{name}"].reindex(cats).to_numpy()
        n = pd.Series(n, index=cats)
        keep = cats.isin(con.index) & (n.to_numpy() >= 50)
        cats, M, n = cats[keep], M[keep], n[keep].to_numpy()
        base = con.loc[cats].assign(log_nuclei=np.log10(n), mito=M[:, pd.Index(genes).str.startswith("MT-")].sum(1) / M.sum(1),
                                    x=lambda d: d["ad"].astype(float)).reset_index(drop=True)
        rows += analyse("PsychAD", cell, M, genes, base, ["age", "sex", "log_nuclei", "mito"], "x", glen_p, rng)
        print(f"  PsychAD {cell}: {len(base)} donors", flush=True)
    T = pd.DataFrame(rows)
    for co, d in T[T["primary"] & (T["status"] == "tested")].groupby("cohort"):
        for col in ("p_perm", "p_set"):
            T.loc[d.index, f"holm_{col[2:]}"] = holm(d[col])
            T.loc[d.index, f"bh_{col[2:]}"] = bh(d[col].to_numpy())
    T.to_csv(OUT / "endpoints.csv", index=False)

    mrows = []
    for (cell, ep), d in T[T["status"] == "tested"].groupby(["cell", "endpoint"]):
        if d["cohort"].nunique() < 2:
            continue
        fe, fse, re_, rse, i2 = meta(d["z"].to_numpy(), d["z_se"].to_numpy())
        efe, efse, ere, erse, ei2 = meta(d["excess"].to_numpy(), d["excess_se_total"].to_numpy())
        mrows.append({"cell": cell, "endpoint": ep, "primary": ep in ENDPOINTS,
                      "r_fixed": np.tanh(fe), "r_fixed_lo": np.tanh(fe - 1.96 * fse), "r_fixed_hi": np.tanh(fe + 1.96 * fse),
                      "r_random": np.tanh(re_), "r_random_lo": np.tanh(re_ - 1.96 * rse), "r_random_hi": np.tanh(re_ + 1.96 * rse),
                      "I2_r": i2, "excess_fixed": efe, "excess_fixed_lo": efe - 1.96 * efse, "excess_fixed_hi": efe + 1.96 * efse,
                      "excess_random": ere, "excess_random_lo": ere - 1.96 * erse, "excess_random_hi": ere + 1.96 * erse,
                      "I2_excess": ei2, "p_excess_random": 2 * stats.norm.sf(abs(ere / erse))})
    MT = pd.DataFrame(mrows)
    pm = MT["primary"]
    MT.loc[pm, "holm_excess"] = holm(MT.loc[pm, "p_excess_random"])
    MT.loc[pm, "bh_excess"] = bh(MT.loc[pm, "p_excess_random"].to_numpy())
    MT.to_csv(OUT / "endpoints_meta.csv", index=False)

    pd.set_option("display.width", 250)
    cols = ["cohort", "cell", "endpoint", "n_genes", "n_donors", "r", "r_lo", "r_hi", "p_perm", "holm_perm", "bh_perm",
            "effect_log2", "effect_lo", "effect_hi", "percentile_vs_matched", "excess", "excess_lo", "excess_hi", "p_set",
            "holm_set", "bh_set"]
    print(T[T["status"] == "tested"][cols].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(T[T["status"] != "tested"][["cohort", "cell", "endpoint", "status"]].to_string(index=False))
    for co, d in T[T["primary"] & (T["status"] == "tested")].groupby("cohort"):
        print(f"\n{co}: {len(d)} primary tests; p_perm < 0.05 {(d.p_perm < 0.05).sum()}, Holm < 0.05 {(d.holm_perm < 0.05).sum()}, "
              f"BH < 0.05 {(d.bh_perm < 0.05).sum()}; p_set < 0.05 {(d.p_set < 0.05).sum()}, Holm {(d.holm_set < 0.05).sum()}, "
              f"BH {(d.bh_set < 0.05).sum()}; |r| 95% CI upper bound median {d[['r_lo', 'r_hi']].abs().max(1).median():.2f}")
    print("\nMeta-analysis (random effects):")
    print(MT[["cell", "endpoint", "r_random", "r_random_lo", "r_random_hi", "I2_r", "excess_random", "excess_random_lo",
              "excess_random_hi", "I2_excess", "p_excess_random", "holm_excess", "bh_excess"]].to_string(
        index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
