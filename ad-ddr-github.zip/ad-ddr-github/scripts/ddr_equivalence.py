"""Equivalence tests and leave-one-gene-out (LOGO) analysis for the DDR null result (README 39, FigS4).

    python scripts/ddr_equivalence.py           # writes results/ddr_equivalence/

The screen (README 13) showed no DDR-specific change; this asks how small a change has been
excluded, and whether any single gene drives or hides a result.

Effect: the competitive excess, delta = r(program) - mean r(200 random gene sets matched on
expression decile x gene-length quintile), r = partial correlation with local CPS (age, sex, PMI,
log nuclei). Uncertainty: 500 donor bootstrap resamples, recomputing delta with the same random sets
(so both the program and its null are resampled). Equivalence (two one-sided tests, alpha = 0.05):
the 90% bootstrap CI lies inside (-bound, +bound). Bounds: 0.20 (primary), 0.10 (strict), and half
the excess of the DAM positive control in MTG microglia. Status: "equivalent" (90% CI inside the
bound), "different" (95% CI excludes 0), otherwise "inconclusive". Benchmark: the same procedure on 20 of
each program's matched random sets, each treated as a program against the rest, gives the rates
expected for arbitrary genes; DDR programs are judged against that benchmark, not against 100%.

Cohorts / scales:
  SEA-AD     every region x cell group x 10 DDR programs (and DAM / cohesin as references)
  PsychAD    excitatory neurons, oligodendrocytes (AD vs control; age, sex, log nuclei, mito fraction;
             random sets matched on expression decile x gene-length decile)
  GeoMx      plaque-contacting vs peri-plaque microglial AOIs: beta (s.d. units) with donor bootstrap of
             the fixed-effect model; null spread from the 200 random sets of scripts/run_geomx_zones.py;
             bounds +/- 0.25 s.d. (DAM: 0.57)
  Stereo-seq log rate ratio within 25 um vs 100-300 um, excess over random sets; spread of the random-set
             null (2 sections, so no donor bootstrap); bound +/- log(1.10)

LOGO (SEA-AD MTG, every cell group x program): delta and p_set with each program gene removed in turn;
the random sets drop the matched substitute of that gene, so the null stays matched. Reported: range of
delta, the most influential gene, and the share of LOGO variants with p_set < 0.05 (calibrated by the
same LOGO procedure applied to 20 random gene sets treated as programs).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
from scipy import stats

from ad_ddr import cohort
from ad_ddr.signatures import all_programs
from ddrmulti.genome import read_gtf_genes

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/ddr_equivalence"
OUT.mkdir(parents=True, exist_ok=True)
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
COHESIN = ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2"]
COV = ["age", "sex", "pmi", "log_nuclei"]
BOUNDS = (0.20, 0.10)


def design(df: pd.DataFrame, cov: list[str]) -> np.ndarray:
    D = pd.get_dummies(df[cov], drop_first=True, dtype=float).to_numpy(float)
    return np.column_stack([np.ones(len(df)), D])


def partial_r(x: np.ndarray, S: np.ndarray, C: np.ndarray) -> np.ndarray:
    """Partial r of x with each column of S given C (C includes the intercept)."""
    beta = np.linalg.lstsq(C, np.column_stack([x, S]), rcond=None)[0]
    R = np.column_stack([x, S]) - C @ beta
    xr, Sr = R[:, 0], R[:, 1:]
    xr = xr - xr.mean()
    Sr = Sr - Sr.mean(0)
    return (xr @ Sr) / (np.linalg.norm(xr) * np.linalg.norm(Sr, axis=0) + 1e-12)


def status(lo90, hi90, lo95, hi95, bound):
    if lo90 > -bound and hi90 < bound:
        return "equivalent"
    if lo95 > 0 or hi95 < 0:
        return "different"
    return "inconclusive"


def prepare(M, genes, gene_len, n_len_bins=5):
    cpm = M / M.sum(1, keepdims=True) * 1e6
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    sd = L.std(0)
    Z = (L - L.mean(0)) / np.where(sd > 0, sd, 1)
    eb = pd.qcut(pd.Series(L.mean(0)).rank(method="first"), 10, labels=False).to_numpy()
    gl = gene_len.reindex(genes.str.upper()).to_numpy()
    ok = np.isfinite(gl)
    lq = np.full(len(gl), -1)
    lq[ok] = pd.qcut(pd.Series(gl[ok]).rank(method="first"), n_len_bins, labels=False).to_numpy()
    bins = np.where(ok, eb * n_len_bins + lq, -1)
    expressed &= ok
    pool = np.flatnonzero(expressed)
    by_bin = {b: pool[bins[pool] == b] for b in np.unique(bins[pool])}
    upper = pd.Series(np.arange(len(genes)), index=genes.str.upper())
    return Z, expressed, bins, by_bin, upper[~upper.index.duplicated()]


def program_sets(programs, Z, expressed, bins, by_bin, upper, rng, n_sets):
    out = {}
    for name, gs in programs.items():
        gi = upper.reindex([g.upper() for g in gs]).dropna().astype(int).to_numpy()
        gi = gi[expressed[gi]]
        if len(gi) < 3:
            continue
        rand = np.stack([np.array([rng.choice(by_bin[b]) for b in bins[gi]]) for _ in range(n_sets)])
        out[name] = (gi, rand)
    return out


def excess_with_ci(Z, x, base, cov, sets, rng, n_boot, n_bench=20, bounds=BOUNDS):
    """delta, its bootstrap CIs and p_set for every program in ``sets``; plus a benchmark: the same
    procedure applied to ``n_bench`` of the program's own random sets, each treated as a program
    against the others, giving the rate of "equivalent" / "different" expected for arbitrary genes."""
    names = list(sets)
    cols = []
    for nm in names:
        gi, rand = sets[nm]
        cols.append(np.column_stack([Z[:, gi].mean(1), Z[:, rand].mean(2)]))
    S = np.column_stack(cols)
    k = [1 + sets[nm][1].shape[0] for nm in names]
    edges = np.cumsum([0] + k)
    C = design(base, cov)
    r0 = partial_r(x, S, C)
    boots = []
    for _ in range(n_boot):
        ix = rng.choice(len(x), len(x))
        if np.linalg.matrix_rank(C[ix]) < C.shape[1]:
            continue
        boots.append(partial_r(x[ix], S[ix], C[ix]))
    B = np.array(boots)
    rows = []
    for j, nm in enumerate(names):
        a, b = edges[j], edges[j + 1]
        obs, null = r0[a], r0[a + 1:b]
        dB = B[:, a] - B[:, a + 1:b].mean(1)
        lo90, hi90 = np.percentile(dB, [5, 95])
        lo95, hi95 = np.percentile(dB, [2.5, 97.5])
        row = {"program": nm, "n_genes": len(sets[nm][0]), "r": obs, "null_mean": null.mean(), "null_sd": null.std(),
               "delta": obs - null.mean(), "se_boot": dB.std(), "lo90": lo90, "hi90": hi90, "lo95": lo95, "hi95": hi95,
               "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (len(null) + 1)}
        nb = min(n_bench, b - a - 1)
        for bd in bounds:
            eq = di = 0
            for m in range(nb):
                c = a + 1 + m
                others = np.r_[a + 1:c, c + 1:b]
                dm = B[:, c] - B[:, others].mean(1)
                l9, h9 = np.percentile(dm, [5, 95])
                l5, h5 = np.percentile(dm, [2.5, 97.5])
                st = status(l9, h9, l5, h5, bd)
                eq += st == "equivalent"
                di += st == "different"
            row[f"bench_equiv_{bd}"] = eq / nb
            row[f"bench_diff_{bd}"] = di / nb
        rows.append(row)
    return rows


def logo(Z, x, C, gi, rand, gene_names):
    """Leave-one-gene-out delta and p_set; the random sets drop the matched substitute."""
    out = []
    for j in range(len(gi)):
        keep = np.delete(np.arange(len(gi)), j)
        S = np.column_stack([Z[:, gi[keep]].mean(1), Z[:, rand[:, keep]].mean(2)])
        r = partial_r(x, S, C)
        obs, null = r[0], r[1:]
        out.append({"dropped": gene_names[gi[j]], "delta": obs - null.mean(),
                    "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (len(null) + 1)})
    return pd.DataFrame(out)


def seaad(args, rng, gene_len):
    progs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}
    progs["cohesin"] = COHESIN
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")[["Donor ID", "Brain Region", "CPS_Local"]]
    cps.columns = ["donor", "region", "cps"]
    rows, logo_rows, logo_null = [], [], []
    for p in sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad")):
        idx, Cnt, genes, meta = cohort.aggregate([p])
        meta = meta.assign(age=pd.to_numeric(meta["age"], errors="coerce"), pmi=pd.to_numeric(meta["pmi"], errors="coerce"),
                           severe=meta["severe"].astype(str).eq("Y"))
        idx = idx.merge(cps, on=["donor", "region"], how="left").join(meta[["age", "sex", "pmi", "severe"]], on="donor")
        keep = (idx["level"] == "group") \
            & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool) & idx[["cps", "age", "pmi"]].notna().all(1)
        for (region, level, group), d in idx[keep].groupby(["region", "level", "group"]):
            if len(d) < 10:
                continue
            base = d.assign(log_nuclei=np.log10(d["n_nuclei"])).reset_index(drop=True)
            Z, expressed, bins, by_bin, upper = prepare(Cnt[d.index.to_numpy()], genes, gene_len)
            sets = program_sets(progs, Z, expressed, bins, by_bin, upper, rng, args.n_sets)
            x = base["cps"].to_numpy(float)
            for r in excess_with_ci(Z, x, base, COV, sets, rng, args.n_boot):
                rows.append({"cohort": "SEA-AD", "region": region, "group": group, "n_donors": len(d), **r})
            if region == "MTG":
                C = design(base, COV)
                gnames = genes.to_numpy()
                for nm in DDR + ["DAM", "cohesin"]:
                    if nm not in sets:
                        continue
                    gi, rand = sets[nm]
                    L = logo(Z, x, C, gi, rand, gnames).assign(group=group, program=nm)
                    logo_rows.append(L)
                # calibration: LOGO on random gene sets of typical program size, treated as programs
                for k in range(args.n_logo_null):
                    nm = DDR[k % len(DDR)]
                    if nm not in sets:
                        continue
                    gi, rand = sets[nm]
                    fake = rand[k]
                    rr = np.stack([np.array([rng.choice(by_bin[b]) for b in bins[fake]]) for _ in range(args.n_sets)])
                    L = logo(Z, x, C, fake, rr, gnames)
                    logo_null.append({"group": group, "size": len(fake), "any_logo_p05": (L["p_set"] < 0.05).any(),
                                      "frac_logo_p05": (L["p_set"] < 0.05).mean()})
        print(f"  {p.stem}: {len(rows)} rows", flush=True)
    return pd.DataFrame(rows), pd.concat(logo_rows), pd.DataFrame(logo_null)


def psychad(args, rng):
    cache = ROOT / "data/processed/psychad_pb"
    mf = cache / "meta.csv"
    if mf.exists():
        meta = pd.read_csv(mf, index_col=0)
        glen = pd.read_csv(cache / "gene_length.csv", index_col=0).iloc[:, 0]
    else:
        a = ad.read_h5ad(ROOT / "data/raw/psychad/MSSM_cohort.h5ad", backed="r")
        o = a.obs
        var = a.raw.var if a.raw is not None else a.var
        glen = pd.Series(np.log10(np.maximum(var["feature_length"].to_numpy(float), 1)),
                         index=var["feature_name"].astype(str).str.upper())
        glen = glen[~glen.index.duplicated()]
        d = o.drop_duplicates("donor_id").set_index("donor_id")
        other = d[[c for c in d.columns if c.endswith("_status") and c != "AD_status"]].astype(str).eq("Yes").any(axis=1)
        meta = pd.DataFrame({"ad": (d["AD_status"].astype(str) == "Yes").to_numpy(),
                             "control": (d["disease"].astype(str) == "normal").to_numpy(),
                             "age": d["development_stage"].astype(str).str.extract(r"(\d+)-year")[0].astype(float).to_numpy(),
                             "sex": d["sex"].astype(str).to_numpy(), "other": other.to_numpy()}, index=d.index.astype(str))
        for cname in ("EN", "Oligo"):
            meta[f"n_{cname}"] = o.loc[o["class"].astype(str) == cname, "donor_id"].astype(str).value_counts().reindex(meta.index).fillna(0).to_numpy()
        meta.to_csv(mf)
        glen.to_csv(cache / "gene_length.csv")
    con = meta[((meta["ad"] & ~meta["other"]) | (meta["control"] & ~meta["ad"])) & meta["age"].notna()]
    progs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}
    progs["cohesin"] = COHESIN
    rows = []
    for cname in ("EN", "Oligo"):
        z = np.load(cache / f"{cname}.npz", allow_pickle=True)
        cats, M, genes = pd.Index(z["cats"].astype(str)), z["M"], pd.Index(z["genes"].astype(str))
        n = con[f"n_{cname}"].reindex(cats).to_numpy()
        ok = np.isfinite(n) & (n >= 50)
        cats, M, n = cats[ok], M[ok], n[ok]
        base = con.loc[cats].assign(log_nuclei=np.log10(n), mito=M[:, genes.str.startswith("MT-")].sum(1) / M.sum(1))
        Z, expressed, bins, by_bin, upper = prepare(M, genes, glen, n_len_bins=10)
        sets = program_sets(progs, Z, expressed, bins, by_bin, upper, rng, args.n_sets)
        for r in excess_with_ci(Z, base["ad"].to_numpy(float), base, ["age", "sex", "log_nuclei", "mito"], sets, rng,
                                args.n_boot):
            rows.append({"cohort": "PsychAD", "region": "DLPFC", "group": cname, "n_donors": len(base), **r})
        print(f"  PsychAD {cname}: {len(base)} donors", flush=True)
    return pd.DataFrame(rows)


def spatial(rng):
    rows = []
    z = pd.read_csv(ROOT / "results/spatial_geomx/zone_effects.csv")
    z = z[z["contrast"] == "P_vs_PP"] if "P_vs_PP" in set(z["contrast"]) else z[z["contrast"].str.contains("P_vs_PP|PvsPP")]
    a = pd.read_csv(ROOT / "results/spatial_geomx/aoi_scores.csv", index_col=0)
    a = a[a["zone"].isin(["P", "PP"])]
    a = a[a.groupby("donor")["zone"].transform("nunique") == 2]
    for _, r in z.iterrows():
        prog = r["program"]
        if prog not in a.columns:
            continue
        donors = a["donor"].unique()

        def beta(df):
            X = np.column_stack([(df["zone"] == "P").astype(float), np.log10(df["total_counts"]), np.log10(df["area"]),
                                 pd.get_dummies(df["donor"], dtype=float).to_numpy()])
            y = df[prog].to_numpy(float)
            y = (y - y.mean()) / y.std()
            return np.linalg.lstsq(X, y, rcond=None)[0][0]
        bs = []
        for _ in range(500):
            pick = rng.choice(donors, len(donors))
            df = pd.concat([a[a["donor"] == d].assign(donor=f"{d}_{i}") for i, d in enumerate(pick)])
            bs.append(beta(df))
        bs = np.array(bs)
        null_sd = (r["null_hi"] - r["null_lo"]) / 3.92
        se = np.sqrt(bs.std() ** 2 + null_sd ** 2)
        d0 = r["excess"]
        rows.append({"cohort": "GeoMx", "region": "hippocampus", "group": "microglial AOIs (P vs PP)",
                     "n_donors": int(r["n_donors"]), "program": prog, "n_genes": int(r["n_genes"]), "r": r["beta_sd"],
                     "null_mean": r["null_mean"], "delta": d0, "se_boot": se, "lo90": d0 - 1.645 * se,
                     "hi90": d0 + 1.645 * se, "lo95": d0 - 1.96 * se, "hi95": d0 + 1.96 * se, "p_set": r["p_set"],
                     "bound": 0.25})
    s = pd.read_csv(ROOT / "results/stereoseq_plaque/pooled_effects.csv")
    s = s[(s["estimand"] == "total") & (s["group"] == "AD_18M")]
    for _, r in s.iterrows():
        d0, se = r["excess_log_vs_sets"], r["null_set_sd_log"]
        rows.append({"cohort": "Stereo-seq", "region": "App NL-G-F cortex", "group": "25 um bins (near vs 100-300 um)",
                     "n_donors": int(r["n_sections"]), "program": r["set"], "n_genes": np.nan, "r": np.log(r["rr"]),
                     "null_mean": np.log(r["rr"]) - d0, "delta": d0, "se_boot": se, "lo90": d0 - 1.645 * se,
                     "hi90": d0 + 1.645 * se, "lo95": d0 - 1.96 * se, "hi95": d0 + 1.96 * se, "p_set": r["p_set"],
                     "bound": np.log(1.10)})
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--n-boot", type=int, default=500)
    ap.add_argument("--n-logo-null", type=int, default=20)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--skip-psychad", action="store_true")
    ap.add_argument("--summary-only", action="store_true", help="re-summarise saved results")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    gene_len = np.log10((genes["end"] - genes["start"]).clip(lower=1))
    gene_len.index = gene_len.index.str.upper()
    gene_len = gene_len[~gene_len.index.duplicated()]

    if args.summary_only:
        E = pd.read_csv(OUT / "equivalence.csv").drop(columns=["status", "status_strict", "status_dam_half", "family"])
        LG, LN = pd.read_csv(OUT / "logo_mtg.csv.gz"), pd.read_csv(OUT / "logo_null_mtg.csv")
    else:
        S, LG, LN = seaad(args, rng, gene_len)
        parts = [S]
        if not args.skip_psychad:
            parts.append(psychad(args, rng))
        parts.append(spatial(rng))
        E = pd.concat(parts, ignore_index=True)
    dam = E[(E["cohort"] == "SEA-AD") & (E["region"] == "MTG") & (E["group"] == "Microglia-PVM") & (E["program"] == "DAM")]
    dam_bound = float(dam["delta"].iat[0]) / 2 if len(dam) else np.nan
    E["bound"] = E["bound"].fillna(BOUNDS[0]) if "bound" in E else BOUNDS[0]
    E["status"] = [status(a, b, c, d, bd) for a, b, c, d, bd in zip(E["lo90"], E["hi90"], E["lo95"], E["hi95"], E["bound"])]
    E["status_strict"] = [status(a, b, c, d, BOUNDS[1] if co in ("SEA-AD", "PsychAD") else bd) for a, b, c, d, bd, co in
                          zip(E["lo90"], E["hi90"], E["lo95"], E["hi95"], E["bound"], E["cohort"])]
    E["status_dam_half"] = [status(a, b, c, d, dam_bound) if co in ("SEA-AD", "PsychAD") else "" for a, b, c, d, co in
                            zip(E["lo90"], E["hi90"], E["lo95"], E["hi95"], E["cohort"])]
    E["family"] = np.where(E["program"].isin(DDR), "DDR", "reference")
    E.to_csv(OUT / "equivalence.csv", index=False)
    LG.to_csv(OUT / "logo_mtg.csv.gz", index=False)
    LN.to_csv(OUT / "logo_null_mtg.csv", index=False)

    ddr = E[E["family"] == "DDR"]
    print(f"\nDAM reference (MTG microglia): delta = {dam_bound * 2:.3f}; half = {dam_bound:.3f}")
    for (co, rg), d in ddr.groupby(["cohort", ddr["region"].where(ddr["region"] == "MTG", "other")]):
        if "bench_equiv_0.2" in d and d["bench_equiv_0.2"].notna().any():
            print(f"{co:10s} {rg:6s} random-set benchmark: equivalent {d['bench_equiv_0.2'].mean():.0%}, "
                  f"different {d['bench_diff_0.2'].mean():.0%} (bound 0.20); equivalent {d['bench_equiv_0.1'].mean():.0%} (0.10)")
        print(f"{co:10s} {rg:6s} n = {len(d):4d}  equivalent (primary bound) {(d.status == 'equivalent').mean():.0%}, "
              f"different {(d.status == 'different').mean():.0%}; strict 0.10: {(d.status_strict == 'equivalent').mean():.0%}; "
              f"half-DAM: {(d.status_dam_half == 'equivalent').mean():.0%}; median 90% CI half-width "
              f"{((d.hi90 - d.lo90) / 2).median():.3f}")
    print("\nNon-equivalent DDR tests (primary bound), MTG / PsychAD / spatial:")
    show = ddr[(ddr["status"] != "equivalent") & ((ddr["region"] == "MTG") | (ddr["cohort"] != "SEA-AD"))]
    print(show[["cohort", "group", "program", "n_donors", "delta", "lo90", "hi90", "p_set", "status"]].to_string(
        index=False, float_format=lambda v: f"{v:.3g}"))
    print("\nReferences:")
    print(E[E["family"] == "reference"].query("region in ['MTG', 'DLPFC'] and group in ['Microglia-PVM', 'L2/3 IT', 'Oligodendrocyte', 'EN', 'Oligo']")[
        ["cohort", "group", "program", "delta", "lo90", "hi90", "status"]].to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # LOGO summary
    mt = E[(E["cohort"] == "SEA-AD") & (E["region"] == "MTG")].copy()
    full = {(g, pnm): v for g, pnm, v in zip(mt["group"], mt["program"], mt["delta"])}
    LG = LG.reset_index(drop=True)
    summ = []
    for (g, pnm), d in LG.groupby(["group", "program"]):
        f = full.get((g, pnm), np.nan)
        k = (d["delta"] - f).abs().idxmax()
        summ.append({"group": g, "program": pnm, "n_genes": len(d), "delta_full": f, "delta_min": d["delta"].min(),
                     "delta_max": d["delta"].max(), "max_abs_change": (d["delta"] - f).abs().max(),
                     "most_influential": d.loc[k, "dropped"], "n_logo_p05": int((d["p_set"] < 0.05).sum()),
                     "frac_logo_p05": (d["p_set"] < 0.05).mean()})
    SM = pd.DataFrame(summ)
    SM.to_csv(OUT / "logo_summary_mtg.csv", index=False)
    dd = SM[SM["program"].isin(DDR)]
    print(f"\nLOGO (MTG, {len(dd)} DDR tests, {int(dd['n_genes'].sum())} variants): variants with p_set < 0.05 "
          f"{(LG[LG.program.isin(DDR)]['p_set'] < 0.05).mean():.3f}; tests with any such variant "
          f"{(dd['n_logo_p05'] > 0).mean():.2f} (random-set calibration: {LN['any_logo_p05'].mean():.2f}); "
          f"median max |change in delta| {dd['max_abs_change'].median():.3f}")
    print(dd.sort_values("max_abs_change", ascending=False).head(12).to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(SM[SM["program"].isin(["DAM", "cohesin"]) & SM["group"].isin(["Microglia-PVM", "L2/3 IT", "Oligodendrocyte"])]
          .to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
