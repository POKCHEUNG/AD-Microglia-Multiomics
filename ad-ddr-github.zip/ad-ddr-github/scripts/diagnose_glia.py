"""Diagnostics for glial positive controls: depth, composition and marker genes vs CPS."""
import sys
import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

from ad_ddr import io, scoring

obs = pd.read_csv("results/v2/cell_scores.csv.gz", index_col=0)
donors = pd.read_csv("results/v2/donors.csv", index_col=0)
cps = donors["cps"]

def r(x):
    x = x.reindex(cps.index).dropna()
    return f"r={np.corrcoef(x, cps[x.index])[0, 1]:+.2f} (n={len(x)})"

print("donor mean log10 UMI vs CPS:", r(obs.groupby("donor")["log_umi"].mean()))
print("fraction multiome nuclei vs CPS:", r(obs.groupby("donor")["method"].apply(lambda m: (m == "10xMulti").mean())))
for g in ["Microglia-PVM", "Astrocyte"]:
    d = obs[obs.group == g]
    print(f"\n{g}: log UMI vs CPS {r(d.groupby('donor')['log_umi'].mean())}")
    comp = pd.crosstab(d.donor, d.supertype, normalize="index")
    for st in comp.columns:
        print(f"  frac {st:24} {r(comp[st])}  mean={comp[st].mean():.3f}")

markers = {"Microglia-PVM": ["TREM2", "SPP1", "APOE", "CD9", "GPNMB", "LPL", "P2RY12", "CX3CR1"],
           "Astrocyte": ["GFAP", "CHI3L1", "SERPINA3", "VIM", "C3", "AQP4", "S100B", "SLC1A2"]}
rows = []
for dn in donors.index:
    rna, _ = io.load_donor(*io.donor_paths("data/raw", dn))
    rna.obs["group"] = scoring.cell_groups(rna.obs)
    for g, genes in markers.items():
        m = (rna.obs["group"] == g).to_numpy()
        X = rna[m, genes].X
        X = X.toarray() if sp.issparse(X) else X
        rows += [{"donor": dn, "group": g, "gene": gn, "mean": X[:, i].mean(), "frac": (X[:, i] > 0).mean()}
                 for i, gn in enumerate(genes)]
mk = pd.DataFrame(rows)
print("\nmarker genes (donor mean ln-expr) vs CPS:")
for (g, gn), d in mk.groupby(["group", "gene"]):
    print(f"  {g:14} {gn:9} {r(d.set_index('donor')['mean'])}")
mk.to_csv("results/v2/marker_genes_by_donor.csv", index=False)
