#!/usr/bin/env bash
# Download per-donor SEA-AD MTG RNA + ATAC h5ad files listed in data/meta/selected_donors.csv.
# Resumable (curl -C -); 3 files in parallel.
set -euo pipefail
B=https://sea-ad-single-cell-profiling.s3.amazonaws.com
cd "$(dirname "$0")/.."
python3 -I - <<'PY' | xargs -P 3 -n 2 sh -c 'mkdir -p "$(dirname "$1")"; curl -sS --retry 5 -C - -o "$1" "'"$B"'/$0" && echo "done $1"'
import csv, urllib.parse
for r in csv.DictReader(open("data/meta/selected_donors.csv")):
    d = r["Donor ID"]
    for mod, key in (("rna", r["rna_key"]), ("atac", r["atac_key"])):
        print(urllib.parse.quote(key), f"data/raw/{mod}/{d}.h5ad")
PY
