#!/usr/bin/env bash
# Download SEA-AD Multiregion_2026 per-subclass pseudobulk objects (~4 GB total). Resumable.
set -euo pipefail
B=https://sea-ad-single-cell-profiling.s3.amazonaws.com
cd "$(dirname "$0")/.."
mkdir -p data/raw/pseudobulk
curl -s "$B/?list-type=2&prefix=Multiregion_2026/pseudobulk_objects/" | tr '<' '\n' | grep '^Key>' | sed 's/^Key>//' \
  | while read -r key; do
      sub=$(basename "$key" | sed -E 's/^SEAAD_(.+)_HIP_MEC.*/\1/')
      echo "$key data/raw/pseudobulk/$sub.h5ad"
    done \
  | xargs -P 3 -n 2 sh -c 'curl -sS --retry 5 -C - -o "$1" "'"$B"'/$0" && echo "done $1"'
