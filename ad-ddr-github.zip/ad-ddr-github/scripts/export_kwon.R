# Export the Kwon 2023 Visium-SPG spe (counts, spot metadata, gene names) for Python.
#   Rscript scripts/export_kwon.R data/raw/visium_kwon/Visium_SPG_AD_spe_wholegenome.Rdata data/processed/kwon
suppressMessages({library(SpatialExperiment); library(Matrix)})
args <- commandArgs(TRUE)
dir.create(args[2], recursive = TRUE, showWarnings = FALSE)
e <- new.env(); load(args[1], envir = e); spe <- e$spe
writeMM(as(counts(spe), "CsparseMatrix"), file.path(args[2], "counts_genes_x_spots.mtx"))
rd <- as.data.frame(rowData(spe)); rd$gene_id <- rownames(spe)
write.csv(rd[, c("gene_id", "gene_name", "gene_type")], file.path(args[2], "genes.csv"), row.names = FALSE)
keep <- c("key", "sample_id", "subject", "diagnosis", "age", "sex", "pmi", "braak", "cerad", "APOe", "array_row", "array_col",
          "sum_umi", "sum_gene", "expr_chrM_ratio", "edge_spots", "edge_distance", "NAbeta", "PAbeta", "NpTau", "PpTau", "NDAPI",
          "path_Abeta", "path_pTau", "path_groups", "BayesSpace_harmony_k02", "BayesSpace_harmony_k09",
          "c2l_ast", "c2l_ex", "c2l_in", "c2l_mic", "c2l_oli", "c2l_opc")
cd <- as.data.frame(colData(spe))[, keep]
cd <- cbind(cd, spatialCoords(spe))
write.csv(cd, file.path(args[2], "spots.csv"), row.names = FALSE)
cat("wrote", ncol(spe), "spots x", nrow(spe), "genes\n")
