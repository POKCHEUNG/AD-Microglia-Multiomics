# Sum Miyoshi 2024 human Visium counts into (sample x cortical-layer annotation) pseudobulks.
#   Rscript scripts/export_miyoshi_pseudobulk.R data/raw/visium_miyoshi/GSE233208_Human_visium_ADDS_seurat_processed.rds data/processed/miyoshi
suppressMessages({library(SeuratObject); library(Matrix)})
args <- commandArgs(TRUE)
dir.create(args[2], recursive = TRUE, showWarnings = FALSE)
s <- readRDS(args[1])
md <- s@meta.data
X <- LayerData(s, assay = "Spatial", layer = "counts")
key <- paste(md$Sample, md$annotation, sep = "|")
f <- factor(key)
A <- sparseMatrix(i = seq_along(f), j = as.integer(f), x = 1, dims = c(length(f), nlevels(f)))
P <- as.matrix(X %*% A)
colnames(P) <- levels(f)
write.csv(P, gzfile(file.path(args[2], "pseudobulk_genes_x_sample_layer.csv.gz")))
deconv <- grep("_deconv$", names(md), value = TRUE)
agg <- aggregate(md[, c("nCount_Spatial", deconv)], list(key = key), mean)
n <- as.data.frame(table(key = key))
info <- unique(md[, c("Sample", "SampleID", "Case.Year", "Case.Num", "Diagnosis", "Sex", "Age", "Slide", "seqbatch")])
out <- merge(merge(agg, n, by = "key"), transform(data.frame(key = levels(f)), Sample = sub("\\|.*", "", key),
                                                  layer = sub(".*\\|", "", key)), by = "key")
out <- merge(out, info, by = "Sample")
write.csv(out, file.path(args[2], "pseudobulk_meta.csv"), row.names = FALSE)
cat(ncol(P), "pseudobulks from", length(unique(md$Sample)), "samples\n")
