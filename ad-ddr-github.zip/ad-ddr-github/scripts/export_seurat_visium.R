# Export the Miyoshi 2024 (GSE233208) human Visium Seurat object to Python-readable files.
#
#   Rscript scripts/export_seurat_visium.R data/raw/miyoshi/GSE233208_Human_visium_ADDS_seurat_processed.rds data/raw/miyoshi/export
#
# Writes: counts.mtx (+ genes.txt, spots.txt) from the Spatial assay, spot metadata
# (obs.csv), tissue coordinates for every image (coords.csv), and a description of the
# metadata columns (obs_columns.txt) so pathology annotations can be located.
suppressPackageStartupMessages({
  library(SeuratObject)
  library(Matrix)
})
args <- commandArgs(trailingOnly = TRUE)
src <- args[1]
out <- args[2]
dir.create(out, showWarnings = FALSE, recursive = TRUE)

obj <- readRDS(src)
cat("class:", class(obj), "\n")
cat("assays:", paste(Assays(obj), collapse = ", "), "\n")
cat("spots:", ncol(obj), " images:", length(Images(obj)), "\n")

assay <- if ("Spatial" %in% Assays(obj)) "Spatial" else DefaultAssay(obj)
counts <- tryCatch(LayerData(obj, assay = assay, layer = "counts"),
                   error = function(e) GetAssayData(obj, assay = assay, slot = "counts"))
cat("counts:", nrow(counts), "genes x", ncol(counts), "spots; class", class(counts), "\n")
writeMM(as(counts, "CsparseMatrix"), file.path(out, "counts.mtx"))
writeLines(rownames(counts), file.path(out, "genes.txt"))
writeLines(colnames(counts), file.path(out, "spots.txt"))

md <- obj@meta.data
write.csv(md, file.path(out, "obs.csv"))
desc <- vapply(names(md), function(c) {
  v <- md[[c]]
  if (is.numeric(v)) sprintf("%s\tnumeric\trange %.3g..%.3g\tNA %d", c, min(v, na.rm = TRUE), max(v, na.rm = TRUE), sum(is.na(v)))
  else { u <- unique(as.character(v)); sprintf("%s\t%s\t%d levels\t%s", c, class(v)[1], length(u), paste(head(u, 8), collapse = "|")) }
}, character(1))
writeLines(desc, file.path(out, "obs_columns.txt"))

coords <- do.call(rbind, lapply(Images(obj), function(im) {
  xy <- tryCatch(GetTissueCoordinates(obj, image = im), error = function(e) NULL)
  if (is.null(xy)) return(NULL)
  xy <- as.data.frame(xy)
  if (!"cell" %in% names(xy)) xy$cell <- rownames(xy)
  xy$image <- im
  sf <- tryCatch(ScaleFactors(obj[[im]]), error = function(e) NULL)
  xy$spot_diameter_fullres <- if (!is.null(sf)) sf$spot else NA
  xy
}))
write.csv(coords, file.path(out, "coords.csv"), row.names = FALSE)
cat("coords rows:", nrow(coords), "\n")
cat("done\n")
