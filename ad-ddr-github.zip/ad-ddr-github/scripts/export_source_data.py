"""Source data for every manuscript figure (README "Reproduce"; docs/REPRODUCIBILITY.md).

    python scripts/export_source_data.py        # writes docs/source_data/<Fig>/ and docs/source_data/INDEX.md

Copies the result tables that each figure script reads (make_paper_figures.py and make_supp_*.py) into one
folder per figure, gzipping tables over 1 MB, and writes an index with the panel each table supports, its
size and its producing script. Re-run after the analyses; the figure scripts read results/ directly.
"""

from __future__ import annotations

import gzip
import shutil
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "results"
OUT = ROOT / "docs/source_data"

# figure -> [(result file, panels, producing script)]
SOURCES = {
    "Fig1": [("global_specific/shared_fraction.csv", "d", "global_vs_specific.py"),
             ("global_specific/specific_counts.csv", "e", "global_vs_specific.py"),
             ("global_specific/programs_vs_shared.csv", "f", "global_vs_specific.py")],
    "Fig2": [("screen/screen_MTG.csv", "a", "run_celltype_screen.py"),
             ("screen/screen_all.csv", "a (all regions)", "run_celltype_screen.py"),
             ("psychad_neurons/ddr_neurons.csv", "b", "run_psychad_neurons.py"),
             ("spatial_geomx/zone_effects.csv", "c", "run_geomx_zones.py"),
             ("stereoseq_plaque/pooled_effects.csv", "d", "run_stereoseq_plaque_ddr.py"),
             ("laminar/laminar.csv", "e", "run_laminar_mismatch.py"),
             ("laminar/donor_level.csv", "f", "run_laminar_mismatch.py")],
    "Fig3": [("published_sets_lenmatched/published_sets.csv", "a", "run_published_sets.py"),
             ("paper_figures/seaad_cohesin_genes.csv", "b (SEA-AD)", "make_paper_figures.py"),
             ("cohesin_psychad/cohesin_psychad_genes.csv", "b (PsychAD)", "replicate_cohesin_psychad.py"),
             ("cohesin_psychad/cohesin_psychad.csv", "c", "replicate_cohesin_psychad.py")],
    "Fig4": [("dam_peaks/dam_peaks_all.csv.gz", "a", "run_dam_peaks.py"),
             ("dam_peaks/peak_rna_pairs.csv.gz", "b", "validate_dam_peaks.py"),
             ("dam_peaks/validation_rna.csv", "b", "validate_dam_peaks.py"),
             ("dam_regulatory/set_tests.csv", "c", "run_dam_regulatory.py"),
             ("hippo_replication/dam_chromatin.csv", "c", "run_hippo_replication.py"),
             ("dam_regulatory/gene_domains.csv.gz", "d", "run_dam_regulatory.py"),
             ("hippo_replication/dam_chromatin_donors.csv", "e", "run_hippo_replication.py")],
    "Fig5": [("dam_peaks/homeostatic_shift_donors.csv", "a", "robust_homeostatic_shift.py"),
             ("dam_peaks/homeostatic_shift_robustness.csv", "b", "robust_homeostatic_shift.py"),
             ("split_replication/splits.csv", "c", "split_replication.py"),
             ("hippo_replication/homeostatic_shift.csv", "d", "run_hippo_replication.py"),
             ("hippo_replication/homeostatic_shift_donors_Braak.csv", "d", "run_hippo_replication.py"),
             ("homeostatic_shift/nucleus_shift.csv", "e, f", "seaad_nucleus_shift.py")],
    "Fig6": [("dam_regulatory/gene_domains.csv.gz", "a", "run_dam_regulatory.py"),
             ("candidate_links/gwas_window_RASGEF1C.csv.gz", "b", "candidate_links.py"),
             ("dam_peaks/dam_peaks_all.csv.gz", "b", "run_dam_peaks.py"),
             ("candidate_links/same_nucleus_links.csv", "b, c", "candidate_links.py"),
             ("candidate_links/gwas_finemap.csv", "c", "candidate_links.py"),
             ("candidate_links/element_snp_eqtl.csv", "c", "candidate_links.py"),
             ("candidate_links/coloc.csv", "c", "candidate_links.py"),
             ("candidate_links/encode_re2g.csv", "c", "candidate_links.py"),
             ("dam_peaks/gwas_enrichment.csv", "d", "gwas_dam_peaks.py")],
    "Fig7": [("dam_tf/tf_families.csv", "a", "dam_tf_grn.py"),
             ("dam_tf/tf_activity.csv", "b", "dam_tf_grn.py"),
             ("dam_tf/motif_activity.csv", "c, e", "dam_tf_grn.py"),
             ("dam_tf/grn_edges.csv", "d", "dam_tf_grn.py")],
    "FigS1": [("paper_figures/hippo_microglia_umap.csv.gz", "a–h", "make_supp_umap.py")],
    "FigS2": [("homeostatic_shift/selection_ci_features_continuum.csv", "a, b, d", "homeostatic_shift_selection.py"),
              ("homeostatic_shift/random_halves_r.csv", "b", "homeostatic_shift_selection.py"),
              ("homeostatic_shift/genome_wide_concordance.csv", "c", "homeostatic_shift_selection.py"),
              ("homeostatic_shift/peak_plaque_r.csv.gz", "c", "homeostatic_shift_selection.py"),
              ("hippo_replication/continuous_quintiles.csv", "e", "hippo_continuous_state.py"),
              ("hippo_replication/continuous_threshold_sweep.csv", "f", "hippo_continuous_state.py")],
    "FigS3": [("microglia_states/supertype_programs.csv", "a", "microglia_states.py"),
              ("microglia_states/program_pathology.csv", "b", "microglia_states.py"),
              ("microglia_states/supertype_share_cps.csv", "c", "microglia_states.py"),
              ("microglia_states/state_motif_activity.csv", "d", "microglia_states.py"),
              ("microglia_states/hippo_cell_programs.csv.gz", "e", "microglia_states.py")],
    "FigS4": [("ddr_equivalence/equivalence.csv", "a, b, d–f", "ddr_equivalence.py"),
              ("ddr_equivalence/logo_summary_mtg.csv", "c", "ddr_equivalence.py"),
              ("ddr_equivalence/logo_null_mtg.csv", "c", "ddr_equivalence.py")],
    "FigS5": [("ddr_endpoints/endpoints.csv", "a–f", "ddr_endpoints.py"),
              ("ddr_endpoints/endpoints_meta.csv", "a–f", "ddr_endpoints.py")],
    "FigS6": [("rasgef1c/B_element_accessibility_by_subclass.csv", "a", "rasgef1c_chain.py"),
              ("rasgef1c/D_expression_by_cell.csv", "b", "rasgef1c_chain.py"),
              ("rasgef1c/C_links.csv", "c", "rasgef1c_chain.py"),
              ("rasgef1c/A_variants.csv", "d", "rasgef1c_chain.py"),
              ("rasgef1c/A_phylop_background.csv", "d", "rasgef1c_chain.py"),
              ("rasgef1c/E_coloc.csv", "e", "rasgef1c_chain.py"),
              ("rasgef1c/F_haglund2025.csv", "e (top row)", "haglund_rasgef1c.py")],
    "FigS7": [("tf_ranking/tf_ranking.csv", "a", "tf_ranking.py"),
              ("tf_ranking/bootstrap_ranks.csv.gz", "b", "tf_ranking.py"),
              ("tf_ranking/leave_one_line_out.csv", "c", "tf_ranking.py")],
    "FigS8": [("global_specific/psychad_shared_fraction.csv", "a", "psychad_global_vs_specific.py"),
              ("global_specific/psychad_specific_counts.csv", "b", "psychad_global_vs_specific.py"),
              ("global_specific/psychad_vs_seaad_replication.csv", "c, d", "psychad_global_vs_specific.py")],
    "FigS9": [("published_claims/power_curve.csv", "a", "published_claims_power.py"),
              ("published_claims/pilot_tests.csv", "b–d", "published_claims_pilot.py")],
}


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    rows, missing = [], []
    for fig, items in SOURCES.items():
        d = OUT / fig
        d.mkdir(parents=True, exist_ok=True)
        for rel, panels, script in items:
            src = R / rel
            if not src.exists():
                missing.append(rel)
                continue
            name = rel.replace("/", "__")
            if src.suffix != ".gz" and src.stat().st_size > 1_000_000:
                dst = d / f"{name}.gz"
                with open(src, "rb") as fi, gzip.open(dst, "wb") as fo:
                    shutil.copyfileobj(fi, fo)
            else:
                dst = d / name
                shutil.copy2(src, dst)
            n = len(pd.read_csv(dst))
            rows.append({"figure": fig, "panels": panels, "file": f"{fig}/{dst.name}", "rows": n,
                         "kB": round(dst.stat().st_size / 1024), "script": f"scripts/{script}", "result": f"results/{rel}"})
    T = pd.DataFrame(rows)
    lines = ["# Source data", "", "One folder per figure; each table is the result file read by the figure script "
             "(`scripts/make_paper_figures.py`, `scripts/make_supp_*.py`). Regenerate with "
             "`python scripts/export_source_data.py` after the analyses.", "",
             "| Figure | Panels | File | Rows | kB | Produced by |", "|---|---|---|---|---|---|"]
    lines += [f"| {r.figure} | {r.panels} | `{r.file}` | {r.rows:,} | {r.kB:,} | `{r.script}` |" for r in T.itertuples()]
    (OUT / "INDEX.md").write_text("\n".join(lines) + "\n")
    print(f"{len(T)} tables, {T['kB'].sum() / 1024:.1f} MB, {T['figure'].nunique()} figures; missing: {missing}")


if __name__ == "__main__":
    main()
