"""Keep per-nucleus microglia counts of one SEA-AD MTG ATAC donor object (README 42).

    python scripts/extract_atac_micro_cells.py <donor.h5ad> data/processed/atac_micro_cells

Nuclei: Subclass Microglia-PVM and "Used in analysis". Columns: the 32,481 peaks tested in the DAM
analysis (results/dam_peaks/dam_peaks_all.csv.gz) plus the per-nucleus total over all 218,882 peaks.
Writes <donor>.npz (sparse nuclei x tested peaks), <donor>.csv (barcode, supertype, supertype
confidence, chemistry, total counts, number of UMIs, doublet score) and <donor>_multivi.npy (the
released MultiVI latent coordinates of the same nuclei).
"""

from __future__ import annotations

import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parents[1]


def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    a = ad.read_h5ad(src)
    obs = a.obs
    donor = str(obs["Donor ID"].iloc[0])
    tested = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz", usecols=["peak"])["peak"]
    pix = pd.Index(a.var_names).get_indexer(tested)
    if (pix < 0).any():
        raise SystemExit(f"{src}: tested peaks missing from the object")
    keep = (obs["Used in analysis"].astype(str).eq("True") & obs["Subclass"].astype(str).eq("Microglia-PVM")).to_numpy()
    X = a.X[keep]
    X = sp.csr_matrix(X) if not sp.issparse(X) else X.tocsr()
    total = np.asarray(X.sum(1)).ravel()
    sp.save_npz(out / f"{donor}.npz", X[:, pix].astype(np.float32))
    o = obs[keep]
    pd.DataFrame({"barcode": o.index.astype(str), "donor": donor, "supertype": o["Supertype"].astype(str).to_numpy(),
                  "supertype_conf": pd.to_numeric(o["Supertype confidence"], errors="coerce").to_numpy(),
                  "method": o["method"].astype(str).to_numpy(), "total_counts": total,
                  "n_umis": pd.to_numeric(o["Number of UMIs"], errors="coerce").to_numpy(),
                  "doublet": pd.to_numeric(o["Doublet score"], errors="coerce").to_numpy()}).to_csv(out / f"{donor}.csv", index=False)
    if "X_MultiVI" in a.obsm:
        np.save(out / f"{donor}_multivi.npy", np.asarray(a.obsm["X_MultiVI"])[keep].astype(np.float32))
    print(f"{donor}: {keep.sum()} microglia")


if __name__ == "__main__":
    main()
