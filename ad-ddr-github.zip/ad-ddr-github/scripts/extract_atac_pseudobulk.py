"""Sum one SEA-AD MTG ATAC donor object into (subclass x chemistry) pseudobulk peak counts.

    python scripts/extract_atac_pseudobulk.py <donor.h5ad> data/processed/atac_pb
    python scripts/extract_atac_pseudobulk.py <donor.h5ad> data/processed/atac_pb_micro Microglia-PVM

Writes <out>/<donor>.npz (sparse rows x 218,882 shared peaks) and <out>/<donor>.csv (row
labels: donor, subclass, method, n_nuclei). The peak list is written once to
<out>/peaks.txt. Chemistry (10xATAC_v1.1 vs 10xMulti) is kept separate because the two
assays differ in fragment profile and their mix varies by donor.
With a third argument (a subclass), only that subclass is kept and it is split by
Supertype instead; the label still goes in the "subclass" column of <donor>.csv.
"""

from __future__ import annotations

import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp


def main():
    src, out = Path(sys.argv[1]), Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    a = ad.read_h5ad(src)
    obs = a.obs
    donor = str(obs["Donor ID"].iloc[0])
    peaks = out / "peaks.txt"
    if peaks.exists():
        if not pd.Index(peaks.read_text().split()).equals(a.var_names):
            raise SystemExit(f"{src}: peak set differs from {peaks}")
    else:
        peaks.write_text("\n".join(a.var_names) + "\n")
    keep = obs["Used in analysis"].astype(str).eq("True").to_numpy()
    label = obs["Subclass"].astype(str)
    if len(sys.argv) > 3:
        keep &= label.eq(sys.argv[3]).to_numpy()
        label = obs["Supertype"].astype(str)
    key = label + "|" + obs["method"].astype(str)
    cat = pd.Categorical(key[keep])
    A = sp.csr_matrix((np.ones(keep.sum()), (cat.codes, np.arange(keep.sum()))), shape=(len(cat.categories), keep.sum()))
    X = sp.csr_matrix(a.X[keep]) if not sp.issparse(a.X) else a.X[keep].tocsr()
    M = sp.csr_matrix(A @ X).astype(np.float32)
    rows = pd.DataFrame([c.split("|") for c in cat.categories], columns=["subclass", "method"])
    rows.insert(0, "donor", donor)
    rows["n_nuclei"] = np.bincount(cat.codes, minlength=len(cat.categories))
    sp.save_npz(out / f"{donor}.npz", M)
    rows.to_csv(out / f"{donor}.csv", index=False)
    print(f"{donor}: {keep.sum()} nuclei -> {len(rows)} pseudobulks")


if __name__ == "__main__":
    main()
