"""Reduce one hippocampus multiome library (GSE288063 / GSE278576) to counts on SEA-AD peaks.

    python scripts/extract_hippo_multiome.py <library> <fragments.tsv.gz> <rna.h5> data/processed/hippo

Cells and labels come from GSE288063_metadata_humanAD.tsv.gz (22 donors aged 75-97, the
study's own subclass annotation). ATAC: Tn5 cut sites (both fragment ends) are counted on
the SEA-AD MTG peak set (data/processed/atac_pb/peaks.txt) so every downstream script can
be reused; written as a subclass x peak pseudobulk and, for microglia and
oligodendrocytes, a cell x peak matrix. RNA (10x h5, Gene Expression features only): a
subclass x gene pseudobulk and microglia / oligodendrocyte cell x gene matrices, so cell
states can be defined from RNA in the same nuclei.
"""

from __future__ import annotations

import sys
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import scipy.sparse as sp

from ddrmulti.genome import parse_peak_names

ROOT = Path(__file__).resolve().parents[1]
CELLS_KEEP = ("Microglia", "Oligo")


def read_10x_h5(path: Path):
    with h5py.File(path, "r") as f:
        g = f["matrix"]
        bc = np.array([b.decode() for b in g["barcodes"][:]])
        feat = g["features"]
        names = np.array([x.decode() for x in feat["name"][:]])
        ftype = np.array([x.decode() for x in feat["feature_type"][:]])
        X = sp.csc_matrix((g["data"][:], g["indices"][:], g["indptr"][:]), shape=tuple(g["shape"][:]))
    keep = ftype == "Gene Expression"
    return bc, names[keep], X[keep].T.tocsr()                        # cells x genes


def main():
    lib, frag, rna, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
    out.mkdir(parents=True, exist_ok=True)
    meta = pd.read_csv(ROOT / "data/raw/hippo_multiome/GSE288063_metadata_humanAD.tsv.gz", sep="\t")
    mlib = lib.replace("rep", "_rep") if "rep" in lib and "_rep" not in lib else lib
    m = meta[meta["library"] == mlib].copy()
    if m.empty:
        raise SystemExit(f"{lib}: no cells in metadata (library {mlib})")
    subs = pd.Index(sorted(m["subclass"].astype(str).unique()))
    bc2sub = pd.Series(subs.get_indexer(m["subclass"].astype(str)), index=m["cell_barcode"].to_numpy())
    keep_cells = m[m["subclass"].isin(CELLS_KEEP)]
    cell_ix = pd.Series(np.arange(len(keep_cells)), index=keep_cells["cell_barcode"].to_numpy())

    peaks = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split()).reset_index(drop=True)
    by_chrom = {}
    for c, d in peaks.groupby("chrom"):
        o = np.argsort(d["start"].to_numpy())
        by_chrom[c] = (d["start"].to_numpy()[o], d["end"].to_numpy()[o], d.index.to_numpy()[o])
    npk = len(peaks)
    pb = np.zeros(len(subs) * npk)
    cell_r, cell_c = [], []
    n_frag = 0
    for ch in pd.read_csv(frag, sep="\t", header=None, comment="#", usecols=[0, 1, 2, 3], names=["chrom", "s", "e", "bc"],
                          chunksize=5_000_000, dtype={"chrom": str, "s": np.int64, "e": np.int64, "bc": str}):
        n_frag += len(ch)
        sub = bc2sub.reindex(ch["bc"]).to_numpy()
        ok = ~np.isnan(sub)
        ch, sub = ch[ok], sub[ok].astype(int)
        cix = cell_ix.reindex(ch["bc"]).to_numpy()
        for c, idx in ch.groupby("chrom").indices.items():
            if c not in by_chrom:
                continue
            st, en, pid = by_chrom[c]
            for pos in (ch["s"].to_numpy()[idx], ch["e"].to_numpy()[idx] - 1):
                j = np.searchsorted(st, pos, side="right") - 1
                hit = (j >= 0) & (pos < en[np.clip(j, 0, None)])
                p = pid[j[hit]]
                np.add.at(pb, sub[idx][hit] * npk + p, 1)
                ci = cix[idx][hit]
                good = ~np.isnan(ci)
                cell_r.append(ci[good].astype(np.int32))
                cell_c.append(p[good].astype(np.int32))
        print(f"  {lib}: {n_frag:,} fragments", flush=True)
    PB = sp.csr_matrix(pb.reshape(len(subs), npk).astype(np.float32))
    r = np.concatenate(cell_r) if cell_r else np.array([], int)
    c = np.concatenate(cell_c) if cell_c else np.array([], int)
    CM = sp.csr_matrix((np.ones(len(r), np.float32), (r, c)), shape=(len(keep_cells), npk))
    sp.save_npz(out / f"{lib}_atac_pb.npz", PB)
    sp.save_npz(out / f"{lib}_atac_cells.npz", CM)

    bc, genes, X = read_10x_h5(rna)
    pos = pd.Series(np.arange(len(bc)), index=bc)
    ri = pos.reindex(m["cell_barcode"]).to_numpy()
    okr = ~np.isnan(ri)
    A = sp.csr_matrix((np.ones(okr.sum()), (bc2sub.reindex(m["cell_barcode"]).to_numpy()[okr].astype(int),
                                            np.arange(okr.sum()))), shape=(len(subs), okr.sum()))
    RPB = sp.csr_matrix(A @ X[ri[okr].astype(int)]).astype(np.float32)
    rk = pos.reindex(keep_cells["cell_barcode"]).to_numpy()
    if np.isnan(rk).any():
        print(f"  {lib}: {int(np.isnan(rk).sum())} kept cells missing from RNA h5")
    RC = X[np.nan_to_num(rk, nan=0).astype(int)].astype(np.float32)
    RC = sp.csr_matrix(RC.multiply((~np.isnan(rk))[:, None]))
    sp.save_npz(out / f"{lib}_rna_pb.npz", RPB)
    sp.save_npz(out / f"{lib}_rna_cells.npz", RC)
    pd.Series(genes).to_csv(out / "rna_genes.txt", index=False, header=False)
    keep_cells.assign(library=lib)[["cell_barcode", "donor", "library", "subclass", "age", "sex", "Braak", "group",
                                    "nCount_RNA"]].to_csv(out / f"{lib}_cells.csv", index=False)
    pd.Series(subs).to_csv(out / f"{lib}_subclasses.txt", index=False, header=False)
    print(f"{lib}: {n_frag:,} fragments; {len(subs)} subclasses; {len(keep_cells)} microglia/oligo cells; "
          f"cut sites in peaks: {int(pb.sum()):,}")


if __name__ == "__main__":
    main()
