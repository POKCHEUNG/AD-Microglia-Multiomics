"""Keep base-resolution Tn5 cut sites of hippocampus microglia for TF footprinting.

    python scripts/extract_microglia_cuts.py <library> <fragments.tsv.gz> data/processed/hippo_cuts

Microglia are the study's own annotation (cells and their order as in
data/processed/hippo/<library>_cells.csv, so the cell index matches the per-nucleus RNA and ATAC
matrices). Both fragment ends (start, end - 1) are kept when they fall within 250 bp of a SEA-AD
peak tested in the DAM analysis (results/dam_peaks/dam_peaks_all.csv.gz). Written as
chrom code (int8), position (int32) and cell index (int32).
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FLANK = 250


def main():
    lib, frag, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
    out.mkdir(parents=True, exist_ok=True)
    cells = pd.read_csv(ROOT / f"data/processed/hippo/{lib}_cells.csv")
    mic = cells[cells["subclass"] == "Microglia"].reset_index(drop=True)
    cix = pd.Series(np.arange(len(mic)), index=mic["cell_barcode"].to_numpy())
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz", usecols=["chrom", "start", "end"])
    chroms = sorted(res["chrom"].unique())
    code = {c: i for i, c in enumerate(chroms)}
    iv = {}
    for c, d in res.groupby("chrom"):
        o = np.argsort(d["start"].to_numpy())
        s, e = d["start"].to_numpy()[o] - FLANK, d["end"].to_numpy()[o] + FLANK
        iv[c] = (s, np.maximum.accumulate(e))
    C, P, I = [], [], []
    n = 0
    for ch in pd.read_csv(frag, sep="\t", header=None, comment="#", usecols=[0, 1, 2, 3], names=["chrom", "s", "e", "bc"],
                          chunksize=5_000_000, dtype={"chrom": str, "s": np.int64, "e": np.int64, "bc": str}):
        n += len(ch)
        ci = cix.reindex(ch["bc"]).to_numpy()
        ok = ~np.isnan(ci)
        ch, ci = ch[ok], ci[ok].astype(np.int32)
        for c, idx in ch.groupby("chrom").indices.items():
            if c not in iv:
                continue
            s, e = iv[c]
            for pos in (ch["s"].to_numpy()[idx], ch["e"].to_numpy()[idx] - 1):
                j = np.searchsorted(s, pos, side="right") - 1
                hit = (j >= 0) & (pos < e[np.clip(j, 0, None)])
                C.append(np.full(hit.sum(), code[c], np.int8))
                P.append(pos[hit].astype(np.int32))
                I.append(ci[idx][hit])
        print(f"  {lib}: {n:,} fragments", flush=True)
    C, P, I = (np.concatenate(x) if x else np.array([], t) for x, t in ((C, np.int8), (P, np.int32), (I, np.int32)))
    np.savez_compressed(out / f"{lib}.npz", chrom=C, pos=P, cell=I, chroms=np.array(chroms))
    print(f"{lib}: {n:,} fragments; {len(mic)} microglia; {len(P):,} cut sites near tested peaks")


if __name__ == "__main__":
    main()
