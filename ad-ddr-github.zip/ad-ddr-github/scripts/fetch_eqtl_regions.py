"""Fetch eQTL Catalogue summary statistics around the candidate elements (remote tabix).

    python scripts/fetch_eqtl_regions.py        # writes data/processed/eqtl_regions/<dataset>_<locus>.tsv.gz

Datasets (eQTL Catalogue release 7, gene expression): QTD000559 Young_2019 primary
microglia (n = 104), QTD000609 OneK1K CD14+ monocytes (n = 959, myeloid proxy),
QTD000434 ROSMAP DLPFC bulk (n = 560). Window: element centre +/- 500 kb. The tabix index
is cached in data/ref/eqtl/tbi/.
"""

from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
import pysam

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data/processed/eqtl_regions"
OUT.mkdir(parents=True, exist_ok=True)
BASE = "https://ftp.ebi.ac.uk/pub/databases/spot/eQTL/sumstats"
DATASETS = {"microglia_Young2019": "QTS000031/QTD000559", "CD14mono_OneK1K": "QTS000038/QTD000609",
            "brain_ROSMAP": "QTS000025/QTD000434"}
COLS = ["molecular_trait_id", "chromosome", "position", "ref", "alt", "variant", "ma_samples", "maf", "pvalue", "beta",
        "se", "type", "ac", "an", "r2", "molecular_trait_object_id", "gene_id", "median_tpm", "rsid"]
LOCI = {"RASGEF1C": ("5", 180_199_000), "chr5_87.1M": ("5", 87_137_900), "DAPK2": ("15", 64_071_500),
        "CD9": ("12", 6_201_200), "ANXA2": ("15", 60_398_400)}
WIN = 500_000


def main():
    tbi = ROOT / "data/ref/eqtl/tbi"
    tbi.mkdir(parents=True, exist_ok=True)
    os.chdir(tbi)                                     # pysam stores the downloaded index in the cwd
    for name, path in DATASETS.items():
        tb = None
        for locus, (chrom, mid) in LOCI.items():
            f = OUT / f"{name}_{locus}.tsv.gz"
            if f.exists():
                continue
            if tb is None:
                tb = pysam.TabixFile(f"{BASE}/{path}/{path.split('/')[1]}.all.tsv.gz")
            rows = [r.split("\t") for r in tb.fetch(chrom, max(mid - WIN, 0), mid + WIN)]
            pd.DataFrame(rows, columns=COLS).to_csv(f, sep="\t", index=False)
            print(name, locus, len(rows), flush=True)


if __name__ == "__main__":
    main()
