"""Fetch eQTL Catalogue QTLs around the RASGEF1C credible set (remote tabix; README 44).

    python scripts/fetch_rasgef1c_qtls.py QTD000560 [...]   # writes data/processed/eqtl_regions/<QTD>_RASGEF1C_chain.tsv.gz

Window chr5:179.95-180.45 Mb (credible set at 180.197-180.202 Mb; RASGEF1C spans 180.10-180.23 Mb).
Datasets: Young 2019 primary microglia gene / exon / transcript / txrevise / leafcutter QTLs
(QTD000559-563); bulk brain (GTEx cortex QTD000171, frontal cortex QTD000176, BrainSeq QTD000051,
CommonMind QTD000075); macrophages (Alasoo naive QTD000001, Nedelec naive QTD000384). The ftp paths come
from data/ref/eqtl/tabix_ftp_paths.tsv; the tabix index is cached in data/ref/eqtl/tbi/.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
import pysam

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data/processed/eqtl_regions"
WIN = ("5", 179_950_000, 180_450_000)


def main(ids):
    paths = pd.read_csv(ROOT / "data/ref/eqtl/tabix_ftp_paths.tsv", sep="\t").set_index("dataset_id")
    os.chdir(ROOT / "data/ref/eqtl/tbi")
    for q in ids:
        f = OUT / f"{q}_RASGEF1C_chain.tsv.gz"
        if f.exists():
            continue
        url = paths.at[q, "ftp_path"].replace("ftp://", "https://")
        tb = pysam.TabixFile(url)
        cols = tb.header[0].lstrip("#").split("\t") if tb.header else None
        recs = [x.split("\t") for x in tb.fetch(*WIN)]
        d = pd.DataFrame(recs, columns=cols if cols and len(cols) == len(recs[0]) else None)
        d.to_csv(f, sep="\t", index=False)
        print(f"{q} {paths.at[q, 'study_label']} {paths.at[q, 'quant_method']}: {len(d)} rows", flush=True)


if __name__ == "__main__":
    main(sys.argv[1:])
