"""TF footprints at DAM driver motifs in hippocampus microglia (Tn5-bias corrected).

    python scripts/footprint_dam_tfs.py         # needs data/processed/hippo_cuts/ (stream_hippo_cuts.sh)

Cut sites: both fragment ends of hippocampus microglia within 250 bp of tested DAM peaks. Groups:
DAM-high and DAM-low thirds of each donor's microglia by the same-nucleus RNA DAM score (as in
Fig. 4e). Motif sites: the best p < 1e-4 match per tested peak for each motif (strand-aware), stronger
half by score. Controls: CTCF and PU.1 (SPI1) for footprints, column-shuffled MITF and CTCF PWMs
(same base composition, no binding) for the bias correction.

Tn5 bias: insertion preference of the 6-mer centred on each cut (positions -3..+2), estimated as
observed cut frequency / frequency of the 6-mer among all positions of the same windows. The expected
profile around a motif is the sum of bias weights at each relative position, scaled to the observed
total in the +/- 100 bp window; footprint = observed / expected.

Per motif and group: flank accessibility (mean corrected signal 25-100 bp from the motif centre,
relative to 150-250 bp background), and footprint depth (centre, |x| <= half motif width, relative
to flank). DAM-high vs DAM-low is tested per donor (paired over donors). CTCF is the positive
control for a deep footprint. A TF that binds more in DAM-high cells should show higher flank
accessibility and an equal or deeper footprint.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from dam_tf_grn import log_odds, motif_genes, pwm_threshold
from motif_dam_peaks import CODE, fetch, read_jaspar

ROOT = Path(__file__).resolve().parents[1]
CUTS = ROOT / "data/processed/hippo_cuts"
OUT = ROOT / "results/dam_tf/footprints"
OUT.mkdir(parents=True, exist_ok=True)
MOTIFS = ["MA0620.4 MITF", "MA0871.3 TFEC", "MA0636.1 BHLHE41", "MA1138.2 FOSL2::JUNB", "MA0150.3 Nfe2l2",
          "MA0102.5 CEBPA", "MA0497.2 MEF2C", "MA0139.2 CTCF", "MA0080.7 Spi1", "shuffled MITF", "shuffled CTCF"]
FLANK, W = 250, 250


def main():
    rng = np.random.default_rng(0)
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz", usecols=["chrom", "start", "end", "call"])
    win = pd.DataFrame({"chrom": res["chrom"], "start": res["start"] - FLANK, "end": res["end"] + FLANK})
    seqs = fetch(ROOT / "data/ref/hg38.fa.gz", win)
    seq_codes = [CODE[np.frombuffer(s.encode(), dtype=np.uint8)] for s in seqs]

    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    libs = [l for l in cache["library"].unique() if (CUTS / f"{l}.npz").exists()]
    # cell index within each library follows the order of that library's microglia in the cache
    cache["cell"] = cache.groupby("library").cumcount()
    thr = cache.groupby("donor")["score"].transform(lambda s: np.quantile(s, 2 / 3) if len(s) >= 30 else np.inf)
    tlo = cache.groupby("donor")["score"].transform(lambda s: np.quantile(s, 1 / 3) if len(s) >= 30 else -np.inf)
    cache["grp"] = np.where(cache["score"] >= thr, "high", np.where(cache["score"] <= tlo, "low", ""))

    # per peak-window index of cuts, by donor and group
    chrom_of = res["chrom"].to_numpy()
    st = win["start"].to_numpy()
    by_chrom = {c: np.flatnonzero(chrom_of == c) for c in np.unique(chrom_of)}
    order = {c: ix[np.argsort(st[ix])] for c, ix in by_chrom.items()}
    cuts = {}                                   # (donor, grp) -> list of (window index, offset)
    for lib in libs:
        z = np.load(CUTS / f"{lib}.npz", allow_pickle=True)
        ch_names = z["chroms"]
        cl = cache[cache["library"] == lib].set_index("cell")
        g = cl["grp"].reindex(z["cell"]).fillna("").to_numpy()
        dn = cl["donor"].reindex(z["cell"]).to_numpy()
        for ci, cname in enumerate(ch_names):
            if cname not in order:
                continue
            m = (z["chrom"] == ci) & (g != "")
            pos = z["pos"][m]
            ix = order[cname]
            j = np.searchsorted(st[ix], pos, side="right") - 1
            ok = j >= 0
            w = ix[j[ok]]
            off = pos[ok] - st[w]
            inside = off < (win["end"].to_numpy()[w] - st[w])
            for key in set(zip(dn[m][ok][inside], g[m][ok][inside])):
                k = (dn[m][ok][inside] == key[0]) & (g[m][ok][inside] == key[1])
                cuts.setdefault(key, []).append(np.column_stack([w[inside][k], off[inside][k]]))
        print(f"  loaded {lib}", flush=True)
    cuts = {k: np.vstack(v) for k, v in cuts.items()}
    print(f"cut sites: {sum(len(v) for v in cuts.values()):,} in {len(cuts)} donor x group sets")

    # Tn5 6-mer bias from all cuts
    def kmer_at(w, off):
        out = np.full(len(w), -1)
        for i in np.unique(w):
            k = w == i
            sc = seq_codes[i]
            o = off[k]
            good = (o >= 3) & (o + 3 <= len(sc))
            km = np.full(k.sum(), -1)
            if good.any():
                idx = o[good][:, None] + np.arange(-3, 3)
                b = sc[idx]
                valid = (b < 4).all(1)
                vals = (b * (4 ** np.arange(5, -1, -1))).sum(1)
                km_g = np.where(valid, vals, -1)
                km[good] = km_g
            out[k] = km
        return out
    allc = np.vstack(list(cuts.values()))
    sub = allc[rng.choice(len(allc), min(len(allc), 5_000_000), replace=False)]
    obs_k = np.bincount(np.clip(kmer_at(sub[:, 0], sub[:, 1]), 0, None), minlength=4096).astype(float)
    bg_k = np.zeros(4096)
    for sc in seq_codes[::5]:
        if len(sc) < 6:
            continue
        b = np.lib.stride_tricks.sliding_window_view(sc, 6)
        valid = (b < 4).all(1)
        bg_k += np.bincount((b[valid] * (4 ** np.arange(5, -1, -1))).sum(1), minlength=4096)
    bias = (obs_k / obs_k.sum()) / np.maximum(bg_k / bg_k.sum(), 1e-12)
    np.save(OUT / "tn5_bias_6mer.npy", bias)

    motifs = read_jaspar(ROOT / "data/ref/motifs/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt")
    rows = []
    prof_rows = []
    for name in ("MA0620.4 MITF", "MA0139.2 CTCF"):                  # negative controls: column-shuffled PWMs
        motifs["shuffled " + name.split(" ")[1]] = motifs[name][np.random.default_rng(1).permutation(len(motifs[name]))]
    for mname in MOTIFS:
        if mname not in motifs:
            print("missing motif", mname)
            continue
        pw = log_odds(motifs[mname])
        w = len(pw)
        th = pwm_threshold(pw)
        sites = []                                    # (window, centre offset, strand, peak call)
        for i, sc in enumerate(seq_codes):
            core = sc[FLANK:len(sc) - FLANK]
            if len(core) < w:
                continue
            for strand, m_ in ((1, pw), (-1, pw[::-1, ::-1])):
                mat = np.vstack([m_.T, np.full((1, w), -10.0)])
                v = np.lib.stride_tricks.sliding_window_view(core, w)
                s_ = mat[v, np.arange(w)].sum(1)
                k = int(np.argmax(s_))
                if s_[k] >= th:
                    sites.append((i, FLANK + k + w // 2, strand, s_[k]))
        S = pd.DataFrame(sites, columns=["w", "c", "strand", "score"]).sort_values("score", ascending=False)
        S = S.drop_duplicates("w")
        S["call"] = res["call"].to_numpy()[S["w"]]
        S = S[S["score"] >= S["score"].quantile(0.5)]                   # stronger half of the matches
        # expected bias profile around the sites
        rel = np.arange(-W, W + 1)
        exp = np.zeros(len(rel))
        for _, s in S.iterrows():
            sc = seq_codes[s["w"]]
            pos = s["c"] + rel * s["strand"]
            ok = (pos >= 3) & (pos + 3 <= len(sc))
            idx = pos[ok][:, None] + np.arange(-3, 3)
            b = sc[idx]
            valid = (b < 4).all(1)
            kv = (b * (4 ** np.arange(5, -1, -1))).sum(1)
            e = np.zeros(ok.sum())
            e[valid] = bias[kv[valid]]
            exp[ok] += e
        site_of = {int(s.w): (int(s.c), int(s.strand)) for s in S.itertuples()}
        for (dn, g), arr in cuts.items():
            m = np.isin(arr[:, 0], list(site_of))
            if not m.any():
                continue
            a = arr[m]
            cc = np.array([site_of[int(x)] for x in a[:, 0]])
            r = (a[:, 1] - cc[:, 0]) * cc[:, 1]
            r = r[np.abs(r) <= W]
            obs = np.bincount(r + W, minlength=2 * W + 1).astype(float)
            corr = obs / np.maximum(exp / exp.sum() * obs.sum(), 1e-9)
            centre = corr[np.abs(rel) <= max(w // 2, 3)].mean()
            flank = corr[(np.abs(rel) >= 25) & (np.abs(rel) <= 100)].mean()
            back = corr[(np.abs(rel) >= 150)].mean()
            rows.append({"motif": mname, "tf": "/".join(motif_genes(mname)) if " " in mname else mname, "donor": dn, "group": g, "n_sites": len(S),
                         "n_cuts": int(obs.sum()), "flank_acc": flank / back, "fp_depth": flank - centre,
                         "fp_ratio": centre / flank})
            prof_rows.append(pd.DataFrame({"motif": mname, "donor": dn, "group": g, "rel": rel, "obs": obs, "corr": corr}))
        print(f"  {mname}: {len(S)} sites", flush=True)
    F = pd.DataFrame(rows)
    F.to_csv(OUT / "footprint_donor_metrics.csv", index=False)
    pd.concat(prof_rows).to_csv(OUT / "footprint_profiles.csv.gz", index=False)
    tests = []
    for mname, d in F.groupby("motif"):
        w_ = d.pivot(index="donor", columns="group", values=["flank_acc", "fp_depth", "fp_ratio"]).dropna()
        for met in ("flank_acc", "fp_depth", "fp_ratio"):
            diff = w_[(met, "high")] - w_[(met, "low")]
            tt = stats.ttest_1samp(diff, 0)
            tests.append({"motif": mname, "metric": met, "n_donors": len(diff), "mean_high": w_[(met, "high")].mean(),
                          "mean_low": w_[(met, "low")].mean(), "mean_diff": diff.mean(), "t": tt.statistic, "p": tt.pvalue,
                          "donors_high_gt_low": int((diff > 0).sum())})
    TT = pd.DataFrame(tests)
    TT.to_csv(OUT / "footprint_tests.csv", index=False)
    print(TT.to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
