"""Core question: is the AD-associated change a program shared by all cell types, or remodelling
concentrated in specific cells? (README 43, Fig. 8)

    python scripts/global_vs_specific.py        # writes results/global_specific/

For every MTG cell group, each gene's (RNA) or peak's (ATAC) partial correlation with local CPS
(age, sex, PMI, log nuclei; ATAC also log fragments and multiome share; severe donors excluded).

Shared versus specific, with noise accounted for by donor split halves (20 random splits):
  reliability_c        corr(r_c in half 1, r_c in half 2): how reproducible a cell type's profile is
  shared_c             corr(mean profile of the OTHER cell types in half 1, r_c in half 2)^2 / reliability_c
                       = share of the reproducible profile of cell type c predicted by the rest
  specific_c           1 - shared_c
  (not reported when reliability_c < 0.1). Sensitivity: "others" weighted so that excitatory,
  inhibitory and non-neuronal classes count equally (the 13+ neuron types cannot outvote the glia).
RNA uses genes expressed in every analysed group; ATAC uses peaks accessible in every analysed subclass
(both mostly promoters), and, per subclass, all of its accessible peaks for the specific counts below.

Specific remodelling: for each cell type, genes / peaks whose r departs from the other cell types'
mean by more than the 99.5th percentile of |r| under 100 CPS permutations of that cell type (the noise
expected if the cell type simply followed the others; expected false count per cell type reported).

Programs: for every DDR program (and DAM, cohesin) x cell group, the observed program r against the
r predicted from the other cell types' gene effects (mean over program genes of their mean r): a
program that only rides the shared change lies on the identity line. Its cell-type-specific component
(mean over its common genes of r - others) is tested against 500 random gene sets with the same
expression-decile composition in that cell type (specific_z, p_specific).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr import cohort
from ad_ddr.signatures import all_programs
from run_dam_peaks import load

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/global_specific"
OUT.mkdir(parents=True, exist_ok=True)
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
COHESIN = ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2"]
N_SPLIT, N_PERM = 20, 100
NONNEURONAL = ("Astro", "Micro", "Oligo", "OPC", "VLMC", "Endo")
INHIBITORY = ("Lamp5", "Pax6", "Pvalb", "Sncg", "Sst", "Vip", "Chandelier")


def cell_class(n):
    if n.startswith(NONNEURONAL):
        return "non-neuronal"
    return "inhibitory" if n.startswith(INHIBITORY) else "excitatory"


def others_mean(R, n, balanced):
    """Mean profile of the other units; balanced: each class (excitatory, inhibitory, non-neuronal)
    weighs equally, so 13 similar neuron types cannot outvote the glia."""
    others = [o for o in R if o != n]
    if not balanced:
        return np.mean([R[o] for o in others], 0)
    cls = pd.Series({o: cell_class(o) for o in others})
    return np.mean([np.mean([R[o] for o in g.index], 0) for _, g in cls.groupby(cls)], 0)


def design(df, cov):
    D = pd.get_dummies(df[cov], drop_first=True, dtype=float).to_numpy(float)
    return np.column_stack([np.ones(len(df)), D])


def rvec(Y, x, C):
    B = np.linalg.lstsq(C, np.column_stack([x, Y]), rcond=None)[0]
    R = np.column_stack([x, Y]) - C @ B
    xr, Yr = R[:, 0] - R[:, 0].mean(), R[:, 1:] - R[:, 1:].mean(0)
    return (xr @ Yr) / (np.linalg.norm(xr) * np.linalg.norm(Yr, axis=0) + 1e-12)


def decompose(units, feats_common, rng, label, balanced=False):
    """units: dict name -> (Y donors x features (common set), x, C, donor ids)."""
    names = list(units)
    rows = []
    for s in range(N_SPLIT):
        donors = sorted(set().union(*[set(u[3]) for u in units.values()]))
        half = set(rng.choice(donors, len(donors) // 2, replace=False))
        R1, R2 = {}, {}
        for n in names:
            Y, x, C, d = units[n]
            m = np.array([v in half for v in d])
            if m.sum() < 12 or (~m).sum() < 12:
                continue
            R1[n] = rvec(Y[m], x[m], C[m])
            R2[n] = rvec(Y[~m], x[~m], C[~m])
        for n in R1:
            rel = np.corrcoef(R1[n], R2[n])[0, 1]
            a1, a2 = others_mean(R1, n, balanced), others_mean(R2, n, balanced)
            pred = (np.corrcoef(a1, R2[n])[0, 1] + np.corrcoef(a2, R1[n])[0, 1]) / 2
            rows.append({"modality": label, "others": "class-balanced" if balanced else "all", "unit": n, "split": s,
                         "reliability": rel, "pred_by_others": pred,
                         "shared_fraction": np.clip(pred ** 2 / rel, 0, 1) if rel > 0 else np.nan})
    return pd.DataFrame(rows)


def specific_counts(units, rng, label, balanced=False):
    """Features whose r departs from the other units' mean beyond the 99.5% permutation threshold."""
    names = list(units)
    full = {n: rvec(*units[n][:3]) for n in names}
    rows = []
    for n in names:
        Y, x, C, _ = units[n]
        dev = full[n] - others_mean(full, n, balanced)
        null = np.concatenate([rvec(Y, rng.permutation(x), C) for _ in range(N_PERM)])   # noise around "same as others"
        thr = np.percentile(np.abs(null), 99.5)
        n_obs = int((np.abs(dev) > thr).sum())
        rows.append({"modality": label, "others": "class-balanced" if balanced else "all", "unit": n, "n_features": len(dev), "n_specific": n_obs,
                     "expected_false": 0.005 * len(dev), "frac_specific": n_obs / len(dev),
                     "threshold": thr})
    return pd.DataFrame(rows), full


def program_excess(dev, gc, level, n_rand=500, seed=1):
    """Cell-type-specific component of a program (mean of r - others over its genes) against random gene
    sets of the same size and the same expression-decile composition in that cell type (own rng, so the
    other analyses' random streams are unchanged)."""
    rng = np.random.default_rng(seed)
    dec = pd.qcut(pd.Series(level).rank(method="first"), 10, labels=False).to_numpy()
    pools = {k: np.flatnonzero(dec == k) for k in range(10)}
    want = pd.Series(dec[gc]).value_counts()
    null = np.array([np.mean(np.concatenate([dev[rng.choice(pools[k], c)] for k, c in want.items()]))
                     for _ in range(n_rand)])
    obs = dev[gc].mean()
    return obs, (obs - null.mean()) / null.std(), (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (n_rand + 1)


def main():
    rng = np.random.default_rng(0)
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    severe = set(meta.index[meta["Severely Affected Donor"].astype(str).eq("Y")])

    # ---------- RNA
    rna_units, gene_sets, rna_full_genes = {}, {}, {}
    for p in sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad")):
        try:
            idx, Cnt, genes, mt = cohort.aggregate([p], regions=["MTG"])
        except ValueError:                                   # cell type absent from MTG
            continue
        mt = mt.assign(age=pd.to_numeric(mt["age"], errors="coerce"), pmi=pd.to_numeric(mt["pmi"], errors="coerce"))
        idx = idx.join(mt[["age", "sex", "pmi"]], on="donor").assign(cps=lambda d: cps.reindex(d["donor"]).to_numpy())
        for grp, d in idx[(idx["level"] == "group") & (idx["n_nuclei"] >= 20)].groupby("group"):
            d = d[~d["donor"].isin(severe) & d[["cps", "age", "pmi"]].notna().all(1)]
            if len(d) < 50:
                continue
            M = Cnt[d.index.to_numpy()]
            cpm = M / M.sum(1, keepdims=True) * 1e6
            expr = (cpm >= 1).mean(0) >= 0.5
            L = np.log2(cpm + 1)
            base = d.reset_index(drop=True).assign(log_nuclei=lambda z: np.log10(z["n_nuclei"]))
            rna_units[grp] = (L, base["cps"].to_numpy(float), design(base, ["age", "sex", "pmi", "log_nuclei"]),
                              base["donor"].to_numpy(), pd.Index(genes).str.upper(), expr)
        print(f"  RNA {p.stem}", flush=True)
    common = None
    for n, u in rna_units.items():
        g = set(u[4][u[5]])
        common = g if common is None else common & g
    common = sorted(common)
    print(f"RNA: {len(rna_units)} cell groups, {len(common)} genes expressed in all")
    units_c = {}
    for n, (L, x, C, d, g, e) in rna_units.items():
        pos = pd.Series(np.arange(len(g)), index=g)
        pos = pos[~pos.index.duplicated()]
        units_c[n] = (L[:, pos.reindex(common).to_numpy()], x, C, d)
    dec_rna = pd.concat([decompose(units_c, common, rng, "RNA", b) for b in (False, True)])
    spec_rna, full_rna = specific_counts(units_c, rng, "RNA")
    np.savez_compressed(OUT / "rna_profiles.npz", units=np.array(list(full_rna)), genes=np.array(common),
                        R=np.array([full_rna[u] for u in full_rna]))          # for the PsychAD comparison (README 46)
    spec_rna = pd.concat([spec_rna, specific_counts(units_c, rng, "RNA", True)[0]])

    # programs vs prediction from the other cell types (genes expressed in that group)
    progs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}
    progs["cohesin"] = COHESIN
    pos_c = pd.Series(np.arange(len(common)), index=common)
    prow = []
    for n, (L, x, C, d, g, e) in rna_units.items():
        others = np.mean([full_rna[o] for o in full_rna if o != n], 0)
        pos = pd.Series(np.arange(len(g)), index=g)
        pos = pos[~pos.index.duplicated()]
        Z = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
        for pn, gs in progs.items():
            gi = pos.reindex([x_.upper() for x_ in gs]).dropna().astype(int).to_numpy()
            gi = gi[e[gi]]
            gc = pos_c.reindex(pd.Index(g)[gi]).dropna().astype(int).to_numpy()
            if len(gi) < 3 or len(gc) < 3:
                continue
            r_obs = rvec(Z[:, gi].mean(1)[:, None], x, C)[0]
            ex, ez, ep = program_excess(full_rna[n] - others, gc, units_c[n][0].mean(0))
            prow.append({"cell": n, "program": pn, "family": "DDR" if pn in DDR else pn, "n_genes": len(gi),
                         "specific_component": ex, "specific_z": ez, "p_specific": ep,
                         "r_observed": r_obs, "r_predicted_from_others": others[gc].mean(),
                         "mean_gene_r_observed": full_rna[n][gc].mean()})
    PR = pd.DataFrame(prow)

    # ---------- ATAC (subclass pseudobulks)
    rows, M = load(ROOT / "data/processed/atac_pb")
    rows = rows.assign(cps=cps.reindex(rows["donor"]).to_numpy())
    atac_units, atac_all = {}, {}
    for sub, r in rows.groupby("subclass"):
        n = r.groupby("donor")["n_nuclei"].sum()
        donors = [x for x in n.index[n >= 50] if x in meta.index and x not in severe and pd.notna(cps.get(x))]
        if len(donors) < 40:
            continue
        Ms, info = [], []
        for x in donors:
            ix = r.index[r["donor"] == x].to_numpy()
            c = np.asarray(M[ix].sum(0)).ravel()
            Ms.append(c)
            info.append({"donor": x, "age": pd.to_numeric(meta.at[x, "Age at Death"], errors="coerce"),
                         "sex": str(meta.at[x, "Sex"]), "pmi": pd.to_numeric(meta.at[x, "PMI"], errors="coerce"),
                         "lognuc": np.log10(n[x]), "logfrag": np.log10(c.sum()),
                         "multi": r.loc[ix].loc[r.loc[ix, "method"] == "10xMulti", "n_nuclei"].sum() / n[x], "cps": cps[x]})
        I = pd.DataFrame(info)
        ok = I.notna().all(1).to_numpy()
        I, Mx = I[ok].reset_index(drop=True), np.array(Ms)[ok]
        cpm = Mx / Mx.sum(1, keepdims=True) * 1e6
        acc = np.median(cpm, 0) >= 2
        atac_all[sub] = (np.log2(cpm + 1), I["cps"].to_numpy(float),
                         design(I, ["age", "sex", "pmi", "lognuc", "logfrag", "multi"]), I["donor"].to_numpy(), acc)
        print(f"  ATAC {sub}: {len(I)} donors, {acc.sum()} accessible peaks", flush=True)
    common_p = np.logical_and.reduce([u[4] for u in atac_all.values()])
    atac_units = {s: (u[0][:, common_p], u[1], u[2], u[3]) for s, u in atac_all.items()}
    print(f"ATAC: {len(atac_units)} subclasses, {common_p.sum()} peaks accessible in all")
    dec_atac = pd.concat([decompose(atac_units, None, rng, "ATAC", b) for b in (False, True)])
    spec_atac = pd.concat([specific_counts(atac_units, rng, "ATAC", b)[0] for b in (False, True)])
    from ddrmulti.genome import parse_peak_names, read_gtf_genes
    pk = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    gg = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    mid = ((pk["start"] + pk["end"]) // 2).to_numpy()
    PROM = []
    for ch, ix in pk.groupby("chrom").indices.items():
        t_ = np.sort(gg.loc[gg["chrom"] == ch, "tss"].to_numpy())
        if not len(t_):
            continue
        j = np.clip(np.searchsorted(t_, mid[ix]), 1, len(t_) - 1)
        dmin = np.minimum(np.abs(mid[ix] - t_[j - 1]), np.abs(mid[ix] - t_[j]))
        PROM.extend(np.asarray(ix)[dmin <= 1000])
    PROM = np.array(PROM)
    # per subclass, all of its accessible peaks: how many track CPS beyond permutation (not relative to others)
    own = []
    for s, (L, x, C, d, acc) in atac_all.items():
        r = rvec(L[:, acc], x, C)
        null = np.concatenate([rvec(L[:, acc], rng.permutation(x), C) for _ in range(50)])
        thr = np.percentile(np.abs(null), 99.5)
        prom = np.isin(np.flatnonzero(acc), PROM)
        lacc = L[:, acc].mean(0)
        own.append({"subclass": s, "mean_r": r.mean(), "frac_r_pos": (r > 0).mean(),
                    "r_vs_accessibility": np.corrcoef(r, lacc)[0, 1], "mean_r_promoter": r[prom].mean(),
                    "mean_r_distal": r[~prom].mean(),
                    "n_donors": len(x), "n_accessible": int(acc.sum()), "n_beyond_null": int((np.abs(r) > thr).sum()),
                    "expected_false": 0.005 * acc.sum(), "ratio_obs_expected": (np.abs(r) > thr).sum() / (0.005 * acc.sum())})
    OWN = pd.DataFrame(own)

    D = pd.concat([dec_rna, dec_atac])
    D.to_csv(OUT / "shared_fraction_splits.csv", index=False)
    S = D.groupby(["modality", "others", "unit"])[["reliability", "pred_by_others", "shared_fraction"]].median().reset_index()
    S["cell_class"] = S["unit"].map(cell_class)
    S.loc[S["reliability"] < 0.1, "shared_fraction"] = np.nan        # profile not reproducible enough to decompose
    S.to_csv(OUT / "shared_fraction.csv", index=False)
    pd.concat([spec_rna, spec_atac]).to_csv(OUT / "specific_counts.csv", index=False)
    PR.to_csv(OUT / "programs_vs_shared.csv", index=False)
    OWN.to_csv(OUT / "atac_peaks_tracking_cps.csv", index=False)
    pd.set_option("display.width", 200)
    print("\nShared fraction of the reproducible CPS profile (median over 20 splits):")
    print(S.sort_values(["modality", "others", "shared_fraction"]).to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print("\nSpecific features (beyond the 99.5% permutation threshold of departure from other cell types):")
    print(pd.concat([spec_rna, spec_atac]).sort_values(["modality", "others", "frac_specific"], ascending=[True, True, False]).to_string(
        index=False, float_format=lambda v: f"{v:.3g}"))
    d = PR[PR["family"] == "DDR"]
    print(f"\nDDR programs: mean gene r observed vs predicted from other cell types: Pearson {np.corrcoef(d.mean_gene_r_observed, d.r_predicted_from_others)[0, 1]:.2f} "
          f"(n = {len(d)}); median |observed - predicted| {np.median(np.abs(d.mean_gene_r_observed - d.r_predicted_from_others)):.3f}")
    print(PR[PR["family"] != "DDR"].to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print("\nATAC peaks of each subclass tracking CPS beyond permutation (99.5%):")
    print(OWN.sort_values("ratio_obs_expected", ascending=False).to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
