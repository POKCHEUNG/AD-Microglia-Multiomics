"""Do DAM-specific chromatin peaks carry AD genetic risk? (Bellenguez et al. 2022 summary statistics, GRCh38)

    python scripts/gwas_dam_peaks.py --out results/dam_peaks

No LD reference is available locally, so this is a SNP-in-peak enrichment, not a
heritability partition (S-LDSC):
  per peak   n SNPs inside, min p, hit = any SNP with p < 1e-5
  sets       DAM-open, DAM-closed (results/dam_peaks), and as a positive control
             microglia-specific vs neuron-specific peaks (pooled subclass pseudobulks from
             data/processed/atac_pb: log2 CPM ratio >= 2 one way, both >= 2 CPM in the high
             group); AD heritability is known to concentrate in microglial regulatory DNA.
  null       1,000 background sets drawn from the comparison pool, matched on the number of
             SNPs in the peak (deciles) and promoter / distal class.
  LD         the APOE region (chr19:43.9-45.9 Mb) is excluded in a sensitivity run, and hits
             are reported as loci (hit peaks merged within 500 kb) as well as peaks.
Axis test: among all tested microglial peaks, the AD-risk peaks (one per 500 kb locus, SNP
p < 1e-5) are placed on the DAM-vs-homeostatic t statistic and compared with matched peaks
(n SNPs, homeostatic accessibility, class) that have no SNP below 1e-3. This uses all
31k peaks instead of the 127 significant ones.
Candidates: differential peaks (q < 0.1) that contain a SNP with p < 1e-5, with lead SNP.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ddrmulti.genome import parse_peak_names
from run_dam_peaks import annotate

ROOT = Path(__file__).resolve().parents[1]
GWAS = ROOT / "data/ref/gwas/GCST90027158_buildGRCh38.tsv.gz"
APOE = ("chr19", 43_900_000, 45_900_000)
NEURON = ["L2/3 IT", "L4 IT", "L5 IT", "L6 IT", "L6 IT Car3", "L5 ET", "L5/6 NP", "L6 CT", "L6b",
          "Lamp5", "Lamp5 Lhx6", "Pax6", "Sncg", "Vip", "Sst", "Sst Chodl", "Pvalb", "Chandelier"]


def load_gwas() -> dict[str, pd.DataFrame]:
    g = pd.read_csv(GWAS, sep="\t", usecols=["variant_id", "p_value", "chromosome", "base_pair_location"],
                    dtype={"chromosome": str})
    g = g.rename(columns={"variant_id": "snp", "p_value": "p", "chromosome": "chrom", "base_pair_location": "pos"}).dropna()
    g["chrom"] = "chr" + g["chrom"].str.replace("chr", "", regex=False)
    return {c: d.sort_values("pos").reset_index(drop=True) for c, d in g.groupby("chrom")}


def peak_snps(peaks: pd.DataFrame, gw: dict) -> pd.DataFrame:
    """Per peak: n SNPs inside, min p, lead SNP, n SNPs with p < 1e-5."""
    out = []
    for chrom, idx in peaks.groupby("chrom").indices.items():
        g = gw.get(chrom)
        sub = peaks.iloc[idx]
        if g is None:
            out.append(pd.DataFrame({"i": idx, "n_snps": 0, "min_p": 1.0, "lead_snp": "", "n_1e5": 0}))
            continue
        pos, p = g["pos"].to_numpy(), g["p"].to_numpy()
        lo = np.searchsorted(pos, sub["start"].to_numpy(), "left")
        hi = np.searchsorted(pos, sub["end"].to_numpy(), "right")
        n = hi - lo
        mn = np.ones(len(idx))
        lead = np.array([""] * len(idx), dtype=object)
        n5 = np.zeros(len(idx), int)
        for k in np.flatnonzero(n > 0):
            pp = p[lo[k]:hi[k]]
            j = int(np.argmin(pp))
            mn[k], lead[k], n5[k] = pp[j], g["snp"].iat[lo[k] + j], int((pp < 1e-5).sum())
        out.append(pd.DataFrame({"i": idx, "n_snps": n, "min_p": mn, "lead_snp": lead, "n_1e5": n5}))
    return pd.concat(out).set_index("i").sort_index()


def loci(df: pd.DataFrame, gap: int = 500_000) -> int:
    n = 0
    for _, d in df.sort_values(["chrom", "start"]).groupby("chrom"):
        n += 1 + int((np.diff(d["start"].to_numpy()) > gap).sum())
    return n


def enrichment(info: pd.DataFrame, fg: np.ndarray, pool: np.ndarray, rng, n_draw: int, label: str, excl_apoe: bool):
    keep = np.ones(len(info), bool)
    if excl_apoe:
        c, s, e = APOE
        keep = ~((info["chrom"] == c) & (info["end"] > s) & (info["start"] < e)).to_numpy()
    fg, pool = fg[keep[fg]], pool[keep[pool]]
    fg, pool = fg[info["n_snps"].to_numpy()[fg] > 0], pool[info["n_snps"].to_numpy()[pool] > 0]
    nb = pd.qcut(info["n_snps"].rank(method="first"), 10, labels=False).to_numpy()
    stratum = nb * 2 + (info["class"].to_numpy() == "promoter")
    by = {s: pool[stratum[pool] == s] for s in np.unique(stratum[pool])}
    hit = (info["min_p"].to_numpy() < 1e-5)
    mlp = -np.log10(info["min_p"].to_numpy())
    obs_hit, obs_mlp = hit[fg].mean(), mlp[fg].mean()
    null_hit, null_mlp = [], []
    for _ in range(n_draw):
        b = np.array([rng.choice(by[s]) for s in stratum[fg] if len(by.get(s, [])) > 0])
        null_hit.append(hit[b].mean())
        null_mlp.append(mlp[b].mean())
    null_hit, null_mlp = np.array(null_hit), np.array(null_mlp)
    fg_hits = info.iloc[fg][hit[fg]]
    return {"set": label, "apoe_excluded": excl_apoe, "n_peaks": len(fg), "hit_frac": obs_hit,
            "null_hit_frac": null_hit.mean(), "fold": obs_hit / null_hit.mean() if null_hit.mean() > 0 else np.nan,
            "p_hit": (np.sum(null_hit >= obs_hit) + 1) / (n_draw + 1), "n_hit_peaks": int(hit[fg].sum()),
            "n_hit_loci": loci(fg_hits) if len(fg_hits) else 0, "mean_maxlog10p": obs_mlp,
            "null_mean_maxlog10p": null_mlp.mean(), "p_mlp": (np.sum(null_mlp >= obs_mlp) + 1) / (n_draw + 1)}


def celltype_sets(peaks: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    d = ROOT / "data/processed/atac_pb"
    rows, mats = [], []
    for f in sorted(d.glob("*.npz")):
        rows.append(pd.read_csv(f.with_suffix(".csv")))
        mats.append(sp.load_npz(f))
    rows = pd.concat(rows, ignore_index=True)
    M = sp.vstack(mats).tocsr()
    def pooled(mask):
        c = np.asarray(M[np.flatnonzero(mask)].sum(0)).ravel()
        return c / c.sum() * 1e6
    mic = pooled(rows["subclass"].eq("Microglia-PVM").to_numpy())
    neu = pooled(rows["subclass"].isin(NEURON).to_numpy())
    lfc = np.log2(mic + 1) - np.log2(neu + 1)
    return np.flatnonzero((lfc >= 2) & (mic >= 2)), np.flatnonzero((lfc <= -2) & (neu >= 2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/dam_peaks")
    ap.add_argument("--n-draw", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    rng = np.random.default_rng(args.seed)

    gw = load_gwas()
    print(f"GWAS SNPs: {sum(len(v) for v in gw.values()):,}")
    allp = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split()).reset_index(names="peak")
    res = pd.read_csv(out / "dam_peaks_all.csv.gz")
    allp = allp.merge(res[["peak", "call", "q", "log2fc"]], on="peak", how="left")
    allp = pd.concat([allp, annotate(allp, ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz").reset_index(drop=True)], axis=1)
    info = pd.concat([allp, peak_snps(allp, gw)], axis=1)
    info.to_csv(out / "peak_gwas.csv.gz", index=False)

    mic, neu = celltype_sets(allp)
    tested = np.flatnonzero(allp["call"].notna().to_numpy())
    ns = np.flatnonzero((allp["call"] == "ns").to_numpy())
    every = np.arange(len(allp))
    rows = []
    for excl in (False, True):
        rows.append(enrichment(info, mic, every, rng, args.n_draw, "microglia-specific (control)", excl))
        rows.append(enrichment(info, neu, every, rng, args.n_draw, "neuron-specific (control)", excl))
        rows.append(enrichment(info, tested, every, rng, args.n_draw, "microglia-accessible (tested)", excl))
        for call in ("DAM-open", "DAM-closed"):
            fg = np.flatnonzero((allp["call"] == call).to_numpy())
            rows.append(enrichment(info, fg, ns, rng, args.n_draw, call, excl))
        fg = np.flatnonzero(((allp["q"] < 0.1) & (allp["call"].notna())).to_numpy() & (allp["log2fc"].abs() >= 0.5).to_numpy())
        rows.append(enrichment(info, fg, ns, rng, args.n_draw, "differential at q < 0.1", excl))
    enr = pd.DataFrame(rows)
    enr.to_csv(out / "gwas_enrichment.csv", index=False)
    print(enr.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # whole-axis test: among all tested microglia peaks, are AD-risk peaks shifted toward DAM-open or closed?
    # one peak per locus (strongest SNP), background matched on n SNPs, class and homeostatic accessibility
    tr = info.iloc[tested].merge(res[["peak", "t", "cpm_hom"]], on="peak")
    tr = tr[tr["n_snps"] > 0].reset_index(drop=True)
    hits = tr[tr["min_p"] < 1e-5].sort_values("min_p")
    lead = []
    for _, d in hits.groupby("chrom"):
        last = -10 ** 9
        for _, r in d.sort_values("start").iterrows():
            if r["start"] - last > 500_000:
                lead.append(r.name)
                last = r["start"]
            elif r["min_p"] < tr.at[lead[-1], "min_p"]:
                lead[-1] = r.name
    lead = np.array(lead)
    strat = (pd.qcut(tr["n_snps"].rank(method="first"), 5, labels=False).to_numpy() * 10
             + pd.qcut(tr["cpm_hom"].rank(method="first"), 5, labels=False).to_numpy() * 2
             + (tr["class"].to_numpy() == "promoter"))
    pool = np.flatnonzero(tr["min_p"].to_numpy() >= 1e-3)
    by = {s: pool[strat[pool] == s] for s in np.unique(strat)}
    tv = tr["t"].to_numpy()
    obs = tv[lead].mean()
    null = np.array([tv[[rng.choice(by[s]) for s in strat[lead]]].mean() for _ in range(args.n_draw)])
    axis = pd.DataFrame([{"n_lead_peaks": len(lead), "mean_t_dam_vs_hom": obs, "null_mean": null.mean(),
                          "null_sd": null.std(), "z": (obs - null.mean()) / null.std(),
                          "p_two_sided": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (args.n_draw + 1)}])
    axis.to_csv(out / "gwas_dam_axis.csv", index=False)
    print("\nAD-risk peaks (one per locus, SNP p < 1e-5) on the DAM-vs-homeostatic chromatin axis:")
    print(axis.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    tr.iloc[lead][["peak", "nearest_gene", "class", "lead_snp", "min_p", "log2fc", "t", "q"]].sort_values("t").to_csv(
        out / "gwas_lead_peaks_axis.csv", index=False)

    cand = info[(info["q"] < 0.1) & (info["log2fc"].abs() >= 0.5) & (info["min_p"] < 1e-5)].sort_values("min_p")
    cand = cand[["peak", "nearest_gene", "dist_tss", "class", "log2fc", "q", "call", "n_snps", "n_1e5", "lead_snp", "min_p"]]
    cand.to_csv(out / "gwas_candidates.csv", index=False)
    print(f"\nCandidate elements (differential q < 0.1, |log2FC| >= 0.5, SNP p < 1e-5 inside): {len(cand)}")
    print(cand.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
