"""RASGEF1C in the single-nucleus brain eQTL study of Haglund et al. 2025 (Nat. Genet., README 47).

    python scripts/haglund_rasgef1c.py          # writes results/rasgef1c/F_haglund2025.csv

Inputs: the published supplementary tables (data/raw/haglund2025/, downloaded from the article page
https://www.nature.com/articles/s41588-024-02050-9): S4 = Supp. Table 1 (cis-eQTLs, 8 cell types, 391
donors), S5 = Supp. Table 2 (disease interaction), S9 = Supp. Table 6 (control-only, 183 donors),
S7 / S11 = Supp. Tables 4 / 8 (coloc with 41 traits, PP.H4 > 0.8; all / control-only), S12 = Supp.
Table 9 (Mendelian randomisation). The full summary statistics (Zenodo 13343729) were not reachable.

Direction: the tables give eQTL beta without alleles; the MR IVW estimate (AD log-odds per unit
expression, harmonised by the authors) gives the sign of the risk allele's effect on expression.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/haglund2025"
OUT = ROOT / "results/rasgef1c"
CREDIBLE = {"rs111274391", "rs116347724", "rs113706587", "rs76792388"}


def table(f, sheet):
    d = pd.read_excel(RAW / f, sheet_name=sheet, header=None)
    i = next(k for k in range(6) if d.iloc[k].astype(str).isin(["Gene", "SNP"]).any())
    d.columns = [str(c) for c in d.iloc[i]]
    d = d.iloc[i + 1:]
    return d[d.astype(str).apply(lambda c: c.str.contains("RASGEF1C", na=False)).any(axis=1)]


def main():
    rows = []
    for f, label in (("S4.xlsx", "eQTL, all 391 donors"), ("S9.xlsx", "eQTL, 183 control donors")):
        for sheet in pd.ExcelFile(RAW / f).sheet_names:
            for _, r in table(f, sheet).iterrows():
                rows.append({"source": label, "cell_type": sheet, "snp": r["SNP"], "in_AD_credible_set": r["SNP"] in CREDIBLE,
                             "beta": r["Beta"], "t": r["t-statistic"], "p": r["p-value"], "fdr": r["FDR"]})
    for f, label in (("S7.xlsx", "coloc with AD (all donors)"), ("S11.xlsx", "coloc with AD (controls)")):
        d = pd.read_excel(RAW / f, header=None)
        for _, r in d[d.astype(str).apply(lambda c: c.str.contains("RASGEF1C", na=False)).any(axis=1)].iterrows():
            v = [x for x in r.tolist() if pd.notna(x)]
            rows.append({"source": label, "cell_type": "Microglia", "snp": ",".join(s for s in map(str, v) if s.startswith("rs")),
                         "pp_h4": next(x for x in v if isinstance(x, float) and 0.8 < x <= 1), "trait": "AD 2022"})
    mr = table("S12.xlsx", "MR")
    for _, r in mr.iterrows():
        rows.append({"source": "Mendelian randomisation", "cell_type": r["Cell-type"], "snp": r["IVs"],
                     "beta": r["IVW beta"], "se": r["IVW std.error"], "p": r["IVW p-value"],
                     "note": "AD log-odds per unit microglial RASGEF1C; negative = lower expression, higher risk"})
    T = pd.DataFrame(rows)
    T.to_csv(OUT / "F_haglund2025.csv", index=False)
    pd.set_option("display.width", 220)
    print(T.to_string(index=False))


if __name__ == "__main__":
    main()
