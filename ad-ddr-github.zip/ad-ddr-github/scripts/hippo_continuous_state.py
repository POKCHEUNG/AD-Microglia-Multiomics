"""Hippocampus multiome: is the homeostatic shift an artefact of how microglia are grouped?

    python scripts/hippo_continuous_state.py    # writes results/hippo_replication/continuous_*.csv, hippo_dam_peaks.csv.gz

Per-nucleus DAM RNA score as in scripts/run_hippo_replication.py (cached by
scripts/make_supp_umap.py). SEA-AD DAM axis = DAM-open minus DAM-closed peaks
(results/dam_peaks/dam_peaks_all.csv.gz), z over the analysed units.

1. Continuous state. Nuclei are binned by cohort-wide quintile of the RNA score; each
   (donor, quintile) with >= 15 nuclei is pseudobulked. Model: axis ~ Braak + quintile
   (fixed) + age + sex + log fragments; p from 5,000 permutations of Braak across donors
   (a donor's quintiles move together), p_set from 500 accessibility-matched random axes.
   Then the same Braak association within each quintile separately.
2. Threshold sweep. "Homeostatic" = score below the cohort 20th ... 60th percentile; the
   pool's mean RNA score replaces the share of high-score nuclei as the state covariate.
3. Hippocampus-defined DAM peaks (independent of SEA-AD donors and labels): DAM-high vs
   DAM-low third within donor, depth-matched and averaged over 20 thinning draws, paired t
   with sign-flip FDR over the SEA-AD tested peaks; used by scripts/homeostatic_shift_selection.py.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr.stats import _covar_matrix, _resid
from run_dam_peaks import flip_test, thin_mean_diff
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/hippo_replication"


def lcpm(c):
    return np.log2(c / c.sum() * 1e6 + 1)


def main():
    rng = np.random.default_rng(0)
    L, _ = load_libs()
    peaks = pd.Index((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    keep = peaks.get_indexer(res["peak"])
    call = res["call"].to_numpy()
    openi, closi, nsi = (np.flatnonzero(call == c) for c in ("DAM-open", "DAM-closed", "ns"))
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    A = {}
    for lib, D in L.items():
        m = (D["cells"]["subclass"] == "Microglia").to_numpy()
        if m.sum():
            A[lib] = D["atac_cells"][m].tocsr()[:, keep]
    X = {lib: A[lib] for lib in cache["library"].unique()}
    import scipy.sparse as sp
    Xall = sp.vstack([X[l] for l in cache["library"].unique()]).tocsr()
    order = pd.concat([cache[cache["library"] == l] for l in cache["library"].unique()]).index.to_numpy()
    cells = cache.loc[order].reset_index(drop=True)
    score = cells["score"].to_numpy()
    donor = cells["donor"].to_numpy()
    dinfo = cells.drop_duplicates("donor").set_index("donor")[["age", "sex", "Braak", "group"]]

    acc = np.log2(np.asarray(Xall.sum(0)).ravel() / Xall.sum() * 1e6 + 1)
    bins = pd.qcut(pd.Series(acc).rank(method="first"), 20, labels=False).to_numpy()
    pool = {b: nsi[bins[nsi] == b] for b in range(20)}
    rand = [(np.array([rng.choice(pool[b]) for b in bins[openi]]), np.array([rng.choice(pool[b]) for b in bins[closi]]))
            for _ in range(500)]

    def units(mask_fn, min_n):
        rows, Lm = [], []
        for d in np.unique(donor):
            for lab, m in mask_fn(d):
                if m.sum() < min_n:
                    continue
                c = np.asarray(Xall[m].sum(0)).ravel()
                Lm.append(lcpm(c))
                rows.append({"donor": d, "unit": lab, "n": int(m.sum()), "logfrag": np.log10(c.sum()),
                             "mean_score": score[m].mean()})
        Lm = np.array(Lm)
        Z = (Lm - Lm.mean(0)) / np.where(Lm.std(0) > 0, Lm.std(0), 1)
        return pd.DataFrame(rows).join(dinfo, on="donor"), Z

    def assoc(info, Z, cov, n_perm=5000):
        m = info[["Braak"] + [c for c in cov if not c.startswith("C(")]].notna().all(1).to_numpy()
        I, Zm = info[m].reset_index(drop=True), Z[m]
        C = _covar_matrix(I, [c for c in cov if not c.startswith("C(")])
        if any(c.startswith("C(") for c in cov):
            C = np.column_stack([C, pd.get_dummies(I["unit"], drop_first=True).to_numpy(float)])
        x = I["Braak"].to_numpy(float)
        xr = _resid(x, C)

        def r_of(o, c):
            return np.corrcoef(xr, _resid(Zm[:, o].mean(1) - Zm[:, c].mean(1), C))[0, 1]
        r = r_of(openi, closi)
        y = _resid(Zm[:, openi].mean(1) - Zm[:, closi].mean(1), C)
        dons = I["donor"].to_numpy()
        ud = np.unique(dons)
        bd = I.drop_duplicates("donor").set_index("donor")["Braak"]
        null = []
        for _ in range(n_perm):
            pm = dict(zip(ud, rng.permutation(bd.reindex(ud).to_numpy())))
            null.append(np.corrcoef(_resid(np.array([pm[d] for d in dons]), C), y)[0, 1])
        null = np.array(null)
        ns = np.array([r_of(o, c) for o, c in rand])
        boot = []
        for _ in range(2000):
            pick = rng.choice(ud, len(ud))
            ix = np.concatenate([np.flatnonzero(dons == d) for d in pick])
            if np.std(xr[ix]) > 0:
                boot.append(np.corrcoef(xr[ix], y[ix])[0, 1])
        return {"n_units": int(m.sum()), "n_donors": len(ud), "r": r, "ci_lo": np.percentile(boot, 2.5),
                "ci_hi": np.percentile(boot, 97.5), "p_perm": (np.sum(np.abs(null) >= abs(r)) + 1) / (n_perm + 1),
                "null_mean": ns.mean(), "p_set": (np.sum(np.abs(ns - ns.mean()) >= abs(r - ns.mean())) + 1) / (len(ns) + 1)}

    # ---- 1. continuous state
    qs = np.quantile(score, [0.2, 0.4, 0.6, 0.8])
    qbin = np.searchsorted(qs, score)
    info, Z = units(lambda d: [(f"Q{q + 1}", (donor == d) & (qbin == q)) for q in range(5)], 15)
    rows1 = [{"model": "all quintiles, quintile fixed effect", **assoc(info, Z, ["age", "sex", "logfrag", "C(unit)"])}]
    for q in range(5):
        k = (info["unit"] == f"Q{q + 1}").to_numpy()
        rows1.append({"model": f"Q{q + 1} only", **assoc(info[k].reset_index(drop=True), Z[k], ["age", "sex", "logfrag"])})
    T1 = pd.DataFrame(rows1)
    T1.to_csv(OUT / "continuous_quintiles.csv", index=False)
    info.assign(axis=Z[:, openi].mean(1) - Z[:, closi].mean(1)).to_csv(OUT / "continuous_quintile_units.csv", index=False)
    print("1. Continuous RNA state (cohort-wide quintiles of the DAM RNA score):")
    print(T1.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---- 2. threshold sweep
    rows2 = []
    for pct in (20, 30, 40, 50, 60):
        thr = np.percentile(score, pct)
        info, Z = units(lambda d: [("homeo", (donor == d) & (score < thr))], 20)
        rows2.append({"threshold_pct": pct, "covariate": "pool mean RNA score",
                      **assoc(info, Z, ["age", "sex", "logfrag", "mean_score"])})
        rows2.append({"threshold_pct": pct, "covariate": "none (age, sex, log fragments)",
                      **assoc(info, Z, ["age", "sex", "logfrag"])})
    T2 = pd.DataFrame(rows2)
    T2.to_csv(OUT / "continuous_threshold_sweep.csv", index=False)
    print("\n2. Threshold sweep for 'homeostatic':")
    print(T2.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---- 3. hippocampus-defined DAM peaks
    D = []
    for d in np.unique(donor):
        m = donor == d
        if m.sum() < 30:
            continue
        s = score[m]
        lo, hi = np.quantile(s, [1 / 3, 2 / 3])
        idx = np.flatnonzero(m)
        ch = np.asarray(Xall[idx[s >= hi]].sum(0)).ravel()
        cl = np.asarray(Xall[idx[s <= lo]].sum(0)).ravel()
        D.append(thin_mean_diff(ch, cl, rng, lcpm))
    D = np.array(D)
    mean, t, p, q = flip_test(D, 2000, rng)
    H = pd.DataFrame({"peak": res["peak"], "hippo_log2fc": mean, "hippo_t": t, "hippo_p": p, "hippo_q": q})
    H["hippo_call"] = np.select([(q < 0.05) & (mean >= 0.5), (q < 0.05) & (mean <= -0.5)], ["DAM-open", "DAM-closed"], "ns")
    H.to_csv(OUT / "hippo_dam_peaks.csv.gz", index=False)
    ct = pd.crosstab(res["call"], H["hippo_call"])
    print(f"\n3. Hippocampus-defined DAM peaks ({len(D)} donors): open {(H.hippo_call == 'DAM-open').sum()}, "
          f"closed {(H.hippo_call == 'DAM-closed').sum()}; Spearman with SEA-AD t "
          f"{pd.Series(t).corr(res['t'], method='spearman'):.2f}\n{ct}")


if __name__ == "__main__":
    main()
