"""Is the homeostatic shift intrinsic, or contamination / composition? (README 41)

    python scripts/homeostatic_mixture.py       # writes results/homeostatic_shift/mixture_*.csv

(a) Contamination bound, SEA-AD. If the homeostatic (Micro-PVM_2) pseudobulk of a donor were a mixture
    (1 - f) * homeostatic + f * DAM-like, how much must f rise with plaques to produce the observed shift?
    Raw axis A = mean log2(CPM + 1) over DAM-open minus DAM-closed peaks. beta = partial slope of A on
    log 6E10 (age, sex, PMI, log nuclei). s = dA/df, obtained by mixing each donor's homeostatic CPM with
    the pooled DAM-like CPM at f = 0..0.2. Required change of f across the 5th-95th percentile of plaques
    = beta * range / s, compared with the change of the DAM-like share of microglia over the same range
    (the pool any mislabelled nuclei would come from).
(b) Nucleus level, hippocampus multiome. Per nucleus, chromatin DAM score = mean SEA-AD DAM t of the
    tested peaks hit by its fragments (all 32,481 peaks, so every fragment counts), minus the donor-
    independent expectation for its depth. Within the nuclei below the cohort-median RNA DAM score:
    (i) per donor, quantiles 10-90% of the nucleus scores against Braak (age, sex, log fragments):
        a location shift moves every quantile, a growing DAM-like tail moves only the upper ones;
    (ii) per donor, the chromatin score predicted at the cohort-median RNA score from a within-donor
        regression of nucleus chromatin score on nucleus RNA score and log fragments, against Braak:
        the shift at a fixed RNA state, which composition cannot produce.
    p from 5,000 permutations of Braak across donors.
    Sensitivity: the score definition (all-peak t vs log open/closed DAM-peak counts) and whether log
    fragments per nucleus, which fall with Braak, is a covariate.
(a2) Composition, SEA-AD: the shift adjusted for every microglial supertype share.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ad_ddr.stats import _covar_matrix, _resid
from run_dam_peaks import DAM, HOM, load
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/homeostatic_shift"
OUT.mkdir(parents=True, exist_ok=True)


def lcpm(c):
    return np.log2(c / c.sum() * 1e6 + 1)


def part_r(x, y, C, rng, n_perm=5000):
    xr, yr = _resid(x, C), _resid(y, C)
    r = np.corrcoef(xr, yr)[0, 1]
    null = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(n_perm)])
    return r, (np.sum(np.abs(null) >= abs(r)) + 1) / (n_perm + 1)


def main():
    rng = np.random.default_rng(0)
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    peaks = pd.Index((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    pix = peaks.get_indexer(res["peak"])
    op = np.flatnonzero((res["call"] == "DAM-open").to_numpy())
    cl = np.flatnonzero((res["call"] == "DAM-closed").to_numpy())

    # ---------- (a) contamination bound
    rows, M = load(ROOT / "data/processed/atac_pb_micro")
    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")["number of 6e10 positive objects per area"]
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    n = rows.groupby(["donor", "subclass"])["n_nuclei"].sum().unstack(fill_value=0)
    micro_cols = [c for c in n.columns if c.startswith("Micro")]
    donors = [d for d in n.index[n[HOM] >= 30] if d in gm.index and d in meta.index]
    Dpool = np.asarray(M[rows.index[rows["subclass"] == DAM].to_numpy()].sum(0)).ravel()[pix]
    cD = Dpool / Dpool.sum()
    info, A, slopes = [], [], []
    for d in donors:
        h = np.asarray(M[rows.index[(rows["donor"] == d) & (rows["subclass"] == HOM)].to_numpy()].sum(0)).ravel()
        tot = h.sum()
        ch = h[pix] / tot
        def axis(c):
            l = np.log2(c * 1e6 + 1)
            return l[op].mean() - l[cl].mean()
        a0 = axis(ch)
        fs = np.array([0, 0.05, 0.1, 0.2])
        # keep the in-peak fraction of the donor: mix the tested-peak share profiles at equal in-peak mass
        mix = [axis((1 - f) * ch + f * cD * ch.sum()) for f in fs]
        slopes.append(np.polyfit(fs, mix, 1)[0])
        A.append(a0)
        info.append({"donor": d, "age": pd.to_numeric(meta.at[d, "Age at Death"], errors="coerce"),
                     "sex": str(meta.at[d, "Sex"]), "pmi": pd.to_numeric(meta.at[d, "PMI"], errors="coerce"),
                     "lognuc": np.log10(n.at[d, HOM]), "plaque": np.log10(float(gm.get(d)) * 1e6 + 1),
                     "dam_share": n.at[d, DAM] / n.loc[d, micro_cols].sum()})
    I = pd.DataFrame(info).assign(axis_raw=A, mix_slope=slopes)
    ok = I.notna().all(1).to_numpy()
    I = I[ok].reset_index(drop=True)
    C = np.column_stack([np.ones(len(I)), _covar_matrix(I, ["age", "sex", "pmi", "lognuc"])])
    b = np.linalg.lstsq(np.column_stack([I["plaque"], C]), I["axis_raw"], rcond=None)[0][0]
    bs = np.linalg.lstsq(np.column_stack([I["plaque"], C]), I["dam_share"], rcond=None)[0][0]
    lo, hi = np.percentile(I["plaque"], [5, 95])
    s = np.median(I["mix_slope"])
    need = b * (hi - lo) / s
    boot = []
    for _ in range(2000):
        ix = rng.choice(len(I), len(I))
        Xb = np.column_stack([I["plaque"].to_numpy()[ix], C[ix]])
        bb = np.linalg.lstsq(Xb, I["axis_raw"].to_numpy()[ix], rcond=None)[0][0]
        sb = np.linalg.lstsq(Xb, I["dam_share"].to_numpy()[ix], rcond=None)[0][0]
        boot.append((bb * (hi - lo) / s, sb * (hi - lo)))
    boot = np.array(boot)
    A_out = pd.Series({"n_donors": len(I), "axis_slope_per_log_plaque": b, "mix_slope_dA_df": s,
                       "plaque_range_5_95": hi - lo, "required_delta_f": need,
                       "required_delta_f_lo": np.percentile(boot[:, 0], 2.5),
                       "required_delta_f_hi": np.percentile(boot[:, 0], 97.5),
                       "observed_delta_dam_share": bs * (hi - lo),
                       "observed_delta_dam_share_lo": np.percentile(boot[:, 1], 2.5),
                       "observed_delta_dam_share_hi": np.percentile(boot[:, 1], 97.5),
                       "median_dam_share": I["dam_share"].median(),
                       "axis_gap_dam_minus_hom_raw": np.median(I["mix_slope"])})
    # composition: every supertype share as covariate
    for st_name, col in (("Micro-PVM_2_3-SEAAD", "share_23"), ("Micro-PVM_4-SEAAD", "share_4")):
        I[col] = [n.at[d, st_name] / n.loc[d, micro_cols].sum() for d in I["donor"]]
    I["share_nonhom"] = [1 - n.at[d, HOM] / n.loc[d, micro_cols].sum() for d in I["donor"]]
    comp = []
    for cov in ([], ["dam_share"], ["dam_share", "share_23"], ["dam_share", "share_23", "share_4"], ["share_nonhom"]):
        Cc = _covar_matrix(I, ["age", "sex", "pmi", "lognuc"] + cov)
        r, pv = part_r(I["plaque"].to_numpy(float), I["axis_raw"].to_numpy(float), Cc, rng)
        comp.append({"extra_covariates": "+".join(cov) or "none", "r": r, "p_perm": pv})
    pd.DataFrame(comp).to_csv(OUT / "mixture_composition.csv", index=False)
    print("   composition-adjusted shift:\n", pd.DataFrame(comp).to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    A_out.to_csv(OUT / "mixture_bound.csv")
    I.to_csv(OUT / "mixture_bound_donors.csv", index=False)
    print("(a) contamination bound (SEA-AD):")
    print(A_out.round(4).to_string())
    print(f"   -> to explain the shift by contamination, the DAM-like fraction hidden in the homeostatic label must rise by "
          f"{need:.1%} (95% CI {A_out['required_delta_f_lo']:.1%} to {A_out['required_delta_f_hi']:.1%}) across the 5-95% "
          f"plaque range; the labelled DAM-like share itself rises by {A_out['observed_delta_dam_share']:.1%}")

    # ---------- (b) nucleus level, hippocampus
    L, _ = load_libs()
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    X = sp.vstack([L[l]["atac_cells"][(L[l]["cells"]["subclass"] == "Microglia").to_numpy()]
                   for l in cache["library"].unique()]).tocsr()[:, pix]
    t = res["t"].to_numpy()
    cnt = np.asarray(X.sum(1)).ravel()
    raw_score = np.asarray(X @ t).ravel() / np.maximum(cnt, 1)
    cache["frag_tested"] = cnt
    # expectation for depth: the score of a nucleus with the pooled profile is the same at any depth, but
    # sparse nuclei hit fewer low-accessibility peaks; regress on log depth across all nuclei
    lg = np.log10(np.maximum(cnt, 1))
    good = cnt >= 200
    coef = np.polyfit(lg[good], raw_score[good], 2)
    cache["chrom_score"] = raw_score - np.polyval(coef, lg)
    cache["log_frag"] = lg
    c = cache[good].copy()
    med = np.median(cache["score"])
    print(f"\n(b) hippocampus: {good.sum()} of {len(cache)} nuclei with >= 200 fragments in tested peaks; "
          f"r(nucleus chromatin score, nucleus RNA DAM score) = {np.corrcoef(c['chrom_score'], c['score'])[0, 1]:.2f}")
    homeo = c[c["score"] < med]
    dinfo = cache.drop_duplicates("donor").set_index("donor")[["age", "sex", "Braak"]]
    rowsq, rowsf = [], []
    for d, g in homeo.groupby("donor"):
        if len(g) < 20:
            continue
        qv = np.percentile(g["chrom_score"], [10, 25, 50, 75, 90])
        rowsq.append({"donor": d, "n": len(g), "log_frag": g["log_frag"].mean(), **{f"q{q}": v for q, v in zip([10, 25, 50, 75, 90], qv)},
                      "mean": g["chrom_score"].mean()})
    for d, g in c.groupby("donor"):
        if len(g) < 30:
            continue
        Xd = np.column_stack([np.ones(len(g)), g["score"], g["log_frag"]])
        bcoef = np.linalg.lstsq(Xd, g["chrom_score"], rcond=None)[0]
        rowsf.append({"donor": d, "n": len(g), "at_median_rna": bcoef[0] + bcoef[1] * med + bcoef[2] * c["log_frag"].median(),
                      "slope_on_rna": bcoef[1], "log_frag": g["log_frag"].mean()})
    Q = pd.DataFrame(rowsq).join(dinfo, on="donor")
    F = pd.DataFrame(rowsf).join(dinfo, on="donor")
    out = []
    for name, D, cols in (("homeostatic nuclei, quantile", Q, ["q10", "q25", "q50", "q75", "q90", "mean"]),
                          ("all nuclei, at fixed RNA state", F, ["at_median_rna", "slope_on_rna"])):
        k = D[["Braak", "age"]].notna().all(1).to_numpy()
        Dk = D[k].reset_index(drop=True)
        Cd = _covar_matrix(Dk, ["age", "sex", "log_frag"])
        for col in cols:
            r, p = part_r(Dk["Braak"].to_numpy(float), Dk[col].to_numpy(float), Cd, rng)
            out.append({"analysis": name, "statistic": col, "n_donors": len(Dk), "r_with_braak": r, "p_perm": p})
    # sensitivity: score definition and depth handling (fragments per nucleus fall with Braak)
    op_c = np.asarray(X[:, op].sum(1)).ravel()
    cl_c = np.asarray(X[:, cl].sum(1)).ravel()
    cache["logratio"] = np.log((op_c + 0.5) / (cl_c + 0.5))
    cache["raw_t"] = raw_score
    q1 = cache["score"] < np.quantile(cache["score"], 0.2)
    for col, lab in (("raw_t", "all-peak t score, no depth correction"), ("logratio", "log(open / closed) DAM peaks")):
        for selname, sel in (("below median", cache["score"] < med), ("lowest quintile", q1)):
            g = cache[sel].groupby("donor").agg(v=(col, "mean"), log_frag=("log_frag", "mean"), n=(col, "size"))
            g = g[g["n"] >= 20].join(dinfo).dropna().reset_index()
            for covs in (["age", "sex", "log_frag"], ["age", "sex"]):
                r, pv = part_r(g["Braak"].to_numpy(float), g["v"].to_numpy(float), _covar_matrix(g, covs), rng)
                out.append({"analysis": f"sensitivity: {lab}, {selname}", "statistic": "+".join(covs), "n_donors": len(g),
                            "r_with_braak": r, "p_perm": pv})
    O = pd.DataFrame(out)
    O.to_csv(OUT / "mixture_nucleus_level.csv", index=False)
    Q.to_csv(OUT / "mixture_quantiles_donors.csv", index=False)
    F.to_csv(OUT / "mixture_fixed_state_donors.csv", index=False)
    cache[["library", "donor", "score", "chrom_score", "log_frag", "frag_tested"]].to_csv(OUT / "mixture_nucleus_scores.csv.gz",
                                                                                     index=False)
    print(O.to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
