"""Homeostatic shift (Fig. 5) in SEA-AD: selection bias, confidence intervals, feature overlap, state continuum.

    python scripts/homeostatic_shift_selection.py    # writes results/homeostatic_shift/

Score per donor and state pseudobulk (>= 30 nuclei unless stated): mean z of log2 CPM over the
axis' open peaks minus its closed peaks (z over donors); exposure log grey-matter 6E10;
covariates age, sex, PMI, log nuclei. Each row: partial r, donor-bootstrap 95% CI (2,000),
p_perm (5,000 exposure permutations), p_set (500 accessibility-matched random axes;
for weighted axes the weights are permuted within accessibility bins).

A. Selection bias. The published axis is called in 23 donors that are also scored.
   A1 cross-fitted: each discovery donor is scored with peaks called without them
      (leave-one-out); the other donors with peaks from all 23.
   A2 independent axis: peaks called in the hippocampus multiome (other cohort, state from
      same-nucleus RNA; scripts/hippo_continuous_state.py).
   A3 threshold-free: every tested peak weighted by its DAM-vs-homeostatic t (cross-fitted
      SEA-AD t, or hippocampus t).
B. Feature overlap. Axis without peaks in +/- 50 kb domains of the RNA genes that separate
   the two labels (top 200 DAM-up and DAM-down); promoter / distal only; 200 random halves
   of the axis; genome-wide, threshold-free: Spearman between each peak's plaque
   association in held-out homeostatic donors and its DAM t (null: 1,000 exposure
   permutations).
C. State continuum. Micro-PVM_2 -> Micro-PVM_2_3-SEAAD -> Micro-PVM_3-SEAAD (>= 10 nuclei):
   per state, pooled with state fixed effect, and the within-donor contrast (DAM-like
   minus homeostatic) against plaques; labels coarsened (Micro-PVM_2 + 2_3 pooled).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.genome import parse_peak_names, peaks_near_genes, read_gtf_genes
from run_dam_peaks import DAM, HOM, flip_test, load, paired

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/homeostatic_shift"
OUT.mkdir(parents=True, exist_ok=True)
MID = "Micro-PVM_2_3-SEAAD"
BASE = ["age", "sex", "pmi", "lognuc"]


def calls_of(mean, q):
    return np.select([(q < 0.05) & (mean >= 0.5), (q < 0.05) & (mean <= -0.5)], [1, -1], 0)


def main():
    rng = np.random.default_rng(0)
    d = ROOT / "data/processed/atac_pb_micro"
    peaks = parse_peak_names((d / "peaks.txt").read_text().split())
    rows, M = load(d)
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    pix = peaks.index.get_indexer(res["peak"])
    pub = np.select([res["call"] == "DAM-open", res["call"] == "DAM-closed"], [1, -1], 0)
    disc = pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"].tolist()
    hip = pd.read_csv(ROOT / "results/hippo_replication/hippo_dam_peaks.csv.gz").set_index("peak").reindex(res["peak"])
    hcall = np.select([hip["hippo_call"].eq("DAM-open"), hip["hippo_call"].eq("DAM-closed")], [1, -1], 0)

    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")["number of 6e10 positive objects per area"]
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")

    def state_matrix(states, min_n):
        r = rows[rows["subclass"].isin(states)]
        n = r.groupby("donor")["n_nuclei"].sum()
        donors = [x for x in n.index[n >= min_n] if x in gm.index and x in meta.index]
        L, info = [], []
        for x in donors:
            c = np.asarray(M[r.index[r["donor"] == x].to_numpy()].sum(0)).ravel()
            L.append(np.log2(c[pix] / c.sum() * 1e6 + 1))
            info.append({"donor": x, "lognuc": np.log10(n[x]), "logfrag": np.log10(c.sum())})
        info = pd.DataFrame(info)
        x = info["donor"]
        info = info.assign(age=pd.to_numeric(meta.loc[x, "Age at Death"].to_numpy(), errors="coerce"),
                           sex=meta.loc[x, "Sex"].astype(str).to_numpy(),
                           pmi=pd.to_numeric(meta.loc[x, "PMI"].to_numpy(), errors="coerce"),
                           plaque=np.log10(pd.to_numeric(gm.reindex(x), errors="coerce").to_numpy() * 1e6 + 1))
        return np.array(L), info

    LH, IH = state_matrix([HOM], 30)
    ZH = (LH - LH.mean(0)) / np.where(LH.std(0) > 0, LH.std(0), 1)
    acc = np.log2(res["cpm_hom"].to_numpy() + 1)
    abin = pd.qcut(pd.Series(acc).rank(method="first"), 20, labels=False).to_numpy()

    bg_pool = {b: np.flatnonzero((abin == b) & (pub == 0)) for b in range(20)}
    bin_ix = {b: np.flatnonzero(abin == b) for b in range(20)}

    def rand_axes(w, n=500):
        """Random versions of an axis: matched peaks for a set axis, permuted weights for a weighted one."""
        out = []
        is_set = set(np.unique(w)) <= {-1, 0, 1}
        for _ in range(n):
            v = np.zeros(len(w)) if is_set else w.copy()
            for b in range(20):
                if is_set:
                    k = [(sgn, int(((w == sgn) & (abin == b)).sum())) for sgn in (1, -1)]
                    tot = k[0][1] + k[1][1]
                    if tot:
                        pick = rng.choice(bg_pool[b], tot, replace=False)
                        v[pick[:k[0][1]]], v[pick[k[0][1]:]] = 1, -1
                else:
                    v[bin_ix[b]] = rng.permutation(w[bin_ix[b]])
            out.append(v)
        return out

    def score(Z, w):
        w = np.asarray(w, float)
        if set(np.unique(w)) <= {-1.0, 0.0, 1.0}:
            o = Z[:, w > 0].mean(1) if (w > 0).any() else 0.0
            c = Z[:, w < 0].mean(1) if (w < 0).any() else 0.0
            return o - c
        return Z @ w / np.abs(w).sum()

    def test(Z, info, w, label, cov=BASE, keep=None, per_donor_w=None, rnd=None, n_perm=5000):
        m = info[["plaque"] + [c for c in cov if c != "state"]].notna().all(1).to_numpy()
        if keep is not None:
            m &= keep
        I, Zm = info[m].reset_index(drop=True), Z[m]
        C = _covar_matrix(I, [c for c in cov if c != "state"])
        if "state" in cov:
            C = np.column_stack([C, pd.get_dummies(I["state"], drop_first=True).to_numpy(float)])
        xr = _resid(I["plaque"].to_numpy(float), C)
        if per_donor_w is None:
            s = score(Zm, w)
        else:
            s = np.array([score(Zm[i:i + 1], per_donor_w.get(dn, w))[0] for i, dn in enumerate(I["donor"])])
        y = _resid(s, C)
        r = np.corrcoef(xr, y)[0, 1]
        dons = I["donor"].to_numpy()
        ud = np.unique(dons)
        boot = []
        for _ in range(2000):
            pick = rng.choice(ud, len(ud))
            ix = np.concatenate([np.flatnonzero(dons == dd) for dd in pick])
            boot.append(np.corrcoef(xr[ix], y[ix])[0, 1])
        if len(ud) == len(dons):
            null = np.array([np.corrcoef(rng.permutation(xr), y)[0, 1] for _ in range(n_perm)])
        else:                                                   # several units per donor: permute donors
            pl = I.drop_duplicates("donor").set_index("donor")["plaque"]
            null = []
            for _ in range(n_perm):
                pm = dict(zip(ud, rng.permutation(pl.reindex(ud).to_numpy())))
                null.append(np.corrcoef(_resid(np.array([pm[dd] for dd in dons]), C), y)[0, 1])
            null = np.array(null)
        row = {"test": label, "n_units": int(m.sum()), "n_donors": len(ud), "n_open": int((np.asarray(w) > 0).sum()),
               "n_closed": int((np.asarray(w) < 0).sum()), "r": r, "ci_lo": np.percentile(boot, 2.5),
               "ci_hi": np.percentile(boot, 97.5), "p_perm": (np.sum(np.abs(null) >= abs(r)) + 1) / (n_perm + 1)}
        if rnd is not None:
            ns = np.array([np.corrcoef(xr, _resid(score(Zm, v), C))[0, 1] for v in rnd])
            row.update(null_mean=ns.mean(), p_set=(np.sum(np.abs(ns - ns.mean()) >= abs(r - ns.mean())) + 1) / (len(ns) + 1))
        return row

    rows_out = []
    held = ~IH["donor"].isin(disc).to_numpy()
    R_pub = rand_axes(pub)
    rows_out.append({"block": "baseline", **test(ZH, IH, pub, "published axis, all donors", rnd=R_pub)})
    rows_out.append({"block": "baseline", **test(ZH, IH, pub, "published axis, held-out donors", keep=held, rnd=R_pub)})

    # ---- A1 cross-fitted axis
    D, used = paired(rows, M, disc, pix, rng=rng)
    loo_w, loo_t = {}, {}
    for i, dn in enumerate(used):
        k = np.arange(len(used)) != i
        mn, t, p, q = flip_test(D[k], 2000, rng)
        loo_w[dn] = calls_of(mn, q)
        loo_t[dn] = t
    sizes = np.array([[(w == 1).sum(), (w == -1).sum()] for w in loo_w.values()])
    print(f"A1. leave-one-out axes: open {sizes[:, 0].min()}-{sizes[:, 0].max()}, closed {sizes[:, 1].min()}-{sizes[:, 1].max()}")
    rows_out.append({"block": "A selection", **test(ZH, IH, pub, "A1 cross-fitted axis (LOO for discovery donors)",
                                                     per_donor_w=loo_w, rnd=R_pub)})
    # ---- A2 hippocampus-defined axis
    rows_out.append({"block": "A selection", **test(ZH, IH, hcall, "A2 hippocampus-defined axis", rnd=rand_axes(hcall))})
    rows_out.append({"block": "A selection", **test(ZH, IH, hcall, "A2 hippocampus-defined axis, held-out donors",
                                                     keep=held, rnd=rand_axes(hcall))})
    # ---- A3 weighted, threshold-free
    t_full = res["t"].to_numpy()
    rows_out.append({"block": "A selection", **test(ZH, IH, t_full, "A3 all peaks weighted by SEA-AD t (cross-fitted)",
                                                     per_donor_w=loo_t, rnd=rand_axes(t_full, 200))})
    th = hip["hippo_t"].fillna(0).to_numpy()
    rows_out.append({"block": "A selection", **test(ZH, IH, th, "A3 all peaks weighted by hippocampus t",
                                                     rnd=rand_axes(th, 200))})

    # ---- B feature overlap
    G = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz")
    ex = G[G["rna_expressed"].astype("boolean").fillna(False).astype(bool)]
    label_genes = set(ex.nlargest(200, "rna_t")["gene"]) | set(ex.nsmallest(200, "rna_t")["gene"])
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    pr = peaks_near_genes(res.set_index("peak")[["chrom", "start", "end"]], genes[genes.index.isin(label_genes)], 50_000)
    near = res["peak"].isin(set(pr["peak"])).to_numpy()
    w_ex = np.where(near, 0, pub)
    rows_out.append({"block": "B features", **test(ZH, IH, w_ex, "axis without peaks near label-defining RNA genes",
                                                    rnd=rand_axes(w_ex))})
    for cl in ("distal", "promoter"):
        w_c = np.where(res["class"].to_numpy() == cl, pub, 0)
        rows_out.append({"block": "B features", **test(ZH, IH, w_c, f"{cl} axis peaks only", rnd=rand_axes(w_c))})
    for sgn, lab in ((1, "open peaks only"), (-1, "closed peaks only")):
        w_s = np.where(pub == sgn, pub, 0)
        rows_out.append({"block": "B features", **test(ZH, IH, w_s, lab, rnd=rand_axes(w_s))})
    halves = []
    mb = IH[["plaque"] + BASE].notna().all(1).to_numpy()
    Cb = _covar_matrix(IH[mb], BASE)
    xb = _resid(IH.loc[mb, "plaque"].to_numpy(float), Cb)
    ax_idx = np.flatnonzero(pub != 0)
    for _ in range(200):
        h = rng.choice(ax_idx, len(ax_idx) // 2, replace=False)
        w_h = np.zeros(len(pub))
        w_h[h] = pub[h]
        halves.append(np.corrcoef(xb, _resid(score(ZH[mb], w_h), Cb))[0, 1])
    halves = np.array(halves)
    pd.Series(halves).to_csv(OUT / "random_halves_r.csv", index=False)
    print(f"B. random halves of the axis: r median {np.median(halves):.2f} (5-95% {np.percentile(halves, 5):.2f}-"
          f"{np.percentile(halves, 95):.2f}); r > 0 in {(halves > 0).mean():.0%}")
    # genome-wide concordance in held-out donors
    mh = mb & held
    Ch = _covar_matrix(IH[mh], BASE)
    xh = _resid(IH.loc[mh, "plaque"].to_numpy(float), Ch)
    Yh = ZH[mh] - Ch @ np.linalg.lstsq(Ch, ZH[mh], rcond=None)[0]
    def peak_r(x):
        xs = (x - x.mean()) / x.std()
        Ys = (Yh - Yh.mean(0)) / np.where(Yh.std(0) > 0, Yh.std(0), 1)
        return xs @ Ys / len(x)
    pr_obs = peak_r(xh)
    rho = stats.spearmanr(pr_obs, t_full).statistic
    nulls = np.array([stats.spearmanr(peak_r(rng.permutation(xh)), t_full).statistic for _ in range(1000)])
    top = pr_obs >= np.quantile(pr_obs, 0.99)
    bot = pr_obs <= np.quantile(pr_obs, 0.01)
    gw = {"held_out_donors": int(mh.sum()), "spearman_peak_plaque_r_vs_dam_t": rho, "null_mean": nulls.mean(),
          "null_sd": nulls.std(), "p_perm": (np.sum(np.abs(nulls) >= abs(rho)) + 1) / 1001,
          "top1pct_plaque_peaks_frac_dam_open": (pub[top] == 1).mean(), "bottom1pct_frac_dam_closed": (pub[bot] == -1).mean(),
          "base_frac_open": (pub == 1).mean(), "base_frac_closed": (pub == -1).mean()}
    pd.Series(gw).to_csv(OUT / "genome_wide_concordance.csv")
    pd.DataFrame({"peak": res["peak"], "plaque_r_heldout": pr_obs, "dam_t": t_full}).to_csv(OUT / "peak_plaque_r.csv.gz", index=False)
    print("B. genome-wide (threshold-free) concordance in held-out donors:", {k: round(v, 4) for k, v in gw.items()})

    # ---- C state continuum
    units, Ls = [], []
    for st in (HOM, MID, DAM):
        L_, I_ = state_matrix([st], 10)
        Ls.append(L_)
        units.append(I_.assign(state=st))
    U = pd.concat(units, ignore_index=True)
    LU = np.vstack(Ls)
    ZU = np.empty_like(LU)
    for st in (HOM, MID, DAM):                       # z within state, so the fixed effect is not doing the work
        k = (U["state"] == st).to_numpy()
        ZU[k] = (LU[k] - LU[k].mean(0)) / np.where(LU[k].std(0) > 0, LU[k].std(0), 1)
    for st in (HOM, MID, DAM):
        k = (U["state"] == st).to_numpy()
        rows_out.append({"block": "C continuum", **test(ZU[k], U[k].reset_index(drop=True), pub, f"{st} only (>= 10 nuclei)",
                                                         rnd=R_pub)})
    rows_out.append({"block": "C continuum", **test(ZU, U, pub, "three states pooled, state fixed effect",
                                                     cov=BASE + ["state"], rnd=R_pub)})
    Lc, Ic = state_matrix([HOM, MID], 30)
    Zc = (Lc - Lc.mean(0)) / np.where(Lc.std(0) > 0, Lc.std(0), 1)
    rows_out.append({"block": "C continuum", **test(Zc, Ic, pub, "coarsened label (Micro-PVM_2 + 2_3)", rnd=R_pub)})
    # within-donor contrast: DAM-like minus homeostatic axis score
    sc = pd.DataFrame({"donor": U["donor"], "state": U["state"], "s": score(LU, pub)})
    wide = sc.pivot_table(index="donor", columns="state", values="s")
    ctr = (wide[DAM] - wide[HOM]).dropna()
    Ict = IH.set_index("donor").reindex(ctr.index).reset_index()
    mk = Ict[["plaque"] + BASE].notna().all(1).to_numpy()
    Cc = _covar_matrix(Ict[mk], BASE)
    rc = np.corrcoef(_resid(Ict.loc[mk, "plaque"].to_numpy(float), Cc), _resid(ctr.to_numpy()[mk], Cc))[0, 1]
    nl = np.array([np.corrcoef(rng.permutation(_resid(Ict.loc[mk, "plaque"].to_numpy(float), Cc)),
                               _resid(ctr.to_numpy()[mk], Cc))[0, 1] for _ in range(5000)])
    rows_out.append({"block": "C continuum", "test": "within-donor contrast DAM-like minus homeostatic",
                     "n_units": int(mk.sum()), "n_donors": int(mk.sum()), "r": rc,
                     "p_perm": (np.sum(np.abs(nl) >= abs(rc)) + 1) / 5001})

    T = pd.DataFrame(rows_out)
    T.to_csv(OUT / "selection_ci_features_continuum.csv", index=False)
    pd.set_option("display.width", 250)
    print(T.drop(columns=["n_open", "n_closed"]).to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
