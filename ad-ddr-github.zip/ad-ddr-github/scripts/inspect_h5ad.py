"""Print structure of SEA-AD h5ad files (backed mode, no full load)."""
import sys
import anndata as ad

for path in sys.argv[1:]:
    a = ad.read_h5ad(path, backed="r")
    print(f"\n### {path}\n{a}")
    print("X dtype:", a.X.dtype if hasattr(a.X, "dtype") else type(a.X))
    print("obs_names head:", list(a.obs_names[:3]))
    print("var head:\n", a.var.head(3))
    for c in a.obs.columns:
        s = a.obs[c]
        n = s.nunique()
        print(f"  {c!r:45} n={n:<6} e.g. {list(s.unique()[:4]) if n < 50 else s.iloc[0]}")
