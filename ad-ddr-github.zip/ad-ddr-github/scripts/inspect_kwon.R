# Print structure of the Kwon 2023 Visium-SPG AD SpatialExperiment.
suppressMessages(library(SpatialExperiment))
e <- new.env(); load(commandArgs(TRUE)[1], envir = e)
cat("objects:", ls(e), "\n")
spe <- get(ls(e)[1], envir = e)
print(spe)
cd <- as.data.frame(colData(spe))
str(cd, list.len = 200)
for (c in names(cd)) if (length(unique(cd[[c]])) < 40) { cat("\n#", c, "\n"); print(table(cd[[c]], useNA = "ifany")) }
print(head(spatialCoords(spe)))
