# Print structure of the Miyoshi 2024 human Visium Seurat object.
suppressMessages(library(SeuratObject))
args <- commandArgs(TRUE)
t0 <- Sys.time()
s <- readRDS(args[1])
cat("read in", format(Sys.time() - t0), "\n")
print(s)
cat("assays:", names(s@assays), "\n")
for (a in names(s@assays)) { x <- s@assays[[a]]; cat(a, class(x), "\n"); print(slotNames(x)); if (inherits(x, "Assay5")) print(names(x@layers)) }
cat("images:", length(s@images), head(names(s@images)), "\n")
md <- s@meta.data
cat(nrow(md), "spots\n"); str(md, list.len = 200)
for (c in names(md)) if (length(unique(md[[c]])) < 60) { cat("\n#", c, "\n"); print(table(md[[c]], useNA = "ifany")) }

