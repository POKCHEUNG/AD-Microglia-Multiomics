"""Figure and tables for the DAM-specific chromatin peaks (results/dam_peaks -> docs/).

    python scripts/make_dam_figure.py
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
R, DOCS = ROOT / "results/dam_peaks", ROOT / "docs"
COL = {"DAM-open": "#2a78d6", "DAM-closed": "#eb6834", "ns": "#c9c8c3"}   # categorical slots 1-2, neutral
INK, MUTED = "#0b0b0b", "#52514e"


def style(ax):
    ax.tick_params(labelsize=8, colors=MUTED, length=0)
    ax.grid(color="#ecebe8", lw=0.6)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


def main():
    res = pd.read_csv(R / "dam_peaks_all.csv.gz")
    pairs = pd.read_csv(R / "peak_rna_pairs.csv.gz")
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))

    ax = axes[0]
    y = -np.log10(np.maximum(res["p"], 1e-12))
    for call in ("ns", "DAM-closed", "DAM-open"):
        d = res["call"] == call
        ax.scatter(res.loc[d, "log2fc"], y[d], s=6 if call == "ns" else 16, color=COL[call], lw=0,
                   label=f"{call} ({d.sum()})" if call != "ns" else f"not differential ({d.sum():,})", zorder=2 if call != "ns" else 1)
    label = res[(res["call"] == "DAM-open") & res["nearest_gene"].isin(["CD9", "VIM-AS1", "RGCC", "HBEGF", "ANXA2"])]
    for _, r in label.iterrows():
        ax.annotate(r["nearest_gene"], (r["log2fc"], -np.log10(r["p"])), xytext=(4, 2), textcoords="offset points",
                    fontsize=7, color=INK)
    ax.set_xlabel("log2 fold change, DAM-like vs homeostatic microglia (within donor)", fontsize=8, color=MUTED)
    ax.set_ylabel("-log10 p (paired t)", fontsize=8, color=MUTED)
    ax.set_title(f"SEA-AD MTG snATAC: {res['peak'].size:,} peaks, 23 donors", fontsize=9, loc="left", color=INK)
    ax.legend(frameon=False, fontsize=7, loc="upper left")
    style(ax)

    ax = axes[1]
    for call in ("ns", "DAM-closed", "DAM-open"):
        x = pairs.loc[pairs["call"] == call].drop_duplicates("nearest_gene")["rna_log2fc"].dropna().clip(-1.5, 1.5)
        xs = np.sort(x)
        ax.plot(xs, np.arange(1, len(xs) + 1) / len(xs), color=COL[call] if call != "ns" else MUTED, lw=2,
                label=f"{'genes near ' + call + ' peaks' if call != 'ns' else 'genes near other peaks'} "
                      f"(n = {len(xs)}, median {np.median(xs):+.2f})")
    ax.axvline(0, color=MUTED, lw=0.6)
    ax.set_xlabel("RNA log2 fold change, DAM-like vs homeostatic (66 donors; clipped at ±1.5)", fontsize=8, color=MUTED)
    ax.set_ylabel("cumulative fraction of genes", fontsize=8, color=MUTED)
    ax.set_title("Independent check: nearby genes move the same way in RNA", fontsize=9, loc="left", color=INK)
    ax.legend(frameon=False, fontsize=7, loc="lower right")
    style(ax)
    fig.tight_layout()
    fig.savefig(DOCS / "dam_peaks.png", dpi=160)
    plt.close(fig)

    cols = ["peak", "chrom", "start", "end", "nearest_gene", "dist_tss", "class", "log2fc", "t", "p", "q", "q_bh",
            "frac_donors_up", "cpm_dam", "cpm_hom", "log2fc_10xMulti", "log2fc_10xATAC_v1.1"]
    sig = res[res["call"] != "ns"].sort_values(["call", "p"])
    mouse = pd.read_csv(R / "dam_peaks_sig_with_mouse.csv").set_index("peak")[["mm_chrom", "mm_pos", "mm_delta"]]
    sig = sig[cols + ["call"]].join(mouse, on="peak")
    sig.round(4).to_csv(DOCS / "dam_peaks_significant.csv", index=False)
    for f in ("validation_rna.csv", "validation_pathology.csv", "validation_mouse.csv"):
        pd.read_csv(R / f).round(4).to_csv(DOCS / f"dam_peaks_{f}", index=False)
    m = pd.read_csv(R / "motif_enrichment.csv")
    m.groupby("set").head(25).round(4).to_csv(DOCS / "dam_peaks_motifs_top.csv", index=False)
    print("wrote docs/dam_peaks.png and tables")


def regulatory_figure():
    G = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz")
    named = pd.read_csv(ROOT / "results/dam_regulatory/named_genes.csv", index_col=0)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.6), gridspec_kw={"width_ratios": [1, 1.1]})
    ax = axes[0]
    expr = G[G["rna_expressed"].astype("boolean").fillna(False).astype(bool)]
    up, dn = expr.nlargest(200, "rna_t"), expr.nsmallest(200, "rna_t")
    for lab, d, c in (("all gene domains", G, MUTED), ("RNA DAM-down top 200", dn, COL["DAM-closed"]),
                      ("RNA DAM-up top 200", up, COL["DAM-open"])):
        xs = np.sort(d["t"].clip(-8, 8).to_numpy())
        ax.plot(xs, np.arange(1, len(xs) + 1) / len(xs), color=c, lw=2, label=f"{lab} (median t {np.median(xs):+.2f})")
    ax.axvline(0, color=MUTED, lw=0.6)
    ax.set_xlabel("chromatin t, gene regulatory domain (TSS +/- 50 kb), DAM-like vs homeostatic", fontsize=8, color=MUTED)
    ax.set_ylabel("cumulative fraction of genes", fontsize=8, color=MUTED)
    ax.set_title("Genes changed in RNA have their whole regulatory domain\nopened or closed (23 donors)", fontsize=9,
                 loc="left", color=INK)
    ax.legend(frameon=False, fontsize=7, loc="lower right")
    style(ax)

    ax = axes[1]
    d = named.dropna(subset=["t"]).sort_values("t")
    y = np.arange(len(d))
    sig = d["q"] < 0.05
    cols = np.where(d["t"] > 0, COL["DAM-open"], COL["DAM-closed"])
    ax.scatter(d["t"], y, s=40, c=np.where(sig, cols, "white"), edgecolors=cols, linewidths=1.5, zorder=3)
    ax.axvline(0, color=MUTED, lw=0.6)
    for yi, (g, r) in zip(y, d.iterrows()):
        m = r["mm_delta"]
        ax.annotate(f"mouse {'+' if m > 0 else '-'}{int(max(r['mm_reps_up'], r['mm_reps_down']))}/3",
                    (8.2, yi), fontsize=6.5, color=MUTED, va="center", annotation_clip=False)
    ax.set_yticks(y, d.index, fontsize=7.5)
    ax.set_xlim(-8, 8)
    ax.set_xlabel("chromatin t of the regulatory domain (filled: q < 0.05)", fontsize=8, color=MUTED)
    ax.set_title("Named genes; right: direction in 5xFAD PAM vs CD11c- (replicates)", fontsize=9, loc="left", color=INK)
    style(ax)
    fig.tight_layout()
    fig.savefig(DOCS / "dam_regulatory.png", dpi=160)
    plt.close(fig)
    for f in ("set_tests.csv", "named_genes.csv", "conserved_gene_domains.csv", "anchored_peaks.csv"):
        pd.read_csv(ROOT / "results/dam_regulatory" / f).round(4).to_csv(DOCS / f"dam_regulatory_{f}", index=False)


if __name__ == "__main__":
    main()
    regulatory_figure()
