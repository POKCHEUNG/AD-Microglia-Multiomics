"""Main figures for the manuscript, Nature layout (183 mm double column, Arial, 7 pt).

    python scripts/make_paper_figures.py            # writes docs/figures/Fig{1..6}.pdf and .png

Palette (NPG-derived, checked for deutan / protan / tritan separation, OKLab dE >= 11 for all
pairs used together; the teal-red pair is also separated by marker shape):
    up / opened / rises with pathology   #E64B35
    down / closed                        #3C5488
    positive control                     #00A087 (square markers)
    random-set null (95% range)          #DDDDDD, null mean #7F7F7F
Cohorts: SEA-AD navy circles, PsychAD red triangles, hippocampus multiome teal squares.
All numbers are read from results/; nothing is recomputed except the SEA-AD per-gene
cohesin correlations (cached in results/paper_figures/).
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "results"
OUT = ROOT / "docs/figures"
OUT.mkdir(parents=True, exist_ok=True)
CACHE = R / "paper_figures"
CACHE.mkdir(parents=True, exist_ok=True)

UP, DOWN, CTRL = "#E64B35", "#3C5488", "#00A087"
NULL, NULLMEAN, INK, MUTED, GRID = "#DDDDDD", "#7F7F7F", "#1A1A1A", "#555555", "#EEEEEE"
COHORT = {"SEA-AD": (DOWN, "o"), "PsychAD": (UP, "^"), "Hippocampus": (CTRL, "s")}
DIV = LinearSegmentedColormap.from_list("npg_div", [DOWN, "#F2F2F2", UP])
MM = 1 / 25.4
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
LABEL = {"p53_targets": "p53 targets", "cGAS_STING_IFN": "cGAS-STING-IFN"}


def setup():
    for f in Path("/System/Library/Fonts/Supplemental").glob("Arial*.ttf"):
        font_manager.fontManager.addfont(str(f))
    plt.rcParams.update({
        "font.family": "Arial", "font.size": 7, "axes.titlesize": 7, "axes.labelsize": 7, "xtick.labelsize": 6,
        "ytick.labelsize": 6, "legend.fontsize": 6, "axes.linewidth": 0.5, "xtick.major.width": 0.5,
        "ytick.major.width": 0.5, "xtick.major.size": 2, "ytick.major.size": 2, "lines.linewidth": 0.8,
        "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42, "ps.fonttype": 42,
        "axes.edgecolor": INK, "axes.labelcolor": INK, "xtick.color": INK, "ytick.color": INK, "text.color": INK,
        "legend.frameon": False, "savefig.dpi": 300})


_LETTERS: list = []


def letter(ax, s, **_):
    """Panel letter, placed after layout at the top-left of the panel's tight bounding box."""
    _LETTERS.append((ax, s))


def new_fig(w_mm, h_mm):
    setup()                       # re-apply: imported project modules change rcParams
    _LETTERS.clear()
    return plt.figure(figsize=(w_mm * MM, h_mm * MM), layout="constrained")


def save(fig, name):
    if fig.get_layout_engine() is not None:
        fig.get_layout_engine().set(w_pad=2 * MM, h_pad=2 * MM, wspace=0.04, hspace=0.06)
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    inv = fig.transFigure.inverted()
    fig.set_layout_engine("none")
    for ax, s in _LETTERS:
        bb = ax.get_tightbbox(r).transformed(inv)
        fig.text(max(bb.x0, 0.002), min(bb.y1 + 0.005, 0.995), s, fontsize=8, fontweight="bold", va="top", ha="left")
    fig.savefig(OUT / f"{name}.pdf")
    fig.savefig(OUT / f"{name}.png", dpi=300)
    plt.close(fig)
    print("wrote", name)


def nullband(ax, y, lo, hi, mean=None, h=0.6, horizontal=True):
    if horizontal:
        ax.barh(y, np.asarray(hi) - np.asarray(lo), left=lo, height=h, color=NULL, lw=0, zorder=1)
        if mean is not None:
            y = np.asarray(y, float)
            mean = np.broadcast_to(np.asarray(mean, float), y.shape)
            ax.vlines(mean, y - h / 2, y + h / 2, color=NULLMEAN, lw=0.6, zorder=2)


def dots(ax, x, y, sig, color, marker="o", s=14):
    sig = np.asarray(sig, bool)
    ax.scatter(np.asarray(x)[sig], np.asarray(y)[sig], s=s, marker=marker, color=color, lw=0, zorder=3)
    ax.scatter(np.asarray(x)[~sig], np.asarray(y)[~sig], s=s, marker=marker, facecolor="white", edgecolor=color,
               lw=0.7, zorder=3)


# ---------------------------------------------------------------- Figure 1
def fig1():
    setup()
    _LETTERS.clear()
    W, Hh, H2 = 183, 62, 64                     # schematic (a-c) on top, the core question (d-f) below
    fig = plt.figure(figsize=(W * MM, (Hh + H2) * MM))
    ax = fig.add_axes([0, H2 / (Hh + H2), 1, Hh / (Hh + H2)])
    ax.set_xlim(0, W)
    ax.set_ylim(0, Hh)
    ax.axis("off")

    def box(x, y, w, h, title, lines, color):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.5", fc="white", ec=color, lw=0.8))
        ax.text(x + 2, y + h - 2, title, fontsize=7, fontweight="bold", color=color, va="top")
        for i, ln in enumerate(lines):
            ax.text(x + 2, y + h - 6.5 - i * 3.4, ln, fontsize=6, va="top")

    ax.text(2, 60, "a", fontsize=8, fontweight="bold", va="top")
    box(6, 33, 55, 26, "Discovery: SEA-AD", ["snRNA pseudobulks: 84 donors, 10 regions",
        "MTG snATAC: 86 donors (subclass and", "microglial supertype)", "Layer-resolved pathology (AT8, 6E10, NeuN)"], DOWN)
    box(65, 33, 55, 26, "Spatial and mouse", ["Human GeoMx: microglia by plaque zone",
        "Human Visium with Aβ / pTau", "Mouse Stereo-seq: 25 µm bins,", "re-registered plaque masks",
        "5xFAD CD11c+ vs CD11c– microglia ATAC"], MUTED)
    box(124, 33, 55, 26, "Independent replication", ["PsychAD snRNA: ~410 donors (DLPFC)",
        "Hippocampus multiome: 22 donors", "(RNA + ATAC in the same nuclei)", "AD GWAS (Bellenguez 2022)"], CTRL)

    ax.text(2, 28, "b", fontsize=8, fontweight="bold", va="top")
    ax.text(7, 28, "Scales tested (coarse to fine)", fontsize=7, fontweight="bold", va="top")
    scales = ["donor × cell type", "cortical layer\n(100s of µm)", "plaque zone\n(GeoMx AOI)", "25 µm bin", "single nucleus\n(multiome)"]
    xs = np.linspace(14, 106, len(scales))
    ax.annotate("", xy=(114, 16), xytext=(9, 16), arrowprops=dict(arrowstyle="-|>", lw=0.6, color=MUTED))
    for i, (x, s) in enumerate(zip(xs, scales)):
        ax.add_patch(plt.Circle((x, 16), 1.8, color=DOWN, alpha=0.25 + 0.17 * i, lw=0, zorder=3))
        ax.text(x, 12, s, fontsize=6, ha="center", va="top")

    ax.text(120, 28, "c", fontsize=8, fontweight="bold", va="top")
    ax.text(125, 28, "Inference used throughout", fontsize=7, fontweight="bold", va="top")
    rules = ["Donor is the unit (pseudobulk, permutation)", "Every set vs matched random sets",
             "  (expression, gene length, accessibility)", "Positive control at every scale",
             "Power reported for null results", "Fixed hypotheses in replication cohorts"]
    for i, s in enumerate(rules):
        if not s.startswith("  "):
            ax.text(125, 22.6 - i * 3.6, "•", fontsize=7, color=CTRL, va="top")
        ax.text(128, 22.6 - i * 3.6, s.strip(), fontsize=6, va="top")
    fig1_core(fig, W, Hh + H2)
    save(fig, "Fig1")


CLASS_COLOR = {"excitatory": DOWN, "inhibitory": "#8491B4", "non-neuronal": UP}


def fig1_core(fig, W, H):
    """d-f: is the pathology-associated change shared by all cell types or concentrated in some (README 43)?"""
    G = R / "global_specific"
    SF = pd.read_csv(G / "shared_fraction.csv")
    SF = SF[SF["others"] == "all"]
    SC = pd.read_csv(G / "specific_counts.csv")
    SC = SC[SC["others"] == "all"]
    PR = pd.read_csv(G / "programs_vs_shared.csv")
    from global_vs_specific import cell_class
    from matplotlib.patches import Patch
    setup()                                     # the import resets rcParams
    order = (SC[SC["modality"] == "RNA"].assign(c=lambda d: d["unit"].map(cell_class))
             .sort_values(["c", "frac_specific"], ascending=[True, True])["unit"].tolist())
    order = sorted(order, key=lambda u: ["excitatory", "inhibitory", "non-neuronal"].index(cell_class(u)))
    short = {"VLMC & Perivascular": "VLMC", "Microglia-PVM": "Microglia", "Oligodendrocyte": "Oligo", "Astrocyte": "Astro"}

    def rect(x, y, w, h):
        return [x / W, y / H, w / W, h / H]

    # d: shared fraction
    ax = fig.add_axes(rect(12, 16, 52, 42))
    for mod, mk, fill in (("RNA", "o", True), ("ATAC", "s", False)):
        d = SF[SF["modality"] == mod].set_index("unit").reindex(order)
        x = np.arange(len(order)) + (-0.15 if mod == "RNA" else 0.15)
        for xi, (u, v) in zip(x, d["shared_fraction"].items()):
            if np.isfinite(v):
                c = CLASS_COLOR[cell_class(u)]
                ax.scatter(xi, v, s=12, marker=mk, color=c if fill else "white", edgecolor=c, lw=0.7, zorder=3)
    ax.set_xticks(range(len(order)), [short.get(u, u) for u in order], rotation=90, fontsize=5)
    ax.set_ylim(0, 0.5)
    ax.set_ylabel("Shared fraction of the\nreproducible CPS profile")
    ax.scatter([], [], s=12, marker="o", color=INK, label="RNA")
    ax.scatter([], [], s=12, marker="s", facecolor="white", edgecolor=INK, label="ATAC")
    ax.legend(loc="upper left", ncol=2, handletextpad=0.2, columnspacing=0.8)
    fig.text(1 / W, 63 / H, "d", fontsize=8, fontweight="bold", va="top")

    # e: specific features, observed / expected
    ax = fig.add_axes(rect(76, 16, 52, 42))
    for mod, off, fill in (("RNA", -0.2, True), ("ATAC", 0.2, False)):
        d = SC[SC["modality"] == mod].set_index("unit").reindex(order)
        ratio = d["n_specific"] / d["expected_false"]
        for i, (u, v) in enumerate(ratio.items()):
            if np.isfinite(v):
                c = CLASS_COLOR[cell_class(u)]
                ax.bar(i + off, v, width=0.38, color=c if fill else "white", edgecolor=c, lw=0.6, zorder=2)
    ax.axhline(1, color=NULLMEAN, lw=0.6, ls="--", zorder=1)
    ax.set_yscale("log")
    ax.set_ylim(0.1, 10)
    ax.set_xticks(range(len(order)), [short.get(u, u) for u in order], rotation=90, fontsize=5)
    ax.set_ylabel("Cell-type-specific features\n(observed / expected by chance)")
    ax.legend(handles=[Patch(color=INK, label="RNA genes"), Patch(fc="white", ec=INK, lw=0.6, label="ATAC peaks")],
              loc="upper left", ncol=2, handletextpad=0.3, columnspacing=0.8)
    fig.text(66 / W, 63 / H, "e", fontsize=8, fontweight="bold", va="top")

    # f: programs, observed vs predicted from the other cell types
    ax = fig.add_axes(rect(140, 16, 40, 42))
    lim = (-0.3, 0.6)
    ax.plot(lim, lim, color=NULLMEAN, lw=0.5, ls="--", zorder=1)
    d = PR[PR["family"] == "DDR"]
    ax.scatter(d["r_predicted_from_others"], d["r_observed"], s=5, color=NULL, edgecolor=NULLMEAN, lw=0.3, zorder=2,
               label="DDR programs")
    for fam, c, mk in (("cohesin", CTRL, "s"), ("DAM", UP, "o")):
        d = PR[PR["family"] == fam]
        ax.scatter(d["r_predicted_from_others"], d["r_observed"], s=10, marker=mk, color=c, lw=0, zorder=3,
                   label="cohesin loading" if fam == "cohesin" else "DAM genes")
    m = PR[(PR["family"] == "DAM") & (PR["cell"] == "Microglia-PVM")].iloc[0]
    ax.annotate("microglia", (m["r_predicted_from_others"], m["r_observed"]), xytext=(-24, 3), textcoords="offset points",
                fontsize=5.5, color=UP)
    ax.set_xlim(-0.1, 0.35)
    ax.set_ylim(*lim)
    ax.set_xlabel("r predicted from other cell types")
    ax.set_ylabel("Program r with CPS (observed)")
    ax.legend(loc="lower right", handletextpad=0.2, borderaxespad=0.1)
    fig.text(131 / W, 63 / H, "f", fontsize=8, fontweight="bold", va="top")
    fig.text(12 / W, 1.5 / H, "Cell class:  ", fontsize=6, va="bottom")
    x0 = 25
    for lab, c in CLASS_COLOR.items():
        fig.patches.append(FancyBboxPatch(((x0) / W, 2 / H), 2.5 / W, 2.5 / H, boxstyle="square,pad=0", fc=c, ec="none",
                                          transform=fig.transFigure))
        fig.text((x0 + 3.5) / W, 1.5 / H, lab, fontsize=6, va="bottom")
        x0 += 22


# ---------------------------------------------------------------- Figure 2
def fig2():
    from ad_ddr.plotting import _order
    fig = new_fig(183, 125)
    gs = fig.add_gridspec(2, 4, height_ratios=[1.15, 1])

    # a heatmap
    ax = fig.add_subplot(gs[0, :3])
    m = pd.read_csv(R / "screen/screen_MTG.csv")
    d = m[m["family"] == "DDR"]
    ex = d.pivot(index="program", columns="group", values="r_excess").reindex(DDR)
    ps = d.pivot(index="program", columns="group", values="p_set").reindex(DDR)
    order = _order(ex.columns)
    ex, ps = ex[order], ps[order]
    cm = DIV.copy()
    cm.set_bad(NULL)
    im = ax.imshow(np.ma.masked_invalid(ex.to_numpy(float)), cmap=cm, vmin=-0.5, vmax=0.5, aspect="auto")
    for i in range(ex.shape[0]):
        for j in range(ex.shape[1]):
            if ps.iat[i, j] < 0.05:
                ax.text(j, i + 0.15, "•", ha="center", va="center", fontsize=6, color=INK)
    ax.set_xticks(range(len(order)), order, rotation=60, ha="right", fontsize=5.5)
    ax.set_yticks(range(len(DDR)), [LABEL.get(p, p) for p in DDR], fontsize=6)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    allr = pd.read_csv(R / "screen/screen_all.csv")
    nq = int(((allr["family"] == "DDR") & (allr["q_perm_region"] < 0.1)).sum())
    ax.set_title(f"SEA-AD MTG, DDR programs vs CPS: r minus matched random sets\n"
                 f"• p_set < 0.05;  tests at q < 0.1 across 9 regions: {nq} of {int((allr.family == 'DDR').sum()):,}", loc="left")
    cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.01)
    cb.set_label("excess r", fontsize=6)
    cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=5.5)
    letter(ax, "a", dx=-0.07)

    # b PsychAD neurons DDR vs random
    ax = fig.add_subplot(gs[0, 3])
    p = pd.read_csv(R / "psychad_neurons/ddr_neurons.csv")
    p = p[(p["model"] == "primary") & (p["cells"] == "EN")].set_index("program")
    progs = [x for x in ["NHEJ", "BER", "NER", "Checkpoint", "p53_targets"] if x in p.index]
    y = np.arange(len(progs))[::-1]
    pp = p.loc[progs]
    nullband(ax, y, pp["random_mean_r"] - 1.96 * pp["random_sd_r"], pp["random_mean_r"] + 1.96 * pp["random_sd_r"], pp["random_mean_r"])
    dots(ax, pp["r"], y, pp["p_vs_random"] < 0.05, DOWN)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, [LABEL.get(x, x) for x in progs])
    ax.set_xlabel("partial r with AD")
    ax.set_title(f"PsychAD Exc\n({int(pp['n_donors'].iloc[0])} donors)", loc="left")
    letter(ax, "b", dx=-0.45)

    # c GeoMx P vs PP
    ax = fig.add_subplot(gs[1, 0])
    z = pd.read_csv(R / "spatial_geomx/zone_effects.csv")
    z = z[z["contrast"] == "P_vs_PP"].set_index("program").reindex(DDR + ["DAM"])
    y = np.arange(len(z))[::-1]
    nullband(ax, y, z["null_lo"], z["null_hi"], z["null_mean"])
    isc = z.index == "DAM"
    dots(ax, z["beta_sd"][~isc], y[~isc], z["p_set"][~isc] < 0.05, DOWN)
    dots(ax, z["beta_sd"][isc], y[isc], z["p_set"][isc] < 0.05, CTRL, "s")
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, [LABEL.get(x, x) for x in z.index])
    ax.set_xlabel("effect (SD)")
    ax.set_title("Human GeoMx:\ncontact vs periplaque", loc="left")
    ax.set_xlim(-0.35, 0.7)
    letter(ax, "c", dx=-0.75)

    # d Stereo-seq
    ax = fig.add_subplot(gs[1, 1])
    st = pd.read_csv(R / "stereoseq_plaque/pooled_effects.csv")
    st = st[(st["group"] == "AD_18M") & (st["estimand"] == "total")].set_index("set").reindex(DDR + ["Trem2_Cd68"])
    y = np.arange(len(st))[::-1]
    isc = st.index == "Trem2_Cd68"
    lr = np.log2(st["rr"])
    dots(ax, lr[~isc], y[~isc], st["p_set"][~isc] < 0.05, DOWN)
    dots(ax, lr[isc], y[isc], st["p_set"][isc] < 0.05, CTRL, "s")
    ax.axvspan(-np.log2(1.1), np.log2(1.1), color=NULL, lw=0, zorder=0)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, [LABEL.get(x, x) if x != "Trem2_Cd68" else "Trem2 + Cd68" for x in st.index])
    ax.set_xlabel("log2 RR, ≤25 vs 100–300 µm")
    ax.set_title("Mouse, 25 µm bins\n(grey: ±10%)", loc="left")
    letter(ax, "d", dx=-0.75)

    # e laminar mismatch
    ax = fig.add_subplot(gs[1, 2])
    lam = pd.read_csv(R / "laminar/laminar.csv")
    lam = lam[(lam["measure"] == "mismatch") & (lam["pathology"] == "AT8")].set_index("program").reindex(DDR).dropna(subset=["beta"])
    y = np.arange(len(lam))[::-1]
    half = 1.96 * lam["perm_sd"]
    nullband(ax, y, -half, half, 0)
    dots(ax, lam["beta"], y, lam["p_perm"] < 0.05, DOWN)
    ax.set_yticks(y, [LABEL.get(x, x) for x in lam.index])
    ax.set_xlabel("β per SD own-layer AT8")
    ax.set_title("Mismatch vs\nlayer-local tau", loc="left")
    letter(ax, "e", dx=-0.75)

    # f positive control coupled
    ax = fig.add_subplot(gs[1, 3])
    don = pd.read_csv(R / "laminar/donor_level.csv")
    dm = don[(don["group"] == "Microglia-PVM") & (don["program"] == "DAM") & (don["pathology"] == "6E10")].set_index("measure")
    lab = ["rna", "atac", "mismatch"]
    y = np.arange(3)[::-1]
    ax.vlines(dm.loc[lab, "null_mean"], y - 0.3, y + 0.3, color=NULLMEAN, lw=0.6, zorder=2)
    dots(ax, dm.loc[lab, "r"], y, dm.loc[lab, "p_set"] < 0.05, CTRL, "s")
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, ["DAM RNA", "DAM ATAC", "mismatch"])
    ax.set_xlabel("partial r with 6E10")
    ax.set_xlim(-0.1, 0.5)
    ax.set_title("Control: DAM,\ncoupled", loc="left")
    letter(ax, "f", dx=-0.75)
    fig.get_layout_engine().set(rect=(0, 0.03, 1, 0.97))
    fig.text(0.01, 0.005, "Filled: p < 0.05 vs matched random sets (b, c, d, f) or permutation (e); open: not significant. "
             "Grey bars: 95% of the null; ticks: null mean.", fontsize=5.5, color=MUTED)
    save(fig, "Fig2")


# ---------------------------------------------------------------- Figure 3
def seaad_cohesin_genes():
    f = CACHE / "seaad_cohesin_genes.csv"
    if f.exists():
        return pd.read_csv(f)
    from ad_ddr import cohort
    from ad_ddr.stats import _covar_matrix, _resid
    import run_published_sets as pubs
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")[["Donor ID", "Brain Region", "CPS_Local"]]
    cps.columns = ["donor", "region", "cps"]
    rows = []
    genes_q = ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2", "NIPBL", "PDS5A", "PDS5B", "WAPL", "CTCF"]
    for grp, files, level in [(cohort.EXC, pubs.EXC_FILES[:9], "class"), ("Oligodendrocyte", ["Oligodendrocyte"], "group")]:
        idx, C, genes, meta = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{x}.h5ad" for x in files], regions=["MTG"])
        meta = meta.assign(age=pd.to_numeric(meta.age, errors="coerce"), pmi=pd.to_numeric(meta.pmi, errors="coerce"),
                           severe=meta.severe.astype(str).eq("Y"))
        idx = idx.merge(cps, on=["donor", "region"], how="left").join(meta[["age", "sex", "pmi", "severe"]], on="donor")
        k = ((idx.level == level) & (idx.group == grp) & (idx.n_nuclei >= 20) & ~idx.severe.astype(bool)
             & idx[["cps", "age", "pmi"]].notna().all(1)).to_numpy()
        d = idx[k].reset_index(drop=True).assign(log_nuclei=lambda x: np.log10(x.n_nuclei))
        M = C[k]
        L = np.log2(M / M.sum(1, keepdims=True) * 1e6 + 1)
        Z = _covar_matrix(d, ["age", "sex", "pmi", "log_nuclei"])
        xr = _resid(d.cps.to_numpy(float), Z)
        up = pd.Series(np.arange(len(genes)), index=genes.str.upper())
        for g in genes_q:
            if g in up:
                rows.append({"cells": "EN" if grp == cohort.EXC else "Oligo", "gene": g,
                             "r": np.corrcoef(xr, _resid(L[:, up[g]], Z))[0, 1]})
    out = pd.DataFrame(rows)
    out.to_csv(f, index=False)
    return out


def fig3():
    fig = new_fig(183, 68)
    gs = fig.add_gridspec(1, 3, width_ratios=[1.1, 1.5, 1.0])
    ps = pd.read_csv(R / "published_sets_lenmatched/published_sets.csv")
    # a published sets in MTG claimed cells
    ax = fig.add_subplot(gs[0, 0])
    d = ps[ps["claimed_here"] & (ps["region"] == "MTG") & (ps["contrast"] == "CPS")]
    keep = [("Mathys2023_cohesin", "Neuronal: Glutamatergic", "cohesin, Exc¹"),
            ("Mathys2023_cohesin", "Oligodendrocyte", "cohesin, Oligo¹"),
            ("Mathys2024_M22_core", "Microglia-PVM", "p53/DDR M22, Mic²"),
            ("Mathys2024_M22_all", "Microglia-PVM", "M22 all, Mic²"),
            ("Fancy2024_microglia_M8", "Microglia-PVM", "module 8, Mic³")]
    rows = [d[(d["program"] == a) & (d["cells"] == b)].iloc[0] for a, b, _ in keep]
    t = pd.DataFrame(rows)
    y = np.arange(len(t))[::-1]
    nullband(ax, y, t["null_mean"] - 1.96 * t["null_sd"], t["null_mean"] + 1.96 * t["null_sd"], t["null_mean"])
    isc = t["program"].str.contains("cohesin").to_numpy()
    dots(ax, t["r"][isc], y[isc], (t["p_set"] < 0.05)[isc], UP)
    dots(ax, t["r"][~isc], y[~isc], (t["p_set"] < 0.05)[~isc], DOWN)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, [x for *_, x in keep])
    ax.set_xlabel("partial r with CPS (SEA-AD MTG)")
    ax.set_title("Published sets, retested\n¹Mathys 2023 ²2024 ³Fancy 2024", loc="left")
    letter(ax, "a", dx=-1.1)

    # b per gene, two cohorts
    ax = fig.add_subplot(gs[0, 1])
    sg = seaad_cohesin_genes()
    pg = pd.read_csv(R / "cohesin_psychad/cohesin_psychad_genes.csv")
    genes = ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2", "NIPBL", "PDS5A", "PDS5B", "WAPL", "CTCF"]
    x = np.arange(len(genes))
    for k, (cells, off) in enumerate((("EN", -0.18), ("Oligo", 0.18))):
        a = sg[sg.cells == cells].set_index("gene").reindex(genes)["r"]
        b = pg[pg.cells == cells].set_index("gene").reindex(genes)["r"]
        ax.scatter(x + off - 0.05, a, s=14, marker="o", color=DOWN if cells == "EN" else "white",
                   edgecolor=DOWN, lw=0.7, zorder=3, label=f"SEA-AD {cells} (CPS, 73 donors)")
        ax.scatter(x + off + 0.05, b, s=14, marker="^", color=UP if cells == "EN" else "white",
                   edgecolor=UP, lw=0.7, zorder=3, label=f"PsychAD {cells} (AD vs ctrl, ~410)")
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.axvspan(-0.5, 4.5, color=GRID, lw=0, zorder=0)
    ax.axvspan(4.5, 7.5, color="#F7F7F7", lw=0, zorder=0)
    ax.text(2, 0.55, "core subunits", ha="center", fontsize=5.5, color=MUTED)
    ax.text(6, 0.55, "loaders", ha="center", fontsize=5.5, color=MUTED)
    ax.text(8.5, 0.55, "WAPL / CTCF", ha="center", fontsize=5.5, color=MUTED)
    ax.set_xticks(x, genes, rotation=45, ha="right")
    ax.set_ylim(-0.2, 0.6)
    ax.set_xlim(-0.5, len(genes) - 0.5)
    ax.set_ylabel("partial r")
    ax.legend(loc="upper center", ncol=2, fontsize=5, handletextpad=0.2, columnspacing=0.8, bbox_to_anchor=(0.5, -0.24))
    ax.set_title("Cohesin loading axis, per gene\n(filled: Exc; open: Oligo)", loc="left")
    letter(ax, "b", dx=-0.16)

    # c regions + independent cohort
    ax = fig.add_subplot(gs[0, 2])
    c = ps[(ps["program"] == "Mathys2023_cohesin") & (ps["contrast"] == "CPS") & ps["cells"].isin(["Neuronal: Glutamatergic", "Oligodendrocyte"])]
    cp = pd.read_csv(R / "cohesin_psychad/cohesin_psychad.csv").set_index("cells")
    for j, (cells, lab, pk) in enumerate((("Neuronal: Glutamatergic", "Exc", "EN"), ("Oligodendrocyte", "Oligo", "Oligo"))):
        v = c[c.cells == cells]["r"].to_numpy()
        jit = np.random.default_rng(j).uniform(-0.12, 0.12, len(v))
        ax.scatter(j * 2 + jit, v, s=10, marker="o", color=DOWN, lw=0, alpha=0.8, zorder=3)
        ax.scatter(j * 2 + 0.6, cp.loc[pk, "r"], s=22, marker="^", color=UP, lw=0, zorder=3)
        ax.vlines(j * 2 + 0.6, cp.loc[pk, "null_mean"] - 1.96 * cp.loc[pk, "null_sd"],
                  cp.loc[pk, "null_mean"] + 1.96 * cp.loc[pk, "null_sd"], color=NULL, lw=4, zorder=1)
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.set_xticks([0.3, 2.3], ["Exc", "Oligo"])
    ax.scatter([], [], s=10, marker="o", color=DOWN, label="SEA-AD, 9 regions")
    ax.scatter([], [], s=22, marker="^", color=UP, label="PsychAD")
    ax.legend(loc="upper left", fontsize=5, handletextpad=0.1)
    ax.set_ylim(-0.3, 0.8)
    ax.set_ylabel("cohesin set, partial r")
    ax.set_title("Regions and cohorts\n(grey: PsychAD null)", loc="left")
    letter(ax, "c", dx=-0.35)
    save(fig, "Fig3")


# ---------------------------------------------------------------- Figure 4
def fig4():
    fig = new_fig(183, 120)
    gs = fig.add_gridspec(2, 3, width_ratios=[1, 1, 1.15])
    res = pd.read_csv(R / "dam_peaks/dam_peaks_all.csv.gz")
    # a volcano
    ax = fig.add_subplot(gs[0, 0])
    yv = -np.log10(np.maximum(res["p"], 1e-12))
    for call, col, s in (("ns", NULL, 2), ("DAM-closed", DOWN, 7), ("DAM-open", UP, 7)):
        k = res["call"] == call
        ax.scatter(res.loc[k, "log2fc"], yv[k], s=s, color=col, lw=0, rasterized=True,
                   label=f"{call} ({k.sum()})" if call != "ns" else None)
    for _, r in res[(res["call"] == "DAM-open") & res["nearest_gene"].isin(["CD9", "ANXA2", "RGCC", "VIM-AS1"])].iterrows():
        ax.annotate(r["nearest_gene"].replace("-AS1", ""), (r["log2fc"], -np.log10(r["p"])), xytext=(3, -7) if r["nearest_gene"] == "VIM-AS1" else (3, 1),
                    textcoords="offset points", fontsize=5.5)
    ax.set_xlabel("log2FC, DAM-like vs homeostatic")
    ax.set_ylabel("-log10 p")
    ax.legend(loc="upper left", fontsize=5.5, handletextpad=0.1)
    ax.set_title("SEA-AD microglia snATAC\n(23 donors, within donor)", loc="left")
    letter(ax, "a", dx=-0.3)

    # b RNA concordance
    ax = fig.add_subplot(gs[0, 1])
    pr = pd.read_csv(R / "dam_peaks/peak_rna_pairs.csv.gz")
    for call, col in (("ns", NULLMEAN), ("DAM-closed", DOWN), ("DAM-open", UP)):
        v = np.sort(pr.loc[pr["call"] == call].drop_duplicates("nearest_gene")["rna_log2fc"].dropna().clip(-1.5, 1.5))
        ax.plot(v, np.arange(1, len(v) + 1) / len(v), color=col, lw=1,
                label={"ns": "other", "DAM-closed": "closed", "DAM-open": "open"}[call] + f" ({len(v)})")
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_xlabel("RNA log2FC of nearest gene (66 donors)")
    ax.set_ylabel("cumulative fraction")
    ax.legend(loc="upper left", fontsize=5.5)
    vr = pd.read_csv(R / "dam_peaks/validation_rna.csv")
    pv = vr.loc[(vr["peaks"] == "all") & (vr["call"] == "DAM-open"), "p_mwu"].iat[0]
    ax.set_title(f"Nearest genes move the same\nway in RNA (open: p = {pv:.0e})", loc="left")
    letter(ax, "b", dx=-0.3)

    # c gene domains, discovery + replication
    ax = fig.add_subplot(gs[0, 2])
    stt = pd.read_csv(R / "dam_regulatory/set_tests.csv").set_index("set")
    hp = pd.read_csv(R / "hippo_replication/dam_chromatin.csv").set_index("test")
    items = [("DAM-up genes (RNA)", "SEA-AD", stt.loc["RNA DAM-up top 200", "z"]),
             ("DAM-down genes (RNA)", "SEA-AD", stt.loc["RNA DAM-down top 200", "z"]),
             ("homeostatic genes", "SEA-AD", stt.loc["homeostatic", "z"]),
             ("opened domains", "Hippocampus", hp.loc["SEA-AD opened gene domains", "z"]),
             ("closed domains", "Hippocampus", hp.loc["SEA-AD closed gene domains", "z"]),
             ("DAM-open peaks", "Hippocampus", hp.loc["SEA-AD DAM-open peaks", "z"]),
             ("DAM-closed peaks", "Hippocampus", hp.loc["SEA-AD DAM-closed peaks", "z"])]
    y = np.arange(len(items))[::-1]
    for yi, (lab, coh, zz) in zip(y, items):
        col, mk = COHORT[coh]
        ax.barh(yi, zz, color=UP if zz > 0 else DOWN, height=0.55, lw=0)
        ax.scatter(zz, yi, marker=mk, s=12, color="white", edgecolor=col, lw=0.7, zorder=3)
    ax.axvspan(-1.96, 1.96, color=NULL, lw=0, zorder=0)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.axhline(3.5, color=MUTED, lw=0.3, ls=(0, (2, 2)))
    ax.set_yticks(y, [x[0] for x in items])
    ax.set_xlabel("z vs matched random sets")
    ax.text(0.99, 0.93, "SEA-AD", transform=ax.transAxes, ha="right", fontsize=5.5, color=DOWN)
    ax.text(0.99, 0.03, "hippocampus\n(21/21 donors)", transform=ax.transAxes, ha="right", fontsize=5.5, color=CTRL)
    ax.set_title("Gene domains: discovery\nand replication", loc="left")
    letter(ax, "c", dx=-0.9)

    # d named genes
    ax = fig.add_subplot(gs[1, 0:2])
    G = pd.read_csv(R / "dam_regulatory/gene_domains.csv.gz").set_index("gene")
    names = ["RGCC", "ANXA2", "CD9", "VIM", "PTPRG", "HBEGF", "DAPK2", "TREM2", "LPL", "SPP1", "AXL", "ITGAX", "GPNMB",
             "APOE", "SPI1", "CX3CR1", "CST7", "CSF1R", "TMEM119", "BIN1", "P2RY12", "RASGEF1C"]
    g = G.reindex(names)
    x = np.arange(len(names))
    sig = (g["q"] < 0.05).to_numpy()
    col = np.where(g["t"] > 0, UP, DOWN)
    ax.bar(x, g["t"], color=np.where(sig, col, "white"), edgecolor=col, lw=0.7, width=0.65)
    ax.scatter(x, g["rna_log2fc"] * 3, marker="_", s=40, color=INK, lw=1, zorder=3, label="RNA log2FC (x3)")
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.set_xticks(x, names, rotation=45, ha="right", fontsize=5.5)
    ax.set_ylabel("domain t (TSS ± 50 kb)")
    ax.legend(loc="upper right", fontsize=5.5)
    ax.set_title("Named genes (filled: domain q < 0.05); TREM2, APOE, SPP1, GPNMB rise in RNA without domain change",
                 loc="left")
    letter(ax, "d", dx=-0.06)

    # e hippocampus per-donor consistency
    ax = fig.add_subplot(gs[1, 2])
    dd = pd.read_csv(R / "hippo_replication/dam_chromatin_donors.csv")
    tests = ["SEA-AD DAM-open peaks", "SEA-AD DAM-closed peaks", "SEA-AD opened gene domains", "SEA-AD closed gene domains"]
    for i, tname in enumerate(tests):
        v = dd[dd["test"] == tname]
        diff = (v["set_log2fc"] - v["background_log2fc"]).to_numpy()
        jit = np.random.default_rng(i).uniform(-0.15, 0.15, len(diff))
        ax.scatter(i + jit, diff, s=8, marker="s", color=UP if "open" in tname else DOWN, lw=0, alpha=0.85)
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.set_xticks(range(4), ["open\npeaks", "closed\npeaks", "opened\ndomains", "closed\ndomains"])
    ax.set_ylabel("log2FC minus matched bg")
    ax.set_title("Hippocampus, per donor\n(state from same-nucleus RNA)", loc="left")
    letter(ax, "e", dx=-0.3)
    save(fig, "Fig4")


# ---------------------------------------------------------------- Figure 5
def fig5():
    fig = new_fig(183, 118)
    gs = fig.add_gridspec(2, 3, width_ratios=[1, 1.15, 1])
    # a SEA-AD scatter
    ax = fig.add_subplot(gs[0, 0])
    d = pd.read_csv(R / "dam_peaks/homeostatic_shift_donors.csv")
    for held, mfc in ((False, DOWN), (True, "white")):
        k = d["held_out"] == held
        ax.scatter(d.loc[k, "x_resid"], d.loc[k, "axis_resid"], s=10, marker="o", facecolor=mfc, edgecolor=DOWN, lw=0.6,
                   label="peak-discovery donors" if not held else "held-out donors")
    b = np.polyfit(d["x_resid"], d["axis_resid"], 1)
    xs = np.linspace(d["x_resid"].min(), d["x_resid"].max(), 10)
    ax.plot(xs, np.polyval(b, xs), color=UP, lw=1)
    ax.set_xlabel("grey-matter 6E10 (residual)")
    ax.set_ylabel("DAM axis, homeostatic\nmicroglia (residual)")
    ax.legend(loc="lower right", fontsize=5, handletextpad=0.1)
    rb = pd.read_csv(R / "dam_peaks/homeostatic_shift_robustness.csv").set_index("test")
    ax.set_title(f"SEA-AD, {int(rb.loc['baseline (result 22)', 'n_donors'])} donors\n"
                 f"r = {rb.loc['baseline (result 22)', 'r']:.2f} (held out: {rb.loc['held-out donors', 'r']:.2f})", loc="left")
    letter(ax, "a", dx=-0.45)

    # b robustness
    ax = fig.add_subplot(gs[0, 1])
    rb = pd.read_csv(R / "dam_peaks/homeostatic_shift_robustness.csv")
    lab = {"baseline (result 22)": "baseline", "held-out donors": "held-out donors",
           "+ DAM-like share (label contamination)": "+ DAM-like share", "+ depth and chemistry": "+ depth, chemistry",
           "ATAC-only nuclei": "ATAC-only nuclei", "+ APOE e4 dosage": "+ APOE ε4", "6E10 adjusted for AT8": "6E10 | AT8",
           "AT8 adjusted for 6E10": "AT8 | 6E10", "dense-core plaque area": "dense-core plaques",
           "Iba1_activated": "activated Iba1", "activated Iba1 cells": "activated Iba1",
           "all covariates": "all covariates", "6E10 adjusted for CPS": "6E10 | CPS"}
    rb = rb[rb["test"].isin(lab) | (rb["test"] == "+ CPS (plaques beyond progression?)")].copy()
    rb["label"] = rb["test"].map(lambda s: lab.get(s, "6E10 | CPS"))
    y = np.arange(len(rb))[::-1]
    ax.hlines(y, rb["loo_min"], rb["loo_max"], color=NULL, lw=3, zorder=1)
    dots(ax, rb["r"], y, rb["p_set"] < 0.05, DOWN)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, rb["label"], fontsize=5.5)
    ax.set_xlabel("partial r (grey: leave-one-out)")
    ax.set_title("Robustness", loc="left")
    letter(ax, "b", dx=-0.45)

    # c splits
    ax = fig.add_subplot(gs[0, 2])
    sp_ = pd.read_csv(R / "split_replication/splits.csv")
    ax.hist(sp_["shift_r"], bins=18, color=DOWN, alpha=0.85, lw=0)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_xlabel("r in donor-disjoint half")
    ax.set_ylabel("splits")
    ax.set_title(f"100 donor splits:\nr > 0 in {int((sp_['shift_r'] > 0).mean() * 100)}%", loc="left")
    letter(ax, "c", dx=-0.4)

    # d hippocampus
    ax = fig.add_subplot(gs[1, 0])
    h = pd.read_csv(R / "hippo_replication/homeostatic_shift_donors_Braak.csv")
    col = h["group"].map({"Normal": "white", "HP": "#7FCFBF", "AD": CTRL})
    ax.scatter(h["x"] + np.random.default_rng(0).uniform(-0.12, 0.12, len(h)), h["axis_resid"], s=14, marker="s",
               facecolor=col, edgecolor=CTRL, lw=0.6)
    b = np.polyfit(h["x"], h["axis_resid"], 1)
    xs = np.linspace(h["x"].min(), h["x"].max(), 10)
    ax.plot(xs, np.polyval(b, xs), color=UP, lw=1)
    hs = pd.read_csv(R / "hippo_replication/homeostatic_shift.csv").set_index("exposure")
    ax.set_xlabel("Braak stage")
    ax.set_ylabel("DAM axis (residual)")
    ax.set_title(f"Hippocampus, {int(hs.loc['Braak', 'n_donors'])} donors\n"
                 f"r = {hs.loc['Braak', 'r']:.2f} (p = {hs.loc['Braak', 'p_perm']:.3f}, p_set = {hs.loc['Braak', 'p_set']:.2f})", loc="left")
    for g_, c_ in (("Normal", "white"), ("HP", "#7FCFBF"), ("AD", CTRL)):
        ax.scatter([], [], s=14, marker="s", facecolor=c_, edgecolor=CTRL, lw=0.6, label=g_)
    ax.legend(loc="upper left", fontsize=5, handletextpad=0.1)
    letter(ax, "d", dx=-0.4)

    # e nucleus level: who carries the shift
    ax = fig.add_subplot(gs[1, 1])
    O = pd.read_csv(R / "homeostatic_shift/nucleus_shift.csv")
    O = O[(O["score"] == "lr") & (O["statistic"] == "mean")]
    rows_ = [("Micro-PVM_2, all", "all 66 donors"),
             ("Micro-PVM_2, ATAC-only donors", "ATAC-only donors (labels via chromatin)"),
             ("Micro-PVM_2, multiome donors", "multiome donors"),
             ("multiome donors, ATAC-only nuclei", "  their ATAC-only nuclei"),
             ("multiome donors, multiome nuclei", "  their multiome nuclei (RNA labels)"),
             ("Micro-PVM_2, multiome, confidence >= 0.9", "  multiome, confidence ≥ 0.9")]
    y = np.arange(len(rows_))[::-1]
    for yi, (key, lab_) in zip(y, rows_):
        r_ = O[O["nuclei"] == key]
        if not len(r_):
            continue
        r_ = r_.iloc[0]
        lo_, hi_ = r_.get("ci_lo", np.nan), r_.get("ci_hi", np.nan)
        if not np.isfinite(lo_):
            se = 1 / np.sqrt(max(r_["n_donors"] - 8, 1))
            lo_, hi_ = np.tanh(np.arctanh(r_["r"]) - 1.96 * se), np.tanh(np.arctanh(r_["r"]) + 1.96 * se)
        col_ = UP if "ATAC-only donors" in key or key.endswith("all") else DOWN
        ax.hlines(yi, lo_, hi_, color=col_, lw=0.8)
        dots(ax, [r_["r"]], [yi], [r_["p_perm"] < 0.05], col_)
        ax.text(1.02, yi, f"n = {int(r_['n_donors'])}", va="center", fontsize=5, transform=ax.get_yaxis_transform())
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, [r_[1] for r_ in rows_], fontsize=5.5)
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel("partial r with plaques, per-nucleus score (95% CI)")
    het = pd.read_csv(R / "homeostatic_shift/nucleus_shift.csv")
    hp = het[(het["score"] == "lr") & het["nuclei"].str.startswith("heterogeneity")]["p_perm"].iat[0]
    ax.set_title(f"SEA-AD nuclei: shift only in ATAC-only\ndonors (heterogeneity p = {hp:.2f})", loc="left")
    letter(ax, "e", dx=-0.45)

    # f quantile profile vs simulated contamination
    ax = fig.add_subplot(gs[1, 2])
    Q = pd.read_csv(R / "homeostatic_shift/nucleus_shift.csv")
    qs_ = ["q10", "q25", "q50", "q75", "q90"]
    for score_, nuc, col_, mk, lab_ in (("lr", "Micro-PVM_2, all", DOWN, "o", "observed, DAM-peak score"),
                                        ("ts", "Micro-PVM_2, all", NULLMEAN, "o", "observed, all-peak score")):
        d_ = Q[(Q["score"] == score_) & (Q["nuclei"] == nuc)].set_index("statistic").reindex(qs_)
        ax.plot([10, 25, 50, 75, 90], d_["r"], color=col_, marker=mk, ms=3, lw=0.8, label=lab_)
    sim = Q[Q["nuclei"].str.startswith("simulated")].set_index("statistic").reindex(qs_)
    ax.plot([10, 25, 50, 75, 90], sim["r"], color=UP, marker="s", ms=3, lw=0.8, ls="--", label="simulated contamination")
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.set_xticks([10, 25, 50, 75, 90])
    ax.set_xlabel("quantile (per donor)")
    ax.set_ylabel("partial r with plaques")
    ax.legend(loc="lower right", fontsize=5)
    ax.set_title("Distribution shape: depends\non the score", loc="left")
    letter(ax, "f", dx=-0.4)
    save(fig, "Fig5")


# ---------------------------------------------------------------- Figure 6
CAND = [("RASGEF1C e1", "chr5:180201040-180201876", "RASGEF1C"),
        ("RASGEF1C e2", "chr5:180196966-180197623", "RASGEF1C"),
        ("chr5:87.1M e", "chr5:87136106-87139734", None),
        ("DAPK2 prom.", "chr15:64070898-64072145", "DAPK2"),
        ("CD9 e", "chr12:6199532-6202852", "CD9"),
        ("ANXA2 e", "chr15:60397094-60399674", "ANXA2")]


def fig6():
    fig = new_fig(183, 128)
    gs = fig.add_gridspec(2, 3, width_ratios=[1, 1.15, 1.0], height_ratios=[1, 1])
    L_ = R / "candidate_links"
    # a two modes
    ax = fig.add_subplot(gs[0, 0])
    G = pd.read_csv(R / "dam_regulatory/gene_domains.csv.gz")
    G = G[G["rna_expressed"].astype("boolean").fillna(False).astype(bool)]
    ax.scatter(G["rna_log2fc"].clip(-3, 3), G["t"].clip(-8, 8), s=1.5, color=NULL, lw=0, rasterized=True)
    Gi = G.set_index("gene")
    pre = ["TREM2", "APOE", "SPP1", "GPNMB", "LPL", "ITGAX"]
    opn = [g for g in ["CD9", "ANXA2", "VIM", "RGCC", "HBEGF", "PTPRG"] if g in Gi.index and Gi.at[g, "q"] < 0.05]
    cls = [g for g in ["RASGEF1C", "P2RY12"] if g in Gi.index and Gi.at[g, "q"] < 0.05]
    for names, col, mk in ((pre, CTRL, "s"), (opn, UP, "o"), (cls, DOWN, "o")):
        s_ = Gi.reindex(names).dropna(subset=["t"])
        ax.scatter(s_["rna_log2fc"], s_["t"], s=14, marker=mk, color=col, lw=0, zorder=3)
        for gname, r in s_.iterrows():
            ax.annotate(gname, (r["rna_log2fc"], r["t"]), xytext=(2, 2), textcoords="offset points", fontsize=5)
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_xlabel("RNA log2FC, DAM-like vs homeostatic")
    ax.set_ylabel("regulatory-domain chromatin t")
    ax.set_title("Two modes: pre-open domains (teal)\nvs domain opening (red: q < 0.05)", loc="left")
    letter(ax, "a")

    # b RASGEF1C locus: GWAS, fine-mapping, DAM chromatin, same-nucleus link
    sub = gs[0, 1:].subgridspec(3, 1, height_ratios=[1.3, 0.8, 0.9], hspace=0.08)
    w = pd.read_csv(L_ / "gwas_window_RASGEF1C.csv.gz")
    lo_, hi_ = 180_120_000, 180_260_000
    w = w[(w["base_pair_location"] > lo_) & (w["base_pair_location"] < hi_)]
    res = pd.read_csv(R / "dam_peaks/dam_peaks_all.csv.gz")
    pk = res[(res["chrom"] == "chr5") & (res["end"] > lo_) & (res["start"] < hi_)]
    els = [c for c in CAND if c[2] == "RASGEF1C"]
    a1 = fig.add_subplot(sub[0])
    a1.scatter(w["base_pair_location"] / 1e6, -np.log10(w["p_value"]), s=3, color=NULLMEAN, lw=0, rasterized=True)
    cs = w[w["in_cs95"]]
    a1.scatter(cs["base_pair_location"] / 1e6, -np.log10(cs["p_value"]), s=12, color=UP, lw=0, zorder=3,
               label=f"95% credible set ({len(cs)} SNPs)")
    a1.axhline(-np.log10(5e-8), color=MUTED, lw=0.4, ls="--")
    a1.set_ylabel("AD GWAS\n–log10 p")
    a1.legend(loc="upper left", fontsize=5)
    fm = pd.read_csv(L_ / "gwas_finemap.csv")
    fmr = fm[fm["locus"] == "RASGEF1C"]
    a1.set_title(f"RASGEF1C locus: {fmr['pip_in_element'].sum():.0%} of the GWAS posterior in two DAM-closed enhancers",
                 loc="left")
    a1.tick_params(labelbottom=False)
    a2 = fig.add_subplot(sub[1], sharex=a1)
    col = np.where(pk["call"] == "DAM-closed", DOWN, np.where(pk["call"] == "DAM-open", UP, NULL))
    a2.bar(((pk["start"] + pk["end"]) / 2) / 1e6, pk["log2fc"], width=(pk["end"] - pk["start"]).clip(lower=600) / 1e6,
           color=col, lw=0)
    a2.axhline(0, color=MUTED, lw=0.4)
    a2.set_ylabel("DAM peak\nlog2FC")
    a2.tick_params(labelbottom=False)
    a3 = fig.add_subplot(sub[2], sharex=a1)
    gtf = read_gene_span("RASGEF1C")
    a3.plot([gtf[0] / 1e6, gtf[1] / 1e6], [0.5, 0.5], color=INK, lw=2, solid_capstyle="butt")
    a3.annotate("", xy=(gtf[1] / 1e6 - 0.006, 0.75), xytext=(gtf[1] / 1e6, 0.75),
                arrowprops=dict(arrowstyle="-|>", color=INK, lw=0.6))
    a3.plot([gtf[1] / 1e6] * 2, [0.5, 0.75], color=INK, lw=0.6)
    a3.text(max(gtf[0], lo_) / 1e6 + 0.03, 0.8, "RASGEF1C (TSS at right, minus strand)", fontsize=5.5, style="italic")
    lk = pd.read_csv(L_ / "same_nucleus_links.csv")
    zs = []
    for lab, pk_, gene in els:
        s0, e0 = map(int, pk_.split(":")[1].split("-"))
        z = lk[(lk["element"].str.contains(pk_, regex=False)) & (lk["gene"] == gene)]["z_state"]
        zs.append(z.iat[0])
        a3.add_patch(plt.Rectangle((s0 / 1e6, 0.05), max(e0 - s0, 800) / 1e6, 0.25, color=DOWN, lw=0))
    a3.text(0.01, 0.05, f"e1, e2 (blue): same-nucleus link to RASGEF1C, z = {zs[0]:.1f}, {zs[1]:.1f}", fontsize=5,
            va="bottom", ha="left", transform=a3.transAxes)
    a3.set_ylim(0, 1.2)
    a3.set_yticks([])
    a3.spines["left"].set_visible(False)
    a3.set_xlabel("chr5 position (Mb, hg38)")
    a3.set_xlim(lo_ / 1e6, hi_ / 1e6)
    letter(a1, "b")

    # c evidence matrix
    ax = fig.add_subplot(gs[1, :2])
    dom = pd.read_csv(R / "dam_regulatory/gene_domains.csv.gz").set_index("gene")
    rs = res.set_index("peak")
    co = pd.read_csv(L_ / "coloc.csv") if (L_ / "coloc.csv").stat().st_size > 5 else pd.DataFrame()
    e2g = pd.read_csv(L_ / "encode_re2g.csv") if (L_ / "encode_re2g.csv").stat().st_size > 5 else pd.DataFrame()
    eqs = pd.read_csv(L_ / "element_snp_eqtl.csv") if (L_ / "element_snp_eqtl.csv").stat().st_size > 5 else pd.DataFrame()
    cols = ["peak log2FC\n(q)", "target gene\nRNA log2FC", "same-nucleus\nlink z", "GWAS PIP\nin element",
            "microglia eQTL\n(target, risk allele)", "rE2G target\n(myeloid)"]
    rows_ = []
    for lab, pk_, gene in CAND:
        r = rs.loc[pk_]
        lks = lk[lk["element"].str.contains(pk_, regex=False)]
        if gene is None and len(lks):
            gene = lks.sort_values("z_state", ascending=False)["gene"].iat[0]
        z = lks.loc[lks["gene"] == gene, "z_state"]
        pip = fm.loc[fm["element"].str.contains(pk_, regex=False), "pip_in_element"]
        eq = eqs[(eqs["element"].str.contains(pk_, regex=False)) & (eqs["dataset"] == "microglia_Young2019")] if len(eqs) else eqs
        own = eq[eq["gene"] == gene].sort_values("eqtl_p") if len(eq) else eq
        if len(own):
            eqtxt = f"risk β {own['beta_risk_allele'].iat[0]:+.2f}\n(p {own['eqtl_p'].iat[0]:.2f})"
        elif len(eq) and eq["eqtl_p"].min() < 0.01:
            eqtxt = f"{eq.sort_values('eqtl_p')['gene'].iat[0]}\n(p {eq['eqtl_p'].min():.0e})"
        else:
            eqtxt = "not tested" if len(eq) else "–"
        tg = e2g[e2g["element"].str.contains(pk_, regex=False)]["target_gene"].unique() if len(e2g) else []
        rows_.append([r["log2fc"], dom["rna_log2fc"].get(gene, np.nan), z.iat[0] if len(z) else np.nan,
                      pip.iat[0] if len(pip) else np.nan, eqtxt,
                      ("yes" if gene in tg else "other: " + ",".join(tg[:2])) if len(tg) else "–", r["q"], gene])
    num = np.array([[x[0] / 1.5, x[1] / 2, x[2] / 6, x[3]] for x in rows_], float)
    ax.imshow(np.clip(np.nan_to_num(num), -1, 1), cmap=DIV, vmin=-1, vmax=1, aspect="auto",
              extent=(-0.5, 3.5, len(rows_) - 0.5, -0.5))
    for i, x in enumerate(rows_):
        txt = [f"{x[0]:+.2f} ({x[6]:.2f})", f"{x[7]}\n{x[1]:+.2f}" if pd.notna(x[1]) else "–",
               f"{x[2]:.1f}" if pd.notna(x[2]) else "not testable", f"{x[3]:.2f}" if pd.notna(x[3]) else "no GWAS hit",
               x[4], x[5]]
        for j, t_ in enumerate(txt):
            ax.text(j, i, t_, ha="center", va="center", fontsize=5.2)
    ax.set_xlim(-0.5, 5.5)
    ax.set_xticks(range(6), cols, fontsize=5.5)
    ax.xaxis.tick_top()
    ax.set_yticks(range(len(rows_)), [c[0] for c in CAND])
    ax.tick_params(length=0)
    for s_ in ax.spines.values():
        s_.set_visible(False)
    ax.set_title("Candidate elements: evidence for an element–gene link", loc="left", pad=22)
    letter(ax, "c")

    # d GWAS enrichment
    ax = fig.add_subplot(gs[1, 2])
    e = pd.read_csv(R / "dam_peaks/gwas_enrichment.csv")
    e = e[~e["apoe_excluded"]].set_index("set")
    sets = ["microglia-specific (control)", "neuron-specific (control)", "microglia-accessible (tested)", "DAM-open", "DAM-closed"]
    labs = ["microglia-specific", "neuron-specific", "all microglial", f"DAM-open ({int(e.loc['DAM-open', 'n_peaks'])})",
            f"DAM-closed ({int(e.loc['DAM-closed', 'n_peaks'])})"]
    y = np.arange(len(sets))[::-1]
    f = e.loc[sets, "fold"].to_numpy()
    sig = (e.loc[sets, "p_hit"] < 0.05).to_numpy()
    cc = [CTRL, CTRL, DOWN, UP, DOWN]
    ax.barh(y, np.log2(f), color=[c if s else "white" for c, s in zip(cc, sig)], edgecolor=cc, lw=0.7, height=0.6)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, labs)
    ax.set_xticks(np.log2([0.5, 1, 2, 4]), ["0.5", "1", "2", "4"])
    ax.set_xlabel("fold enrichment (SNP p < 1e-5)")
    ax.set_title("AD GWAS enrichment\n(DAM sets too small to test)", loc="left")
    letter(ax, "d")
    save(fig, "Fig6")


FAMILY_LABEL = {"FOSL2/JUNB": "AP-1", "BACH1/MAFK": "MAF/NFE2", "CEBPG": "C/EBP", "CEBPA": "C/EBP",
                "MITF": "MiT/TFE", "BHLHE41": "E-box (BHLHE41)", "SP4": "SP/KLF", "RELA": "NF-κB",
                "MEF2B": "MEF2", "NR3C1": "GR (NR3C1)", "HLF": "PAR bZIP", "SREBF1": "SREBF"}


def fig7():
    fig = new_fig(183, 132)
    gs = fig.add_gridspec(2, 3, width_ratios=[1.05, 1, 1], height_ratios=[1, 1.15])
    D_ = R / "dam_tf"
    T = pd.read_csv(D_ / "motif_activity.csv")
    F = pd.read_csv(D_ / "tf_families.csv")
    TF = pd.read_csv(D_ / "tf_activity.csv")

    # a family activity
    ax = fig.add_subplot(gs[0, 0])
    show = F[F["family"].isin(FAMILY_LABEL)].copy()
    show["label"] = show["family"].map(FAMILY_LABEL)
    show = show.sort_values("seaad_t", key=np.abs, ascending=False).drop_duplicates("label").head(11)
    show = show.sort_values("seaad_t")
    y = np.arange(len(show))
    col = np.where(show["seaad_t"] > 0, UP, DOWN)
    ax.barh(y, show["seaad_t"], color=col, height=0.6, lw=0)
    ax.scatter(show["hippo_t"], y, marker="s", s=14, facecolor="white", edgecolor=CTRL, lw=0.8, zorder=3,
               label="hippocampus")
    ax.scatter(show["multiome_t"], y, marker="o", s=10, color=INK, lw=0, zorder=3, label="SEA-AD multiome only")
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_yticks(y, show["label"])
    ax.set_xlabel("motif activity t, DAM-like vs homeostatic")
    ax.legend(loc="lower right", fontsize=5)
    ax.set_title("TF motif families (bars: SEA-AD,\n23 donors, all 32,481 peaks)", loc="left")
    letter(ax, "a")

    # b which TF: own RNA vs motif activity
    ax = fig.add_subplot(gs[0, 1])
    sup = TF[TF["status"] != "not supported"].drop_duplicates("tf")
    ax.scatter(sup["tf_rna_t"].clip(-20, 20), sup["seaad_t"], s=4, color=NULL, lw=0)
    lab = {"MITF": (UP, (2, 2)), "TFEC": (UP, (2, 2)), "NFE2L2": (UP, (2, 4)), "MAFG": (UP, (-14, -8)),
           "CEBPA": (UP, (-12, 4)), "KLF6": (UP, (2, 2)), "NR3C1": (UP, (2, 2)), "BHLHE41": (DOWN, (2, 2)),
           "CEBPB": (DOWN, (2, -7)), "MEF2C": (DOWN, (2, 2)), "RELA": (DOWN, (2, 2))}
    for g_, (c_, off_) in lab.items():
        r = TF[TF["tf"] == g_].sort_values("seaad_t", key=np.abs, ascending=False).head(1)
        if len(r):
            ax.scatter(r["tf_rna_t"].clip(-20, 20), r["seaad_t"], s=14, color=c_, lw=0, zorder=3)
            ax.annotate(g_, (r["tf_rna_t"].clip(-20, 20).iat[0], r["seaad_t"].iat[0]), xytext=off_,
                        textcoords="offset points", fontsize=5)
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_xlabel("TF RNA t, DAM-like vs homeostatic (66 donors)")
    ax.set_ylabel("motif activity t")
    ax.set_title("Which TF: red = expression follows\nactivity; blue = opposite", loc="left")
    letter(ax, "b")

    # c replication across all motifs
    ax = fig.add_subplot(gs[0, 2])
    ax.scatter(T["seaad_t"], T["hippo_t"], s=3, color=DOWN, lw=0, alpha=0.6)
    sig = T["seaad_q"] < 0.05
    ax.scatter(T.loc[sig, "seaad_t"], T.loc[sig, "hippo_t"], s=5, color=UP, lw=0)
    rho = T[["seaad_t", "hippo_t"]].corr(method="spearman").iat[0, 1]
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_xlabel("SEA-AD motif activity t")
    ax.set_ylabel("hippocampus motif activity t")
    ax.set_title(f"Independent cohort: ρ = {rho:.2f}\n({len(T)} motifs; red: SEA-AD q < 0.05)", loc="left")
    letter(ax, "c")

    # d network (core families; SP/KLF and SREBF motifs are GC-rich and promiscuous, shown in the table only)
    ax = fig.add_subplot(gs[1, :2])
    NODE = {"MiT/TFE": "MiT/TFE (MITF↑, TFEC↑)", "MAF/NFE2": "MAF/NFE2 (NFE2L2↑, MAFG↑)",
            "C/EBP": "C/EBP (CEBPA↑, CEBPB↓)", "AP-1": "AP-1 (TF unresolved)", "E-box (BHLHE41)": "E-box (BHLHE41↓)",
            "NF-κB": "NF-κB (RELA↓)", "GR (NR3C1)": "GR (NR3C1↑)", "PAR bZIP": "PAR bZIP (HLF, NFIL3)",
            "MEF2": "MEF2 (MEF2C↓)"}
    E = pd.read_csv(D_ / "grn_edges.csv")
    E = E.assign(label=E["family"].map(FAMILY_LABEL))
    E = E[E["label"].isin(NODE)]
    E = E[~E["gene"].str.match(r"^(AC|AL|AP)\d|^LINC|^SNHG|-AS1$")]
    g_ = E.groupby("gene").agg(nfam=("label", "nunique"), tier=("tier", "min"), rt=("gene_rna_t", "first"))
    keep_g = g_[(g_["nfam"] >= 3) | (g_["tier"] == 1)].sort_values("rt", ascending=False)
    E = E[E["gene"].isin(keep_g.index)]
    fams = [f_ for f_ in NODE if f_ in set(E["label"])]
    fy = dict(zip(fams, np.linspace(0.97, 0.03, len(fams))))
    gy = dict(zip(keep_g.index, np.linspace(0.99, 0.01, len(keep_g))))
    for _, e in E.sort_values("tier", ascending=False).drop_duplicates(["label", "gene"]).iterrows():
        t1 = (E[(E["label"] == e["label"]) & (E["gene"] == e["gene"])]["tier"] == 1).any()
        ax.plot([0.3, 0.75], [fy[e["label"]], gy[e["gene"]]], color=UP if e["element_log2fc"] > 0 else DOWN,
                lw=0.8 if t1 else 0.4, ls="-" if t1 else (0, (2, 2)), alpha=0.85, zorder=1)
    for f_, yv in fy.items():
        up_ = E.loc[E["label"] == f_, "element_log2fc"].iat[0] > 0
        ax.scatter(0.3, yv, s=40, color=UP if up_ else DOWN, zorder=3, lw=0)
        ax.text(0.28, yv, NODE[f_], ha="right", va="center", fontsize=5.5)
    for g2, yv in gy.items():
        ax.scatter(0.75, yv, s=10, marker="s", color=UP if keep_g.at[g2, "rt"] > 0 else DOWN, zorder=3, lw=0)
        ax.text(0.765, yv, g2, ha="left", va="center", fontsize=5, style="italic")
    ax.set_xlim(-0.05, 1.0)
    ax.set_ylim(-0.03, 1.03)
    ax.axis("off")
    ax.plot([], [], color=INK, lw=0.8, label="same-nucleus link (tier 1)")
    ax.plot([], [], color=INK, lw=0.4, ls=(0, (2, 2)), label="domain-proximal only (tier 2)")
    ax.legend(loc="upper center", fontsize=5, bbox_to_anchor=(0.5, 0.0), ncol=2)
    ax.set_title("TF family → DAM element → gene (genes with a tier-1 link or ≥ 3 families)", loc="left", x=0.04)
    letter(ax, "d")

    # e homeostatic shift: per-motif plaque association vs DAM activity
    ax = fig.add_subplot(gs[1, 2])
    ax.scatter(T["seaad_t"], T["homeo_plaque_r_heldout"], s=3, color=DOWN, lw=0, alpha=0.6)
    for m_, l_ in (("MA0620.4 MITF", "MITF"), ("MA0497.2 MEF2C", "MEF2C"), ("MA1550.2 PPARD", "PPARD"),
                   ("MA1138.2 FOSL2::JUNB", "AP-1"), ("MA0591.2 Bach1::Mafk", "MAF/NFE2")):
        r = T[T["motif"] == m_]
        if len(r):
            ax.scatter(r["seaad_t"], r["homeo_plaque_r_heldout"], s=12, color=UP, lw=0, zorder=3)
            ax.annotate(l_, (r["seaad_t"].iat[0], r["homeo_plaque_r_heldout"].iat[0]), xytext=(2, 2),
                        textcoords="offset points", fontsize=5)
    rh = T[["seaad_t", "homeo_plaque_r_heldout"]].corr(method="spearman").iat[0, 1]
    ax.axhline(0, color=MUTED, lw=0.4)
    ax.axvline(0, color=MUTED, lw=0.4)
    ax.set_xlabel("motif activity t, DAM-like vs homeostatic")
    ax.set_ylabel("motif score vs plaques in homeostatic\nmicroglia (r, 43 held-out donors)")
    ax.set_title(f"Homeostatic cells: no motif passes FDR\n(across motifs ρ = {rh:.2f})", loc="left")
    letter(ax, "e")
    save(fig, "Fig7")


def read_gene_span(gene):
    import gzip
    with gzip.open(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz", "rt") as fh:
        for line in fh:
            if "\tgene\t" in line and f'gene_name "{gene}";' in line:
                a = line.split("\t")
                return int(a[3]), int(a[4])


if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(ROOT / "scripts"))
    setup()
    for f in (fig1, fig2, fig3, fig4, fig5, fig6, fig7):
        f()
