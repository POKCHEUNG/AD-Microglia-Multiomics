"""Figures and tables for the cell-type screen and the plaque-proximity analyses.

    python scripts/make_spatial_figures.py

Reads results/screen, results/spatial_geomx, results/spatial_kwon, results/laminar; writes
docs/screen.png, docs/geomx_zones.png, docs/laminar_mismatch.png and the tables shown in the README.
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ad_ddr.plotting import _order

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
SERIES = {"DDR": "#2a78d6", "control": "#eb6834"}        # categorical slots 1-2, fixed order
INK, MUTED, NULL = "#0b0b0b", "#52514e", "#d9d8d4"


def screen_heatmap():
    mtg = pd.read_csv(ROOT / "results/screen/screen_MTG.csv")
    d = mtg[mtg["family"] == "DDR"]
    ex = d.pivot(index="program", columns="group", values="r_excess").reindex(DDR)
    ps = d.pivot(index="program", columns="group", values="p_set").reindex(DDR)
    order = _order(ex.columns)
    ex, ps = ex[order], ps[order]
    fig, ax = plt.subplots(figsize=(0.36 * len(order) + 2.6, 0.34 * len(DDR) + 2.0))
    cmap = plt.get_cmap("RdBu_r").copy()
    cmap.set_bad(NULL)                                     # untested: < 3 expressed program genes
    im = ax.imshow(np.ma.masked_invalid(ex.to_numpy(float)), cmap=cmap, vmin=-0.5, vmax=0.5, aspect="auto")
    for i in range(ex.shape[0]):
        for j in range(ex.shape[1]):
            if ps.iat[i, j] < 0.05:
                ax.text(j, i, "*", ha="center", va="center", fontsize=9, color=INK)
    ax.set_xticks(range(len(order)), order, rotation=60, ha="right", fontsize=8)
    ax.set_yticks(range(len(DDR)), [p.replace("_", " ") for p in DDR], fontsize=8)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    allr = pd.read_csv(ROOT / "results/screen/screen_all.csv")
    n_q = int(((allr["family"] == "DDR") & (allr["q_perm_region"] < 0.1)).sum())
    ax.set_title(f"MTG, 24 cell groups x 10 DDR programs: partial r with CPS minus random-gene-set null\n"
                 f"* p < 0.05 vs 200 matched random sets; grey = not tested (< 3 expressed genes); "
                 f"tests with q < 0.1 (any of 9 regions): {n_q}",
                 fontsize=9, loc="left", color=INK)
    cb = fig.colorbar(im, ax=ax, shrink=0.7, pad=0.01)
    cb.set_label("r excess over null", fontsize=8, color=MUTED)
    cb.outline.set_visible(False)
    fig.tight_layout()
    fig.savefig(DOCS / "screen.png", dpi=160)
    plt.close(fig)

    a = allr[allr["family"] == "DDR"]
    t = a.groupby("region").agg(tests=("p_perm", "size"), frac_p_perm_05=("p_perm", lambda p: (p < .05).mean()),
                                frac_p_set_05=("p_set", lambda p: (p < .05).mean()), min_q=("q_perm_region", "min"))
    t.round(3).to_csv(DOCS / "screen_by_region.csv")
    cols = ["group", "program", "n_donors", "r", "null_mean", "r_excess", "p_perm", "q_perm_region", "p_set",
            "n_regions_same_sign_p05", "n_regions_tested"]
    d.sort_values("p_perm")[cols].round(4).to_csv(DOCS / "screen_MTG.csv", index=False)


def geomx_dotplot():
    z = pd.read_csv(ROOT / "results/spatial_geomx/zone_effects.csv")
    progs = DDR + ["DAM"]
    panels = [("P_vs_PP", "Plaque contact vs periplaque"), ("PP_vs_A", "Periplaque vs away"),
              ("P_vs_A", "Plaque contact vs away")]
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 4.4), sharey=True)
    y = np.arange(len(progs))[::-1]
    lim = max(z["beta_sd"].abs().max(), z["null_hi"].abs().max(), z["null_lo"].abs().max()) * 1.08
    for ax, (c, title) in zip(axes, panels):
        d = z[z["contrast"] == c].set_index("program").reindex(progs)
        ax.barh(y, d["null_hi"] - d["null_lo"], left=d["null_lo"], height=0.56, color=NULL, zorder=1)
        ax.vlines(d["null_mean"], y - 0.28, y + 0.28, color=MUTED, lw=1, zorder=2)
        ax.axvline(0, color=MUTED, lw=0.6, zorder=0)
        for yi, (prog, r) in zip(y, d.iterrows()):
            col = SERIES["control" if prog == "DAM" else "DDR"]
            filled = r["p_set"] < 0.05
            ax.scatter(r["beta_sd"], yi, s=46, zorder=3, color=col if filled else "white", edgecolor=col, lw=1.6)
            if filled:
                ax.annotate(f"p_set={r['p_set']:.3f}", (r["beta_sd"], yi), xytext=(6, 4), textcoords="offset points",
                            fontsize=7, color=MUTED)
        ax.set_xlim(-lim, lim)
        ax.set_title(f"{title}\n{int(d['n_donors'].iloc[0])} donors, {int(d['n_aoi'].iloc[0])} AOIs",
                     fontsize=9, loc="left", color=INK)
        ax.set_xlabel("zone effect (SD of program score)", fontsize=8, color=MUTED)
        ax.tick_params(labelsize=8, colors=MUTED, length=0)
        ax.grid(axis="x", color="#ecebe8", lw=0.6)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
    axes[0].set_yticks(y, [p.replace("_", " ") for p in progs])
    handles = [plt.Line2D([], [], marker="o", ls="", color=SERIES["DDR"], label="DDR program"),
               plt.Line2D([], [], marker="o", ls="", color=SERIES["control"], label="DAM (positive control)"),
               plt.Line2D([], [], marker="o", ls="", mfc="white", mec=MUTED, label="open: p_set >= 0.05"),
               plt.Rectangle((0, 0), 1, 1, color=NULL, label="95% of 200 random gene sets")]
    fig.legend(handles=handles, loc="lower center", ncol=4, frameon=False, fontsize=8)
    fig.suptitle("GSE306381 microglia-enriched AOIs (GeoMx WTA, hippocampus): within-donor zone effects",
                 x=0.01, ha="left", fontsize=10, color=INK)
    fig.tight_layout(rect=(0, 0.06, 1, 0.96))
    fig.savefig(DOCS / "geomx_zones.png", dpi=160)
    plt.close(fig)
    z.round(4).to_csv(DOCS / "geomx_zone_effects.csv", index=False)


def kwon_table():
    k = pd.read_csv(ROOT / "results/spatial_kwon/pooled_effects.csv")
    k.round(4).to_csv(DOCS / "kwon_pathology_effects.csv", index=False)


def laminar_dotplot():
    lam = pd.read_csv(ROOT / "results/laminar/laminar.csv")
    don = pd.read_csv(ROOT / "results/laminar/donor_level.csv")
    fig, axes = plt.subplots(1, 3, figsize=(11, 4.2), gridspec_kw={"width_ratios": [1, 1, 0.9]})
    y = np.arange(len(DDR))[::-1]
    for ax, path in zip(axes[:2], ["AT8", "6E10"]):
        d = lam[(lam["measure"] == "mismatch") & (lam["pathology"] == path)].set_index("program").reindex(DDR)
        half = 1.96 * d["perm_sd"]
        ax.barh(y, 2 * half, left=-half, height=0.56, color=NULL, zorder=1)
        ax.axvline(0, color=MUTED, lw=0.6, zorder=0)
        for yi, (_, r) in zip(y, d.iterrows()):
            filled = r["p_perm"] < 0.05
            ax.scatter(r["beta"], yi, s=46, zorder=3, color=SERIES["DDR"] if filled else "white",
                       edgecolor=SERIES["DDR"], lw=1.6)
        ax.set_xlim(-0.8, 0.8)
        ax.set_title(f"Own-layer {path} (within donor)\n{int(d['n_donors'].iloc[0])} donors, 9 excitatory subclasses",
                     fontsize=9, loc="left", color=INK)
        ax.set_xlabel("mismatch (SD) per SD of own-layer pathology", fontsize=8, color=MUTED)
        ax.set_yticks(y, [p.replace("_", " ") for p in DDR] if path == "AT8" else [])
        ax.tick_params(labelsize=8, colors=MUTED, length=0)
        ax.grid(axis="x", color="#ecebe8", lw=0.6)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
    ax = axes[2]
    m = don[(don["group"] == "Microglia-PVM") & (don["program"] == "DAM")].set_index(["pathology", "measure"])
    labels = [("6E10", "rna"), ("6E10", "atac"), ("6E10", "mismatch"), ("AT8", "rna"), ("AT8", "atac"), ("AT8", "mismatch")]
    yy = np.arange(len(labels))[::-1]
    for yi, key in zip(yy, labels):
        r = m.loc[key]
        col = SERIES["control"]
        filled = r["p_set"] < 0.05
        ax.scatter(r["r"], yi, s=46, zorder=3, color=col if filled else "white", edgecolor=col, lw=1.6)
        ax.scatter(r["null_mean"], yi, marker="|", s=120, color=MUTED, zorder=2)
    ax.axvline(0, color=MUTED, lw=0.6)
    ax.set_yticks(yy, [f"{p} · {k.upper() if k != 'mismatch' else 'mismatch'}" for p, k in labels])
    ax.set_xlim(-0.2, 0.6)
    ax.set_title("Positive control: microglial DAM\nvs grey-matter pathology (donor level)", fontsize=9, loc="left", color=INK)
    ax.set_xlabel("partial r (| = random-set null mean)", fontsize=8, color=MUTED)
    ax.tick_params(labelsize=8, colors=MUTED, length=0)
    ax.grid(axis="x", color="#ecebe8", lw=0.6)
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    handles = [plt.Line2D([], [], marker="o", ls="", color=SERIES["DDR"], label="DDR program: RNA minus promoter ATAC"),
               plt.Line2D([], [], marker="o", ls="", color=SERIES["control"], label="DAM (positive control)"),
               plt.Line2D([], [], marker="o", ls="", mfc="white", mec=MUTED, label="open: p >= 0.05 (DDR: permutation; DAM: random sets)"),
               plt.Rectangle((0, 0), 1, 1, color=NULL, label="95% of within-donor permutations")]
    fig.legend(handles=handles, loc="lower center", ncol=4, frameon=False, fontsize=8)
    fig.suptitle("SEA-AD MTG: is layer-local pathology accompanied by a repair expression / promoter chromatin mismatch?",
                 x=0.01, ha="left", fontsize=10, color=INK)
    fig.tight_layout(rect=(0, 0.07, 1, 0.95))
    fig.savefig(DOCS / "laminar_mismatch.png", dpi=160)
    plt.close(fig)
    lam.round(4).to_csv(DOCS / "laminar_mismatch.csv", index=False)
    don[don["measure"] == "mismatch"].round(4).to_csv(DOCS / "laminar_donor_level_mismatch.csv", index=False)


if __name__ == "__main__":
    screen_heatmap()
    geomx_dotplot()
    kwon_table()
    laminar_dotplot()
    for f in ["results/screen/l5et_adjusted.csv", "results/screen/l5et_hr_genes.csv",
              "results/spatial_miyoshi/layer_effects.csv"]:
        pd.read_csv(ROOT / f).round(4).to_csv(DOCS / (("miyoshi_" if "miyoshi" in f else "") + Path(f).name), index=False)
    print("wrote docs/screen.png, docs/geomx_zones.png and tables")
