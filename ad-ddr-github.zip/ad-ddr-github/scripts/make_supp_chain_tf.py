"""Supplementary figures S6 (RASGEF1C evidence chain, README 44), S7 (candidate TF ranking, README 45) and
S8 (the core question in PsychAD, README 46) and S9 (audit of published gene-set claims, README 48).

    python scripts/make_supp_chain_tf.py        # writes docs/figures/FigS6–FigS9 (.pdf, .png)
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import make_paper_figures as mf

RC = mf.R / "rasgef1c"
RT = mf.R / "tf_ranking"
SHORT = {"Microglia-PVM": "Microglia", "Oligodendrocyte": "Oligo", "Astrocyte": "Astro", "VLMC & Perivascular": "VLMC"}
LINE_LABEL = {"L1_chromatin": "motif activity", "L2_multiome": "SEA-AD multiome", "L3_hippocampus": "hippocampus",
              "L4_tf_rna": "TF RNA induction", "L5_coupling": "TF-motif coupling", "L6_abundance": "abundance",
              "L7_paralog_share": "paralog share", "L8_targets": "known targets"}


def figS6():
    fig = mf.new_fig(183, 128)
    gs = fig.add_gridspec(2, 3)

    ax = fig.add_subplot(gs[0, 0])
    A = pd.read_csv(RC / "B_element_accessibility_by_subclass.csv").head(12)[::-1]
    y = np.arange(len(A))
    col = [mf.UP if s == "Microglia-PVM" else mf.NULLMEAN for s in A["subclass"]]
    ax.barh(y + 0.2, A["e1_cpm"], height=0.38, color=col, lw=0)
    ax.barh(y - 0.2, A["e2_cpm"], height=0.38, color="white", edgecolor=col, lw=0.6)
    ax.set_yticks(y, [SHORT.get(s, s) for s in A["subclass"]])
    ax.set_xlabel("Accessibility (CPM, pooled)")
    ax.set_title("Element accessibility by subclass\n(filled e1, open e2)", loc="left")
    mf.letter(ax, "a")

    ax = fig.add_subplot(gs[0, 1])
    E = pd.read_csv(RC / "D_expression_by_cell.csv").head(12)[::-1]
    y = np.arange(len(E))
    ax.barh(y, E["RASGEF1C_cpm"], color=[mf.UP if c == "Microglia-PVM" else mf.NULLMEAN for c in E["cell"]], lw=0, height=0.7)
    ax.set_yticks(y, [SHORT.get(c, c) for c in E["cell"]])
    ax.set_xlabel("RASGEF1C RNA (CPM, MTG)")
    ax.set_title("RASGEF1C RNA by cell group", loc="left")
    mf.letter(ax, "b")

    ax = fig.add_subplot(gs[0, 2])
    L = pd.read_csv(RC / "C_links.csv")
    for k, (el, off, mk) in enumerate((("180201040", 0.15, "o"), ("180196966", -0.15, "s"))):
        d = L[L["element"].str.contains(el)].sort_values("dist_kb")
        hit = d["gene"] == "RASGEF1C"
        ax.scatter(d.loc[~hit, "dist_kb"], d.loc[~hit, "z_state"], s=8, marker=mk, color=mf.NULL, edgecolor=mf.NULLMEAN, lw=0.4)
        ax.scatter(d.loc[hit, "dist_kb"], d.loc[hit, "z_state"], s=16, marker=mk, color=mf.UP, lw=0,
                   label="e1 - RASGEF1C" if k == 0 else "e2 - RASGEF1C")
    ax.axhline(2.5, color=mf.NULLMEAN, lw=0.5, ls="--")
    ax.set_xlabel("Gene TSS distance from element (kb)")
    ax.set_ylabel("Same-nucleus link z (state-adjusted)")
    ax.set_title("Element-gene links\n(all genes within 500 kb)", loc="left")
    ax.legend(loc="upper left")
    mf.letter(ax, "c")

    ax = fig.add_subplot(gs[1, 0])
    BG = pd.read_csv(RC / "A_phylop_background.csv")
    S = pd.read_csv(RC / "A_variants.csv")
    for k, (lab, c) in enumerate((("vert", mf.DOWN), ("primate", mf.CTRL))):
        v = BG[f"{lab}_position"].dropna()
        vp = ax.violinplot(v.clip(-4, 4), positions=[k], widths=0.7, showextrema=False)
        for b in vp["bodies"]:
            b.set_facecolor(mf.NULL)
            b.set_edgecolor(mf.NULLMEAN)
            b.set_alpha(1)
        ax.scatter(np.full(len(S), k) + np.linspace(-0.12, 0.12, len(S)), S[f"phyloP_{lab}"], s=14, color=mf.UP, zorder=3)
    ax.set_xticks([0, 1], ["100-way\nvertebrate", "30-way\nprimate"])
    ax.axhline(0, color=mf.NULLMEAN, lw=0.4)
    ax.set_ylabel("phyloP")
    ax.set_title("Conservation of the\ncredible-set SNPs (red)", loc="left")
    mf.letter(ax, "d")

    ax = fig.add_subplot(gs[1, 1:])
    CO = pd.read_csv(RC / "E_coloc.csv")
    g = CO[CO["trait"].isin(["ENSG00000146090", "Stouffer"])].reset_index(drop=True)
    HG = pd.read_csv(RC / "F_haglund2025.csv")
    h = HG[(HG["source"] == "eQTL, all 391 donors") & (HG["cell_type"] == "Microglia")].iloc[0]
    pp = HG.loc[HG["source"] == "coloc with AD (all donors)", "pp_h4"].iat[0]
    # sign of the risk allele from the authors' harmonised MR (higher expression, lower AD risk)
    g = pd.concat([pd.DataFrame([{"dataset": "microglia, single-nucleus (Haglund 2025)", "trait": "external",
                                   "z_risk_at_gwas_lead": np.nan, "z_risk_at_gwas_lead_conditional": -abs(h["t"]),
                                   "p_at_gwas_lead_conditional": h["p"], "PP4_shared": np.nan, "PP4_conditional": pp}]), g],
                  ignore_index=True)[::-1].reset_index(drop=True)
    y = np.arange(len(g))
    for i, r in g.iterrows():
        meta = r["trait"] == "Stouffer"
        ext = r["trait"] == "external"
        c = mf.INK if meta else (mf.UP if r["dataset"].startswith(("microglia", "macrophage")) else mf.DOWN)
        if not meta and not ext:
            ax.scatter(r["z_risk_at_gwas_lead"], i, s=12, marker="o", facecolor="white", edgecolor=c, lw=0.6, zorder=3)
        zc = max(r["z_risk_at_gwas_lead_conditional"], -5.3)
        ax.scatter(zc, i, s=22 if (meta or ext) else 16, marker="D" if meta else ("<" if ext else "o"), color=c, lw=0, zorder=4)
        if ext:
            txt = f"t {r['z_risk_at_gwas_lead_conditional']:.1f}   PP4 {r['PP4_conditional']:.3f}"
        else:
            txt = f"p {r['p_at_gwas_lead_conditional']:.1g}" + ("" if meta else f"   PP4 {r['PP4_shared']:.2f} -> {r['PP4_conditional']:.2f}")
        ax.text(5.2, i, txt, fontsize=5.5, va="center")
    ax.axvline(0, color=mf.NULLMEAN, lw=0.5)
    ax.axvspan(-1.96, 1.96, color=mf.GRID, lw=0, zorder=0)
    ax.set_yticks(y, [d.replace("ENSG00000146090", "") for d in g["dataset"]])
    ax.set_xlim(-5.5, 5)
    ax.set_xlabel("RASGEF1C eQTL z of the AD risk allele at rs113706587\n(open: marginal; filled: conditional on the distinct eQTL signals; red: myeloid, blue: bulk brain)")
    ax.set_title("Genotype effect on RASGEF1C expression", loc="left")
    mf.letter(ax, "e")
    mf.save(fig, "FigS6")


def figS7():
    T = pd.read_csv(RT / "tf_ranking.csv", index_col=0)
    B = pd.read_csv(RT / "bootstrap_ranks.csv.gz")
    LO = pd.read_csv(RT / "leave_one_line_out.csv")
    lines = list(LINE_LABEL)
    show = list(T.index[:15]) + [t for t in ("TFE3", "TFEB", "BHLHE41", "MEF2C") if t in T.index and t not in T.index[:15]]
    P = np.column_stack([1 - (T[f"rank_{c}"] - 1) / len(T) for c in lines])
    P = pd.DataFrame(P, index=T.index, columns=lines).loc[show]
    fig = mf.new_fig(183, 100)
    gs = fig.add_gridspec(1, 3, width_ratios=[1.5, 1, 0.8])

    ax = fig.add_subplot(gs[0, 0])
    im = ax.imshow(P.to_numpy(), cmap=mf.LinearSegmentedColormap.from_list("w_red", ["#FFFFFF", mf.UP]), vmin=0, vmax=1,
                   aspect="auto")
    ax.set_yticks(range(len(P)), [f"{t}  ({int(T.at[t, 'rank_mean'])})" for t in P.index])
    ax.set_xticks(range(len(lines)), [LINE_LABEL[c] for c in lines], rotation=60, ha="right")
    ax.axhline(14.5, color=mf.INK, lw=0.6)
    for sp in ax.spines.values():
        sp.set_visible(False)
    cb = fig.colorbar(im, ax=ax, shrink=0.5, pad=0.02)
    cb.set_label("Percentile rank among 327 TFs")
    ax.set_title("Evidence lines (overall rank in brackets)", loc="left")
    mf.letter(ax, "a")

    ax = fig.add_subplot(gs[0, 1])
    top = list(T.index[:10])[::-1]
    for i, t in enumerate(top):
        v = B.loc[B["tf"] == t, "rank_mean"].to_numpy()
        ax.scatter(v + np.random.default_rng(i).uniform(-0.2, 0.2, len(v)), np.full(len(v), i) + np.random.default_rng(i + 99).uniform(-0.2, 0.2, len(v)),
                   s=2, color=mf.UP if t == "MITF" else mf.NULLMEAN, alpha=0.5, lw=0)
        ax.scatter(np.median(v), i, s=14, color=mf.INK, marker="|", zorder=3)
    ax.set_yticks(range(len(top)), top)
    ax.set_xscale("log")
    ax.set_xlabel("Rank in 200 donor bootstraps")
    ax.set_title("Stability of the ranking", loc="left")
    mf.letter(ax, "b")

    ax = fig.add_subplot(gs[0, 2])
    y = np.arange(len(LO))[::-1]
    ax.scatter(LO["MITF_rank_mean"], y, s=14, color=mf.UP, label="mean rank")
    ax.scatter(LO["MITF_rank_rra"], y - 0.2, s=12, marker="s", facecolor="white", edgecolor=mf.UP, lw=0.6, label="RRA")
    ax.set_yticks(y, [f"without {LINE_LABEL[c]}" for c in LO["dropped"]])
    ax.set_xlim(0.5, 5.5)
    ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_xlabel("MITF rank")
    ax.legend(loc="upper right")
    ax.set_title("Leave one line out", loc="left")
    mf.letter(ax, "c")
    mf.save(fig, "FigS7")


PSY_CLASS = {"excitatory": mf.DOWN, "inhibitory": "#8491B4", "non-neuronal": mf.UP}


def psy_class(u):
    return "excitatory" if u.startswith("EN_") else "inhibitory" if u.startswith("IN_") else "non-neuronal"


def figS8():
    G = mf.R / "global_specific"
    S = pd.read_csv(G / "psychad_shared_fraction.csv")
    S = S[S["others"] == "all"]
    C = pd.read_csv(G / "psychad_specific_counts.csv")
    C = C[C["others"] == "all"]
    REP = pd.read_csv(G / "psychad_vs_seaad_replication.csv")
    SS = pd.read_csv(G / "shared_fraction.csv")
    SS = SS[(SS["others"] == "all") & (SS["modality"] == "RNA")].set_index("unit")["shared_fraction"]
    order = sorted(C["unit"], key=lambda u: (["excitatory", "inhibitory", "non-neuronal"].index(psy_class(u)),
                                             C.set_index("unit").at[u, "n_specific"]))
    fig = mf.new_fig(183, 120)
    gs = fig.add_gridspec(2, 2)

    ax = fig.add_subplot(gs[0, 0])
    d = S.set_index("unit").reindex(order)
    for i, (u, v) in enumerate(d["shared_fraction"].items()):
        if np.isfinite(v):
            ax.scatter(i, v, s=12, color=PSY_CLASS[psy_class(u)], lw=0)
    ax.set_xticks(range(len(order)), [u.replace("_", " ") for u in order], rotation=90, fontsize=5)
    ax.set_ylim(0, 0.6)
    ax.set_ylabel("Shared fraction (PsychAD)")
    ax.set_title("Shared fraction of the reproducible AD profile", loc="left")
    mf.letter(ax, "a")

    ax = fig.add_subplot(gs[0, 1])
    d = C.set_index("unit").reindex(order)
    ax.bar(range(len(order)), d["n_specific"] / d["expected_false"], color=[PSY_CLASS[psy_class(u)] for u in order], lw=0)
    ax.axhline(1, color=mf.NULLMEAN, lw=0.6, ls="--")
    ax.set_yscale("log")
    ax.set_xticks(range(len(order)), [u.replace("_", " ") for u in order], rotation=90, fontsize=5)
    ax.set_ylabel("Specific genes\n(observed / expected by chance)")
    ax.set_title("Cell-type-specific genes (PsychAD)", loc="left")
    mf.letter(ax, "b")

    ax = fig.add_subplot(gs[1, 0])
    R_ = REP.sort_values("r_specific")
    y = np.arange(len(R_))
    ax.axvspan(-0.04, 0.162, color=mf.GRID, lw=0, zorder=0)
    ax.scatter(R_["r_profiles"], y, s=10, marker="o", facecolor="white", edgecolor=mf.NULLMEAN, lw=0.6, label="whole profile r")
    ax.scatter(R_["r_specific"], y, s=14, color=[PSY_CLASS[c] for c in R_["class"]], lw=0)
    ax.scatter([], [], s=14, color=mf.INK, lw=0, label="cell-type-specific component d")
    ax.set_yticks(y, [f"{a} / {b}" for a, b in zip(R_["seaad"], R_["psychad"].str.replace("_", " "))], fontsize=5)
    ax.set_xlabel("Correlation between SEA-AD (MTG, CPS) and PsychAD (DLPFC, AD)")
    ax.set_title("Replication of each cell type's profile\n(grey: mismatched cell-type pairs, median to 95th pct)", loc="left")
    ax.legend(loc="upper left", bbox_to_anchor=(0.0, 1.0))
    ax.set_xlim(-0.1, 0.7)
    mf.letter(ax, "c")

    ax = fig.add_subplot(gs[1, 1])
    R_ = REP.assign(ratio=(REP["n_specific_both_same_sign"] + 0.5) / (REP["expected_both"] + 0.5)).sort_values("ratio")
    y = np.arange(len(R_))
    ax.barh(y, R_["ratio"], color=[PSY_CLASS[c] for c in R_["class"]], lw=0, height=0.7)
    for i, r in enumerate(R_.itertuples()):
        ax.text(r.ratio * 1.05, i, f"{r.n_specific_both_same_sign} / {r.expected_both:.1f}", fontsize=5, va="center")
    ax.axvline(1, color=mf.NULLMEAN, lw=0.6, ls="--")
    ax.set_xscale("log")
    ax.set_yticks(y, R_["seaad"], fontsize=5.5)
    ax.set_xlabel("Specific genes shared by both cohorts, same sign\n(observed / expected; labels: observed / expected)")
    ax.set_title("Overlap of the specific genes", loc="left")
    mf.letter(ax, "d")
    mf.save(fig, "FigS8")


def figS9():
    P = mf.R / "published_claims"
    T = pd.read_csv(P / "pilot_tests.csv")
    T = T[T["status"] == "tested"]
    PC = pd.read_csv(P / "power_curve.csv")
    fig = mf.new_fig(183, 125)
    gs = fig.add_gridspec(2, 2, width_ratios=[1, 1.25])

    ax = fig.add_subplot(gs[0, 0])
    for ct, c in (("Ex", mf.DOWN), ("In", "#8491B4")):
        d = PC[PC["cell"] == ct].groupby("n_donors")[["self_sig", "len_sig_same_sign"]].agg(["mean", "std"])
        n = d.index.to_numpy()
        ax.errorbar(n, d[("self_sig", "mean")], yerr=d[("self_sig", "std")], color=c, marker="o", ms=3, lw=0.8, capsize=1.5,
                    label=f"{'excitatory' if ct == 'Ex' else 'inhibitory'}: self-contained")
        ax.errorbar(n, d[("len_sig_same_sign", "mean")], yerr=d[("len_sig_same_sign", "std")], color=c, marker="s", ms=3,
                    lw=0.8, ls="--", mfc="white", capsize=1.5,
                    label=f"{'excitatory' if ct == 'Ex' else 'inhibitory'}: vs matched genes")
    ax.axhline(0.05, color=mf.NULLMEAN, lw=0.5, ls=":")
    ax.set_xlabel("Donors (PsychAD, subsampled)")
    ax.set_ylabel("Hallmark sets with p < 0.05")
    ax.set_ylim(0, 1)
    ax.legend(loc="upper left", fontsize=5.5)
    ax.set_title("Pathway 'changes' grow with cohort size;\nspecific changes do not", loc="left")
    mf.letter(ax, "a")

    ax = fig.add_subplot(gs[0, 1])
    d = T[(T["cohort"] == "PsychAD") & (T["source"] == "Hallmark") & T["cell"].isin(["Ex", "In"])]
    sig = d["p_perm"] < 0.05
    spec = (d["p_len"] < 0.05) & (np.sign(d["excess_len"]) == np.sign(d["r"]))
    ax.scatter(d.loc[~sig, "r"], d.loc[~sig, "excess_len"], s=8, color=mf.NULL, edgecolor=mf.NULLMEAN, lw=0.3, label="not significant")
    ax.scatter(d.loc[sig & ~spec, "r"], d.loc[sig & ~spec, "excess_len"], s=10, color="#8491B4", lw=0,
               label=f"self-contained only ({int((sig & ~spec).sum())})")
    ax.scatter(d.loc[sig & spec, "r"], d.loc[sig & spec, "excess_len"], s=14, color=mf.UP, lw=0,
               label=f"specific, same sign ({int((sig & spec).sum())})")
    ax.axhline(0, color=mf.NULLMEAN, lw=0.5)
    ax.axvline(0, color=mf.NULLMEAN, lw=0.5)
    ax.set_xlabel("Hallmark set r with AD (self-contained)")
    ax.set_ylabel("Excess r over matched sets")
    ax.set_title("PsychAD neurons: 50 Hallmark sets x 2 classes", loc="left")
    ax.legend(loc="upper left", fontsize=5.5)
    mf.letter(ax, "b")

    m = T[T["source"] != "Hallmark"]
    b = m.pivot_table(index=["source", "claim", "cell"], columns="cohort", values="holds_len").dropna().reset_index()
    b["both"] = (b["SEA-AD"] + b["PsychAD"]) == 2
    SRC = {"Mathys2024 pathology DEGs": "Mathys 2024\npathology DEGs\n(427 donors)", "Mathys2019 DEGs": "Mathys 2019\nDEGs\n(48 donors)",
           "Mathys2024 AD modules": "Mathys 2024\nAD-associated\nmodules", "published modules": "DNA-damage /\ncohesin\nmodules"}
    ax = fig.add_subplot(gs[1, 0])
    x = np.arange(len(SRC))
    for k, (col, c, lab) in enumerate((("SEA-AD", mf.DOWN, "SEA-AD"), ("PsychAD", mf.UP, "PsychAD"), ("both", mf.INK, "both cohorts"))):
        v = [b.loc[b["source"] == s_, col].mean() for s_ in SRC]
        ax.bar(x + (k - 1) * 0.26, v, width=0.24, color=c, lw=0, label=lab)
    for i_, s_ in enumerate(SRC):
        n = (b["source"] == s_).sum()
        ax.text(i_, 1.03, f"n = {n}", ha="center", fontsize=5.5)
    ax.set_xticks(x, list(SRC.values()), fontsize=5.5)
    ax.set_ylim(0, 1.3)
    ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_ylabel("Claims holding against expression x\nlength-matched genes (claimed sign, p < 0.05)")
    ax.legend(loc="upper center", ncol=3, fontsize=5.5)
    ax.set_title("Published claims by source", loc="left")
    mf.letter(ax, "c")

    ax = fig.add_subplot(gs[1, 1])
    CT = ["Ex", "In", "Ast", "Oli", "Opc", "Mic"]
    names = {"Ex": "Excitatory", "In": "Inhibitory", "Ast": "Astrocyte", "Oli": "Oligodendrocyte", "Opc": "OPC", "Mic": "Microglia"}
    v = [b.loc[b["cell"] == c_, "both"].mean() for c_ in CT]
    ns = [(b["cell"] == c_).sum() for c_ in CT]
    col = [mf.DOWN, "#8491B4"] + [mf.UP] * 4
    ax.barh(np.arange(len(CT))[::-1], v, color=col, lw=0, height=0.65)
    for i_, (vv, n) in enumerate(zip(v, ns)):
        ax.text(vv + 0.02, len(CT) - 1 - i_, f"{int(round(vv * n))} / {n}", va="center", fontsize=5.5)
    ax.set_yticks(np.arange(len(CT))[::-1], [names[c_] for c_ in CT])
    ax.set_xlim(0, 1.05)
    ax.set_xlabel("Claims holding in both cohorts")
    ax.set_title("Published claims by reported cell type", loc="left")
    mf.letter(ax, "d")
    mf.save(fig, "FigS9")


if __name__ == "__main__":
    figS7()
    figS6()
    figS8()
    figS9()
