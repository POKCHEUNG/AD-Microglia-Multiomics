"""Supplementary figure S5: pre-specified DDR endpoints, effect sizes with 95% CIs in two cohorts.

    python scripts/make_supp_endpoints.py       # writes docs/figures/FigS5.pdf and .png
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import make_paper_figures as mf

R = mf.R / "ddr_endpoints"
ORDER = ["DSB sensing", "p53 response", "NHEJ core", "BER core", "senescence", "cGAS-STING", "CDKN1A (p21)", "GADD45A",
         "DAM (reference)", "cohesin (reference)"]
CELLS = ["Excitatory", "L2/3 IT", "Inhibitory", "Microglia", "Oligodendrocyte", "Astrocyte"]


def main():
    T = pd.read_csv(R / "endpoints.csv")
    M = pd.read_csv(R / "endpoints_meta.csv")
    fig = mf.new_fig(183, 150)
    gs = fig.add_gridspec(2, 3)
    for k, cell in enumerate(CELLS):
        ax = fig.add_subplot(gs[k // 3, k % 3])
        y0 = np.arange(len(ORDER))[::-1].astype(float)
        ax.axvspan(-0.2, 0.2, color=mf.GRID, lw=0, zorder=0)
        for off, co, mk, col in ((0.22, "SEA-AD", "o", mf.DOWN), (0.0, "PsychAD", "^", mf.UP)):
            d = T[(T["cohort"] == co) & (T["cell"] == cell) & (T["status"] == "tested")].set_index("endpoint")
            for i, ep in enumerate(ORDER):
                if ep not in d.index:
                    continue
                r = d.loc[ep]
                yy = y0[i] + off
                ax.hlines(yy, r["excess_lo"], r["excess_hi"], color=col, lw=0.7)
                sig = r["bh_set"] < 0.05 if pd.notna(r.get("bh_set", np.nan)) else r["p_set"] < 0.05
                ax.scatter(r["excess"], yy, s=10, marker=mk, color=col if sig else "white", edgecolor=col, lw=0.6, zorder=3)
        m = M[M["cell"] == cell].set_index("endpoint")
        for i, ep in enumerate(ORDER):
            if ep not in m.index:
                continue
            r = m.loc[ep]
            yy = y0[i] - 0.22
            ax.hlines(yy, r["excess_random_lo"], r["excess_random_hi"], color=mf.INK, lw=0.9)
            ax.scatter(r["excess_random"], yy, s=12, marker="D", color=mf.INK, lw=0, zorder=3)
        ax.axvline(0, color=mf.MUTED, lw=0.4)
        ax.axhline(1.5, color=mf.MUTED, lw=0.3, ls=":")
        ax.set_yticks(y0, ORDER if k % 3 == 0 else [""] * len(ORDER), fontsize=5)
        ax.tick_params(axis="y", length=0)
        ax.set_xlim(-0.55, 0.65)
        ax.set_xlabel("excess r over matched genes (95% CI)")
        ax.set_title(cell, loc="left", x=0.04)
        if k == 0:
            ax.scatter([], [], marker="o", s=10, color=mf.DOWN, label="SEA-AD (CPS)")
            ax.scatter([], [], marker="^", s=10, color=mf.UP, label="PsychAD (AD)")
            ax.scatter([], [], marker="D", s=10, color=mf.INK, label="random-effects meta")
            ax.legend(loc="upper right", fontsize=4.8, bbox_to_anchor=(1.0, 1.0), framealpha=0.9, frameon=True,
                      edgecolor="none")
        mf.letter(ax, "abcdef"[k])
    fig.text(0.5, 0.001, "Filled: q < 0.05 (BH over the 48 primary tests of the cohort; references: p_set < 0.05). "
             "Grey band: ± 0.20. Diamonds: random-effects meta-analysis, variance including the matched-set spread.",
             ha="center", va="bottom", fontsize=5, color=mf.MUTED)
    mf.save(fig, "FigS5")


if __name__ == "__main__":
    main()
