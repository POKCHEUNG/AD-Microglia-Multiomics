"""Supplementary figure S4: equivalence tests and leave-one-gene-out for the DDR programs.

    python scripts/make_supp_equivalence.py     # writes docs/figures/FigS4.pdf and .png
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import make_paper_figures as mf

R = mf.R / "ddr_equivalence"
COL = {"equivalent": mf.CTRL, "inconclusive": mf.NULLMEAN, "different": mf.UP}


def forest(ax, d, bound, labels, ref=None):
    y = np.arange(len(d))[::-1]
    ax.axvspan(-bound, bound, color=mf.GRID, lw=0, zorder=0)
    for yi, (_, r) in zip(y, d.iterrows()):
        ax.hlines(yi, r["lo90"], r["hi90"], color=COL[r["status"]], lw=0.9)
        ax.scatter(r["delta"], yi, s=10, color=COL[r["status"]], lw=0, zorder=3)
    if ref is not None:
        yr = -1.2
        ax.hlines(yr, ref["lo90"], ref["hi90"], color=mf.CTRL, lw=0.9)
        ax.scatter(ref["delta"], yr, s=14, marker="s", color=mf.CTRL, lw=0, zorder=3)
        labels = list(labels) + [ref["label"]]
        y = list(y) + [yr]
    ax.axvline(0, color=mf.MUTED, lw=0.4)
    ax.set_yticks(y, labels, fontsize=5)
    ax.tick_params(axis="y", length=0)


def main():
    E = pd.read_csv(R / "equivalence.csv")
    LS = pd.read_csv(R / "logo_summary_mtg.csv")
    LN = pd.read_csv(R / "logo_null_mtg.csv")
    fig = mf.new_fig(183, 130)
    gs = fig.add_gridspec(2, 3, width_ratios=[1.5, 1, 1])

    # a caterpillar, SEA-AD MTG
    ax = fig.add_subplot(gs[0, 0])
    m = E[(E["cohort"] == "SEA-AD") & (E["region"] == "MTG") & (E["family"] == "DDR") & (E["n_donors"] >= 70)]
    m = m.sort_values("delta").reset_index(drop=True)
    x = np.arange(len(m))
    ax.axhspan(-0.2, 0.2, color=mf.GRID, lw=0, zorder=0)
    for st, c in COL.items():
        k = m["status"] == st
        ax.vlines(x[k], m.loc[k, "lo90"], m.loc[k, "hi90"], color=c, lw=0.5)
        ax.scatter(x[k], m.loc[k, "delta"], s=2, color=c, lw=0, zorder=3, label=f"{st} ({k.sum()})")
    ref = E[(E["cohort"] == "SEA-AD") & (E["region"] == "MTG") & (E["group"] == "Microglia-PVM") & (E["program"] == "DAM")].iloc[0]
    coh = E[(E["cohort"] == "SEA-AD") & (E["region"] == "MTG") & (E["group"] == "L2/3 IT") & (E["program"] == "cohesin")].iloc[0]
    for xx, r, lab in ((len(m) + 6, ref, "DAM\n(microglia)"), (len(m) + 30, coh, "cohesin\n(L2/3 IT)")):
        ax.vlines(xx, r["lo90"], r["hi90"], color=mf.CTRL, lw=0.9)
        ax.scatter(xx, r["delta"], s=12, marker="s", color=mf.CTRL, lw=0, zorder=3)
        ax.text(xx + 4, r["lo90"] - 0.02, lab, ha="left", va="top", fontsize=4.8)
    ax.axhline(0, color=mf.MUTED, lw=0.4)
    ax.set_xticks([])
    ax.set_xlabel(f"{len(m)} DDR tests, MTG (cell groups with ≥ 70 donors), sorted")
    ax.set_ylabel("excess r over matched random genes\n(90% donor-bootstrap CI)")
    ax.legend(loc="upper left", fontsize=5, markerscale=2.5)
    ax.set_title("SEA-AD: equivalence band ± 0.20 (grey)", loc="left")
    mf.letter(ax, "a")

    # b DDR vs random-set benchmark
    ax = fig.add_subplot(gs[0, 1])
    groups = [("SEA-AD MTG", (E["cohort"] == "SEA-AD") & (E["region"] == "MTG")),
              ("SEA-AD other regions", (E["cohort"] == "SEA-AD") & (E["region"] != "MTG")),
              ("PsychAD", E["cohort"] == "PsychAD")]
    y = np.arange(len(groups))[::-1]
    for yi, (lab, k) in zip(y, groups):
        d = E[k & (E["family"] == "DDR")]
        for off, val, bench, c in ((0.15, (d["status"] == "equivalent").mean(), d["bench_equiv_0.2"].mean(), mf.CTRL),
                                   (-0.15, (d["status"] == "different").mean(), d["bench_diff_0.2"].mean(), mf.UP)):
            ax.barh(yi + off, val * 100, height=0.28, color=c, lw=0)
            ax.scatter(bench * 100, yi + off, marker="|", s=60, color=mf.INK, lw=1.2, zorder=3)
    ax.set_yticks(y, [g[0] for g in groups])
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel("% of tests (bars: DDR; ticks: random sets)")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=mf.CTRL, label="equivalent (± 0.20)"), Patch(color=mf.UP, label="different (95% CI excludes 0)")],
              loc="upper right", fontsize=5)
    ax.set_title("DDR programs behave like\nmatched random gene sets", loc="left")
    mf.letter(ax, "b")

    # f LOGO
    ax = fig.add_subplot(gs[0, 2])
    ld = LS[LS["program"].isin(mf.DDR)].merge(E[(E["cohort"] == "SEA-AD") & (E["region"] == "MTG")][["group", "program", "n_donors"]],
                                              on=["group", "program"])
    ld = ld[ld["n_donors"] >= 70]
    ax.scatter(ld["n_genes"], ld["max_abs_change"], s=5, color=mf.DOWN, lw=0, alpha=0.7)
    for (g, p), lab in ((("L5 ET", "HR"), "L5 ET HR"),):
        r = LS[(LS["group"] == g) & (LS["program"] == p)]
        if len(r):
            ax.scatter(r["n_genes"], r["max_abs_change"], s=12, color=mf.UP, lw=0, zorder=3)
            ax.annotate(f"{lab} (all {int(r['n_genes'].iat[0])}\nLOGO p_set < 0.05)", (r["n_genes"].iat[0], r["max_abs_change"].iat[0]),
                        xytext=(3, 3), textcoords="offset points", fontsize=4.8)
    ax.set_xscale("log")
    ax.set_xticks([3, 10, 30], ["3", "10", "30"])
    ax.minorticks_off()
    ax.set_xlabel("genes in program")
    ax.set_ylabel("largest change in excess r\nwhen one gene is left out")
    dd = LS[LS["program"].isin(mf.DDR)]
    ax.set_title(f"Leave-one-gene-out: any p_set < 0.05\nin {(dd['n_logo_p05'] > 0).mean():.0%} of tests "
                 f"(random sets {LN['any_logo_p05'].mean():.0%})", loc="left")
    mf.letter(ax, "c")

    # d PsychAD
    ax = fig.add_subplot(gs[1, 0])
    p = E[(E["cohort"] == "PsychAD") & (E["family"] == "DDR")].sort_values(["group", "program"])
    labs = [f"{g} {q}" for g, q in zip(p["group"], p["program"].str.replace("_", " "))]
    c = E[(E["cohort"] == "PsychAD") & (E["group"] == "EN") & (E["program"] == "cohesin")].iloc[0].copy()
    c["label"] = "EN cohesin (reference)"
    c["status"] = "different"
    forest(ax, p, 0.2, labs, c)
    ax.axvline(-0.1, color=mf.MUTED, lw=0.4, ls="--")
    ax.axvline(0.1, color=mf.MUTED, lw=0.4, ls="--")
    ax.set_xlabel("excess r (90% CI); grey ± 0.20, dashed ± 0.10")
    ax.set_title(f"PsychAD (≈ 410 donors): every 90% CI\nwithin ± {max(p['lo90'].abs().max(), p['hi90'].abs().max()):.2f}",
                 loc="left")
    mf.letter(ax, "d")

    # e GeoMx
    ax = fig.add_subplot(gs[1, 1])
    g = E[(E["cohort"] == "GeoMx") & (E["family"] == "DDR")].sort_values("delta")
    r = E[(E["cohort"] == "GeoMx") & (E["program"] == "DAM")].iloc[0].copy()
    r["label"] = "DAM (control)"
    forest(ax, g, 0.25, g["program"].str.replace("_", " "), r)
    ax.set_xlabel("P vs PP, excess (s.d.); grey ± 0.25")
    ax.set_title("GeoMx (28 donors):\ninconclusive, too few donors", loc="left")
    mf.letter(ax, "e")

    # f Stereo-seq
    ax = fig.add_subplot(gs[1, 2])
    s = E[(E["cohort"] == "Stereo-seq") & (E["family"] == "DDR")].sort_values("delta")
    r = E[(E["cohort"] == "Stereo-seq") & (E["program"] == "Trem2_Cd68")].iloc[0].copy()
    r["label"] = "Trem2+Cd68 (control)"
    forest(ax, s, np.log(1.1), s["program"].str.replace("_", " "), r)
    ax.set_xlabel("log RR excess (90% CI); grey ± log 1.10")
    ax.set_title(f"Stereo-seq: {(s['status'] == 'equivalent').sum()}/{len(s)} programs\nwithin ± 10%", loc="left")
    mf.letter(ax, "f")
    mf.save(fig, "FigS4")


if __name__ == "__main__":
    main()
