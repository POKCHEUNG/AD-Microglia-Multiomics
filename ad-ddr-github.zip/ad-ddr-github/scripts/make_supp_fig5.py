"""Supplementary figure S2 (extends Fig. 5): selection bias, confidence intervals, feature overlap, state continuum.

    python scripts/make_supp_fig5.py            # writes docs/figures/FigS2.pdf and .png

Reads results/homeostatic_shift/ (scripts/homeostatic_shift_selection.py) and
results/hippo_replication/continuous_*.csv (scripts/hippo_continuous_state.py).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import make_paper_figures as mf

R = mf.R


def forest(ax, T, labels, color_by_pset=True, cohort_color=mf.DOWN, marker="o"):
    y = np.arange(len(T))[::-1]
    for yi, (_, r) in zip(y, T.iterrows()):
        sig = r.get("p_set", np.nan) < 0.05 if color_by_pset and pd.notna(r.get("p_set", np.nan)) else r["p_perm"] < 0.05
        if pd.notna(r.get("ci_lo", np.nan)):
            ax.hlines(yi, r["ci_lo"], r["ci_hi"], color=cohort_color, lw=0.8, zorder=2)
        if pd.notna(r.get("null_mean", np.nan)):
            ax.vlines(r["null_mean"], yi - 0.3, yi + 0.3, color=mf.NULLMEAN, lw=0.6, zorder=1)
        mf.dots(ax, [r["r"]], [yi], [sig], cohort_color, marker=marker, s=16)
    ax.axvline(0, color=mf.MUTED, lw=0.4)
    ax.set_yticks(y, labels)
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel("partial r with plaques (95% CI)")


def main():
    T = pd.read_csv(R / "homeostatic_shift/selection_ci_features_continuum.csv")
    fig = mf.new_fig(183, 125)
    gs = fig.add_gridspec(2, 3, width_ratios=[1.25, 1.05, 1])

    # a selection bias
    ax = fig.add_subplot(gs[0, 0])
    a = T[T["block"].isin(["baseline", "A selection"])]
    lab = ["Published, 66 donors", "Published, 43 held-out", "Cross-fitted (LOO)", "Hippocampus-defined",
           "Hippo-defined, held-out", "Weighted, SEA-AD t", "Weighted, hippo t"]
    forest(ax, a, lab)
    ax.set_title("Selection bias: axis defined without\nthe scored donors (filled: p_set < 0.05)", loc="left")
    mf.letter(ax, "a")

    # b features
    ax = fig.add_subplot(gs[0, 1])
    b = T[T["block"] == "B features"]
    blab = ["No label-gene domains", "Distal only", "Promoter only", "Open only", "Closed only"]
    forest(ax, b, blab)
    halves = pd.read_csv(R / "homeostatic_shift/random_halves_r.csv").iloc[:, 0]
    ax.boxplot([halves], positions=[-1], vert=False, widths=0.5, showfliers=False,
               medianprops=dict(color=mf.INK, lw=0.7), boxprops=dict(lw=0.5), whiskerprops=dict(lw=0.5),
               capprops=dict(lw=0.5))
    ax.set_yticks(list(np.arange(len(b))[::-1]) + [-1], blab + ["200 random halves"])
    ax.set_ylim(-1.7, len(b) - 0.4)
    ax.set_title("Feature overlap: which peaks\ncarry the shift", loc="left")
    mf.letter(ax, "b")

    # c genome-wide concordance
    ax = fig.add_subplot(gs[0, 2])
    pp = pd.read_csv(R / "homeostatic_shift/peak_plaque_r.csv.gz")
    gw = pd.read_csv(R / "homeostatic_shift/genome_wide_concordance.csv", index_col=0).iloc[:, 0]
    pp["bin"] = pd.qcut(pp["dam_t"].rank(method="first"), 20, labels=False)
    g = pp.groupby("bin").agg(t=("dam_t", "median"), m=("plaque_r_heldout", "mean"),
                              se=("plaque_r_heldout", lambda v: v.std() / np.sqrt(len(v))))
    ax.errorbar(g["t"], g["m"], yerr=1.96 * g["se"], fmt="o", ms=2.5, color=mf.DOWN, elinewidth=0.6, capsize=0)
    ax.axhline(0, color=mf.MUTED, lw=0.4)
    ax.axvline(0, color=mf.MUTED, lw=0.4)
    ax.set_xlabel("DAM vs homeostatic t (20 bins)")
    ax.set_ylabel("peak's plaque r in homeostatic\nmicroglia (43 held-out donors)")
    ax.set_title(f"No threshold: ρ = {gw['spearman_peak_plaque_r_vs_dam_t']:.2f}\n"
                 f"(null {gw['null_mean']:.2f} ± {gw['null_sd']:.2f}, p = {gw['p_perm']:.3f})", loc="left")
    mf.letter(ax, "c")

    # d SEA-AD state continuum
    ax = fig.add_subplot(gs[1, 0])
    c = T[T["block"] == "C continuum"]
    forest(ax, c, ["Micro-PVM_2", "Micro-PVM_2_3", "Micro-PVM_3", "3 states, state effect", "Labels 2 + 2_3",
                   "Contrast 3 − 2"])
    ax.set_title("SEA-AD state continuum: all states\nmove the same way", loc="left")
    mf.letter(ax, "d")

    # e hippocampus RNA-score quintiles
    ax = fig.add_subplot(gs[1, 1])
    q = pd.read_csv(R / "hippo_replication/continuous_quintiles.csv")
    qq = q[q["model"].str.endswith("only")].reset_index(drop=True)
    x = np.arange(len(qq))
    ax.vlines(x, qq["ci_lo"], qq["ci_hi"], color=mf.CTRL, lw=0.8)
    mf.dots(ax, x, qq["r"], qq["p_perm"] < 0.05, mf.CTRL, marker="s", s=16)
    ax.axhline(0, color=mf.MUTED, lw=0.4)
    ax.set_xticks(x, [f"Q{i + 1}\n({int(n)})" for i, n in enumerate(qq["n_donors"])])
    ax.set_xlabel("DAM RNA-score quintile (donors)")
    ax.set_ylabel("partial r with Braak (95% CI)")
    pooled = q.iloc[0]
    ax.set_title(f"Hippocampus RNA-score quintiles\n(pooled r = {pooled['r']:.2f}; filled p < 0.05)", loc="left")
    mf.letter(ax, "e")

    # f threshold sweep
    ax = fig.add_subplot(gs[1, 2])
    s = pd.read_csv(R / "hippo_replication/continuous_threshold_sweep.csv")
    for cov, off, mk in (("pool mean RNA score", -1.2, "s"), ("none (age, sex, log fragments)", 1.2, "o")):
        d = s[s["covariate"] == cov]
        ax.vlines(d["threshold_pct"] + off, d["ci_lo"], d["ci_hi"], color=mf.CTRL, lw=0.8)
        mf.dots(ax, d["threshold_pct"] + off, d["r"], d["p_set"] < 0.05, mf.CTRL, marker=mk, s=14)
        ax.scatter([], [], marker=mk, s=14, facecolor="white", edgecolor=mf.CTRL, lw=0.7,
                   label="+ pool mean RNA score" if mk == "s" else "base covariates")
    ax.axhline(0, color=mf.MUTED, lw=0.4)
    ax.set_xticks([20, 30, 40, 50, 60])
    ax.set_xlabel("RNA-score percentile cut-off")
    ax.set_ylabel("partial r with Braak (95% CI)")
    ax.legend(loc="upper right", fontsize=5, handletextpad=0.1)
    ax.set_title("Hippocampus threshold sweep\n(filled: p_set < 0.05)", loc="left")
    mf.letter(ax, "f")
    mf.save(fig, "FigS2")


if __name__ == "__main__":
    main()
