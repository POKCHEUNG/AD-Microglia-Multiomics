"""Supplementary figure S3: microglial states beyond DAM (results/microglia_states/, scripts/microglia_states.py).

    python scripts/make_supp_states.py          # writes docs/figures/FigS3.pdf and .png
"""

from __future__ import annotations

import numpy as np
import pandas as pd

import make_paper_figures as mf
from make_paper_figures import FAMILY_LABEL

R = mf.R / "microglia_states"
SHORT = {"Micro-PVM_2": "PVM_2 (homeostatic)", "Micro-PVM_2_1-SEAAD": "PVM_2_1", "Micro-PVM_2_3-SEAAD": "PVM_2_3",
         "Micro-PVM_3-SEAAD": "PVM_3 (DAM-like)", "Micro-PVM_4-SEAAD": "PVM_4", "Micro-PVM_1": "PVM_1 (perivascular)"}


def main():
    H = pd.read_csv(R / "supertype_programs.csv", index_col=0)
    P = pd.read_csv(R / "program_pathology.csv")
    SH = pd.read_csv(R / "supertype_share_cps.csv")
    ST = pd.read_csv(R / "state_motif_activity.csv")
    C = pd.read_csv(R / "hippo_cell_programs.csv.gz")
    fig = mf.new_fig(183, 120)
    gs = fig.add_gridspec(2, 4, width_ratios=[1.35, 1, 1, 1], wspace=0.12)

    ax = fig.add_subplot(gs[0, :2])
    im = ax.imshow(H.to_numpy(), cmap=mf.DIV, vmin=-1.8, vmax=1.8, aspect="auto")
    ax.set_yticks(range(len(H)), [SHORT[i] for i in H.index])
    ax.set_xticks(range(H.shape[1]), H.columns, rotation=35, ha="right")
    for i in range(H.shape[0]):
        for j in range(H.shape[1]):
            ax.text(j, i, f"{H.iat[i, j]:+.1f}", ha="center", va="center", fontsize=4.8)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    cb = fig.colorbar(im, ax=ax, shrink=0.6, aspect=12, pad=0.01)
    cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=5, width=0.4, length=1.5)
    ax.set_title("SEA-AD MTG: program score by supertype (z across supertypes)", loc="left")
    mf.letter(ax, "a")

    ax = fig.add_subplot(gs[0, 2])
    p = P[P["exposure"] == "cps"].iloc[::-1].reset_index(drop=True)
    y = np.arange(len(p))
    ax.vlines(p["null_mean"], y - 0.3, y + 0.3, color=mf.NULLMEAN, lw=0.6)
    mf.dots(ax, p["r"], y, p["p_set"] < 0.05, mf.UP)
    ax.scatter(p.loc[p["program"] == "DAM", "r"], y[p["program"] == "DAM"], s=16, marker="s", color=mf.CTRL, zorder=4)
    ax.axvline(0, color=mf.MUTED, lw=0.4)
    ax.set_yticks(y, p["program"])
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel("partial r with CPS (73 donors)")
    ax.set_title("Programs vs CPS\n(ticks: random-set mean)", loc="left")
    mf.letter(ax, "b")

    ax = fig.add_subplot(gs[0, 3])
    sh = SH.iloc[::-1].reset_index(drop=True)
    y = np.arange(len(sh))
    ax.barh(y, sh["rho_cps"], color=[mf.UP if (r > 0 and q < 0.05) else mf.NULL for r, q in zip(sh["rho_cps"], sh["p"])],
            height=0.6, lw=0)
    ax.axvline(0, color=mf.MUTED, lw=0.4)
    ax.set_yticks(y, [SHORT[s] for s in sh["supertype"]])
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel("ρ, share vs CPS")
    ax.set_title("Supertype share\nvs CPS", loc="left")
    mf.letter(ax, "c")

    ax = fig.add_subplot(gs[1, 0])
    fams = [f for f in FAMILY_LABEL if f in set(ST["family"])]
    M = ST[ST["family"].isin(fams)].sort_values("t", key=np.abs, ascending=False).drop_duplicates(["state", "family"])
    W = M.pivot(index="family", columns="state", values="t").reindex(fams)
    W = W.groupby(W.index.map(FAMILY_LABEL)).first()
    W = W[[c for c in ["Micro-PVM_3-SEAAD", "Micro-PVM_2_3-SEAAD", "Micro-PVM_1"] if c in W.columns]]
    im = ax.imshow(np.clip(W.to_numpy(), -8, 8), cmap=mf.DIV, vmin=-8, vmax=8, aspect="auto")
    for i in range(W.shape[0]):
        for j in range(W.shape[1]):
            ax.text(j, i, f"{W.iat[i, j]:+.1f}", ha="center", va="center", fontsize=4.8)
    nd = ST.groupby("state")["n_donors"].first()
    ax.set_xticks(range(W.shape[1]), [f"{SHORT[c].split(' ')[0]}\n({nd[c]})" for c in W.columns])
    ax.set_yticks(range(W.shape[0]), W.index)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title("Motif families vs PVM_2\n(t; donors in brackets)", loc="left")
    mf.letter(ax, "d")

    for k, prog in enumerate(["interferon", "MHC-II", "lipid", "ex vivo / IEG"]):
        ax = fig.add_subplot(gs[1, 1 + k]) if k < 3 else None
        if ax is None:
            break
        v = C[f"prog_{prog}"]
        lim = np.nanquantile(np.abs(v), 0.98)
        o = np.random.default_rng(0).permutation(len(C))
        ax.scatter(C["rna_u1"].to_numpy()[o], C["rna_u2"].to_numpy()[o], c=v.to_numpy()[o], cmap=mf.DIV, vmin=-lim,
                   vmax=lim, s=0.8, lw=0, rasterized=True)
        ax.set_xticks([]), ax.set_yticks([])
        for s in ("left", "bottom"):
            ax.spines[s].set_visible(False)
        r = np.corrcoef(v.fillna(0), C["score"])[0, 1]
        ax.set_title(f"Hippocampus: {prog}\nr with DAM score = {r:+.2f}", loc="left", x=0.08)
        if k == 0:
            mf.letter(ax, "e")
    mf.save(fig, "FigS3")


if __name__ == "__main__":
    main()
