"""Supplementary figure: UMAP of hippocampus multiome microglia and the RNA-defined DAM state.

    python scripts/make_supp_umap.py            # writes docs/figures/FigS1.pdf and .png

The DAM score and the two state definitions are those of scripts/run_hippo_replication.py:
score = mean z of SEA-AD DAM-up top-200 genes minus DAM-down top-200 genes (log-normalised RNA,
z over all microglia); "DAM-high / DAM-low" = top / bottom third within donor (donors with
>= 30 microglia, Fig. 4c,e); "homeostatic" = score below the cohort median (Fig. 5d).
Embeddings are for display only; no statistic in the paper is computed from them.
RNA: top 2,000 variable genes, PCA (30), PCs centred per library (removes library offsets;
no integration package is installed). ATAC: TF-IDF on peaks detected in >= 2% of cells,
truncated SVD (30, first component dropped as depth), same per-library centring.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
import umap
from scipy.stats import spearmanr
from sklearn.decomposition import TruncatedSVD
from sklearn.neighbors import NearestNeighbors

import make_paper_figures as mf
from run_dam_regulatory import rna_lfc
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz"
GROUP = {"Normal": "#BBBBBB", "HP": "#F39B7F", "AD": mf.UP}
GLABEL = {"Normal": "Control", "HP": "High pathology, no dementia", "AD": "AD"}
TERT = {"high": mf.UP, "mid": "#DDDDDD", "low": mf.DOWN}
HOMEO = ["P2RY12", "CX3CR1", "TMEM119", "CSF1R", "SELPLG"]
DAMG = ["CD9", "SPP1", "APOE", "GPNMB", "TREM2", "ITGAX", "LPL", "ANXA2"]


def centre_by(X, lib):
    X = X.copy()
    for l in np.unique(lib):
        m = lib == l
        X[m] -= X[m].mean(0)
    return X


def build():
    L, genes = load_libs()
    gu = pd.Series(np.arange(len(genes)), index=genes.str.upper())
    gu = gu[~gu.index.duplicated()]
    rna, _ = rna_lfc()
    expr = rna[rna["rna_expressed"].astype("boolean").fillna(False).astype(bool)]
    up = [g for g in expr.nlargest(200, "rna_t").index if g in gu.index]
    dn = [g for g in expr.nsmallest(200, "rna_t").index if g in gu.index]

    cells, R, A = [], [], []
    for lib, D in L.items():
        m = (D["cells"]["subclass"] == "Microglia").to_numpy()
        if m.sum():
            cells.append(D["cells"][m])
            R.append(D["rna_cells"][m])
            A.append(D["atac_cells"][m])
    cells = pd.concat(cells, ignore_index=True)
    R, A = sp.vstack(R).tocsr(), sp.vstack(A).tocsr()
    lib = cells["library"].to_numpy()

    tot = np.asarray(R.sum(1)).ravel()
    Ln = (sp.diags(1e4 / np.maximum(tot, 1)) @ R).tocsc()
    Ln.data = np.log1p(Ln.data)
    mu = np.asarray(Ln.mean(0)).ravel()
    sd = np.sqrt(np.maximum(np.asarray(Ln.multiply(Ln).mean(0)).ravel() - mu ** 2, 1e-12))
    ui, di = gu.reindex(up).to_numpy(), gu.reindex(dn).to_numpy()
    cells["score"] = ((Ln[:, ui].toarray() - mu[ui]) / sd[ui]).mean(1) - ((Ln[:, di].toarray() - mu[di]) / sd[di]).mean(1)
    cells["homeostatic"] = cells["score"] < np.median(cells["score"])
    cells["tertile"] = "excluded"
    for d, ix in cells.groupby("donor").groups.items():
        s = cells.loc[ix, "score"]
        if len(s) < 30:
            continue
        lo, hi = np.quantile(s, [1 / 3, 2 / 3])
        cells.loc[ix, "tertile"] = np.where(s >= hi, "high", np.where(s <= lo, "low", "mid"))
    for g in HOMEO + DAMG:
        cells[f"g_{g}"] = Ln[:, gu[g]].toarray().ravel()
    cells["in_score_set"] = ""
    cells.attrs["in_up"] = [g for g in HOMEO + DAMG if g in up]
    cells.attrs["in_dn"] = [g for g in HOMEO + DAMG if g in dn]

    # RNA embedding
    keep = (np.asarray((R > 0).sum(0)).ravel() >= 0.01 * R.shape[0])
    var = sd ** 2 / np.maximum(mu, 1e-3)
    hv = np.where(keep)[0][np.argsort(var[keep])[::-1][:2000]]
    Xh = (Ln[:, hv].toarray() - mu[hv]) / sd[hv]
    pcs = TruncatedSVD(30, random_state=0).fit_transform(np.clip(Xh, -10, 10))
    pcs = centre_by(pcs, lib)
    nn = NearestNeighbors(n_neighbors=31).fit(pcs).kneighbors(pcs, return_distance=False)[:, 1:]
    cells["same_lib_nn"] = (lib[nn] == lib[:, None]).mean(1)
    cells[["rna_u1", "rna_u2"]] = umap.UMAP(n_neighbors=30, min_dist=0.3, random_state=0).fit_transform(pcs)

    # ATAC embedding (TF-IDF / LSI)
    B = A.copy()
    B.data[:] = 1
    pk = np.where(np.asarray(B.sum(0)).ravel() >= 0.02 * B.shape[0])[0]
    B = B[:, pk].tocsr()
    tf = sp.diags(1 / np.maximum(np.asarray(B.sum(1)).ravel(), 1)) @ B
    idf = np.log1p(B.shape[0] / np.maximum(np.asarray(B.sum(0)).ravel(), 1))
    T = (tf @ sp.diags(idf)).tocsr()
    T.data = np.log1p(T.data * 1e4)
    lsi = TruncatedSVD(31, random_state=0).fit_transform(T)[:, 1:]
    lsi = (lsi - lsi.mean(0)) / lsi.std(0)
    lsi = centre_by(lsi, lib)
    cells[["atac_u1", "atac_u2"]] = umap.UMAP(n_neighbors=30, min_dist=0.3, random_state=0).fit_transform(lsi)
    print(f"microglia: {len(cells)}; HVG {len(hv)}; ATAC peaks {len(pk)}")
    print("marker genes in DAM-up set:", cells.attrs["in_up"], "| in DAM-down set:", cells.attrs["in_dn"])
    cells.to_csv(CACHE, index=False)
    pd.Series({"in_up": ",".join(cells.attrs["in_up"]), "in_dn": ",".join(cells.attrs["in_dn"])}).to_csv(
        CACHE.with_suffix("").with_suffix(".sets.csv"))
    return cells


def scatter(ax, x, y, c, s=1.2, **kw):
    o = np.random.default_rng(0).permutation(len(x))
    sc = ax.scatter(np.asarray(x)[o], np.asarray(y)[o], c=np.asarray(c)[o] if not isinstance(c, str) else c,
                    s=s, lw=0, rasterized=True, **kw)
    ax.set_xticks([]), ax.set_yticks([])
    for sp_ in ("left", "bottom"):
        ax.spines[sp_].set_visible(False)
    return sc


def umap_axes(ax, kind):
    ax.set_xlabel(f"{kind} UMAP1", labelpad=1)
    ax.set_ylabel(f"{kind} UMAP2", labelpad=1)


def main():
    c = pd.read_csv(CACHE) if CACHE.exists() else build()
    sets = pd.read_csv(CACHE.with_suffix("").with_suffix(".sets.csv"), index_col=0).iloc[:, 0].fillna("")
    in_set = set(",".join(sets.astype(str)).split(","))
    lim = np.quantile(np.abs(c["score"]), 0.98)

    fig = mf.new_fig(183, 128)
    gs = fig.add_gridspec(2, 4, width_ratios=[1, 1, 1, 1.15])

    ax = fig.add_subplot(gs[0, 0])
    sc = scatter(ax, c["rna_u1"], c["rna_u2"], c["score"], cmap=mf.DIV, vmin=-lim, vmax=lim)
    umap_axes(ax, "RNA")
    ax.set_title("DAM RNA score", pad=2)
    cb = fig.colorbar(sc, ax=ax, shrink=0.4, aspect=10, pad=0.01)
    cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=5, width=0.4, length=1.5)
    mf.letter(ax, "a")

    ax = fig.add_subplot(gs[0, 1])
    for t in ("excluded", "mid", "low", "high"):
        m = c["tertile"] == t
        scatter(ax, c.loc[m, "rna_u1"], c.loc[m, "rna_u2"], TERT.get(t, "#F2F2F2"))
    umap_axes(ax, "RNA")
    ax.set_title("Within-donor thirds", pad=2)
    for t, lab in (("high", "DAM-high"), ("mid", "middle"), ("low", "DAM-low")):
        ax.scatter([], [], s=8, color=TERT[t], lw=0, label=f"{lab} ({(c['tertile'] == t).sum():,})")
    ax.legend(loc="upper left", bbox_to_anchor=(0, -0.06), handletextpad=0.1, borderaxespad=0, fontsize=5, labelspacing=0.2)
    mf.letter(ax, "b")

    ax = fig.add_subplot(gs[0, 2])
    for g in ("Normal", "HP", "AD"):
        m = c["group"] == g
        scatter(ax, c.loc[m, "rna_u1"], c.loc[m, "rna_u2"], GROUP[g])
        ax.scatter([], [], s=8, color=GROUP[g], lw=0, label=f"{GLABEL[g]} ({c.loc[m, 'donor'].nunique()})")
    umap_axes(ax, "RNA")
    ax.set_title("Donor group", pad=2)
    ax.legend(loc="upper left", bbox_to_anchor=(0, -0.06), handletextpad=0.1, borderaxespad=0, fontsize=5, labelspacing=0.2)
    mf.letter(ax, "c")

    # d: marker genes by within-donor third (dot plot)
    ax = fig.add_subplot(gs[0, 3])
    genes = HOMEO + DAMG
    tt = ["low", "mid", "high"]
    sub = c[c["tertile"].isin(tt)]
    mean = np.array([[sub.loc[sub["tertile"] == t, f"g_{g}"].mean() for t in tt] for g in genes])
    frac = np.array([[(sub.loc[sub["tertile"] == t, f"g_{g}"] > 0).mean() for t in tt] for g in genes])
    z = (mean - mean.mean(1, keepdims=True)) / np.maximum(mean.std(1, keepdims=True), 1e-9)
    yy, xx = np.meshgrid(np.arange(len(genes)), np.arange(len(tt)), indexing="ij")
    ax.scatter(xx.ravel(), yy.ravel(), s=frac.ravel() * 28 + 0.5, c=z.ravel(), cmap=mf.DIV, vmin=-1.3, vmax=1.3, lw=0)
    ax.set_xticks(range(3), ["DAM-low", "middle", "DAM-high"], rotation=30, ha="right")
    ax.set_yticks(range(len(genes)), [g + ("*" if g in in_set else "") for g in genes], fontstyle="italic")
    ax.set_ylim(len(genes) - 0.5, -0.5)
    ax.set_xlim(-0.6, 2.6)
    ax.axhline(len(HOMEO) - 0.5, color=mf.GRID, lw=0.6)
    ax.text(2.75, (len(HOMEO) - 1) / 2, "homeostatic", rotation=270, va="center", ha="left", fontsize=5.5, color=mf.MUTED)
    ax.text(2.75, len(HOMEO) + (len(DAMG) - 1) / 2, "DAM", rotation=270, va="center", ha="left", fontsize=5.5, color=mf.MUTED)
    for f_ in (0.25, 0.75):
        ax.scatter([], [], s=f_ * 28 + 0.5, color=mf.MUTED, lw=0, label=f"{int(f_ * 100)}%")
    ax.legend(title="detected", title_fontsize=5, fontsize=5, loc="upper left", bbox_to_anchor=(1.12, 1.0),
              handletextpad=0.1, labelspacing=0.3)
    ax.set_title("Marker genes", pad=2)
    ax.text(1.12, 0.62, "colour: row z\n* in score set", transform=ax.transAxes, fontsize=5, color=mf.MUTED, va="top")
    for s_ in ("left", "bottom"):
        ax.spines[s_].set_visible(False)
    ax.tick_params(length=0)
    mf.letter(ax, "d")

    ax = fig.add_subplot(gs[1, 0])
    sc = scatter(ax, c["atac_u1"], c["atac_u2"], c["score"], cmap=mf.DIV, vmin=-lim, vmax=lim)
    umap_axes(ax, "ATAC")
    ax.set_title("ATAC, coloured by RNA score", pad=2)
    mf.letter(ax, "e")

    # f: library mixing in the RNA PC space
    ax = fig.add_subplot(gs[1, 1])
    lb = c.groupby("library").agg(obs=("same_lib_nn", "mean"), n=("score", "size"), group=("group", "first"))
    lb["exp"] = lb["n"] / len(c)
    lb = lb.sort_values("exp")
    ax.scatter(lb["exp"], lb["obs"], s=10, color=[GROUP[g] for g in lb["group"]], marker="s", lw=0.4,
               edgecolor=[mf.INK if g == "Normal" else GROUP[g] for g in lb["group"]], zorder=3)
    hi = max(lb["obs"].max(), lb["exp"].max()) * 1.1
    ax.plot([0, hi], [0, hi], color=mf.NULLMEAN, lw=0.6, ls="--", zorder=1)
    ax.set_xlim(0, hi), ax.set_ylim(0, hi)
    ax.set_xlabel("Library share of all microglia")
    ax.set_ylabel("Share of 30 nearest neighbours\nfrom the same library")
    ax.set_title("Library mixing", pad=2)
    mf.letter(ax, "f")

    # g: per-donor share of cells above the cohort median, by group
    ax = fig.add_subplot(gs[1, 2])
    d = c.groupby("donor").agg(group=("group", "first"), n=("score", "size"),
                               hi=("homeostatic", lambda v: 1 - v.mean()))
    order = ["Normal", "HP", "AD"]
    rng = np.random.default_rng(1)
    for i, g in enumerate(order):
        dd = d[d["group"] == g]
        ax.scatter(i + rng.uniform(-0.18, 0.18, len(dd)), dd["hi"], s=np.clip(dd["n"] / 12, 3, 30),
                   color=GROUP[g], marker="s", lw=0.4, edgecolor=mf.INK if g == "Normal" else GROUP[g], zorder=3)
        ax.hlines(dd["hi"].median(), i - 0.3, i + 0.3, color=mf.INK, lw=0.8, zorder=4)
    ax.set_xticks(range(3), ["Ctrl", "HP", "AD"])
    ax.set_xlim(-0.6, 2.6)
    ax.set_ylabel("Share of microglia above\ncohort-median DAM score")
    ax.set_title("High-score share", pad=2)
    mf.letter(ax, "g")

    # h: score distribution per donor, ordered by Braak
    ax = fig.add_subplot(gs[1, 3])
    don = c.groupby("donor").agg(Braak=("Braak", "first"), group=("group", "first"), med=("score", "median"),
                                 n=("score", "size")).sort_values(["Braak", "med"], na_position="first")
    data = [c.loc[c["donor"] == dn_, "score"].to_numpy() for dn_ in don.index]
    bp = ax.boxplot(data, vert=False, widths=0.6, showfliers=False, patch_artist=True,
                    medianprops=dict(color=mf.INK, lw=0.7), whiskerprops=dict(lw=0.5), capprops=dict(lw=0.5),
                    boxprops=dict(lw=0.4))
    for b, g in zip(bp["boxes"], don["group"]):
        b.set_facecolor(GROUP[g])
    ax.axvline(np.median(c["score"]), color=mf.NULLMEAN, lw=0.6, ls="--")
    ax.set_yticks(range(1, len(don) + 1),
                  [f"{dn_}  B{'?' if np.isnan(b_) else int(b_)}" for dn_, b_ in zip(don.index, don["Braak"])], fontsize=4.5)
    ax.set_xlabel("DAM RNA score")
    ax.set_title("Score by donor", pad=2)
    ax.tick_params(axis="y", length=0)
    x_ = don.dropna(subset=["Braak"])
    mean_ = c.groupby("donor")["score"].mean().reindex(x_.index)
    rho, p_ = spearmanr(x_["Braak"], mean_)
    ax.set_xlabel(f"DAM RNA score\n(donor mean vs Braak: \u03c1 = {rho:.2f}, p = {p_:.2f})")
    mf.letter(ax, "h")

    mf.save(fig, "FigS1")


if __name__ == "__main__":
    main()
