"""10-minute talk: 10 slides (16:9) in Chinese and English, built from the manuscript figures.

    python scripts/make_talk_slides.py          # writes docs/slides/talk10_{zh,en}.pdf and slide PNGs

Key panels are cropped from the figures at 300 dpi (the figure functions are re-run with a save hook that
records every panel's bounding box), enlarged and placed with a conclusion-style title and at most three
short points per slide. Slides 2, 9 and 10 carry schematics drawn here. The spoken script is
docs/slides/talk10_script.md.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Ellipse, FancyArrowPatch, FancyBboxPatch
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import make_paper_figures as mf  # noqa: E402
import make_supp_chain_tf as ms  # noqa: E402

OUT = ROOT / "docs/slides"
OUT.mkdir(parents=True, exist_ok=True)
DPI = 300
NAVY, RED, TEAL, GREY, INK, LIGHT = "#3C5488", "#E64B35", "#00A087", "#7F7F7F", "#1A1A1A", "#F2F4F8"
W, H = 13.333, 7.5


# ---------------------------------------------------------------- panel crops
def render_panels(tmp: Path):
    boxes = {}

    def save(fig, name):
        plt.rcParams["savefig.bbox"] = "standard"          # pixel boxes must refer to the full canvas
        if fig.get_layout_engine() is not None:
            fig.get_layout_engine().set(w_pad=2 * mf.MM, h_pad=2 * mf.MM, wspace=0.04, hspace=0.06)
        fig.canvas.draw()
        fig.set_layout_engine("none")
        fig.set_dpi(DPI)
        fig.canvas.draw()
        r = fig.canvas.get_renderer()
        hh = fig.get_size_inches()[1] * DPI
        boxes[name] = [(bb.x0, hh - bb.y1, bb.x1, hh - bb.y0) for bb in (ax.get_tightbbox(r) for ax in fig.axes)]
        fig.savefig(tmp / f"{name}.png", dpi=DPI, bbox_inches=None, pad_inches=0)
        # each panel alone (other axes and figure-level texts hidden), so neighbours never leak into a crop
        texts = list(fig.texts)
        for t_ in texts:
            t_.set_visible(False)
        for i, ax in enumerate(fig.axes):
            for j, other in enumerate(fig.axes):
                other.set_visible(j == i)
            fig.savefig(tmp / f"{name}_{i}.png", dpi=DPI, bbox_inches=None, pad_inches=0)
        for ax in fig.axes:
            ax.set_visible(True)
        for t_ in texts:
            t_.set_visible(True)
        plt.close(fig)

    mf.save = save
    ms.mf.save = save
    mf.setup()
    for f in (mf.fig1, mf.fig2, mf.fig4, mf.fig6, ms.figS6, ms.figS8, ms.figS9):
        f()
    return boxes


def crop(tmp, boxes, name, axes_idx, pad=40, bottom_extra=0, right_extra=0, left_extra=0, top_cut=0):
    """Crop the union of the given axes' tight boxes (+ padding; extra margins in pixels at 300 dpi), each panel
    taken from its isolated render so that neighbouring panels never leak in."""
    b = np.array([boxes[name][i] for i in axes_idx])
    x0, y0 = max(b[:, 0].min() - pad - left_extra, 0), max(b[:, 1].min() - pad + top_cut, 0)
    x1, y1 = b[:, 2].max() + pad + right_extra, b[:, 3].max() + pad + bottom_extra
    box_ = (int(x0), int(y0), int(x1), int(y1))
    layers = []
    for i in axes_idx:
        im = Image.open(tmp / f"{name}_{i}.png").convert("RGB")
        canvas = Image.new("RGB", (box_[2] - box_[0], box_[3] - box_[1]), "white")
        canvas.paste(im.crop((box_[0], box_[1], min(box_[2], im.width), min(box_[3], im.height))), (0, 0))
        layers.append(np.asarray(canvas).astype(int))
    return np.min(layers, axis=0).astype(np.uint8)


# ---------------------------------------------------------------- slide primitives
def setup_fonts():
    for f in list(Path("/System/Library/Fonts/Supplemental").glob("Arial*.ttf")) + [Path("/System/Library/Fonts/Hiragino Sans GB.ttc")]:
        font_manager.fontManager.addfont(str(f))
    plt.rcParams.update({"font.family": ["Arial", "Hiragino Sans GB"], "pdf.fonttype": 42})


def Circle(xy, r, transform=None, **kw):
    """A round dot in figure coordinates (the figure is 16:9, so the x radius is scaled)."""
    return Ellipse(xy, 2 * r * H / W, 2 * r, transform=transform, **kw)


def slide(title, sub=None, n=None):
    fig = plt.figure(figsize=(W, H))
    fig.patch.set_facecolor("white")
    fig.add_artist(plt.Rectangle((0, 0.905), 1, 0.095, transform=fig.transFigure, color=LIGHT, zorder=-1))
    fig.text(0.035, 0.952, title, fontsize=23, fontweight="bold", color=INK, va="center")
    if sub:
        fig.text(0.035, 0.875, sub, fontsize=13.5, color=GREY, va="center")
    if n is not None:
        fig.text(0.975, 0.025, str(n), fontsize=11, color=GREY, ha="right")
    return fig


def place(fig, img, rect):
    ax = fig.add_axes(rect)
    ax.imshow(img, interpolation="lanczos")
    ax.set_axis_off()
    # keep aspect: shrink rect to the image aspect, centred
    h, w = img.shape[:2]
    fw, fh = rect[2] * W, rect[3] * H
    s = min(fw / w, fh / h)
    nw, nh = w * s / W, h * s / H
    ax.set_position([rect[0] + (rect[2] - nw) / 2, rect[1] + (rect[3] - nh) / 2, nw, nh])
    return ax


def points(fig, items, x=0.66, y=0.78, dy=0.14, size=15, width=0.31):
    for i, (head, body) in enumerate(items):
        yy = y - i * dy
        fig.add_artist(Circle((x, yy + 0.005), 0.006, transform=fig.transFigure, color=RED))
        fig.text(x + 0.018, yy, head, fontsize=size, fontweight="bold", color=INK, va="center", wrap=True)
        if body:
            fig.text(x + 0.018, yy - 0.045, body, fontsize=size - 3, color="#333333", va="center", wrap=True)


def box(fig, x, y, w, h, text, fc, ec=None, size=13, color=INK, bold=False):
    fig.add_artist(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.015", transform=fig.transFigure,
                                  fc=fc, ec=ec or fc, lw=1.4))
    fig.text(x + w / 2, y + h / 2, text, fontsize=size, ha="center", va="center", color=color,
             fontweight="bold" if bold else "normal", linespacing=1.35)


def arrow(fig, x0, y0, x1, y1, color=GREY):
    fig.add_artist(FancyArrowPatch((x0, y0), (x1, y1), transform=fig.transFigure, arrowstyle="-|>", mutation_scale=18,
                                   lw=1.8, color=color))


# ---------------------------------------------------------------- text (zh / en)
T = {
    "zh": {
        "t1": "阿尔茨海默病重塑胶质细胞的调控元件，\n而非全细胞共同的 DNA 损伤应答",
        "s1": "Alzheimer's disease remodels glial regulatory elements rather than a shared DNA-damage response",
        "who": "[报告人 · 单位 · 日期]",
        "t2": "核心问题：共同程序，还是特定细胞的元件重塑？",
        "s2": "最初的设想：斑块旁 DNA 损伤 → 染色质改变并留下\"记忆\"。它隐含一个判断：所有细胞共同应答",
        "m1": "图景一：所有细胞共同的程序", "m1b": "（如 DNA 损伤–修复）",
        "m2": "图景二：特定细胞中的元件重塑", "m2b": "（只在少数细胞中改写特定元件）",
        "cells": ["神经元", "星形胶质", "少突胶质", "小胶质", "OPC"],
        "data": "数据：SEA-AD（84 人 × 10 脑区 RNA；86 人 ATAC）· PsychAD（约 430 人）· 人海马 multiome（22 人）· 人 / 小鼠空间数据 · AD GWAS 与 eQTL",
        "t3": "关键方法：必须与匹配的随机基因比较",
        "s3": "PsychAD 兴奋性神经元（402 人）：DNA 修复程序与 AD 的关系",
        "p3": [("修复基因确实在\"下降\"", "置换检验 p 低至 0.00001"), ("但都落在灰条内", "灰条 = 表达量和基因长度匹配的随机基因"),
               ("所有基因都在一起漂移", "只有超出随机基因，才算特异变化")],
        "t4": "AD 相关的变化以细胞特异为主，胶质细胞最强",
        "s4": "SEA-AD 21 种细胞（RNA）与 16 种细胞（ATAC）；PsychAD 24 个亚类复现",
        "p4": [("共享比例只有 7–29%", "没有哪种细胞被共同程序主导"), ("特异基因 / 元件集中在胶质细胞", "小胶质细胞 354 个基因（偶然期望 63）"),
               ("两个队列间高度一致", "胶质细胞特异部分相关 0.52–0.58")],
        "t5": "DNA 修复在所有尺度上都没有特异改变",
        "s5": "左：各程序实际变化 vs \"随大流\"的预测；右：小鼠斑块 25 µm 以内 vs 100–300 µm",
        "p5": [("DDR ≈ 0，DAM 只在小胶质细胞升高", "cohesin 在各细胞中一起上升（共同变化）"),
               ("斑块旁 25 µm 也不变", "阳性对照 Trem2 / Cd68 富集 1.5 倍"), ("大队列排除 ±0.15 以上的效应", "\"有损伤，无特异应答\"")],
        "t6": "图谱越大，假的\"通路变化\"越多",
        "s6": "PsychAD 神经元供体随机抽样：50 个 Hallmark 通路中 p < 0.05 的比例",
        "p6": [("自身检验：20% → 90%", "随样本量一路上升"), ("与匹配随机基因比较：6–19%", "真正特异的变化不增加"),
               ("对大型图谱的提醒", "已发表的差异基因 88% 可靠，模块层面只有 25%")],
        "t7": "小胶质细胞 DAM 改写了数百个调控元件，并逐供体复现",
        "s7": "左：SEA-AD 同一供体内 DAM 样 vs 稳态（23 人）；右：独立的人海马队列，状态由同一个核的 RNA 定义",
        "p7": [("115 个开放、121 个关闭", "655 个基因调控区改变；深度匹配避免假\"关闭\""), ("21 / 21 名供体方向一致", "不依赖转移来的细胞标签"),
               ("伏笔：RASGEF1C 调控区关闭", "")],
        "t8": "疾病状态与遗传风险交汇于 RASGEF1C 的一对增强子",
        "s8": "上：AD GWAS（红 = 4 个 SNP 的可信集）；中：各元件在 DAM 中的变化；下：基因与增强子 e1、e2",
        "p8": [("79% 的遗传信号落在 e1、e2", "两个在 DAM 中关闭的小胶质细胞增强子"),
               ("同一个核中只与 RASGEF1C 相关", "z = 6.0、4.7；500 kb 内唯一")],
        "t9": "风险等位基因降低小胶质细胞的 RASGEF1C",
        "s9": "证据链：每一环在相关性层面都有支持",
        "chain": ["AD 风险变异\n4 个连锁 SNP", "小胶质细胞\n增强子 e1 / e2", "在 DAM 中关闭\nlog2FC −1.5 / −1.2",
                  "与 RASGEF1C 相关\n同核 z = 6.0 / 4.7", "风险等位基因\n降低 RASGEF1C"],
        "eqtl": "外部单细胞核 eQTL（391 人）：小胶质细胞主 eQTL 正是可信集 SNP（t = 11.6），与 AD 共定位 PP = 0.997",
        "model": "模型：风险等位基因在稳态小胶质细胞中\"提前\"削弱了 DAM 才会关闭的增强子",
        "mitf": "上游：DAM 染色质由 MITF 等因子写入（327 个候选中排第一，独立确认 2026 年的报道）",
        "t10": "结论与下一步",
        "c": [("变化是细胞特异的", "胶质细胞最强，跨队列复现"), ("有损伤，无修复应答", "DNA 修复在所有尺度上不变；大图谱通路结论易虚高"),
              ("RASGEF1C 增强子承载 AD 风险", "疾病状态与遗传风险作用在同一对元件上")],
        "next": "下一步（人 iPSC 小胶质细胞）", "steps": ["CRISPRi 关闭\ne1 / e2", "测 RASGEF1C\n是否下降", "编辑 4 个 SNP\n找因果变异"],
        "thanks": "谢谢！ 数据来自 SEA-AD、PsychAD 与公开数据的贡献者",
    },
    "en": {
        "t1": "Alzheimer's disease remodels glial regulatory elements\nrather than a shared DNA-damage response",
        "s1": "Donor-level analysis of public single-nucleus RNA, chromatin, spatial and genetic data",
        "who": "[Speaker · Affiliation · Date]",
        "t2": "Core question: a shared program, or remodelling in specific cells?",
        "s2": "Original idea: DNA damage near plaques → chromatin change with \"memory\" — which assumes a response shared by all cells",
        "m1": "Model 1: a program shared by all cells", "m1b": "(e.g. DNA damage and repair)",
        "m2": "Model 2: element remodelling in specific cells", "m2b": "(specific elements rewritten in a few cell types)",
        "cells": ["Neurons", "Astro", "Oligo", "Microglia", "OPC"],
        "data": "Data: SEA-AD (RNA 84 donors × 10 regions; ATAC 86) · PsychAD (~430) · hippocampal multiome (22) · human / mouse spatial · AD GWAS and eQTL",
        "t3": "Key method: compare with matched random genes",
        "s3": "PsychAD excitatory neurons (402 donors): DNA-repair programs vs AD",
        "p3": [("Repair genes do \"fall\"", "permutation p as low as 0.00001"), ("But all lie in the grey bars", "grey = random genes matched on expression and length"),
               ("All genes drift together", "only change beyond random genes is specific")],
        "t4": "AD-associated change is mostly cell-type-specific, strongest in glia",
        "s4": "SEA-AD, 21 cell types (RNA) and 16 (ATAC); replicated in 24 PsychAD subclasses",
        "p4": [("Shared fraction only 7–29%", "no cell type is dominated by a shared program"),
               ("Specific genes / elements in glia", "microglia: 354 genes (63 expected)"), ("Consistent across cohorts", "glial specific components r = 0.52–0.58")],
        "t5": "DNA repair shows no specific change at any scale",
        "s5": "Left: observed change vs that predicted from other cell types; right: mouse, ≤ 25 µm vs 100–300 µm from plaques",
        "p5": [("DDR ≈ 0; DAM rises only in microglia", "cohesin rises everywhere (shared change)"),
               ("No change within 25 µm of plaques", "positive controls Trem2 / Cd68 enriched 1.5-fold"),
               ("Effects beyond ±0.15 excluded", "\"damage without a specific response\"")],
        "t6": "The larger the atlas, the more false pathway \"changes\"",
        "s6": "PsychAD neurons, donors subsampled: share of 50 Hallmark pathways with p < 0.05",
        "p6": [("Self-contained test: 20% → 90%", "rises with cohort size"), ("Against matched genes: 6–19%", "specific change does not grow"),
               ("A caution for large atlases", "published DEGs 88% reliable; module-level claims 25%")],
        "t7": "Microglial DAM rewrites hundreds of elements, replicated donor by donor",
        "s7": "Left: SEA-AD, DAM-like vs homeostatic within donors (23); right: independent hippocampal cohort, state from each nucleus's own RNA",
        "p7": [("115 opened, 121 closed", "655 gene domains; depth matching avoids false closing"), ("21 / 21 donors concordant", "no transferred labels needed"),
               ("Note: RASGEF1C domain closes", "")],
        "t8": "Disease state and genetic risk converge on a RASGEF1C enhancer pair",
        "s8": "Top: AD GWAS (red, 4-SNP credible set); middle: DAM change of each element; bottom: gene and enhancers e1, e2",
        "p8": [("79% of the genetic signal in e1 / e2", "two microglial enhancers that close in DAM"),
               ("Linked to RASGEF1C only", "same-nucleus z = 6.0, 4.7; unique within 500 kb")],
        "t9": "The risk allele lowers RASGEF1C in microglia",
        "s9": "The evidence chain: every link supported at the level of association",
        "chain": ["AD risk variants\n4 linked SNPs", "Microglial\nenhancers e1 / e2", "Close in DAM\nlog2FC −1.5 / −1.2",
                  "Track RASGEF1C\nsame-nucleus z 6.0 / 4.7", "Risk allele\nlowers RASGEF1C"],
        "eqtl": "External single-nucleus eQTL (391 donors): the lead microglial eQTL is a credible-set SNP (t = 11.6); coloc with AD PP = 0.997",
        "model": "Model: the risk allele weakens, in homeostatic microglia, enhancers that normally close only in DAM",
        "mitf": "Upstream: DAM chromatin is written by MITF and partners (ranked 1st of 327; independent confirmation of 2026 reports)",
        "t10": "Conclusions and next steps",
        "c": [("Change is cell-type-specific", "strongest in glia, replicated across cohorts"),
              ("Damage without a repair response", "DNA repair unchanged at all scales; pathway claims inflate in large atlases"),
              ("RASGEF1C enhancers carry AD risk", "disease state and genetic risk act on the same elements")],
        "next": "Next (human iPSC-derived microglia)", "steps": ["CRISPRi of\ne1 / e2", "Measure\nRASGEF1C", "Edit the 4 SNPs\nto find the causal one"],
        "thanks": "Thank you! Data from SEA-AD, PsychAD and all public data contributors",
    },
}


def build(lang, crops):
    t = T[lang]
    pdf = PdfPages(OUT / f"talk10_{lang}.pdf")
    figs = []

    # 1 title
    fig = plt.figure(figsize=(W, H))
    fig.add_artist(plt.Rectangle((0, 0), 1, 1, transform=fig.transFigure, color=NAVY, zorder=-2))
    fig.text(0.07, 0.62, t["t1"], fontsize=32, fontweight="bold", color="white", va="center", linespacing=1.4)
    fig.text(0.07, 0.42, t["s1"], fontsize=15, color="#DDE3EF", va="center")
    fig.text(0.07, 0.18, t["who"], fontsize=15, color="#DDE3EF")
    figs.append(fig)

    # 2 the question
    fig = slide(t["t2"], t["s2"], 2)
    for k, (x0, title, sub, col) in enumerate(((0.06, t["m1"], t["m1b"], GREY), (0.54, t["m2"], t["m2b"], RED))):
        box(fig, x0, 0.25, 0.40, 0.55, "", "#FAFAFA", "#DDDDDD")
        fig.text(x0 + 0.20, 0.75, title, fontsize=16, fontweight="bold", ha="center", color=col)
        fig.text(x0 + 0.20, 0.705, sub, fontsize=12.5, ha="center", color=GREY)
        for i, c in enumerate(t["cells"]):
            xx = x0 + 0.05 + i * 0.075
            glia = i >= 1
            fc = (RED if (k == 1 and glia) else ("#C9D3E6" if k == 1 else GREY))
            fig.add_artist(Circle((xx, 0.52), 0.027, transform=fig.transFigure, color=fc, alpha=0.9))
            fig.text(xx, 0.455, c, fontsize=10.5, ha="center")
            if k == 0:
                arrow(fig, xx, 0.575, xx, 0.635, GREY)
            elif glia:
                for j in range(3):
                    fig.add_artist(plt.Rectangle((xx - 0.02 + j * 0.014, 0.34), 0.01, 0.035, transform=fig.transFigure,
                                                 color=(RED if j != 1 else NAVY)))
        if k == 1:
            for xx, col_, lab in ((x0 + 0.11, RED, "元件开放" if lang == "zh" else "element opened"),
                                  (x0 + 0.24, NAVY, "元件关闭" if lang == "zh" else "element closed")):
                fig.add_artist(plt.Rectangle((xx, 0.282), 0.012, 0.022, transform=fig.transFigure, color=col_))
                fig.text(xx + 0.018, 0.293, lab, fontsize=11, va="center", color=GREY)
    fig.text(0.5, 0.13, t["data"], fontsize=12, ha="center", color="#333333", wrap=True)
    figs.append(fig)

    # 3 method: 2b
    fig = slide(t["t3"], t["s3"], 3)
    place(fig, crops["2b"], [0.04, 0.06, 0.56, 0.76])
    points(fig, t["p3"])
    figs.append(fig)

    # 4 cell-type specificity: 1d, 1e, S8c
    fig = slide(t["t4"], t["s4"], 4)
    place(fig, crops["1de"], [0.01, 0.06, 0.56, 0.78])
    place(fig, crops["S8c"], [0.58, 0.42, 0.41, 0.42])
    points(fig, t["p4"], x=0.62, y=0.36, dy=0.11, size=13.5, width=0.34)
    figs.append(fig)

    # 5 DNA repair: 1f + 2d
    fig = slide(t["t5"], t["s5"], 5)
    place(fig, crops["1f"], [0.02, 0.08, 0.33, 0.76])
    place(fig, crops["2d"], [0.36, 0.08, 0.32, 0.76])
    points(fig, t["p5"], x=0.70, y=0.74, dy=0.15, size=14)
    figs.append(fig)

    # 6 inflation: S9a
    fig = slide(t["t6"], t["s6"], 6)
    place(fig, crops["S9a"], [0.04, 0.06, 0.56, 0.76])
    points(fig, t["p6"])
    figs.append(fig)

    # 7 DAM elements: 4a + 4e
    fig = slide(t["t7"], t["s7"], 7)
    place(fig, crops["4a"], [0.02, 0.08, 0.32, 0.76])
    place(fig, crops["4e"], [0.35, 0.08, 0.33, 0.76])
    points(fig, t["p7"], x=0.70, y=0.74, dy=0.15, size=14)
    figs.append(fig)

    # 8 RASGEF1C locus: 6b
    fig = slide(t["t8"], t["s8"], 8)
    place(fig, crops["6b"], [0.03, 0.06, 0.62, 0.76])
    points(fig, t["p8"], x=0.68, y=0.66, dy=0.18)
    figs.append(fig)

    # 9 chain + S6e top
    fig = slide(t["t9"], t["s9"], 9)
    xs = np.linspace(0.04, 0.80, 5)
    for i, (x, txt) in enumerate(zip(xs, t["chain"])):
        box(fig, x, 0.60, 0.16, 0.17, txt, "#FDECEA" if i in (0, 4) else "#EEF1F7", RED if i in (0, 4) else NAVY, size=13,
            bold=i == 4)
        if i < 4:
            arrow(fig, x + 0.163, 0.685, xs[i + 1] - 0.004, 0.685, NAVY)
    fig.text(0.04, 0.50, t["eqtl"], fontsize=13.5, color="#333333")
    box(fig, 0.04, 0.33, 0.92, 0.10, t["model"], "#FDECEA", RED, size=16, bold=True)
    fig.text(0.04, 0.22, t["mitf"], fontsize=13.5, color="#333333")
    figs.append(fig)

    # 10 conclusions
    fig = slide(t["t10"], None, 10)
    points(fig, t["c"], x=0.05, y=0.76, dy=0.16, size=17, width=0.5)
    fig.text(0.60, 0.78, t["next"], fontsize=16, fontweight="bold", color=NAVY)
    for i, s in enumerate(t["steps"]):
        box(fig, 0.60, 0.58 - i * 0.16, 0.30, 0.11, s, "#EEF1F7", NAVY, size=13.5)
        if i < 2:
            arrow(fig, 0.75, 0.575 - i * 0.16, 0.75, 0.535 - i * 0.16, NAVY)
    fig.text(0.5, 0.06, t["thanks"], fontsize=14, ha="center", color=GREY)
    figs.append(fig)

    for i, f in enumerate(figs, 1):
        pdf.savefig(f)
        f.savefig(OUT / f"talk10_{lang}_{i:02d}.png", dpi=150)
        plt.close(f)
    pdf.close()


def main():
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        boxes = render_panels(tmp)
        crops = {"1de": crop(tmp, boxes, "Fig1", [1, 2], pad=15, bottom_extra=75), "1f": crop(tmp, boxes, "Fig1", [3], pad=8),
                 "2b": crop(tmp, boxes, "Fig2", [2]), "2d": crop(tmp, boxes, "Fig2", [4], pad=6),
                 "4a": crop(tmp, boxes, "Fig4", [0]), "4e": crop(tmp, boxes, "Fig4", [4], pad=8, left_extra=230, bottom_extra=70, right_extra=40),
                 "6b": crop(tmp, boxes, "Fig6", [1, 2, 3]), "S8c": crop(tmp, boxes, "FigS8", [2], pad=12),
                 "S9a": crop(tmp, boxes, "FigS9", [0])}
    setup_fonts()
    for lang in ("zh", "en"):
        build(lang, crops)
    print("wrote", sorted(p.name for p in OUT.glob("talk10_*.pdf")))


if __name__ == "__main__":
    main()
