"""Microglial states beyond DAM: programs, pathology, and the TF motifs that mark each state (FigS3).

    python scripts/microglia_states.py          # writes results/microglia_states/

Programs (canonical marker sets, fixed before looking at the data): homeostatic, DAM (Keren-Shaul),
interferon response, inflammatory / NF-kB, MHC-II antigen presentation, lysosomal (CLEAR targets),
lipid handling, perivascular macrophage, proliferation, and the immediate-early / heat-shock genes
induced by tissue handling (Marsh et al. 2022), which flag ex vivo activation rather than biology.

1. SEA-AD MTG RNA: program score of each supertype (pooled over donors, z across supertypes).
2. Per donor, all parenchymal microglia pooled (Micro-PVM_2, 2_1, 2_3, 3, 4): program score vs CPS and
   vs grey-matter 6E10 (age, sex, PMI, log nuclei), p_set against 200 expression-matched random sets;
   and each supertype's share of microglia vs CPS (Spearman).
3. SEA-AD snATAC: motif-family activity of each supertype against homeostatic Micro-PVM_2 within donor
   (depth-matched, 20 draws; donors with >= 10 nuclei of the state), same scorer as scripts/dam_tf_grn.py.
4. Hippocampus multiome: per-nucleus program scores on the FigS1 UMAP.
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from ad_ddr.signatures import DAM as DAM_GENES
from ad_ddr.stats import _covar_matrix, _resid
from dam_tf_grn import MotifScorer, lcpm
from run_dam_peaks import HOM, flip_test, load, thin_mean_diff
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/microglia_states"
OUT.mkdir(parents=True, exist_ok=True)
PROGRAMS = {
    "homeostatic": ["P2RY12", "CX3CR1", "TMEM119", "CSF1R", "SELPLG", "SALL1", "GPR34", "OLFML3", "FCRLS", "SIGLECH"],
    "DAM": list(DAM_GENES),
    "interferon": ["IFIT1", "IFIT2", "IFIT3", "ISG15", "MX1", "MX2", "OAS1", "OAS2", "RSAD2", "IFI44L", "IFI6", "STAT1",
                   "IRF7", "XAF1"],
    "inflammatory": ["NFKBIA", "TNF", "IL1B", "CCL3", "CCL4", "NFKBIZ", "TNFAIP3", "IER3", "CXCL8", "CCL2"],
    "MHC-II": ["HLA-DRA", "HLA-DRB1", "HLA-DPA1", "HLA-DPB1", "HLA-DQA1", "HLA-DQB1", "CD74", "CIITA"],
    "lysosomal": ["CTSB", "CTSD", "CTSL", "CTSS", "LAMP1", "LAMP2", "ATP6V1H", "HEXA", "HEXB", "GRN", "NPC1", "NPC2",
                  "MCOLN1", "GBA1", "LIPA"],
    "lipid": ["PLIN2", "ACSL1", "CD36", "SOAT1", "ABCA1", "ABCG1", "APOC1", "LPL", "FABP5", "MSR1"],
    "perivascular": ["MRC1", "LYVE1", "CD163", "F13A1", "SIGLEC1", "MS4A7", "STAB1", "COLEC12"],
    "proliferation": ["MKI67", "TOP2A", "CENPF", "NUSAP1", "ASPM", "TPX2", "BIRC5", "CDK1"],
    "ex vivo / IEG": ["FOS", "FOSB", "JUN", "JUNB", "EGR1", "HSPA1A", "HSPA1B", "DUSP1", "IER2", "KLF2"],
}
STATES = ["Micro-PVM_2", "Micro-PVM_2_1-SEAAD", "Micro-PVM_2_3-SEAAD", "Micro-PVM_3-SEAAD", "Micro-PVM_4-SEAAD",
          "Micro-PVM_1"]
PAREN = STATES[:5]
BASE = ["age", "sex", "pmi", "lognuc"]


def main():
    rng = np.random.default_rng(0)
    a = ad.read_h5ad(ROOT / "data/raw/pseudobulk/Immune.h5ad")
    a = a[a.obs["Brain Region"] == "MTG"]
    o, X = a.obs, sp.csr_matrix(a.X)
    genes = pd.Index(a.var_names.str.upper())
    sev = o["Severely Affected Donor"].astype(str).eq("Y")

    # ---- 1. supertype x program
    rows = []
    for st in STATES:
        m = (o["Supertype"].astype(str) == st).to_numpy() & ~sev.to_numpy()
        c = np.asarray(X[m].sum(0)).ravel()
        rows.append(np.log2(c / c.sum() * 1e6 + 1))
    LS = pd.DataFrame(np.array(rows), index=STATES, columns=genes)
    LS = LS.T.groupby(level=0).mean().T
    expressed = LS.columns[(LS >= np.log2(10 + 1)).any(axis=0)]
    Z = (LS[expressed] - LS[expressed].mean(0)) / LS[expressed].std(0).replace(0, 1)
    H = pd.DataFrame({p: Z[[g for g in gs if g in Z.columns]].mean(1) for p, gs in PROGRAMS.items()})
    H.to_csv(OUT / "supertype_programs.csv")
    nuc = o.groupby(o["Supertype"].astype(str))["Number of nuclei"].sum()
    print("1. program z by supertype (MTG):\n", H.round(2).to_string(), "\n", nuc.reindex(STATES).to_string())

    # ---- 2. per donor, parenchymal microglia
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")["number of 6e10 positive objects per area"]
    dons, L, info = [], [], []
    for d, idx in o.groupby("Donor ID").indices.items():
        sub = o.iloc[idx]
        if sev.iloc[idx].any():
            continue
        m = idx[sub["Supertype"].astype(str).isin(PAREN).to_numpy()]
        n = o["Number of nuclei"].iloc[m].sum()
        if n < 50:
            continue
        c = np.asarray(X[m].sum(0)).ravel()
        L.append(np.log2(c / c.sum() * 1e6 + 1))
        info.append({"donor": d, "lognuc": np.log10(n), "age": pd.to_numeric(sub["Age at Death"].iat[0], errors="coerce"),
                     "sex": str(sub["Sex"].iat[0]), "pmi": pd.to_numeric(sub["PMI"].iat[0], errors="coerce"),
                     "cps": cps.get(d, np.nan),
                     "plaque": np.log10(pd.to_numeric(gm.get(d, np.nan), errors="coerce") * 1e6 + 1),
                     **{f"share_{s}": o["Number of nuclei"].iloc[idx[(sub["Supertype"].astype(str) == s).to_numpy()]].sum()
                        / max(o["Number of nuclei"].iloc[idx[sub["Supertype"].astype(str).str.startswith("Micro")
                                                             .to_numpy()]].sum(), 1) for s in STATES}})
    L = np.array(L)
    I = pd.DataFrame(info)
    keep_g = (L >= np.log2(1 + 1)).mean(0) >= 0.5
    Lk, gk = L[:, keep_g], genes[keep_g]
    Zd = (Lk - Lk.mean(0)) / np.where(Lk.std(0) > 0, Lk.std(0), 1)
    mexp = Lk.mean(0)
    dec = pd.qcut(pd.Series(mexp).rank(method="first"), 10, labels=False).to_numpy()
    gpos = pd.Series(np.arange(len(gk)), index=gk)
    gpos = gpos[~gpos.index.duplicated()]
    out = []
    for expo in ("cps", "plaque"):
        m = I[[expo] + BASE].notna().all(1).to_numpy()
        C = _covar_matrix(I[m], BASE)
        xr = _resid(I.loc[m, expo].to_numpy(float), C)
        for p, gs in PROGRAMS.items():
            gi = gpos.reindex([g for g in gs if g in gpos.index]).dropna().astype(int).to_numpy()
            if len(gi) < 3:
                continue
            s_ = _resid(Zd[m][:, gi].mean(1), C)
            r = np.corrcoef(xr, s_)[0, 1]
            null = np.array([np.corrcoef(xr, _resid(Zd[m][:, [rng.choice(np.flatnonzero(dec == dec[g])) for g in gi]].mean(1),
                                                     C))[0, 1] for _ in range(200)])
            perm = np.array([np.corrcoef(rng.permutation(xr), s_)[0, 1] for _ in range(2000)])
            out.append({"program": p, "exposure": expo, "n_genes": len(gi), "n_donors": int(m.sum()), "r": r,
                        "p_perm": (np.sum(np.abs(perm) >= abs(r)) + 1) / 2001, "null_mean": null.mean(),
                        "p_set": (np.sum(np.abs(null - null.mean()) >= abs(r - null.mean())) + 1) / 201})
    P = pd.DataFrame(out)
    P["q_set"] = P.groupby("exposure")["p_set"].transform(lambda v: stats.false_discovery_control(v))
    P.to_csv(OUT / "program_pathology.csv", index=False)
    print("\n2. parenchymal microglia programs vs pathology (donor level):\n",
          P.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    sh = []
    for s in STATES:
        k = I[["cps", f"share_{s}"]].notna().all(1)
        rr = stats.spearmanr(I.loc[k, "cps"], I.loc[k, f"share_{s}"])
        sh.append({"supertype": s, "median_share": I[f"share_{s}"].median(), "rho_cps": rr.statistic, "p": rr.pvalue})
    SH = pd.DataFrame(sh)
    SH.to_csv(OUT / "supertype_share_cps.csv", index=False)
    print("\n   supertype share of microglia vs CPS:\n", SH.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---- 3. motif families per state vs homeostatic
    T = pd.read_csv(ROOT / "results/dam_tf/motif_activity.csv")
    z = np.load(ROOT / "results/dam_tf/motif_hits_p1e4.npz", allow_pickle=True)
    names = list(z["names"])
    cols = [names.index(m) for m in T["motif"]]
    hits, gc = z["hits"][:, cols], z["gc"]
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    acc = np.log2((res["cpm_dam"] + res["cpm_hom"]).to_numpy() / 2 + 1)
    bins = (pd.qcut(pd.Series(gc).rank(method="first"), 10, labels=False).to_numpy() * 10
            + pd.qcut(pd.Series(acc).rank(method="first"), 10, labels=False).to_numpy())
    S = MotifScorer(hits, bins)
    peaks = pd.Index((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    pix = peaks.get_indexer(res["peak"])
    rows_, M = load(ROOT / "data/processed/atac_pb_micro")
    n = rows_.groupby(["donor", "subclass"])["n_nuclei"].sum().unstack(fill_value=0)
    st_rows = []
    for st in STATES[1:]:
        if st not in n.columns:
            continue
        dd = [x for x in n.index if n.at[x, st] >= 10 and n.at[x, HOM] >= 30]
        if len(dd) < 6:
            print(f"   {st}: {len(dd)} donors with >= 10 nuclei, skipped")
            continue
        D = []
        for x in dd:
            a_ = np.asarray(M[rows_.index[(rows_["donor"] == x) & (rows_["subclass"] == st)].to_numpy()].sum(0)).ravel()
            b_ = np.asarray(M[rows_.index[(rows_["donor"] == x) & (rows_["subclass"] == HOM)].to_numpy()].sum(0)).ravel()
            D.append(thin_mean_diff(a_, b_, rng, lambda c: lcpm(c)[pix]))
        mean, t, p, q = flip_test(S(np.array(D)), 2000, rng)
        st_rows.append(pd.DataFrame({"state": st, "n_donors": len(dd), "motif": T["motif"], "family": T["family"],
                                     "t": t, "q": q}))
        top = st_rows[-1].sort_values("t", key=np.abs, ascending=False).drop_duplicates("family").head(6)
        print(f"\n3. {st} vs Micro-PVM_2 ({len(dd)} donors): top families "
              + "; ".join(f"{r.family} {r.t:+.1f} (q {r.q:.2g})" for r in top.itertuples()))
    ST = pd.concat(st_rows)
    ST.to_csv(OUT / "state_motif_activity.csv", index=False)

    # ---- 4. hippocampus per-nucleus program scores
    Lh, gn = load_libs()
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    R_ = sp.vstack([Lh[l]["rna_cells"][(Lh[l]["cells"]["subclass"] == "Microglia").to_numpy()]
                    for l in cache["library"].unique()]).tocsr()
    tot = np.asarray(R_.sum(1)).ravel()
    Ln = (sp.diags(1e4 / np.maximum(tot, 1)) @ R_).tocsc()
    Ln.data = np.log1p(Ln.data)
    gu = pd.Series(np.arange(len(gn)), index=gn.str.upper())
    gu = gu[~gu.index.duplicated()]
    mu = np.asarray(Ln.mean(0)).ravel()
    sd = np.sqrt(np.maximum(np.asarray(Ln.multiply(Ln).mean(0)).ravel() - mu ** 2, 1e-12))
    for p, gs in PROGRAMS.items():
        gi = gu.reindex([g for g in gs if g in gu.index]).dropna().astype(int).to_numpy()
        gi = gi[(np.asarray((R_[:, gi] > 0).mean(0)).ravel() >= 0.01)]
        cache[f"prog_{p}"] = ((Ln[:, gi].toarray() - mu[gi]) / sd[gi]).mean(1) if len(gi) else np.nan
    cache[["library", "donor", "rna_u1", "rna_u2", "score"] + [f"prog_{p}" for p in PROGRAMS]].to_csv(
        OUT / "hippo_cell_programs.csv.gz", index=False)
    cc = cache[[f"prog_{p}" for p in PROGRAMS] + ["score"]].corr().round(2)
    print("\n4. hippocampus per-nucleus program correlations with the DAM RNA score:\n", cc["score"].to_string())


if __name__ == "__main__":
    main()
