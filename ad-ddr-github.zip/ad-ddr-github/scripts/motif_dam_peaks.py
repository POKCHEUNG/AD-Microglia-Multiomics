"""Transcription-factor motif enrichment in DAM-open / DAM-closed peaks (no external motif tools).

    python scripts/motif_dam_peaks.py --out results/dam_peaks

500 bp around each peak centre (hg38, UCSC hg38.fa.gz streamed once). Background: peaks
tested but not differential, sampled 3:1 within GC-content deciles and the same
promoter/distal mix as each foreground set. Motifs: JASPAR 2024 CORE vertebrates
non-redundant PFMs, log-odds with 0.25 background and 0.8 total pseudocount; a sequence
has a motif if any window on either strand scores >= 85% of the motif's score range.
Fisher's exact test per motif, BH across motifs.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
CODE = np.full(256, 4, dtype=np.int8)
for i, b in enumerate("ACGT"):
    CODE[ord(b)] = CODE[ord(b.lower())] = i


def read_jaspar(path: Path) -> dict[str, np.ndarray]:
    motifs, name, rows = {}, None, []
    for line in open(path):
        line = line.strip()
        if line.startswith(">"):
            if name:
                motifs[name] = np.array(rows, float).T                # w x 4 (A C G T)
            name, rows = line[1:].replace("\t", " "), []
        elif line:
            rows.append([float(x) for x in line.split("[")[1].split("]")[0].split()])
    if name:
        motifs[name] = np.array(rows, float).T
    return motifs


def fetch(fasta: Path, regions: pd.DataFrame) -> list[str]:
    """Sequences for regions (chrom, start, end), one streaming pass over a gzipped FASTA."""
    want = {c: d for c, d in regions.groupby("chrom")}
    seqs = {}
    chrom, buf = None, []

    def flush():
        if chrom in want:
            s = "".join(buf)
            for i, r in want[chrom].iterrows():
                seqs[i] = s[r["start"]:r["end"]]
    with gzip.open(fasta, "rt") as fh:
        for line in fh:
            if line.startswith(">"):
                flush()
                chrom, buf = line[1:].split()[0], []
            elif chrom in want:
                buf.append(line.rstrip())
        flush()
    return [seqs.get(i, "") for i in regions.index]


def onehot(seqs: list[str], L: int) -> np.ndarray:
    X = np.full((len(seqs), L), 4, dtype=np.int8)
    for i, s in enumerate(seqs):
        b = np.frombuffer(s[:L].encode(), dtype=np.uint8)
        X[i, :len(b)] = CODE[b]
    return X


def has_motif(X: np.ndarray, pfm: np.ndarray, frac: float = 0.85) -> np.ndarray:
    p = (pfm + 0.2) / (pfm + 0.2).sum(1, keepdims=True)
    pwm = np.log2(p / 0.25)
    pwm5 = np.vstack([pwm.T, np.full((1, len(pwm)), -10.0)])           # N base -> strongly penalised
    lo, hi = pwm.min(1).sum(), pwm.max(1).sum()
    thr = lo + frac * (hi - lo)
    w, L = len(pwm), X.shape[1]
    hit = np.zeros(len(X), bool)
    for mat in (pwm5, np.vstack([pwm[::-1, ::-1].T, np.full((1, len(pwm)), -10.0)])):   # forward, reverse complement
        sc = np.zeros((len(X), L - w + 1))
        for k in range(w):
            sc += mat[X[:, k:k + L - w + 1], k]
        hit |= (sc >= thr).any(1)
    return hit


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/dam_peaks")
    ap.add_argument("--width", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    rng = np.random.default_rng(args.seed)
    res = pd.read_csv(out / "dam_peaks_all.csv.gz")
    mid = (res["start"] + res["end"]) // 2
    res["s"], res["e"] = (mid - args.width // 2).clip(lower=0), mid + args.width // 2

    fg = {c: res.index[res["call"] == c].to_numpy() for c in ("DAM-open", "DAM-closed")}
    ns = res.index[res["call"] == "ns"].to_numpy()
    cand = rng.choice(ns, size=min(len(ns), 60000), replace=False)
    need = np.unique(np.concatenate([*fg.values(), cand]))
    reg = res.loc[need, ["chrom", "s", "e"]].rename(columns={"s": "start", "e": "end"})
    seqs = pd.Series(fetch(ROOT / "data/ref/hg38.fa.gz", reg), index=need)
    gc = seqs.map(lambda s: (s.upper().count("G") + s.upper().count("C")) / max(len(s), 1))
    motifs = read_jaspar(ROOT / "data/ref/motifs/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt")
    print(f"{len(motifs)} motifs; sequences fetched: {len(seqs)}")

    rows = []
    for call, idx in fg.items():
        if len(idx) < 20:
            continue
        gbin = pd.qcut(gc, 10, labels=False, duplicates="drop")
        bg = []
        for (b, cls), d in pd.DataFrame({"b": gbin[idx], "cls": res.loc[idx, "class"]}).groupby(["b", "cls"]):
            pool = cand[(gbin[cand].to_numpy() == b) & (res.loc[cand, "class"].to_numpy() == cls)]
            bg.extend(rng.choice(pool, size=min(len(pool), 3 * len(d)), replace=False))
        bg = np.array(bg)
        Xf, Xb = onehot(seqs[idx].tolist(), args.width), onehot(seqs[bg].tolist(), args.width)
        for name, pfm in motifs.items():
            hf, hb = has_motif(Xf, pfm), has_motif(Xb, pfm)
            a, b = hf.sum(), len(hf) - hf.sum()
            c, d = hb.sum(), len(hb) - hb.sum()
            orr, p = stats.fisher_exact([[a, b], [c, d]])
            rows.append({"set": call, "motif": name, "frac_fg": a / len(hf), "frac_bg": c / len(hb),
                         "odds_ratio": orr, "p": p, "n_fg": len(hf), "n_bg": len(hb)})
        print(f"  {call}: {len(idx)} peaks vs {len(bg)} GC/class-matched background", flush=True)
    m = pd.DataFrame(rows)
    m["q"] = m.groupby("set")["p"].transform(lambda p: bh(p.to_numpy()))
    m = m.sort_values(["set", "p"])
    m.to_csv(out / "motif_enrichment.csv", index=False)
    for call, d in m.groupby("set"):
        print(f"\n{call}: top enriched motifs")
        print(d[d["odds_ratio"] > 1].head(20).to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out / 'motif_enrichment.csv'}")


if __name__ == "__main__":
    main()
