"""Figure for README result 21 from results/psychad_neurons/ddr_neurons.csv."""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
t = pd.read_csv(ROOT / "results/psychad_neurons/ddr_neurons.csv")
p = t[(t.model == "primary") & (t.cells != "MG")].reset_index(drop=True)
lab = p.cells + " " + p.program
y = np.arange(len(p))
fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.2), gridspec_kw={"width_ratios": [1.4, 1]})
ax[0].errorbar(p.random_mean_r, y + 0.15, xerr=1.96 * p.random_sd_r, fmt="s", color="0.55", ms=4, capsize=2,
               label="matched random gene sets (mean ± 1.96 sd)")
ax[0].errorbar(p.r, y - 0.15, xerr=[p.r - p.ci_lo, p.ci_hi - p.r], fmt="o", color="#c0392b", ms=5, capsize=2,
               label="DDR program (r, 95% CI)")
ax[0].axvline(0, color="0.5", lw=0.8)
ax[0].set_yticks(y, lab, fontsize=8)
ax[0].invert_yaxis()
ax[0].set_xlabel("partial r, AD vs control")
ax[0].set_title(f"PsychAD MSSM neurons ({int(p.n_donors.max())} donors): DDR moves with every other gene", fontsize=9)
ax[0].legend(fontsize=7, frameon=False, loc="lower right")
cal = {"EN": 0.62, "IN": 0.94, "MG": 0.20}
ax[1].bar(range(3), list(cal.values()), color=["#d9822b", "#3b6fb6", "#2e8b57"])
ax[1].axhline(0.05, color="#c0392b", ls="--", lw=1)
ax[1].set_xticks(range(3), ["excitatory", "inhibitory", "microglia"])
ax[1].set_ylabel("random 20-gene sets with p < 0.05 for AD")
ax[1].set_title("Self-contained tests are badly miscalibrated", fontsize=9)
for i, v in enumerate(cal.values()):
    ax[1].text(i, v + 0.02, f"{v:.0%}", ha="center", fontsize=8)
fig.tight_layout()
fig.savefig(ROOT / "docs/psychad_neurons.png", dpi=160)
print("wrote docs/psychad_neurons.png")
