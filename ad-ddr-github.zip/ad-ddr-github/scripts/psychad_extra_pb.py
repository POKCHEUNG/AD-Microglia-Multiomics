"""Donor pseudobulks of further PsychAD MSSM cell types for the DDR endpoint analysis (README 40).

    python scripts/psychad_extra_pb.py          # writes data/processed/psychad_pb/{IN,Astro,Micro,EN_L2_3_IT}.npz

Same format as the EN / Oligo caches of scripts/replicate_cohesin_psychad.py (cats, M, genes), raw counts
summed per donor with run_psychad_neurons.pseudobulk; cell type from obs 'class' (IN, Astro) or
'subclass' (Micro, EN_L2_3_IT).
"""

from __future__ import annotations

import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_psychad_neurons import pseudobulk  # noqa: E402

TYPES = {"IN": ("class", "IN"), "Astro": ("class", "Astro"), "Micro": ("subclass", "Micro"),
         "EN_L2_3_IT": ("subclass", "EN_L2_3_IT")}


def main():
    a = ad.read_h5ad(ROOT / "data/raw/psychad/MSSM_cohort.h5ad", backed="r")
    o = a.obs
    var = a.raw.var if a.raw is not None else a.var
    sym = np.array(var["feature_name"].astype(str))
    donor = o["donor_id"].astype(str).to_numpy()
    out = ROOT / "data/processed/psychad_pb"
    for name, (col, val) in TYPES.items():
        f = out / f"{name}.npz"
        if f.exists():
            continue
        keep = (o[col].astype(str) == val).to_numpy()
        print(f"{name}: {keep.sum():,} nuclei", flush=True)
        cats, M = pseudobulk(a, keep, donor)
        n = pd.Series(donor[keep]).value_counts().reindex(cats).to_numpy()
        np.savez_compressed(f, cats=np.array(cats), M=M, genes=sym, n_nuclei=n)


if __name__ == "__main__":
    main()
