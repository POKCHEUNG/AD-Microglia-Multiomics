"""Core question in an independent cohort: PsychAD MSSM (DLPFC, AD vs control), RNA (README 46, Fig. S8).

    python scripts/psychad_subclass_pb.py           # first: donor pseudobulks of every subclass
    python scripts/psychad_global_vs_specific.py    # writes results/global_specific/psychad_*.csv

Same estimators as scripts/global_vs_specific.py (shared fraction over 20 donor split halves, corrected
for split-half reliability; specific genes beyond the 99.5% permutation threshold; programs observed vs
predicted from the other cell types; class-balanced sensitivity). Exposure: AD (no other diagnosis) vs
control; covariates age, sex, log nuclei, mitochondrial fraction; subclasses with >= 50 donors of >= 20
nuclei; genes expressed (CPM >= 1 in half the donors) in every subclass.

Replication against SEA-AD (MTG, CPS; results/global_specific/rna_profiles.npz), for the matched
cell types and the genes common to both: correlation of the profiles r, correlation of the cell-type-
specific components d = r - mean(others), and overlap of the specific genes (same sign) against chance.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

import global_vs_specific as gv
from ddrmulti.stats import bh
from ad_ddr.signatures import all_programs

ROOT = Path(__file__).resolve().parents[1]
PB = ROOT / "data/processed/psychad_pb"
OUT = ROOT / "results/global_specific"
MATCH = {"EN_L2_3_IT": "L2/3 IT", "EN_L5_6_NP": "L5/6 NP", "EN_L6B": "L6b", "EN_L6_CT": "L6 CT", "EN_L6_IT_1": "L6 IT",
         "IN_LAMP5_LHX6": "Lamp5 Lhx6", "IN_LAMP5_RELN": "Lamp5", "IN_PVALB": "Pvalb", "IN_PVALB_CHC": "Chandelier",
         "IN_SST": "Sst", "IN_VIP": "Vip", "Astro": "Astrocyte", "Micro": "Microglia-PVM", "Oligo": "Oligodendrocyte",
         "OPC": "OPC", "VLMC": "VLMC & Perivascular"}


def cell_class(n):
    if n.startswith("EN_"):
        return "excitatory"
    if n.startswith("IN_"):
        return "inhibitory"
    return "non-neuronal"


def main():
    rng = np.random.default_rng(0)
    gv.cell_class = cell_class                        # PsychAD subclass names
    meta = pd.read_csv(PB / "meta.csv", index_col=0)
    con = meta[((meta["ad"] & ~meta["other"]) | (meta["control"] & ~meta["ad"])) & meta["age"].notna()]
    units_all = {}
    for f in sorted(PB.glob("sub_*.npz")):
        name = f.stem[4:]
        z = np.load(f, allow_pickle=True)
        cats, M, genes, n = z["cats"], z["M"].astype(float), pd.Index(z["genes"]).str.upper(), z["n_nuclei"]
        ok = (n >= 20) & np.isin(cats, con.index)
        if ok.sum() < 50:
            print(f"  skip {name}: {ok.sum()} donors")
            continue
        M, cats, n = M[ok], cats[ok], n[ok]
        cpm = M / M.sum(1, keepdims=True) * 1e6
        base = con.loc[cats].reset_index(drop=True).assign(
            log_nuclei=np.log10(n), mito=M[:, genes.str.startswith("MT-")].sum(1) / M.sum(1))
        x = base["ad"].astype(float).to_numpy()
        units_all[name] = (np.log2(cpm + 1), x, gv.design(base, ["age", "sex", "log_nuclei", "mito"]), cats, genes,
                           (cpm >= 1).mean(0) >= 0.5)
        print(f"  {name}: {ok.sum()} donors ({int(x.sum())} AD)", flush=True)
    common = None
    for u in units_all.values():
        g = set(u[4][u[5]])
        common = g if common is None else common & g
    common = sorted(common)
    units = {}
    for name, (L, x, C, d, g, e) in units_all.items():
        pos = pd.Series(np.arange(len(g)), index=g)
        pos = pos[~pos.index.duplicated()]
        units[name] = (L[:, pos.reindex(common).to_numpy()], x, C, d)
    print(f"PsychAD: {len(units)} subclasses, {len(common)} genes expressed in all", flush=True)

    dec = pd.concat([gv.decompose(units, common, rng, "RNA", b) for b in (False, True)])
    spec, full = gv.specific_counts(units, rng, "RNA")
    spec = pd.concat([spec, gv.specific_counts(units, rng, "RNA", True)[0]])
    S = dec.groupby(["modality", "others", "unit"])[["reliability", "pred_by_others", "shared_fraction"]].median().reset_index()
    S["cell_class"] = S["unit"].map(cell_class)
    S.loc[S["reliability"] < 0.1, "shared_fraction"] = np.nan

    # programs
    progs = {k: v for k, v in all_programs().items() if k in gv.DDR + ["DAM"]}
    progs["cohesin"] = gv.COHESIN
    pos_c = pd.Series(np.arange(len(common)), index=common)
    prow = []
    for n_, (L, x, C, d, g, e) in units_all.items():
        others = np.mean([full[o] for o in full if o != n_], 0)
        pos = pd.Series(np.arange(len(g)), index=g)
        pos = pos[~pos.index.duplicated()]
        Z = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
        for pn, gs in progs.items():
            gi = pos.reindex([x_.upper() for x_ in gs]).dropna().astype(int).to_numpy()
            gi = gi[e[gi]]
            gc = pos_c.reindex(pd.Index(g)[gi]).dropna().astype(int).to_numpy()
            if len(gi) < 3 or len(gc) < 3:
                continue
            ex, ez, ep = gv.program_excess(full[n_] - others, gc, units[n_][0].mean(0))
            prow.append({"cell": n_, "program": pn, "family": "DDR" if pn in gv.DDR else pn, "n_genes": len(gi),
                         "specific_component": ex, "specific_z": ez, "p_specific": ep,
                         "r_observed": gv.rvec(Z[:, gi].mean(1)[:, None], x, C)[0],
                         "r_predicted_from_others": others[gc].mean(), "mean_gene_r_observed": full[n_][gc].mean()})
    PR = pd.DataFrame(prow)

    # replication against SEA-AD
    z = np.load(OUT / "rna_profiles.npz", allow_pickle=True)
    sea = pd.DataFrame(z["R"].T, index=pd.Index(z["genes"]), columns=z["units"])
    psy = pd.DataFrame(np.array([full[u] for u in full]).T, index=pd.Index(common), columns=list(full))
    shared_g = sea.index.intersection(psy.index)
    sea, psy = sea.loc[shared_g], psy.loc[shared_g]
    thr_p = spec[spec["others"] == "all"].set_index("unit")["threshold"]
    thr_s = pd.read_csv(OUT / "specific_counts.csv")
    thr_s = thr_s[(thr_s["modality"] == "RNA") & (thr_s["others"] == "all")].set_index("unit")["threshold"]
    rep = []
    for pu, su in MATCH.items():
        if pu not in psy or su not in sea:
            continue
        dp = psy[pu] - psy.drop(columns=pu).mean(1)
        ds = sea[su] - sea.drop(columns=su).mean(1)
        sp_p, sp_s = np.abs(dp) > thr_p[pu], np.abs(ds) > thr_s[su]
        both = (sp_p & sp_s & (np.sign(dp) == np.sign(ds))).sum()
        exp = sp_p.sum() * sp_s.sum() / len(dp) / 2
        # null for the specific-component correlation: permute genes within expression-matched bins is overkill;
        # report the Pearson r with its t-based p (genes are not independent, so treat p as descriptive)
        rep.append({"psychad": pu, "seaad": su, "class": cell_class(pu), "n_genes": len(dp),
                    "r_profiles": np.corrcoef(psy[pu], sea[su])[0, 1], "r_specific": np.corrcoef(dp, ds)[0, 1],
                    "n_specific_psychad": int(sp_p.sum()), "n_specific_seaad": int(sp_s.sum()),
                    "n_specific_both_same_sign": int(both), "expected_both": exp,
                    "p_overlap": stats.hypergeom.sf(both - 1, len(dp), sp_p.sum(), sp_s.sum()) if sp_s.sum() else np.nan})
    REP = pd.DataFrame(rep)
    # null for r_specific: specific component of mismatched cell types (SEA-AD unit != matched one)
    null = []
    for pu, su in MATCH.items():
        if pu not in psy:
            continue
        dp = psy[pu] - psy.drop(columns=pu).mean(1)
        for other in sea.columns:
            if other == su:
                continue
            ds = sea[other] - sea.drop(columns=other).mean(1)
            null.append(np.corrcoef(dp, ds)[0, 1])
    null = np.array(null)
    REP["r_specific_pct_vs_mismatched"] = [np.mean(null < v) * 100 for v in REP["r_specific"]]

    S.to_csv(OUT / "psychad_shared_fraction.csv", index=False)
    dec.to_csv(OUT / "psychad_shared_fraction_splits.csv", index=False)
    spec.to_csv(OUT / "psychad_specific_counts.csv", index=False)
    PR.to_csv(OUT / "psychad_programs_vs_shared.csv", index=False)
    REP.to_csv(OUT / "psychad_vs_seaad_replication.csv", index=False)
    pd.set_option("display.width", 220)
    print("\nPsychAD shared fraction (median of 20 splits):")
    print(S.sort_values(["others", "shared_fraction"]).to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print("\nPsychAD specific genes:")
    print(spec.assign(ratio=spec["n_specific"] / spec["expected_false"]).sort_values(["others", "ratio"], ascending=[True, False])
          .to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    d = PR[PR["family"] == "DDR"]
    print(f"\nDDR programs: median |r| {np.median(np.abs(d.r_observed)):.3f}; median |observed - predicted| "
          f"{np.median(np.abs(d.r_observed - d.r_predicted_from_others)):.3f}; specific component vs matched random "
          f"sets p < 0.05 in {(d.p_specific < 0.05).sum()}/{len(d)}, BH q < 0.1 in {(bh(d.p_specific.to_numpy()) < 0.1).sum()}")
    print(PR[PR["family"] != "DDR"].to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print(f"\nReplication vs SEA-AD ({len(shared_g)} genes; mismatched-pair null for r_specific: median {np.median(null):.3f}, "
          f"95th pct {np.percentile(null, 95):.3f}):")
    print(REP.to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
