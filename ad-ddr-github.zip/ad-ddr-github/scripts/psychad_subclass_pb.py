"""Donor pseudobulks of every PsychAD MSSM subclass, in one pass over the file (README 46).

    python scripts/psychad_subclass_pb.py       # writes data/processed/psychad_pb/sub_<subclass>.npz

Same format as the other caches (cats, M, genes, n_nuclei); raw counts summed per donor. Only the 437
donors of the AD-vs-control design (AD without other diagnoses, or controls; age known) are kept, which
keeps one pass over 4.1 M nuclei within memory. Subclasses with < 5,000 nuclei (EN_L5_ET, SMC, Adaptive)
are skipped.
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data/processed/psychad_pb"
CHUNK = 100_000


def main():
    meta = pd.read_csv(OUT / "meta.csv", index_col=0)
    con = meta[((meta["ad"] & ~meta["other"]) | (meta["control"] & ~meta["ad"])) & meta["age"].notna()]
    donors = pd.Index(sorted(con.index))
    a = ad.read_h5ad(ROOT / "data/raw/psychad/MSSM_cohort.h5ad", backed="r")
    o = a.obs
    raw = a.raw if a.raw is not None else a
    sym = np.array((a.raw.var if a.raw is not None else a.var)["feature_name"].astype(str))
    sub = o["subclass"].astype(str).to_numpy()
    counts = pd.Series(sub).value_counts()
    subs = [s for s in counts.index if counts[s] >= 5000]
    dcode = donors.get_indexer(o["donor_id"].astype(str).to_numpy())
    scode = pd.Index(subs).get_indexer(sub)
    keep = (dcode >= 0) & (scode >= 0)
    G = len(sym)
    acc = {s: np.zeros((len(donors), G), np.float32) for s in subs}
    nn = {s: np.zeros(len(donors), int) for s in subs}
    print(f"{len(subs)} subclasses, {len(donors)} donors, {keep.sum():,} nuclei kept of {len(o):,}", flush=True)
    for i in range(0, len(o), CHUNK):
        r = np.arange(i, min(i + CHUNK, len(o)))
        r = r[keep[r]]
        if not len(r):
            continue
        X = sp.csr_matrix(raw.X[r[0]:r[-1] + 1])[r - r[0]]
        for k, s in enumerate(subs):
            m = scode[r] == k
            if not m.any():
                continue
            d = dcode[r][m]
            A = sp.csr_matrix((np.ones(m.sum()), (d, np.arange(m.sum()))), shape=(len(donors), m.sum()))
            acc[s] += np.asarray((A @ X[m]).todense(), np.float32)
            nn[s] += np.bincount(d, minlength=len(donors))
        print(f"   {min(i + CHUNK, len(o)):,}/{len(o):,}", flush=True)
    for s in subs:
        ok = nn[s] > 0
        np.savez_compressed(OUT / f"sub_{s}.npz", cats=np.array(donors[ok]), M=acc[s][ok], genes=sym, n_nuclei=nn[s][ok])
        print(f"wrote sub_{s}: {ok.sum()} donors, {nn[s].sum():,} nuclei", flush=True)


if __name__ == "__main__":
    main()
