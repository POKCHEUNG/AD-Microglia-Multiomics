"""Pilot: how many published AD single-nucleus gene-set claims are specific beyond matched random genes? (README 48)

    python scripts/published_claims_pilot.py    # writes results/published_claims/pilot_*.csv

Claims tested (the cell type of the original report):
  Mathys 2019 (Nature; ROSMAP, 48 donors) Supplementary Table 2: DEGs (flag DEGs.Ind.Mix.models) of
    pathology vs no pathology and of early pathology vs no pathology, split into up and down, in Ex, In,
    Ast, Oli, Opc, Mic (data/raw/published_claims/)
  Mathys 2024 (Nature; ROSMAP, 427 donors, 6 regions): gene-expression modules (Supp. Table 6) whose
    cells are enriched in AD or control individuals (Supp. Table 7, covariate nrad, p < 1e-3, >= 5 genes;
    AD -> up, control -> down), and pathology-biased DEGs (Supp. Table 10: up = significant up in >= 3
    regions and never down, down = the reverse, separately for NFT- and plaque-biased genes)
  published sets already in data/meta/published_sets (Mathys 2023 cohesin, Mathys 2024 M22 and EC
    shared-up, Fancy 2024 microglia module 8)
  MSigDB Hallmark (50 sets) in each of the six cell types (no claimed direction; the sets most often
    reported as changed in AD atlases)
Cohorts: SEA-AD MTG (local CPS; age, sex, PMI, log nuclei; 73 donors) and PsychAD MSSM (AD vs control;
age, sex, log nuclei, mitochondrial fraction; ~400 donors). Set score = mean donor-z of log2 CPM of its
expressed genes (CPM >= 1 in half the donors). Three tests of the partial r with the exposure:
  self-contained   2,000 donor permutations of the exposure (p_perm)
  expression-matched competitive   500 random sets, each gene replaced from its expression decile (p_expr)
  expression x length competitive  500 random sets matched on expression decile x gene-length quintile (p_len)
A directional claim "holds" under a test if r has the claimed sign and p < 0.05.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr import cohort
from ddr_endpoints import EXC, INH, corr_cols, design, resid
from ddrmulti.genome import read_gtf_genes
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/published_claims"
OUT.mkdir(parents=True, exist_ok=True)
N_PERM, N_SETS = 2000, 500
SEA = {"Ex": ("class", cohort.EXC, EXC), "In": ("class", cohort.INH, INH), "Mic": ("group", "Microglia-PVM", ["Immune"]),
       "Oli": ("group", "Oligodendrocyte", ["Oligodendrocyte"]), "Ast": ("group", "Astrocyte", ["Astrocyte"]),
       "Opc": ("group", "OPC", ["OPC"])}
PSY = {"Ex": "EN.npz", "In": "IN.npz", "Mic": "Micro.npz", "Oli": "Oligo.npz", "Ast": "Astro.npz", "Opc": "sub_OPC.npz"}
PUBLISHED = [("Mathys2023 cohesin", "Ex", "up", ["mathys2023_cohesin_CORUM165_SA1.txt", "mathys2023_cohesin_CORUM166_SA2.txt"]),
             ("Mathys2023 cohesin", "Oli", "up", ["mathys2023_cohesin_CORUM165_SA1.txt", "mathys2023_cohesin_CORUM166_SA2.txt"]),
             ("Mathys2024 M22 p53/DNA damage (core)", "Mic", "up", ["mathys2024_Mic_Immune_M22_core.txt"]),
             ("Mathys2024 M22 p53/DNA damage (all)", "Mic", "up", ["mathys2024_Mic_Immune_M22_all.txt"]),
             ("Fancy2024 microglia module 8", "Mic", "up", ["fancy2024_microglia_Module8.txt"])]


def claims():
    out = []
    f = ROOT / "data/raw/published_claims/mathys2019_supp_table2_DEGs.xlsx"
    for ct in SEA:
        d = pd.read_excel(f, sheet_name=ct, header=None)
        for c0, lab in ((0, "pathology vs none"), (11, "early pathology vs none")):
            b = d.iloc[2:, c0:c0 + 9]
            b.columns = ["gene", "adjp", "m0", "m1", "fc", "mz", "mp", "deg_ind", "deg_mix"]
            b = b[b["gene"].notna() & (b["deg_mix"].astype(str) == "True")]
            fc = pd.to_numeric(b["fc"], errors="coerce")
            if lab == "early pathology vs none":
                fc = np.sign(pd.to_numeric(b["m1"], errors="coerce") - pd.to_numeric(b["m0"], errors="coerce"))
            for direction, sel in (("up", fc > 0), ("down", fc < 0)):
                gs = b.loc[sel, "gene"].astype(str).str.upper().tolist()
                if len(gs) >= 5:
                    out.append({"source": "Mathys2019 DEGs", "claim": f"Mathys2019 {ct} {lab} {direction}", "cell": ct,
                                "direction": direction, "genes": gs})
    R = ROOT / "data/raw/published_claims"
    m24 = {"Ast": "Ast", "Mic_Immune": "Mic", "Oli": "Oli", "Opc": "Opc", "Exc": "Ex", "Inh": "In"}
    mods = pd.concat([pd.read_excel(R / "mathys2024_supp_table6_modules.xlsx", sheet_name=sh) for sh in m24])
    cov = pd.read_excel(R / "mathys2024_supp_table7_module_covariates.xlsx")
    cov = cov[(cov["covariate"] == "nrad") & (cov["log10p"] >= 3) & cov["set"].isin(list(m24))]
    for _, r in cov.iterrows():
        k = int(r["mname"].split()[0][1:])
        gs = sorted(set(mods.loc[(mods["set"] == r["set"]) & (mods["module"] == k) & mods["is.core.gene"].astype(bool), "gene"].astype(str).str.upper()))
        if len(gs) >= 5:
            out.append({"source": "Mathys2024 AD modules", "claim": f"Mathys2024 {m24[r['set']]} M{k} ({'AD' if r['level'] == 'AD' else 'control'})",
                        "cell": m24[r["set"]], "direction": "up" if r["level"] == "AD" else "down", "genes": gs})
    t10 = pd.read_csv(R / "mathys2024_supp_table10_pathology_DEGs.txt", sep="\t")
    for st, d in t10.groupby("set"):
        ct = m24[st.rsplit("_", 1)[0]]
        for path, col in (("NFT", "nft"), ("Plaque", "plaq")):
            dd = d[d["dir"] == path]
            for direction, sel in (("up", (dd[f"sig.{col}.up"] >= 3) & (dd[f"sig.{col}.dw"] == 0)),
                                   ("down", (dd[f"sig.{col}.dw"] >= 3) & (dd[f"sig.{col}.up"] == 0))):
                gs = dd.loc[sel, "gene"].astype(str).str.upper().tolist()
                if len(gs) >= 5:
                    out.append({"source": "Mathys2024 pathology DEGs", "claim": f"Mathys2024 {ct} {path}-biased {direction}",
                                "cell": ct, "direction": direction, "genes": gs})
    P = ROOT / "data/meta/published_sets"
    for name, ct, direction, files in PUBLISHED:
        gs = sorted({g.strip().upper() for fn in files for g in (P / fn).read_text().split() if g.strip() and not g.startswith("#")})
        out.append({"source": "published modules", "claim": name, "cell": ct, "direction": direction, "genes": gs})
    H = pd.read_csv(ROOT / "data/ref/msigdb_hallmark.csv")
    for ct in SEA:
        for hm, d in H.groupby("source"):
            out.append({"source": "Hallmark", "claim": f"Hallmark {hm}", "cell": ct, "direction": "",
                        "genes": d["target"].str.upper().tolist()})
    return out


def test(cohort_name, ct, M, genes, base, cov, expo, glen, cl, rng):
    cpm = M / M.sum(1, keepdims=True) * 1e6
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    up = pd.Series(np.arange(len(genes)), index=pd.Index(genes).str.upper())
    up = up[~up.index.duplicated()]
    gl = glen.reindex(pd.Index(genes).str.upper()).to_numpy()
    ok = expressed & np.isfinite(gl)
    eb = np.full(len(gl), -1)
    eb[ok] = pd.qcut(pd.Series(L.mean(0)[ok]).rank(method="first"), 10, labels=False).to_numpy()
    lb = np.full(len(gl), -1)
    lb[ok] = pd.qcut(pd.Series(gl[ok]).rank(method="first"), 5, labels=False).to_numpy()
    s_expr, s_len = np.where(ok, eb, -1), np.where(ok, eb * 5 + lb, -1)
    by_e = {s: np.flatnonzero(s_expr == s) for s in np.unique(s_expr[ok])}
    by_l = {s: np.flatnonzero(s_len == s) for s in np.unique(s_len[ok])}
    sd = L.std(0)
    Z = (L - L.mean(0)) / np.where(sd > 0, sd, 1)
    C = design(base, cov)
    xr = resid(base[expo].to_numpy(float), C)
    Zr = resid(Z, C)
    gl_mean = np.nanmean(gl[ok])
    rows = []
    for c in cl:
        if c["cell"] != ct:
            continue
        gi = up.reindex(c["genes"]).dropna().astype(int).to_numpy()
        gi = np.unique(gi[ok[gi]])
        row = {"cohort": cohort_name, "source": c["source"], "claim": c["claim"], "cell": ct, "direction": c["direction"],
               "n_listed": len(c["genes"]), "n_genes": len(gi), "n_donors": len(xr)}
        if len(gi) < 3:
            rows.append({**row, "status": "too few expressed"})
            continue
        score = Zr[:, gi].mean(1)
        r = corr_cols(xr, score[:, None])[0]
        perm = np.array([corr_cols(rng.permutation(xr), score[:, None])[0] for _ in range(N_PERM)])
        res = {}
        for lab, strat, by in (("expr", s_expr, by_e), ("len", s_len, by_l)):
            idx = np.stack([np.array([rng.choice(by[s]) for s in strat[gi]]) for _ in range(N_SETS)])
            null = corr_cols(xr, Zr[:, idx].mean(2))
            res[f"null_mean_{lab}"] = null.mean()
            res[f"p_{lab}"] = (np.sum(np.abs(null - null.mean()) >= abs(r - null.mean())) + 1) / (N_SETS + 1)
            res[f"excess_{lab}"] = r - null.mean()
        rows.append({**row, "status": "tested", "r": r, "p_perm": (np.sum(np.abs(perm) >= abs(r)) + 1) / (N_PERM + 1),
                     "set_log_length_minus_mean": np.nanmean(gl[gi]) - gl_mean, **res})
    return rows


def main():
    rng = np.random.default_rng(0)
    cl = claims()
    g = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    glen = np.log10((g["end"] - g["start"]).clip(lower=1))
    glen.index = glen.index.str.upper()
    glen = glen[~glen.index.duplicated()]
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    rows = []
    for ct, (level, grp, files) in SEA.items():
        idx, Cnt, genes, mt = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{f}.h5ad" for f in files], regions=["MTG"])
        mt = mt.assign(age=pd.to_numeric(mt["age"], errors="coerce"), pmi=pd.to_numeric(mt["pmi"], errors="coerce"),
                       severe=mt["severe"].astype(str).eq("Y"))
        idx = idx.join(mt[["age", "sex", "pmi", "severe"]], on="donor").assign(cps=lambda d: cps.reindex(d["donor"]).to_numpy())
        k = ((idx["level"] == level) & (idx["group"] == grp) & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool)
             & idx[["cps", "age", "pmi"]].notna().all(1)).to_numpy()
        d = idx[k].reset_index(drop=True).assign(log_nuclei=lambda z: np.log10(z["n_nuclei"]))
        rows += test("SEA-AD", ct, Cnt[np.flatnonzero(k)], genes, d, ["age", "sex", "pmi", "log_nuclei"], "cps", glen, cl, rng)
        print(f"  SEA-AD {ct}: {len(d)} donors", flush=True)
    pc = ROOT / "data/processed/psychad_pb"
    meta_ = pd.read_csv(pc / "meta.csv", index_col=0)
    con = meta_[((meta_["ad"] & ~meta_["other"]) | (meta_["control"] & ~meta_["ad"])) & meta_["age"].notna()]
    glen_p = pd.read_csv(pc / "gene_length.csv", index_col=0).iloc[:, 0]
    glen_p.index = glen_p.index.str.upper()
    for ct, fn in PSY.items():
        z = np.load(pc / fn, allow_pickle=True)
        cats, M, genes = pd.Index(z["cats"].astype(str)), z["M"].astype(float), np.array(z["genes"].astype(str))
        n = pd.Series(z["n_nuclei"] if "n_nuclei" in z.files else meta_[f"n_{fn[:-4]}"].reindex(cats).to_numpy(), index=cats)
        keep = cats.isin(con.index) & (n.to_numpy() >= (50 if fn != "sub_OPC.npz" else 20))
        cats, M, n = cats[keep], M[keep], n[keep].to_numpy()
        base = con.loc[cats].assign(log_nuclei=np.log10(n), mito=M[:, pd.Index(genes).str.startswith("MT-")].sum(1) / M.sum(1),
                                    x=lambda d: d["ad"].astype(float)).reset_index(drop=True)
        rows += test("PsychAD", ct, M, genes, base, ["age", "sex", "log_nuclei", "mito"], "x", glen_p, cl, rng)
        print(f"  PsychAD {ct}: {len(base)} donors", flush=True)
    T = pd.DataFrame(rows)
    t = T["status"] == "tested"
    for p in ("p_perm", "p_expr", "p_len"):
        T.loc[t, p.replace("p_", "q_")] = np.nan
        for (co, src), d in T[t].groupby(["cohort", "source"]):
            T.loc[d.index, p.replace("p_", "q_")] = bh(d[p].to_numpy())
    sgn = np.where(T["direction"] == "up", 1, np.where(T["direction"] == "down", -1, 0))
    for p in ("p_perm", "p_expr", "p_len"):
        ex = "r" if p == "p_perm" else p.replace("p_", "excess_")
        T[f"holds_{p[2:]}"] = np.where(sgn != 0, (np.sign(T[ex]) == sgn) & (T[p] < 0.05), T[p] < 0.05)
    T.to_csv(OUT / "pilot_tests.csv", index=False)
    S = (T[t].assign(cls=lambda d: np.where(d["cell"].isin(["Ex", "In"]), "neurons", "glia"))
         .groupby(["cohort", "source", "cls"]).agg(n=("claim", "size"), holds_perm=("holds_perm", "mean"),
                                                   holds_expr=("holds_expr", "mean"), holds_len=("holds_len", "mean"),
                                                   q_len_lt_0_1=("q_len", lambda v: (v < 0.1).mean())).reset_index())
    S.to_csv(OUT / "pilot_summary.csv", index=False)
    pd.set_option("display.width", 220)
    print(S.to_string(index=False, float_format=lambda v: f"{v:.2f}"))
    show = ["cohort", "claim", "cell", "n_genes", "r", "p_perm", "excess_expr", "p_expr", "excess_len", "p_len", "set_log_length_minus_mean"]
    print(T[t & (T["source"] != "Hallmark")][show].to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
