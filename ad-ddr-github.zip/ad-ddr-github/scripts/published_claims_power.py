"""How the inflation of self-contained pathway tests grows with cohort size (README 48, Fig. S9d).

    python scripts/published_claims_power.py    # writes results/published_claims/power_curve.csv

PsychAD excitatory and inhibitory neurons, 50 Hallmark sets: donors subsampled to n = 50, 100, 200, 300 and
all (10 draws each). Per draw and set: self-contained p from the partial correlation's t distribution and
competitive p against 200 random sets matched on expression decile x gene-length quintile (as in
scripts/published_claims_pilot.py). Reported: fraction of sets with p < 0.05 under each test.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from ddr_endpoints import corr_cols, design, resid

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/published_claims"
SIZES, DRAWS, N_SETS = [50, 100, 200, 300, None], 10, 200


def main():
    rng = np.random.default_rng(0)
    pc = ROOT / "data/processed/psychad_pb"
    meta_ = pd.read_csv(pc / "meta.csv", index_col=0)
    con = meta_[((meta_["ad"] & ~meta_["other"]) | (meta_["control"] & ~meta_["ad"])) & meta_["age"].notna()]
    glen = pd.read_csv(pc / "gene_length.csv", index_col=0).iloc[:, 0]
    glen.index = glen.index.str.upper()
    H = pd.read_csv(ROOT / "data/ref/msigdb_hallmark.csv")
    rows = []
    for ct, fn in (("Ex", "EN"), ("In", "IN")):
        z = np.load(pc / f"{fn}.npz", allow_pickle=True)
        cats, M, genes = pd.Index(z["cats"].astype(str)), z["M"].astype(float), np.array(z["genes"].astype(str))
        n = pd.Series(z["n_nuclei"] if "n_nuclei" in z.files else meta_[f"n_{fn}"].reindex(cats).to_numpy(), index=cats)
        keep = cats.isin(con.index) & (n.to_numpy() >= 50)
        cats, M, n = cats[keep], M[keep], n[keep].to_numpy()
        base = con.loc[cats].assign(log_nuclei=np.log10(n), mito=M[:, pd.Index(genes).str.startswith("MT-")].sum(1) / M.sum(1),
                                    x=lambda d: d["ad"].astype(float)).reset_index(drop=True)
        cpm = M / M.sum(1, keepdims=True) * 1e6
        L = np.log2(cpm + 1)
        ok = ((cpm >= 1).mean(0) >= 0.5) & np.isfinite(glen.reindex(pd.Index(genes).str.upper()).to_numpy())
        up = pd.Series(np.arange(len(genes)), index=pd.Index(genes).str.upper())
        up = up[~up.index.duplicated()]
        gl = glen.reindex(pd.Index(genes).str.upper()).to_numpy()
        eb = np.full(len(gl), -1)
        eb[ok] = pd.qcut(pd.Series(L.mean(0)[ok]).rank(method="first"), 10, labels=False).to_numpy()
        lb = np.full(len(gl), -1)
        lb[ok] = pd.qcut(pd.Series(gl[ok]).rank(method="first"), 5, labels=False).to_numpy()
        strat = np.where(ok, eb * 5 + lb, -1)
        by = {s: np.flatnonzero(strat == s) for s in np.unique(strat[ok])}
        sets = []
        for hm, d in H.groupby("source"):
            gi = up.reindex(d["target"].str.upper()).dropna().astype(int).to_numpy()
            gi = np.unique(gi[ok[gi]])
            if len(gi) >= 5:
                sets.append((hm, gi, np.stack([np.array([rng.choice(by[s]) for s in strat[gi]]) for _ in range(N_SETS)])))
        for size in SIZES:
            for draw in range(DRAWS if size else 1):
                ix = np.sort(rng.choice(len(base), size, replace=False)) if size else np.arange(len(base))
                b = base.iloc[ix].reset_index(drop=True)
                Lx = L[ix]
                Z = (Lx - Lx.mean(0)) / np.where(Lx.std(0) > 0, Lx.std(0), 1)
                C = design(b, ["age", "sex", "log_nuclei", "mito"])
                xr = resid(b["x"].to_numpy(float), C)
                Zr = resid(Z, C)
                dof = len(ix) - C.shape[1] - 1
                for hm, gi, rand in sets:
                    r = corr_cols(xr, Zr[:, gi].mean(1)[:, None])[0]
                    t = r * np.sqrt(dof / max(1 - r ** 2, 1e-12))
                    null = corr_cols(xr, Zr[:, rand].mean(2))
                    p_set = (np.sum(np.abs(null - null.mean()) >= abs(r - null.mean())) + 1) / (N_SETS + 1)
                    rows.append({"cell": ct, "n_donors": len(ix), "draw": draw, "set": hm, "r": r,
                                 "p_self": 2 * stats.t.sf(abs(t), dof), "p_len": p_set, "excess": r - null.mean()})
            print(f"  {ct} n = {size or len(base)}", flush=True)
    T = pd.DataFrame(rows)
    T["self_sig"] = T["p_self"] < 0.05
    T["len_sig_same_sign"] = (T["p_len"] < 0.05) & (np.sign(T["excess"]) == np.sign(T["r"]))
    S = T.groupby(["cell", "n_donors", "draw"])[["self_sig", "len_sig_same_sign"]].mean().reset_index()
    S.to_csv(OUT / "power_curve.csv", index=False)
    print(S.groupby(["cell", "n_donors"])[["self_sig", "len_sig_same_sign"]].mean().round(3).to_string())


if __name__ == "__main__":
    main()
