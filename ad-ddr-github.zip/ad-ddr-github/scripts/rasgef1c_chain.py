"""RASGEF1C: the genetic-regulatory evidence chain, link by link (README 44, Fig. S6).

    python scripts/fetch_rasgef1c_qtls.py QTD000559 ...   # first: QTLs around the locus (see that script)
    python scripts/rasgef1c_chain.py                      # writes results/rasgef1c/

Variant -> element -> state -> gene -> genotype, with the evidence for each link:
  A variant    the SuSiE credible set (results/candidate_links/susie_RASGEF1C.csv.gz); phyloP100way (UCSC API)
               at each SNP and over each element, against 200 random non-DAM microglial peaks (a random
               position and the peak mean); motif gains / losses of the risk allele (results/dam_tf)
  B element    accessibility of e1 / e2 across SEA-AD MTG subclasses (pooled CPM: is it microglial?);
               DAM-like vs homeostatic change in SEA-AD and in the hippocampus (state from same-nucleus RNA);
               the orthologous mouse position in 5xFAD CD11c+ (PAM) vs CD11c- microglia (GSE296025)
  C link       same-nucleus element-gene correlation for every gene within 500 kb (hippocampus)
  D gene       RASGEF1C RNA across SEA-AD MTG cell groups; DAM-like vs homeostatic (SEA-AD); DAM-high
               vs DAM-low thirds of hippocampal microglia by RNA DAM score, per donor
  E genotype   RASGEF1C gene and transcript QTLs in primary microglia (Young 2019), macrophages and bulk
               brain at the credible-set SNPs (beta of the AD risk allele); coloc-ABF with the GWAS
               (priors as in candidate_links.py); the eQTL lead SNP and its LD (1000 Genomes EUR r^2) with
               the GWAS lead rs113706587
  F            one table: link, evidence, verdict
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd
import pysam
import scipy.sparse as sp

from scipy import stats

from ad_ddr import cohort
from candidate_links import coloc, lnabf
from run_dam_peaks import load

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/rasgef1c"
OUT.mkdir(parents=True, exist_ok=True)
E1, E2 = "chr5:180201040-180201876", "chr5:180196966-180197623"
GENE_ID = "ENSG00000146090"
GWAS_LEAD = 180201150
COLS = ["molecular_trait_id", "chromosome", "position", "ref", "alt", "variant", "ma_samples", "maf", "pvalue", "beta",
        "se", "type", "ac", "an", "r2", "molecular_trait_object_id", "gene_id", "median_tpm", "rsid"]
QTL_FILES = {"microglia Young2019 gene": "QTD000559_RASGEF1C_chain.tsv.gz",
             "microglia Young2019 exon": "QTD000560_RASGEF1C_chain.tsv.gz",
             "microglia Young2019 transcript": "QTD000561_RASGEF1C_chain.tsv.gz",
             "microglia Young2019 txrevise": "QTD000562_RASGEF1C_chain.tsv.gz",
             "macrophage Alasoo2018": "QTD000001_RASGEF1C_chain.tsv.gz",
             "macrophage Nedelec2016": "QTD000384_RASGEF1C_chain.tsv.gz",
             "brain GTEx cortex": "QTD000171_RASGEF1C_chain.tsv.gz",
             "brain GTEx frontal cortex": "QTD000176_RASGEF1C_chain.tsv.gz",
             "brain BrainSeq DLPFC": "QTD000051_RASGEF1C_chain.tsv.gz",
             "brain CommonMind DLPFC": "QTD000075_RASGEF1C_chain.tsv.gz",
             "brain ROSMAP DLPFC": "brain_ROSMAP_RASGEF1C.tsv.gz"}


def phylop(chrom, start, end, track="phyloP100way"):
    """phyloP per base over [start, end) (0-based), from the UCSC REST API (100-way vertebrate or 30-way primate)."""
    url = f"https://api.genome.ucsc.edu/getData/track?genome=hg38;track={track};chrom={chrom};start={start};end={end}"
    for _ in range(3):
        try:
            d = json.loads(subprocess.run(["curl", "-s", "-m", "60", url], capture_output=True, text=True).stdout)
            return {v["start"]: v["value"] for v in d.get(track, [])}
        except json.JSONDecodeError:
            continue
    return {}


def gwas_window():
    f = ROOT / "data/processed/gwas_RASGEF1C_window.tsv.gz"
    if not f.exists():
        cols = ["variant_id", "p_value", "chromosome", "base_pair_location", "effect_allele", "other_allele", "beta",
                "standard_error"]
        parts = []
        for ch in pd.read_csv(ROOT / "data/ref/gwas/GCST90027158_buildGRCh38.tsv.gz", sep="\t", usecols=cols,
                              dtype={"chromosome": str}, chunksize=2_000_000):
            parts.append(ch[(ch["chromosome"] == "5") & ch["base_pair_location"].between(179_950_000, 180_450_000)])
        pd.concat(parts).dropna(subset=["beta", "standard_error"]).to_csv(f, sep="\t", index=False)
    return pd.read_csv(f, sep="\t", dtype={"chromosome": str})


_GENO = {}


def genotypes(lo=179_950_000, hi=180_450_000):
    """1000 Genomes EUR alt-allele dosages of biallelic SNVs (MAF >= 1%) in the window: {pos: (ref, alt, dosage)}."""
    if not _GENO:
        from susie_finemap import KG, eur_samples
        cwd = os.getcwd()
        os.chdir(ROOT / "data/ref/1kg")
        vf = pysam.VariantFile(KG.format(c="5"))
        eur = set(eur_samples())
        vf.subset_samples([s for s in vf.header.samples if s in eur])
        for r in vf.fetch("5", lo, hi):
            if len(r.ref) == 1 and len(r.alts or ()) == 1 and len(r.alts[0]) == 1:
                g = np.array([sum(x for x in s["GT"] if x is not None) for s in r.samples.values()], float)
                if 0.01 <= g.mean() / 2 <= 0.99:
                    _GENO[r.pos] = (r.ref, r.alts[0], g)
        os.chdir(cwd)
    return _GENO


def ld_r2(positions):
    G = genotypes()
    P = [p for p in positions if p in G]
    return {(a, b): np.corrcoef(G[a][2], G[b][2])[0, 1] ** 2 for a in P for b in P}


def conditional(t_, max_signals=3, p_in=1e-5, r2_protect=0.1):
    """Stepwise conditional analysis of one QTL trait on 1000 Genomes EUR LD (COJO-like, z-scale).

    Signals are added by largest conditional |z| while p < p_in, skipping SNPs in LD (r^2 >= r2_protect) with the
    GWAS lead, so that the remaining association is what is left after removing the QTL's distinct signals.
    Returns (table of SNPs with conditional z and its variance factor, list of conditioning SNPs)."""
    G = genotypes()
    d = t_[t_["position"].isin(G)].copy()
    d = d[[(G[p][0], G[p][1]) == (r_, a_) for p, r_, a_ in zip(d["position"], d["ref"], d["alt"])]]
    d = d.drop_duplicates("position").reset_index(drop=True)
    X = np.array([G[p][2] for p in d["position"]])
    R = np.corrcoef(X)
    z = (d["beta"] / d["se"]).to_numpy()
    lead = d.index[d["position"] == GWAS_LEAD]
    protect = (R[lead[0]] ** 2 >= r2_protect) if len(lead) else np.zeros(len(d), bool)
    sel = []
    zc, vf = z.copy(), np.ones(len(z))
    for _ in range(max_signals):
        cand = np.where(protect | (vf < 0.05), 0, np.abs(zc))           # skip selected SNPs and their near-perfect proxies
        j = int(np.argmax(cand))
        if 2 * stats.norm.sf(cand[j]) >= p_in:
            break
        sel.append(j)
        Rs = R[np.ix_(sel, sel)] + 1e-6 * np.eye(len(sel))
        W = R[:, sel] @ np.linalg.inv(Rs)
        zc = z - W @ z[sel]
        vf = np.clip(1 - np.einsum("ij,ij->i", W, R[:, sel]), 1e-3, None)
        zc = np.where(vf < 0.05, 0, zc / np.sqrt(vf))
    d["z"], d["z_cond"], d["var_factor"] = z, zc, vf
    return d, [d.at[j, "rsid"] for j in sel]


def summarise(S, A, r, MM, lk, EX, G, hi_lo, Q, CO, bg_snp, bg_el):
    mg = A.set_index("subclass").loc["Microglia-PVM"]
    oth = A[A["subclass"] != "Microglia-PVM"]
    top = EX.iloc[0]
    rasg = lk[lk["gene"] == "RASGEF1C"]
    yg = Q[Q["dataset"] == "microglia Young2019 gene"]
    cg = CO.dropna(subset=["PP4_shared"])
    best4 = cg.loc[cg["PP4_shared"].idxmax()]
    br = CO[CO["dataset"] == "brain ROSMAP DLPFC"]
    rows = [
        ("A variant: signal resolved to the elements",
         f"4-SNP credible set, purity 1.0; PIP {S.loc[S['element'].notna(), 'pip'].sum():.2f} in e1 / e2 (rs113706587 in e1; "
         "rs116347724, rs111274391 in e2); the 4 SNPs are in complete LD", "supported; causal SNP not separable"),
        ("A variant: conservation",
         "phyloP vertebrate / primate (percentile among random microglial-peak positions) "
         + ", ".join(f"{a.variant_id} {a.phyloP_vert:.2f} ({a.phyloP_vert_pct:.0f}) / {a.phyloP_primate:.2f} ({a.phyloP_primate_pct:.0f})"
                     for a in S.itertuples())
         + "; element means (percentile among peaks) "
         + ", ".join(f"{e_} {lab} {S.attrs['el_phylop'][(lab, E)][0]:.2f} ({S.attrs['el_phylop'][(lab, E)][1]:.0f})"
                     for e_, E in (("e1", E1), ("e2", E2)) for lab in ("vert", "primate")),
         "see values"),
        ("A variant: motif disruption",
         "; ".join(f"{a.variant_id}: {a.motif_events}" for a in S.itertuples() if a.motif_events) or "none at p < 1e-4",
         "candidate mechanism only"),
        ("B element: microglial",
         f"e1 / e2 CPM in microglia {mg.e1_cpm:.0f} / {mg.e2_cpm:.0f}; highest other subclass {oth.e1_cpm.max():.0f} / "
         f"{oth.e2_cpm.max():.0f}", "supported" if mg.e1_cpm > 3 * oth.e1_cpm.max() else "partly"),
        ("B element: closes in DAM",
         f"SEA-AD log2FC e1 {r.at[E1, 'log2fc']:.2f} (q {r.at[E1, 'q']:.3f}), e2 {r.at[E2, 'log2fc']:.2f} (q {r.at[E2, 'q']:.3f}); "
         f"hippocampus t {r.at[E1, 'hippo_t']:.1f} / {r.at[E2, 'hippo_t']:.1f}", "supported"),
        ("B element: mouse orthologue",
         "; ".join(f"{a['element']} {a['mm10']} PAM-nonPAM {np.nanmean([a.get(f'delta_rep{k}', np.nan) for k in (1, 2, 3)]):+.2f}"
                   for a in MM.to_dict("records")), "see values"),
        ("C element-gene link",
         "; ".join(f"{a.element.split(' (')[1][:-1]} r {a.r:.3f}, z_peak {a.z_peak:.1f}, z_state {a.z_state:.1f}"
                   for a in rasg.itertuples()) + f"; rank among genes in 500 kb (z_state): "
         + ", ".join(str(int(lk[lk['element'] == e].reset_index(drop=True).index[lk[lk['element'] == e].reset_index(drop=True)['gene'] == 'RASGEF1C'][0]) + 1)
                     for e in rasg["element"]), "supported (correlative)"),
        ("D gene: expressed in microglia",
         f"highest MTG group {top.cell} ({top.RASGEF1C_cpm:.0f} CPM); microglia "
         f"{EX.loc[EX['cell'].str.contains('Micro'), 'RASGEF1C_cpm'].max():.0f} CPM", "see values"),
        ("D gene: falls in DAM",
         f"SEA-AD RNA log2FC {G['rna_log2fc']:.2f} (t {G['rna_t']:.1f}); hippocampus DAM-high < DAM-low in "
         f"{(hi_lo < 0).sum()}/{len(hi_lo)} donors", "supported"),
        ("E genotype: microglia eQTL direction",
         ", ".join(f"{a.snp} beta {a.beta_risk:+.2f} (p {a.p:.2g})" for a in yg.itertuples()),
         "consistent direction (risk allele lower), not significant"),
        ("E genotype: coloc (single causal variant)",
         f"best PP4 {best4.PP4_shared:.2f} ({best4.dataset}, {best4.trait}); ROSMAP PP3 {br['PP3_distinct'].max():.3f}, "
         f"eQTL lead r2 with GWAS lead {br['r2_eqtl_lead_vs_gwas_lead'].max():.2f}", "distinct primary eQTL"),
        ("E genotype: after conditioning on the distinct eQTL signals",
         "; ".join(f"{a.dataset}: risk z {a.z_risk_at_gwas_lead:+.1f} -> {a.z_risk_at_gwas_lead_conditional:+.1f} "
                   f"(p {a.p_at_gwas_lead_conditional:.2g}), PP4 {a.PP4_conditional:.2f}"
                   for a in cg[cg["trait"] == GENE_ID].itertuples())
         + "; " + "; ".join(f"{a.dataset} z {a.z_risk_at_gwas_lead_conditional:+.1f} (p {a.p_at_gwas_lead_conditional:.2g})"
                            for a in CO[CO["trait"] == "Stouffer"].itertuples()), "see values"),
    ]
    return pd.DataFrame(rows, columns=["link", "evidence", "verdict"])


def main():
    rng = np.random.default_rng(0)
    # ---------- A variant
    su = pd.read_csv(ROOT / "results/candidate_links/susie_RASGEF1C.csv.gz")
    cs = pd.read_csv(ROOT / "results/candidate_links/susie_credible_sets.csv")
    S = su[su["variant_id"].isin(cs.loc[cs["locus"] == "RASGEF1C", "snps"].iat[0].split(","))].copy().reset_index(drop=True)
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    bgf = OUT / "A_phylop_background.csv"
    if bgf.exists():
        BG = pd.read_csv(bgf)
    else:
        bg = []
        for _, p_ in res[res["call"] == "ns"].sample(200, random_state=0).iterrows():
            pos = int(rng.integers(p_["start"], p_["end"]))
            row = {"peak": p_["peak"]}
            for tr, lab in (("phyloP100way", "vert"), ("phyloP30way", "primate")):
                v = phylop(p_["chrom"], int(p_["start"]), int(p_["end"]), tr)
                row[f"{lab}_position"] = v.get(pos, np.nan)
                row[f"{lab}_peak_mean"] = np.mean(list(v.values())) if v else np.nan
            bg.append(row)
        BG = pd.DataFrame(bg)
        BG.to_csv(bgf, index=False)
    el = {}
    for tr, lab in (("phyloP100way", "vert"), ("phyloP30way", "primate")):
        S[f"phyloP_{lab}"] = [phylop("chr5", int(p) - 1, int(p), tr).get(int(p) - 1, np.nan) for p in S["pos"]]
        S[f"phyloP_{lab}_pct"] = [np.nanmean(BG[f"{lab}_position"] < v) * 100 for v in S[f"phyloP_{lab}"]]
        for e in (E1, E2):
            s_, e_ = map(int, e.split(":")[1].split("-"))
            m_ = np.nanmean(list(phylop("chr5", s_, e_, tr).values()))
            el[(lab, e)] = (m_, np.nanmean(BG[f"{lab}_peak_mean"] < m_) * 100)
    S.attrs["el_phylop"] = el
    bg_snp, bg_el = BG["vert_position"].to_numpy(), BG["vert_peak_mean"].to_numpy()
    mb = pd.read_csv(ROOT / "results/dam_tf/rasgef1c_motif_break.csv")
    S["motif_events"] = [", ".join(f"{a.tfs} {a.effect_of_risk_allele}" for a in mb[mb["snp"] == s].itertuples())
                         for s in S["variant_id"]]
    S.to_csv(OUT / "A_variants.csv", index=False)
    pd.set_option("display.width", 220)
    print("A. credible-set SNPs:\n", S.drop(columns=["in_microglia_peak"]).to_string(index=False))
    for lab in ("vert", "primate"):
        print(f"   phyloP {lab}: random positions in 200 non-DAM microglial peaks median {BG[f'{lab}_position'].median():.2f}, "
              f"90th pct {BG[f'{lab}_position'].quantile(0.9):.2f}; element means e1 {el[(lab, E1)][0]:.3f} "
              f"(pct {el[(lab, E1)][1]:.0f}), e2 {el[(lab, E2)][0]:.3f} (pct {el[(lab, E2)][1]:.0f})")

    # ---------- B element
    rows, M = load(ROOT / "data/processed/atac_pb")
    peaks = pd.Index((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    ix = peaks.get_indexer([E1, E2])
    acc = []
    for sub, ii in rows.reset_index(drop=True).groupby("subclass").indices.items():
        n = rows["n_nuclei"].to_numpy()[ii].sum()
        if n < 500:
            continue
        c = np.asarray(M[ii].sum(0)).ravel()
        cpm = c / c.sum() * 1e6
        acc.append({"subclass": sub, "n_nuclei": int(n), "e1_cpm": cpm[ix[0]], "e2_cpm": cpm[ix[1]]})
    A = pd.DataFrame(acc).sort_values("e1_cpm", ascending=False)
    A.to_csv(OUT / "B_element_accessibility_by_subclass.csv", index=False)
    print("\nB. e1 / e2 accessibility by subclass (pooled CPM over tested peaks):\n", A.round(1).to_string(index=False))
    r = res.set_index("peak").loc[[E1, E2], ["log2fc", "q", "call", "frac_donors_up", "cpm_dam", "cpm_hom"]]
    h = pd.read_csv(ROOT / "results/hippo_replication/hippo_dam_peaks.csv.gz").set_index("peak").reindex([E1, E2])
    r = r.join(h[["hippo_log2fc", "hippo_t", "hippo_q"]])
    from run_dam_regulatory import mouse_at_points, mouse_samples
    from validate_dam_peaks import liftover_points, read_chain
    chain = read_chain(ROOT / "data/ref/hg38ToMm10.over.chain.gz")
    pts = [180201150, 180197032, (180201040 + 180201876) // 2, (180196966 + 180197623) // 2]
    lift = liftover_points(chain, ["chr5"] * len(pts), pts)
    MS = mouse_at_points(mouse_samples(ROOT / "data/raw/gse296025"), [c for c, _ in lift], [p for _, p in lift])
    MM = pd.concat([pd.DataFrame({"element": ["e1 rs113706587", "e2 rs116347724", "e1 centre", "e2 centre"],
                                  "mm10": [f"{c}:{p}" if c else "unlifted" for c, p in lift]}), MS], axis=1)
    for k in (1, 2, 3):
        MM[f"delta_rep{k}"] = MM[f"PAMrep{k}"] - MM[f"nonPAMrep{k}"]
    r.to_csv(OUT / "B_element_state.csv")
    MM.to_csv(OUT / "B_element_mouse.csv", index=False)
    print(r.round(3).to_string())
    print(MM.round(3).to_string(index=False))

    # ---------- C link
    lk = pd.read_csv(ROOT / "results/candidate_links/same_nucleus_links.csv")
    lk = lk[lk["element"].str.contains("RASGEF1C distal")].sort_values(["element", "z_state"], ascending=[True, False])
    lk.to_csv(OUT / "C_links.csv", index=False)
    print("\nC. same-nucleus links of e1 / e2 (top 5 genes within 500 kb by z_state):\n",
          lk.groupby("element").head(5)[["element", "gene", "dist_kb", "r", "z_peak", "z_state", "q_peak"]].round(3).to_string(index=False))

    # ---------- D gene expression across cell types and states
    ex = []
    for p in sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad")):
        try:
            idx, Cnt, genes, _ = cohort.aggregate([p], regions=["MTG"])
        except ValueError:
            continue
        gu = pd.Index(genes).str.upper()
        if "RASGEF1C" not in gu:
            continue
        gi = int(np.flatnonzero(gu == "RASGEF1C")[0])
        for grp, d in idx[idx["level"] == "group"].groupby("group"):
            c = Cnt[d.index.to_numpy()].sum(0)
            ex.append({"cell": grp, "n_nuclei": int(d["n_nuclei"].sum()), "RASGEF1C_cpm": c[gi] / c.sum() * 1e6})
    EX = pd.DataFrame(ex).sort_values("RASGEF1C_cpm", ascending=False).reset_index(drop=True)
    EX.to_csv(OUT / "D_expression_by_cell.csv", index=False)
    G = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz").set_index("gene").loc["RASGEF1C"]
    print("\nD. RASGEF1C CPM by MTG cell group:\n", EX.round(1).to_string(index=False))
    print(f"   SEA-AD DAM-like vs homeostatic: RNA log2FC {G['rna_log2fc']:.2f} (t {G['rna_t']:.1f}); "
          f"regulatory domain log2FC {G['log2fc']:.2f} (q {G['q']:.3f})")
    hc = pd.read_csv(ROOT / "results/microglia_states/hippo_cell_programs.csv.gz")
    from run_hippo_replication import load_libs
    Lh, gn = load_libs()
    R_ = sp.vstack([Lh[l]["rna_cells"][(Lh[l]["cells"]["subclass"] == "Microglia").to_numpy()]
                    for l in hc["library"].unique()]).tocsr()
    assert R_.shape[0] == len(hc)
    gpos = int(np.flatnonzero(gn.str.upper() == "RASGEF1C")[0])
    tot = np.asarray(R_.sum(1)).ravel()
    hc["RASGEF1C"] = np.log1p(R_[:, gpos].toarray().ravel() / np.maximum(tot, 1) * 1e4)
    hi_lo = []
    for d, g in hc.groupby("donor"):
        if len(g) < 30:
            continue
        lo, hi = np.quantile(g["score"], [1 / 3, 2 / 3])
        hi_lo.append(g.loc[g["score"] >= hi, "RASGEF1C"].mean() - g.loc[g["score"] <= lo, "RASGEF1C"].mean())
    hi_lo = np.array(hi_lo)
    pd.DataFrame({"dam_high_minus_low": hi_lo}).to_csv(OUT / "D_hippo_donor_differences.csv", index=False)
    print(f"   hippocampus: RASGEF1C lower in DAM-high than DAM-low thirds in {(hi_lo < 0).sum()}/{len(hi_lo)} donors "
          f"(mean {hi_lo.mean():+.3f} log-normalised)")

    # ---------- E genotype effects: QTLs at the credible set, coloc, eQTL lead and its LD with the GWAS lead
    gw = gwas_window()
    risk = dict(zip(S["variant_id"], np.where(S["z"] > 0, S["alt"], S["ref"])))
    qrows, crows = [], []
    for lab, f in QTL_FILES.items():
        d = pd.read_csv(ROOT / "data/processed/eqtl_regions" / f, sep="\t", dtype=str)
        if d.empty:
            crows.append({"dataset": lab, "trait": "no data"})
            continue
        d.columns = COLS
        d = d[(d["type"] == "SNP") & (d["gene_id"] == GENE_ID)]
        if d.empty:
            crows.append({"dataset": lab, "trait": "RASGEF1C not tested"})
            continue
        for c_ in ("position", "pvalue", "beta", "se", "maf", "median_tpm"):
            d[c_] = pd.to_numeric(d[c_])
        for trait, t_ in d.groupby("molecular_trait_id"):
            t_ = t_.drop_duplicates("position")
            for _, s in S.iterrows():
                h_ = t_[t_["position"] == int(s["pos"])]
                if h_.empty:
                    continue
                h_ = h_.iloc[0]
                a = risk[s["variant_id"]]
                b = h_["beta"] if h_["alt"] == a else (-h_["beta"] if h_["ref"] == a else np.nan)
                qrows.append({"dataset": lab, "trait": trait, "snp": s["variant_id"], "risk_allele": a, "beta_risk": b,
                              "se": h_["se"], "p": h_["pvalue"], "maf": h_["maf"], "median_tpm": h_["median_tpm"]})
            m = gw.merge(t_, left_on="base_pair_location", right_on="position")
            m = m[((m["effect_allele"] == m["alt"]) & (m["other_allele"] == m["ref"])) |
                  ((m["effect_allele"] == m["ref"]) & (m["other_allele"] == m["alt"]))]
            l1 = lnabf(m["beta_x"] / m["standard_error"], m["standard_error"] ** 2, 0.2 ** 2).to_numpy()
            l2 = lnabf(m["beta_y"] / m["se"], m["se"] ** 2, 0.15 ** 2).to_numpy()
            pp = coloc(l1, l2)
            lead = t_.loc[t_["pvalue"].idxmin()]
            # conditional on the QTL's own distinct signals (not in LD with the GWAS lead): what is left at the GWAS set?
            dc, sel = conditional(t_)
            mc = gw.merge(dc[["position", "ref", "alt", "z_cond", "var_factor", "se"]], left_on="base_pair_location",
                          right_on="position")
            mc = mc[((mc["effect_allele"] == mc["alt"]) & (mc["other_allele"] == mc["ref"])) |
                    ((mc["effect_allele"] == mc["ref"]) & (mc["other_allele"] == mc["alt"]))]
            lc = lnabf(mc["z_cond"], mc["se"] ** 2 / mc["var_factor"], 0.15 ** 2).to_numpy()
            l1c = lnabf(mc["beta"] / mc["standard_error"], mc["standard_error"] ** 2, 0.2 ** 2).to_numpy()
            ppc = coloc(l1c, lc)
            atl = dc[dc["position"] == GWAS_LEAD]
            sgn = 1 if risk["rs113706587"] == (atl["alt"].iat[0] if len(atl) else None) else -1
            crows.append({"dataset": lab, "trait": trait, "n_snps": len(m), "median_tpm": lead["median_tpm"],
                          "eqtl_lead": lead["rsid"], "eqtl_lead_pos": int(lead["position"]), "eqtl_lead_p": lead["pvalue"],
                          "min_p_in_gwas_cs": t_.loc[t_["position"].isin(S["pos"].astype(int)), "pvalue"].min(),
                          "PP3_distinct": pp[3], "PP4_shared": pp[4],
                          "conditioned_on": ",".join(map(str, sel)),
                          "z_risk_at_gwas_lead": sgn * atl["z"].iat[0] if len(atl) else np.nan,
                          "z_risk_at_gwas_lead_conditional": sgn * atl["z_cond"].iat[0] if len(atl) else np.nan,
                          "p_at_gwas_lead_conditional": 2 * stats.norm.sf(abs(atl["z_cond"].iat[0])) if len(atl) else np.nan,
                          "PP3_conditional": ppc[3], "PP4_conditional": ppc[4]})
    Q, CO = pd.DataFrame(qrows), pd.DataFrame(crows)
    ld = ld_r2(sorted(set(S["pos"].astype(int)) | set(CO["eqtl_lead_pos"].dropna().astype(int))))
    CO["r2_eqtl_lead_vs_gwas_lead"] = [ld.get((int(p), GWAS_LEAD), np.nan) if pd.notna(p) else np.nan
                                       for p in CO["eqtl_lead_pos"]]
    # combined evidence at the GWAS lead after conditioning: Stouffer z weighted by sqrt(sample size)
    n_qtl = {"microglia Young2019 gene": 104, "macrophage Alasoo2018": 84, "macrophage Nedelec2016": 163,
             "brain GTEx cortex": 205, "brain GTEx frontal cortex": 175, "brain BrainSeq DLPFC": 479,
             "brain CommonMind DLPFC": 586, "brain ROSMAP DLPFC": 560}
    g_ = CO[CO["trait"] == GENE_ID].set_index("dataset")
    for lab, keys in (("meta: bulk brain", [k for k in n_qtl if k.startswith("brain")]),
                      ("meta: bulk brain without CommonMind", [k for k in n_qtl if k.startswith("brain") and "CommonMind" not in k]),
                      ("meta: microglia + macrophages", [k for k in n_qtl if not k.startswith("brain")]),
                      ("meta: all", list(n_qtl))):
        w = np.sqrt([n_qtl[k] for k in keys])
        zz = g_.loc[keys, "z_risk_at_gwas_lead_conditional"].to_numpy(float)
        zm = (w * zz).sum() / np.sqrt((w ** 2).sum())
        CO = pd.concat([CO, pd.DataFrame([{"dataset": lab, "trait": "Stouffer", "n_snps": len(keys),
                                           "z_risk_at_gwas_lead_conditional": zm,
                                           "p_at_gwas_lead_conditional": 2 * stats.norm.sf(abs(zm))}])], ignore_index=True)
    Q.to_csv(OUT / "E_qtls_at_credible_set.csv", index=False)
    CO.to_csv(OUT / "E_coloc.csv", index=False)
    print("\nE. RASGEF1C QTLs at the credible-set SNPs (beta of the AD risk allele):")
    print(Q.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\n   coloc with the AD GWAS and LD (EUR r2) of each eQTL lead with rs113706587:")
    print(CO.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- F chain summary
    F = summarise(S, A, r, MM, lk, EX, G, hi_lo, Q, CO, bg_snp, bg_el)
    F.to_csv(OUT / "chain_summary.csv", index=False)
    print("\nF. Evidence chain:")
    for a in F.itertuples():
        print(f" - {a.link}: {a.evidence}  [{a.verdict}]")


if __name__ == "__main__":
    main()
