"""Which transcription factors control the RASGEF1C risk enhancers e1 / e2? (README 49)

    python scripts/rasgef1c_motifs.py           # writes results/rasgef1c/G_*.csv

Question: e1 and e2 close in the DAM state, so they are unlikely to be MiT/TFE-opened elements. Are they
elements of homeostatic factors (e.g. MEF2) that lose activity in DAM?

1. Motif content. All 392 motifs of the TF analysis (README 35; JASPAR 2024, per-motif p < 1e-4 thresholds)
   scanned over the full e1 and e2 sequences (both strands), with motif families and the family's DAM
   activity t (results/dam_tf). Context: the fraction of DAM-closed, DAM-opened and all tested peaks
   carrying each family (cached 500 bp scans), and the enrichment of each family in DAM-closed peaks
   (Fisher test against non-differential peaks).
2. Same-nucleus TF-element coupling (hippocampus multiome microglia, 6,302 nuclei). For each candidate TF:
   correlation of its log-normalised RNA with e1 / e2 accessibility (fragments > 0), both residualised on
   donor, log depths and the nucleus' RNA DAM score (so shared state is removed), against the same TF's
   correlation with 200 peaks on other chromosomes matched on GC, detection and DAM log2FC decile (z).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from dam_tf_grn import log_odds, motif_genes, pwm_threshold
from ddrmulti.genome import parse_peak_names
from motif_dam_peaks import CODE, fetch, read_jaspar
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/rasgef1c"
E = {"e1": "chr5:180201040-180201876", "e2": "chr5:180196966-180197623"}
SNPS = {"rs113706587": 180201150, "rs116347724": 180197032, "rs111274391": 180196966, "rs76792388": 180202485}
PANEL = ["MEF2C", "MEF2A", "MITF", "TFEC", "TFEB", "TFE3", "BHLHE41", "SPI1", "IRF8", "RUNX1", "CEBPA", "CEBPB",
         "NFE2L2", "MAFB", "FOS", "JUN", "SALL1", "ETV5", "TCF7L2", "SMAD3"]


def scan_positions(seq, pw, thr):
    x = CODE[np.frombuffer(seq.upper().encode(), dtype=np.uint8)]
    w, L = len(pw), len(x)
    hits = []
    for strand, m in (("+", pw), ("-", pw[::-1, ::-1])):
        mat = np.vstack([m.T, np.full((1, w), -10.0)])
        sc = np.array([mat[x[i:i + w], np.arange(w)].sum() for i in range(L - w + 1)])
        hits += [(int(i), strand, float(sc[i])) for i in np.flatnonzero(sc >= thr)]
    return hits


def resid(X, C):
    return X - C @ np.linalg.lstsq(C, X, rcond=None)[0]


def main():
    rng = np.random.default_rng(0)
    TFA = pd.read_csv(ROOT / "results/dam_tf/tf_activity.csv")
    MA = pd.read_csv(ROOT / "results/dam_tf/motif_activity.csv").set_index("motif")
    fam_t = MA.groupby("family")["seaad_t"].apply(lambda v: v.iloc[np.argmax(np.abs(v.to_numpy()))])
    z = np.load(ROOT / "results/dam_tf/motif_hits_p1e4.npz", allow_pickle=True)
    hits, names = z["hits"], list(z["names"])
    keep = [i for i, m in enumerate(names) if m in MA.index]
    hits, names = hits[:, keep], [names[i] for i in keep]
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    fam = MA.loc[names, "family"].to_numpy()

    # ---------- 1. motif content of e1 / e2 (full length) and context
    pfm = read_jaspar(ROOT / "data/ref/motifs/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt")
    reg = pd.DataFrame([{"chrom": p.split(":")[0], "start": int(p.split(":")[1].split("-")[0]),
                         "end": int(p.split("-")[1])} for p in E.values()], index=list(E))
    seqs = fetch(ROOT / "data/ref/hg38.fa.gz", reg)
    rows = []
    for k, (lab, peak) in enumerate(E.items()):
        s0 = reg.at[lab, "start"]
        for m in names:
            pw = log_odds(pfm[m])
            for pos, strand, sc in scan_positions(seqs[k], pw, pwm_threshold(pw)):
                g0, g1 = s0 + pos + 1, s0 + pos + len(pw)
                snp = [r for r, p in SNPS.items() if g0 <= p <= g1]
                rows.append({"element": lab, "motif": m, "family": MA.at[m, "family"], "family_dam_t": fam_t[MA.at[m, "family"]],
                             "start": g0, "end": g1, "strand": strand, "score": sc, "overlaps_snp": ",".join(snp)})
    H = pd.DataFrame(rows)
    H.to_csv(OUT / "G_e1e2_motif_instances.csv", index=False)
    fam_hit = pd.DataFrame(hits, columns=names).T.groupby(fam).any().T.to_numpy()
    fams = sorted(set(fam))
    closed, opened = (res["call"] == "DAM-closed").to_numpy(), (res["call"] == "DAM-open").to_numpy()
    ns = (res["call"] == "ns").to_numpy()
    ctx = []
    for j, f in enumerate(fams):
        a, b = fam_hit[closed, j].sum(), closed.sum()
        c, d = fam_hit[ns, j].sum(), ns.sum()
        orr, p = stats.fisher_exact([[a, b - a], [c, d - c]])
        ctx.append({"family": f, "family_dam_t": fam_t[f], "frac_closed": a / b, "frac_open": fam_hit[opened, j].mean(),
                    "frac_all": fam_hit[:, j].mean(), "OR_closed_vs_ns": orr, "p_closed_vs_ns": p,
                    "in_e1": f in set(H.loc[H["element"] == "e1", "family"]), "in_e2": f in set(H.loc[H["element"] == "e2", "family"])})
    CX = pd.DataFrame(ctx)
    CX["q_closed_vs_ns"] = stats.false_discovery_control(CX["p_closed_vs_ns"])
    CX.to_csv(OUT / "G_family_context.csv", index=False)

    # ---------- 2. same-nucleus TF-element coupling, state-adjusted
    peaks = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    L, gnames = load_libs()
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    A = sp.vstack([L[l]["atac_cells"][(L[l]["cells"]["subclass"] == "Microglia").to_numpy()] for l in cache["library"].unique()]).tocsc()
    R_ = sp.vstack([L[l]["rna_cells"][(L[l]["cells"]["subclass"] == "Microglia").to_numpy()] for l in cache["library"].unique()]).tocsr()
    tot = np.asarray(R_.sum(1)).ravel()
    C = np.column_stack([pd.get_dummies(cache["donor"]).to_numpy(float), np.log10(np.maximum(tot, 1)),
                         np.log10(np.asarray(A.sum(1)).ravel() + 1), cache["score"].to_numpy(float)])
    gsym = pd.Index(gnames.str.upper())
    det = np.asarray((A > 0).mean(0)).ravel()
    pix = peaks.index.get_indexer(res["peak"])
    lfc = pd.Series(res["log2fc"].to_numpy(), index=pix)
    tested = np.flatnonzero(det[pix] >= 0.01)
    pk = pix[tested]
    sub = peaks.iloc[pk].reset_index(drop=True)
    sq = fetch(ROOT / "data/ref/hg38.fa.gz", sub[["chrom", "start", "end"]])
    gc = np.array([(s.upper().count("G") + s.upper().count("C")) / max(len(s), 1) for s in sq])
    gb = pd.qcut(pd.Series(gc).rank(method="first"), 5, labels=False).to_numpy()
    db = pd.qcut(pd.Series(det[pk]).rank(method="first"), 5, labels=False).to_numpy()
    fb = pd.qcut(pd.Series(lfc.loc[pk].to_numpy()).rank(method="first"), 10, labels=False).to_numpy()

    def zcols(X):
        X = resid(X, C)
        return (X - X.mean(0)) / np.where(X.std(0) > 0, X.std(0), 1)

    tf_rows = []
    present = [g for g in PANEL if (gsym == g).any()]
    Yt = zcols(np.column_stack([np.log1p(R_[:, int(np.flatnonzero(gsym == g)[0])].toarray().ravel() / np.maximum(tot, 1) * 1e4)
                                for g in present]))
    n = Yt.shape[0]
    for lab, peak in E.items():
        j = peaks.index.get_loc(peak)
        k = np.flatnonzero(pk == j)[0]
        xe = zcols((A[:, [j]] > 0).toarray().astype(float))[:, 0]
        same = (gb == gb[k]) & (db == db[k]) & (fb == fb[k]) & (sub["chrom"].to_numpy() != "chr5")
        bg = rng.choice(np.flatnonzero(same), min(200, same.sum()), replace=False)
        Xb = zcols((A[:, pk[bg]] > 0).toarray().astype(float))
        r_e = xe @ Yt / n
        r_b = Xb.T @ Yt / n
        for i, g in enumerate(present):
            zz = (r_e[i] - r_b[:, i].mean()) / r_b[:, i].std()
            tf_rows.append({"element": lab, "tf": g, "r_state_adjusted": r_e[i], "null_mean": r_b[:, i].mean(),
                            "z": zz, "p": 2 * stats.norm.sf(abs(zz)), "n_background": len(bg),
                            "tf_motif_in_element": any(g in motif_genes(m) for m in H.loc[H["element"] == lab, "motif"])})
    TC = pd.DataFrame(tf_rows)
    TC["q"] = stats.false_discovery_control(TC["p"])
    TC.to_csv(OUT / "G_tf_element_coupling.csv", index=False)

    pd.set_option("display.width", 220)
    print("1. Motif families with a p < 1e-4 site in e1 / e2 (family DAM activity t; enrichment in DAM-closed peaks):")
    hit_f = sorted(set(H["family"]))
    print(CX[CX["family"].isin(hit_f)].sort_values("family_dam_t")[["family", "family_dam_t", "in_e1", "in_e2", "frac_closed",
          "frac_open", "frac_all", "OR_closed_vs_ns", "q_closed_vs_ns"]].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\n   instances overlapping a credible-set SNP:")
    print(H[H["overlaps_snp"] != ""][["element", "motif", "family", "start", "end", "strand", "overlaps_snp"]].to_string(index=False))
    print("\n   families most enriched in DAM-closed peaks genome-wide:")
    print(CX.sort_values("OR_closed_vs_ns", ascending=False).head(8)[["family", "family_dam_t", "frac_closed", "frac_all",
          "OR_closed_vs_ns", "q_closed_vs_ns", "in_e1", "in_e2"]].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\n2. Same-nucleus TF RNA - element accessibility coupling (state-adjusted; z vs DAM-change-matched peaks):")
    print(TC.sort_values(["element", "z"], ascending=[True, False]).to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
