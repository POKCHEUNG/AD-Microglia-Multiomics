"""Minimal stdlib xlsx -> CSV reader (first sheet), for when openpyxl is unavailable."""
import csv, re, sys, zipfile
import xml.etree.ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
z = zipfile.ZipFile(sys.argv[1])
shared = []
if "xl/sharedStrings.xml" in z.namelist():
    for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
        shared.append("".join(t.text or "" for t in si.iter(f"{{{NS['m']}}}t")))
sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
rows = []
for row in sheet.iter(f"{{{NS['m']}}}row"):
    cells = {}
    for c in row.findall("m:c", NS):
        col = re.match(r"[A-Z]+", c.get("r")).group()
        idx = 0
        for ch in col:
            idx = idx * 26 + ord(ch) - 64
        v = c.find("m:v", NS)
        val = "" if v is None else v.text
        if c.get("t") == "s":
            val = shared[int(val)]
        elif c.get("t") == "inlineStr":
            val = "".join(t.text or "" for t in c.iter(f"{{{NS['m']}}}t"))
        cells[idx - 1] = val
    rows.append([cells.get(i, "") for i in range(max(cells) + 1)] if cells else [])
# pad every row (including a header with trailing empty cells) to the same width so that
# column counts agree; otherwise pandas silently shifts columns into the index
width = max(len(r) for r in rows)
rows = [r + [""] * (width - len(r)) for r in rows]
csv.writer(sys.stdout).writerows(rows)
