"""Recover the mask -> transcript coordinate transform for a GSE263789 plaque mask.

    python scripts/register_plaque_mask.py data/raw/gse263789 GSM8199179_mSS_18M_AD_E3 180

The 'aligned' plaque masks (adjacent-section staining) have a different pixel grid from
both the gem coordinates and the aligned ssDNA image, and no transform is deposited. Here
the transform is estimated from the data: the mask is blurred, flipped / transposed,
scaled and shifted to maximise FFT cross-correlation with the density of plaque-induced
microglial transcripts (REG genes) on a 25 um grid. Registration is then judged on genes
NOT used to fit it (HELD_OUT) and on how sharp the correlation peak is.
"""

from __future__ import annotations

import gzip
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from scipy import ndimage

Image.MAX_IMAGE_PIXELS = None
REG = ["Cst7", "Clec7a", "Itgax", "Lpl", "Spp1", "Axl"]
HELD_OUT = ["Cd68", "Lgals3", "C4b", "Gfap", "Trem2", "Cd9"]
BIN = 50                                                       # DNB per grid cell (25 um)


def gem_grid(path: Path, genes: list[str], shape: tuple[int, int]):
    """Per-bin counts (y, x) for total UMI and each gene in ``genes``."""
    tot = np.zeros(shape)
    per = {g: np.zeros(shape) for g in genes}
    for ch in pd.read_csv(path, sep="\t", comment="#", usecols=["geneID", "x", "y", "MIDCount"], chunksize=20_000_000,
                          dtype={"geneID": "category", "x": np.int32, "y": np.int32, "MIDCount": np.int32}):
        by, bx = (ch["y"] // BIN).to_numpy(), (ch["x"] // BIN).to_numpy()
        np.add.at(tot, (by, bx), ch["MIDCount"].to_numpy())
        f = ch[ch["geneID"].isin(genes)]
        for g, d in f.groupby("geneID", observed=True):
            np.add.at(per[g], ((d["y"] // BIN).to_numpy(), (d["x"] // BIN).to_numpy()), d["MIDCount"].to_numpy())
    return tot, per


def xcorr(a: np.ndarray, b: np.ndarray):
    """Max normalised cross-correlation of b against a over circular shifts; returns (r, dy, dx)."""
    A = np.fft.rfft2(a - a.mean())
    B = np.fft.rfft2(b - b.mean())
    c = np.fft.irfft2(A * np.conj(B), s=a.shape) / (a.std() * b.std() * a.size)
    i = np.unravel_index(np.argmax(c), c.shape)
    dy, dx = [v if v <= s // 2 else v - s for v, s in zip(i, a.shape)]
    return float(c[i]), int(dy), int(dx), c


def main():
    d, prefix, thr = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
    out = Path("results/stereoseq_audit") / prefix
    out.mkdir(parents=True, exist_ok=True)
    gem = d / f"{prefix}_bin1_max.gem.txt.gz"
    n = 26460 // BIN + 1
    cache = out / "grid.npz"
    if cache.exists():
        z = np.load(cache)
        tot, per = z["tot"], {g: z[g] for g in REG + HELD_OUT}
    else:
        tot, per = gem_grid(gem, REG + HELD_OUT, (n, n))
        np.savez_compressed(cache, tot=tot, **per)
    tissue = tot >= 200
    reg = sum(per[g] for g in REG)
    target = ndimage.gaussian_filter(np.where(tissue, reg / np.maximum(tot, 1) * 1e4, 0), 1)

    im = np.array(Image.open(gzip.open(d / f"{prefix.replace("mss_", "mSS_")}_{thr}_PlaqueSegmentation_Binary_Aligned.png.gz")), dtype=np.float32) / 255
    f = 10                                                         # pre-shrink 10x so the scale search is fast
    im = im[: im.shape[0] // f * f, : im.shape[1] // f * f].reshape(im.shape[0] // f, f, im.shape[1] // f, f).mean((1, 3))
    rows = []
    best = None
    for orient in range(8):
        m = im.T if orient & 4 else im
        m = m[::-1] if orient & 1 else m
        m = m[:, ::-1] if orient & 2 else m
        for sy in np.arange(0.90, 1.36, 0.02):
            for sx in np.arange(0.90, 1.36, 0.02):
                # mask pixel -> DNB scale (sy, sx), then to the 25 um grid; place at origin, search shift by FFT
                h, w = int(m.shape[0] * f * sy / BIN), int(m.shape[1] * f * sx / BIN)
                small = np.asarray(Image.fromarray(m).resize((w, h), Image.BILINEAR))
                canvas = np.zeros_like(target)
                hh, ww = min(h, n), min(w, n)
                canvas[:hh, :ww] = small[:hh, :ww]
                canvas = ndimage.gaussian_filter(canvas, 1)
                r, dy, dx, _ = xcorr(target, canvas)
                rows.append((orient, sy, sx, r, dy, dx))
                if best is None or r > best[3]:
                    best = (orient, sy, sx, r, dy, dx, canvas)
    res = pd.DataFrame(rows, columns=["orient", "sy", "sx", "r", "dy", "dx"]).sort_values("r", ascending=False)
    res.to_csv(out / f"registration_search_{thr}.csv", index=False)
    print(res.head(10).to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    by_orient = res.groupby("orient")["r"].max().sort_values(ascending=False)
    print("\nbest r per orientation:", by_orient.round(3).to_dict())

    orient, sy, sx, r, dy, dx, canvas = best
    placed = np.roll(np.roll(canvas, dy, 0), dx, 1)
    # held-out validation: enrichment of genes not used for fitting, inside vs far from registered plaques
    pl = placed > 0.25 * placed.max()
    dist = ndimage.distance_transform_edt(~pl) * BIN * 0.5          # um
    val = []
    for g in HELD_OUT + ["Total_REG"]:
        c = reg if g == "Total_REG" else per[g]
        near = tissue & (dist <= 25)
        far = tissue & (dist > 200)
        e_near = c[near].sum() / tot[near].sum()
        e_far = c[far].sum() / tot[far].sum()
        val.append({"gene": g, "used_for_fit": g == "Total_REG", "near_per10k": e_near * 1e4,
                    "far_per10k": e_far * 1e4, "ratio": e_near / e_far if e_far > 0 else np.nan})
    val = pd.DataFrame(val)
    val.to_csv(out / f"registration_validation_{thr}.csv", index=False)
    # null for the peak: same search statistic with the target shuffled in 8x8-bin blocks
    rng = np.random.default_rng(0)
    m = im.T if orient & 4 else im
    m = m[::-1] if orient & 1 else m
    m = m[:, ::-1] if orient & 2 else m
    null = []
    for _ in range(50):
        k = 8
        t = target[: n // k * k, : n // k * k].reshape(n // k, k, n // k, k).transpose(0, 2, 1, 3).reshape(-1, k, k)
        t = t[rng.permutation(len(t))].reshape(n // k, n // k, k, k).transpose(0, 2, 1, 3).reshape(n // k * k, n // k * k)
        tt = np.zeros_like(target)
        tt[: t.shape[0], : t.shape[1]] = t
        null.append(xcorr(tt, canvas)[0])
    print(f"\nbest: orient={orient} sy={sy:.2f} sx={sx:.2f} shift=({dy},{dx}) bins  r={r:.3f}; "
          f"block-shuffled null r max {max(null):.3f} (mean {np.mean(null):.3f})")
    print("\nHeld-out validation (genes not used in the fit), per 10k UMI within 25 um vs > 200 um:")
    print(val.to_string(index=False, float_format=lambda v: f"{v:.2f}"))
    np.save(out / f"plaque_grid_{thr}.npy", placed)
    pd.Series({"orient": orient, "sy": sy, "sx": sx, "dy_bins": dy, "dx_bins": dx, "r": r,
               "null_max": max(null), "null_mean": float(np.mean(null))}).to_csv(out / f"registration_best_{thr}.csv")


if __name__ == "__main__":
    main()
