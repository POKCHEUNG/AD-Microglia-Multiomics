"""Renumber the English manuscript's references in order of first citation (README 46-47).

    python scripts/renumber_refs.py             # rewrites docs/manuscript_en/*.md in place

Citations are bracketed numbers ([3], [2,5], [4–7]) in 00_front, 01_main, 02_methods and 03_legends;
the list in 04_references is reordered to match and uncited entries are dropped (and reported).
"""

from __future__ import annotations

import re
from pathlib import Path

D = Path(__file__).resolve().parents[1] / "docs/manuscript_en"
TEXT = ["00_front.md", "01_main.md", "02_methods.md", "03_legends.md"]
PAT = re.compile(r"\[(\d+(?:[–,]\d+)*)\]")


def expand(g):
    out = []
    for part in g.split(","):
        a, _, b = part.partition("–")
        out += list(range(int(a), int(b) + 1)) if b else [int(a)]
    return out


def compress(nums):
    nums, out, i = sorted(set(nums)), [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        out.append(f"{nums[i]}–{nums[j]}" if j - i >= 2 else ",".join(map(str, nums[i:j + 1])))
        i = j + 1
    return ",".join(out)


def main():
    texts = {f: (D / f).read_text() for f in TEXT}
    order = []
    for f in TEXT:
        for m in PAT.finditer(texts[f]):
            order += [n for n in expand(m.group(1)) if n not in order]
    new = {old: i + 1 for i, old in enumerate(order)}
    ref = (D / "04_references.md").read_text()
    head, body = ref.split("\n1. ", 1)
    body = "1. " + body
    tail = body[body.index("\n---"):]
    ent = {int(a): b for a, b in re.findall(r"^(\d+)\. (.*)$", body[:body.index("\n---")], re.M)}
    missing = [n for n in order if n not in ent]
    if missing:
        raise SystemExit(f"cited but not listed: {missing}")
    dropped = sorted(set(ent) - set(order))
    for f in TEXT:
        (D / f).write_text(PAT.sub(lambda m: "[" + compress([new[n] for n in expand(m.group(1))]) + "]", texts[f]))
    lines = [f"{new[o]}. {ent[o]}" for o in sorted(order, key=new.get)]
    (D / "04_references.md").write_text(head + "\n" + "\n".join(lines) + "\n" + tail)
    print(f"{len(order)} references; dropped uncited: {[ent[d][:60] for d in dropped]}")


if __name__ == "__main__":
    main()
