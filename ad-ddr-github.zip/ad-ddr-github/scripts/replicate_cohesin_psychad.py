"""Independent replication of the cohesin rise (result 26) in PsychAD MSSM (open; DLPFC; different brain bank).

    python scripts/replicate_cohesin_psychad.py --out results/cohesin_psychad

Fixed before looking: cells = excitatory neurons (class EN) and oligodendrocytes (class
Oligo); donor pseudobulks of raw counts (>= 50 nuclei); AD (AD_status == Yes, no other
neurological diagnosis) vs control (disease == normal), same donor rules as
scripts/run_psychad_neurons.py; covariates age, sex, log nuclei, mitochondrial fraction.
Sets: Mathys 2023 cohesin complex (primary), cohesin loader / regulators (NIPBL, PDS5A,
PDS5B, WAPL, CTCF) per gene (descriptive). Inference: partial r with AD, permutation p, and
competitive p vs 1,000 random gene sets matched on expression decile x gene-length decile.
Pseudobulks are cached in data/processed/psychad_pb/ for reuse.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402
from run_psychad_neurons import pseudobulk  # noqa: E402

COHESIN = ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2"]
REG = ["NIPBL", "PDS5A", "PDS5B", "WAPL", "CTCF", "ESCO2"]
OTHER = ["DLBD_status", "FTD_status", "Tauopathy_status", "Vascular_status", "Schizophrenia", "Parkinson_disease",
         "Bipolar_Disorder", "Tardive_dyskinesia"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--h5ad", default="data/raw/psychad/MSSM_cohort.h5ad")
    ap.add_argument("--out", default="results/cohesin_psychad")
    ap.add_argument("--n-random", type=int, default=1000)
    ap.add_argument("--n-perm", type=int, default=5000)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    cache = ROOT / "data/processed/psychad_pb"
    cache.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(0)

    a = ad.read_h5ad(ROOT / args.h5ad, backed="r")
    o = a.obs
    var = a.raw.var if a.raw is not None else a.var
    sym = pd.Index(var["feature_name"].astype(str))
    glen_all = np.log10(np.maximum(var["feature_length"].to_numpy(float), 1))
    donor = o["donor_id"].astype(str).to_numpy()
    cls = o["class"].astype(str).to_numpy()

    d = o.drop_duplicates("donor_id").set_index("donor_id")
    other = d[[c for c in OTHER if c in d]].astype(str).eq("Yes").any(axis=1)
    info = pd.DataFrame({"ad": (d["AD_status"].astype(str) == "Yes").to_numpy(),
                         "control": (d["disease"].astype(str) == "normal").to_numpy(),
                         "age": d["development_stage"].astype(str).str.extract(r"(\d+)-year")[0].astype(float).to_numpy(),
                         "sex": d["sex"].astype(str).to_numpy(), "other": other.to_numpy()}, index=d.index.astype(str))
    con = info[((info.ad & ~info.other) | (info.control & ~info.ad)) & info.age.notna()].copy()
    con["x"] = con["ad"].astype(float)
    print(f"donors AD vs control: {len(con)} (AD {int(con.x.sum())})", flush=True)

    rows, genes_out = [], []
    for cname in ("EN", "Oligo"):
        f = cache / f"{cname}.npz"
        if f.exists():
            z = np.load(f, allow_pickle=True)
            cats, M = pd.Index(z["cats"]), z["M"]
        else:
            keep = (cls == cname) & np.isin(donor, con.index)
            print(f"  pseudobulk {cname}: {keep.sum():,} nuclei", flush=True)
            cats, M = pseudobulk(a, keep, donor)
            np.savez_compressed(f, cats=np.array(cats), M=M, genes=np.array(sym))
        n = pd.Series(donor[(cls == cname) & np.isin(donor, con.index)]).value_counts().reindex(cats).to_numpy()
        ok = n >= 50
        cats, M, n = cats[ok], M[ok], n[ok]
        dd = con.loc[cats]
        cpm = M / M.sum(1, keepdims=True) * 1e6
        expressed = (cpm >= 1).mean(0) >= 0.5
        L = pd.DataFrame(np.log2(cpm[:, expressed] + 1), columns=sym[expressed], index=cats)
        L = L.loc[:, ~L.columns.duplicated()]
        glen = pd.Series(glen_all[expressed], index=sym[expressed])
        glen = glen[~glen.index.duplicated()].reindex(L.columns)
        cov = dd[["age", "sex"]].assign(log_n=np.log10(n), mito=M[:, sym.str.startswith("MT-")].sum(1) / M.sum(1))
        Z = pd.get_dummies(cov, drop_first=True, dtype=float).to_numpy(float)
        Z1 = np.column_stack([np.ones(len(L)), Z])
        R = L - Z1 @ np.linalg.lstsq(Z1, L.to_numpy(), rcond=None)[0]
        R = (R - R.mean()) / R.std().replace(0, 1)
        x = dd["x"].to_numpy(float)
        ebin = pd.qcut(L.mean().rank(method="first"), 10, labels=False)
        lbin = pd.qcut(glen.rank(method="first"), 10, labels=False)
        strat = (ebin * 10 + lbin).to_numpy()
        by = {s: np.flatnonzero(strat == s) for s in np.unique(strat)}
        cols = pd.Series(np.arange(R.shape[1]), index=R.columns)
        gi = cols.reindex(COHESIN).dropna().astype(int).to_numpy()
        score = R.iloc[:, gi].mean(1).to_numpy()
        r_obs, p_param = partial_r(score[:, None], x, Z)
        r_obs = float(r_obs[0])
        xr = x - Z1 @ np.linalg.lstsq(Z1, x, rcond=None)[0]
        sr = score - Z1 @ np.linalg.lstsq(Z1, score, rcond=None)[0]
        perm = np.array([np.corrcoef(rng.permutation(xr), sr)[0, 1] for _ in range(args.n_perm)])
        rand = np.column_stack([R.iloc[:, [rng.choice(by[s]) for s in strat[gi]]].mean(1).to_numpy()
                                for _ in range(args.n_random)])
        r_null, _ = partial_r(rand, x, Z)
        rows.append({"cells": cname, "n_donors": len(R), "n_ad": int(x.sum()), "n_genes": len(gi), "r": r_obs,
                     "p_param": float(p_param[0]),
                     "p_perm": (np.sum(np.abs(perm) >= abs(r_obs)) + 1) / (args.n_perm + 1),
                     "null_mean": r_null.mean(), "null_sd": r_null.std(), "z_vs_null": (r_obs - r_null.mean()) / r_null.std(),
                     "p_set": (np.sum(np.abs(r_null - r_null.mean()) >= abs(r_obs - r_null.mean())) + 1) / (args.n_random + 1)})
        gl = [g for g in COHESIN + REG if g in R.columns]
        rg, pg = partial_r(R[gl].to_numpy(), x, Z)
        genes_out += [{"cells": cname, "gene": g, "r": float(rr), "p": float(pp)} for g, rr, pp in zip(gl, rg, pg)]
        print(f"  {cname}: {len(R)} donors (AD {int(x.sum())}); cohesin r = {r_obs:+.3f}", flush=True)
    res = pd.DataFrame(rows)
    res.to_csv(out / "cohesin_psychad.csv", index=False)
    pd.DataFrame(genes_out).to_csv(out / "cohesin_psychad_genes.csv", index=False)
    print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(pd.DataFrame(genes_out).pivot(index="gene", columns="cells", values="r").round(3).to_string())


if __name__ == "__main__":
    main()
