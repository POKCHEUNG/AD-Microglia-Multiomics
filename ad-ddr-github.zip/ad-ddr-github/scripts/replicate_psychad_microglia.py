"""Large-scale replication of microglial PTPRG in PsychAD (CELLxGENE, open access).

    python scripts/replicate_psychad_microglia.py

Data: "Frozen in silico sorted myeloid single nuclei RNA-seq from human prefrontal cortex"
(Lee et al. 2026 Nat Genet, CELLxGENE dataset 09642770...), 1,469 donors, DLPFC.
Fixed before looking at gene results:
* cells: class == "MG" (microglia; PVM excluded); donors with >= 20 microglia
* contrast: AD == 1 vs Control == 1 (no continuous pathology is released); donors with
  other neurological diagnoses are excluded from the contrast
* covariates: age, sex, brain bank (Source), log #nuclei, mitochondrial fraction (no PMI)
* PTPRG, direction pre-specified (+): partial r, one-sided permutation p; genome-wide rank;
  competitive p vs 1,000 random genes matched on expression decile AND gene-length decile
* positive control: DAM program (README) and CD9 / GPNMB / APOE; also S100A4 and CECR2
* reported overall and per brain bank (M = MSSM, R = RADC/ROSMAP, H = HBCC)
"""
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402

from ad_ddr.signatures import DAM

rng = np.random.default_rng(0)
a = ad.read_h5ad(ROOT / "data/raw/psychad/myeloid_frozen_snRNA.h5ad", backed="r")
o = a.obs
mg = (o["class"].astype(str) == "MG").to_numpy()
print(f"microglia: {mg.sum():,} nuclei")
raw = a.raw
sym = pd.Index(raw.var["feature_name"].astype(str)) if "feature_name" in raw.var else pd.Index(a.var["feature_name"].astype(str))
length = (raw.var["feature_length"] if "feature_length" in raw.var else a.var["feature_length"]).to_numpy(float)

# donor pseudobulk of raw counts, in chunks (backed)
donor = o["donor_id"].astype(str).to_numpy()
idx_mg = np.flatnonzero(mg)
cats = pd.Index(sorted(set(donor[idx_mg])))
code = pd.Series(np.arange(len(cats)), index=cats)
M = np.zeros((len(cats), raw.shape[1]))
for start in range(0, len(idx_mg), 20000):
    rows = idx_mg[start:start + 20000]
    X = sp.csr_matrix(raw.X[rows])
    c = code[donor[rows]].to_numpy()
    A = sp.csr_matrix((np.ones(len(rows)), (c, np.arange(len(rows)))), shape=(len(cats), len(rows)))
    M += np.asarray((A @ X).todense())
n = pd.Series(donor[idx_mg]).value_counts().reindex(cats).to_numpy()

d = o.iloc[idx_mg].drop_duplicates("donor_id").set_index("donor_id").loc[cats]
info = pd.DataFrame({
    "ad": pd.to_numeric(d["AD"], errors="coerce"), "control": pd.to_numeric(d["Control"], errors="coerce"),
    "age": d["development_stage"].astype(str).str.extract(r"(\d+)-year")[0].astype(float),
    "sex": d["sex"].astype(str), "source": d["Source"].astype(str), "n": n}, index=cats)
other = [c for c in ["PD", "DLBD", "FTD", "ALS", "Tauopathy", "MS", "Vascular", "SCZ", "MDD", "PTSD", "ADHD", "BD_ALL", "TD_ALL"] if c in d]
info["other_neuro"] = d[other].apply(pd.to_numeric, errors="coerce").fillna(0).sum(1).to_numpy() > 0
keep = (info.n >= 20) & info.age.notna() & (((info.ad == 1) & ~info.other_neuro) | ((info.control == 1) & (info.ad != 1)))
info, M = info[keep], M[keep.to_numpy()]
info["x"] = (info.ad == 1).astype(float)
info["mito"] = M[:, sym.str.startswith("MT-")].sum(1) / M.sum(1)
print(f"donors in contrast: {len(info)} (AD {int(info.x.sum())}, control {int((info.x == 0).sum())}); "
      f"by bank: {info.groupby('source').x.agg(['size', 'sum']).to_dict('index')}")

cpm = M / M.sum(1, keepdims=True) * 1e6
expressed = (cpm >= 1).mean(0) >= 0.5
L = pd.DataFrame(np.log2(cpm[:, expressed] + 1), columns=sym[expressed], index=info.index)
glen = pd.Series(np.log10(np.maximum(length[expressed], 1)), index=sym[expressed])
L, glen = L.loc[:, ~L.columns.duplicated()], glen[~glen.index.duplicated()]
ebin = pd.qcut(L.mean().rank(method="first"), 10, labels=False)
lbin = pd.qcut(glen.reindex(L.columns).rank(method="first"), 10, labels=False)
print(f"expressed microglial genes: {L.shape[1]:,}")


def test(sub: pd.DataFrame, label: str):
    Lx = L.loc[sub.index]
    covs = ["age", "sex", "mito"] + (["source"] if sub.source.nunique() > 1 else [])
    Z = pd.get_dummies(sub[covs], drop_first=True, dtype=float).assign(log_n=np.log10(sub.n)).to_numpy(float)
    r, _ = partial_r(Lx.to_numpy(), sub.x.to_numpy(float), Z)
    rs = pd.Series(r, index=Lx.columns)
    Z1 = np.column_stack([np.ones(len(sub)), Z])
    H = Z1 @ np.linalg.pinv(Z1)
    xr = sub.x.to_numpy(float) - H @ sub.x.to_numpy(float)
    out = []
    genes = ["PTPRG", "S100A4", "CECR2", "CD9", "GPNMB", "APOE", "P2RY12", "CX3CR1"]
    dam = [g for g in DAM if g in Lx.columns]
    Lx = Lx.assign(DAM_program=Lx[dam].sub(Lx[dam].mean()).div(Lx[dam].std()).mean(1))
    for g in genes + ["DAM_program"]:
        if g not in Lx.columns:
            continue
        y = Lx[g].to_numpy()
        yr = y - H @ y
        obs = np.corrcoef(xr, yr)[0, 1]
        perm = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(10000)])
        row = {"subset": label, "gene": g, "n_donors": len(sub), "n_AD": int(sub.x.sum()), "r": obs,
               "p_one_sided_up": (np.sum(perm >= obs) + 1) / 10001, "p_two_sided": (np.sum(np.abs(perm) >= abs(obs)) + 1) / 10001}
        if g in rs.index:
            pool = rs.index[((ebin == ebin[g]) & (lbin == lbin[g])).to_numpy() & (rs.index != g)]
            null = rs.loc[rng.choice(pool, 1000)].to_numpy()
            row.update({"genome_rank_pct": float((rs >= rs[g]).mean() * 100), "random_median_r": float(np.median(null)),
                        "p_vs_random_up": (np.sum(null >= rs[g]) + 1) / 1001})
        out.append(row)
    top = rs.sort_values(ascending=False).head(10)
    print(f"  [{label}] top genes up in AD: " + ", ".join(f"{k} {v:+.2f}" for k, v in top.items()))
    return out


rows = test(info, "all banks")
for src, sub in info.groupby("source"):
    if sub.x.sum() >= 10 and (sub.x == 0).sum() >= 10:
        rows += test(sub, f"bank {src}")
res = pd.DataFrame(rows)
outdir = ROOT / "results/psychad"
outdir.mkdir(parents=True, exist_ok=True)
res.to_csv(outdir / "microglia_replication.csv", index=False)
pd.set_option("display.width", 220)
print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

# figure: gene-level r per bank, PTPRG highlighted
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(8, 3.6))
order = ["PTPRG", "APOE", "GPNMB", "DAM_program", "CD9", "P2RY12", "CX3CR1", "CECR2"]
subs = [s_ for s_ in ["all banks", "bank M", "bank R"] if s_ in set(res.subset)]
w = 0.8 / len(subs)
for i, s_ in enumerate(subs):
    d_ = res[res.subset == s_].set_index("gene").reindex(order)
    n_ = int(res.loc[res.subset == s_, "n_donors"].iloc[0])
    ax.bar(np.arange(len(order)) + (i - (len(subs) - 1) / 2) * w, d_.r, width=w, label=f"{s_} (n={n_})")
ax.axhline(0, color="0.5", lw=0.8)
ax.set_xticks(range(len(order)), order, fontsize=8)
ax.set_ylabel("partial r, AD vs control (microglia)")
ax.set_title("PsychAD DLPFC microglia: PTPRG is the top AD-associated gene in every bank", fontsize=9)
ax.legend(fontsize=7, frameon=False)
fig.tight_layout()
fig.savefig(ROOT / "docs/psychad_microglia.png", dpi=160)
