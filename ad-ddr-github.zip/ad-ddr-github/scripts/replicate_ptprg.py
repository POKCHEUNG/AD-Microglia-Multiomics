"""Replication of the microglial PTPRG / S100A4 candidates (README result 12).

    python scripts/replicate_ptprg.py

Run after scripts/run_microglia_genes.py and scripts/check_ptprg_ambient.py.
1. SEA-AD MTG: PTPRG ~ CPS adjusting for covariates + OPC-marker score + mitochondrial fraction
2. Morabito 2021 PFC microglia (independent cohort, 18 donors): pre-specified direction (+),
   one-sided permutation p; AD vs control and Braak stage; vs expression-matched random genes
3. Miyoshi 2024 Visium: PTPRG residual (composition/depth/layer) in microglia-rich and
   grey-matter spots vs Control/earlyAD/AD (spots mix cell types; see README)
Writes results/microglia_genes/replication.csv and docs/ptprg.png.
"""
import sys
from pathlib import Path

import anndata as ad
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402
from run_visium import DX_ORDER, residualise  # noqa: E402

rng = np.random.default_rng(0)
OUT = ROOT / "results/microglia_genes"
rows = []


def donor_sum(X, labels):
    cat = pd.Categorical(labels)
    A = sp.csr_matrix((np.ones(len(cat)), (cat.codes, np.arange(len(cat)))))
    return pd.Index(cat.categories), np.asarray((A @ sp.csr_matrix(X)).todense()), cat


# 1. SEA-AD MTG with OPC + mito adjustment
s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
info = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]]
info[["age", "pmi"]] = info[["age", "pmi"]].apply(pd.to_numeric, errors="coerce")
info = info.dropna()
a = ad.read_h5ad(ROOT / "data/raw/pseudobulk/Immune.h5ad")
a = a[(a.obs["Brain Region"] == "MTG") & a.obs.Supertype.astype(str).str.startswith("Micro-PVM")]
donors, M, cat = donor_sum(a.X, a.obs["Donor ID"].astype(str))
n = a.obs.groupby(cat, observed=False)["Number of nuclei"].sum().to_numpy()
keep = donors.isin(info.index) & (n >= 20)
g = pd.Index(a.var_names)
L = pd.DataFrame(np.log2(M[keep] / M[keep].sum(1, keepdims=True) * 1e6 + 1), columns=g)
D = info.loc[donors[keep]].assign(log_nuclei=np.log10(n[keep]))
mito = M[keep][:, g.str.startswith("MT-")].sum(1) / M[keep].sum(1)
opc = L[["PDGFRA", "VCAN", "OLIG1", "OLIG2"]].mean(1).to_numpy()
Zb = pd.get_dummies(D[["age", "sex", "pmi", "log_nuclei"]], drop_first=True, dtype=float).to_numpy()
for gene in ("PTPRG", "S100A4"):
    for tag, Z in (("covariates", Zb), ("covariates + OPC + mito", np.column_stack([Zb, opc, mito]))):
        r, p = partial_r(L[[gene]].to_numpy(), D.cps.to_numpy(float), Z)
        rows.append({"cohort": "SEA-AD MTG (discovery)", "gene": gene, "exposure": f"CPS | {tag}", "n_donors": len(D),
                     "r": r[0], "p": p[0], "p_type": "two-sided analytic"})

# 2. Morabito
X = sc.read_10x_h5(ROOT / "data/raw/morabito/GSE174367_snRNA-seq_filtered_feature_bc_matrix.h5")
X.var_names_make_unique()
m = pd.read_csv(ROOT / "data/raw/morabito/GSE174367_snRNA-seq_cell_meta.csv.gz").set_index("Barcode")
X = X[X.obs_names.isin(m.index)]
mm = m.loc[X.obs_names]
sel = (mm["Cell.Type"] == "MG").to_numpy()
X, mm = X[sel], mm[sel]
donors, M, cat = donor_sum(X.X, mm.SampleID)
n = np.bincount(cat.codes)
g = pd.Index(X.var_names)
cpm = M / M.sum(1, keepdims=True) * 1e6
expressed = (cpm >= 1).mean(0) >= 0.5
L = pd.DataFrame(np.log2(cpm[:, expressed] + 1), columns=g[expressed], index=donors)
d = mm.drop_duplicates("SampleID").set_index("SampleID").loc[donors]
D = pd.DataFrame({"ad": (d.Diagnosis == "AD").astype(float).to_numpy(), "age": d.Age.to_numpy(float), "sex": d.Sex.to_numpy(),
                  "braak": d["Tangle.Stage"].str.extract(r"(\d)")[0].astype(float).to_numpy(), "log_nuclei": np.log10(n)},
                 index=donors)
Z = pd.get_dummies(D[["age", "sex", "log_nuclei"]], drop_first=True, dtype=float).to_numpy()
bins = pd.qcut(L.mean().rank(method="first"), 10, labels=False)
Zr = np.column_stack([np.ones(len(D)), Z])
H = Zr @ np.linalg.pinv(Zr)
for x in ("ad", "braak"):
    rs = pd.Series(partial_r(L.to_numpy(), D[x].to_numpy(float), Z)[0], index=L.columns)
    for gene in ("PTPRG", "S100A4"):
        y = L[gene].to_numpy()
        xr, yr = D[x].to_numpy(float) - H @ D[x].to_numpy(float), y - H @ y
        perm = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(20000)])
        pool = rs.index[(bins == bins[gene]).to_numpy() & (rs.index != gene)]
        null = rs.loc[rng.choice(pool, 1000)].to_numpy()
        rows.append({"cohort": "Morabito 2021 PFC (independent)", "gene": gene,
                     "exposure": "AD vs control" if x == "ad" else "Braak stage", "n_donors": len(D), "r": rs[gene],
                     "p": (np.sum(perm >= rs[gene]) + 1) / 20001, "p_type": "one-sided permutation (pre-specified +)",
                     "p_vs_random_genes": (np.sum(null >= rs[gene]) + 1) / 1001,
                     "genome_rank_top_pct": float((rs >= rs[gene]).mean() * 100)})

# 3. Visium
v = ad.read_h5ad(ROOT / "data/raw/miyoshi/miyoshi_visium.h5ad")
o = v.obs.copy()
gi = list(v.var_names).index("PTPRG")
cnt = np.asarray(v.X[:, gi].todense()).ravel()
tot = np.asarray(v.X.sum(1)).ravel()
o["ptprg"] = np.log1p(cnt / np.maximum(tot, 1) * 1e4)
o["ptprg_res"] = residualise(o, ["ptprg"])["ptprg"]
for label, mask in (("microglia-rich spots", o.MG_deconv >= 0.2), ("grey-matter spots", ~o.annotation.astype(str).str.startswith("WM"))):
    t = o[mask].groupby("donor").agg(v=("ptprg_res", "mean"), dx=("Diagnosis", "first"), age=("Age", "first"), sex=("Sex", "first"))
    t = t[t.dx.isin(DX_ORDER)].assign(o=lambda d_: d_.dx.map(DX_ORDER))
    r, p = partial_r(t[["v"]].to_numpy(), t.o.to_numpy(float), pd.get_dummies(t[["age", "sex"]], drop_first=True, dtype=float).to_numpy())
    rows.append({"cohort": f"Miyoshi 2024 Visium ({label})", "gene": "PTPRG", "exposure": "Control/earlyAD/AD trend",
                 "n_donors": len(t), "r": r[0], "p": p[0], "p_type": "two-sided analytic"})

res = pd.DataFrame(rows)
res.to_csv(OUT / "replication.csv", index=False)
print(res.to_string(index=False, float_format=lambda x: f"{x:.3g}"))

# figure: PTPRG / S100A4 across regions and cohorts
reg = pd.read_csv(OUT / "candidates_by_region.csv")
fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
order = ["MEC", "HIP", "ITG", "MTG", "STG", "FI", "AnG", "DFC", "V1C"]
for gene, c, off in (("PTPRG", "#c0392b", -0.15), ("S100A4", "#3b6fb6", 0.15)):
    d_ = reg[reg.gene == gene].set_index("region").reindex(order)
    ax[0].bar(np.arange(len(order)) + off, d_.r, width=0.3, color=c, label=gene)
ax[0].set_xticks(range(len(order)), order, fontsize=8)
ax[0].axhline(0, color="0.5", lw=0.8)
ax[0].set_ylabel("partial r with local CPS (microglia)")
ax[0].set_title("SEA-AD: 9 regions (MTG = discovery; regions share donors)", fontsize=9)
ax[0].legend(fontsize=7, frameon=False)
rep = res[res.cohort.str.startswith("Morabito")]
lab = rep.gene + "\n" + rep.exposure.str.replace("AD vs control", "AD vs ctrl")
ax[1].bar(range(len(rep)), rep.r, color=["#c0392b" if g_ == "PTPRG" else "#3b6fb6" for g_ in rep.gene])
for i, (_, row) in enumerate(rep.iterrows()):
    ax[1].text(i, row.r + 0.02, f"p={row.p:.3f}", ha="center", fontsize=7)
ax[1].set_xticks(range(len(rep)), lab, fontsize=7)
ax[1].axhline(0, color="0.5", lw=0.8)
ax[1].set_ylabel("partial r (microglia pseudobulk)")
ax[1].set_title("Independent cohort: Morabito 2021 PFC (18 donors; one-sided)", fontsize=9)
fig.tight_layout()
fig.savefig(ROOT / "docs/ptprg.png", dpi=160)
print("wrote", OUT / "replication.csv", "and docs/ptprg.png")
