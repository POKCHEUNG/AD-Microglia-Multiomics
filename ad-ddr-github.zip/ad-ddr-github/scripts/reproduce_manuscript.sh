#!/usr/bin/env bash
# Reproduce every analysis, figure and draft of the manuscript, in dependency order (docs/REPRODUCIBILITY.md).
#
#   ./scripts/reproduce_manuscript.sh [stage ...]       # stages: data seaad atac hippo psychad spatial genetics
#                                                       #         results figures drafts   (default: all, in order)
#
# Run from the repository root with the environment of requirements-lock.txt activated (or PYTHON=...).
# Downloads are large (SEA-AD ATAC ~60 GB streamed twice + once per nucleus, hippocampus fragments ~54 GB
# streamed twice, PsychAD MSSM 36 GB kept); streaming steps keep only reduced matrices. Every step skips
# work whose outputs already exist where the underlying script supports it. Approximate wall times on a
# 2023 laptop (M2, 48 GB RAM) are given per step.
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PYTHON:-.venv/bin/python}
run() { echo; echo "==> $*"; "$@"; }
dl() { # dl URL DEST: fresh download, accepted only if the size matches (no resume + retry, which can corrupt)
  [ -s "$2" ] && return 0
  mkdir -p "$(dirname "$2")"
  curl -fsSL -o "$2.part" "$1" && mv "$2.part" "$2"
}

stage_data() {
  ./scripts/download_pseudobulk.sh                                              # SEA-AD pseudobulks, ~4 GB
  dl "https://sea-ad-single-cell-profiling.s3.amazonaws.com/Multiregion_2026/model_outputs/continuous_pseudo-progression_score/Global_and_Local_CPS.20260105.csv" data/meta/Global_and_Local_CPS.csv
  dl "https://cdn.prod.website-files.com/689cfbd308fa7373b604d290/6a4579d1d67150b0e69ad044_sea-ad-quantitative-neuropathology-063026.xlsx" data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx
  dl https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_32/gencode.v32.basic.annotation.gtf.gz data/ref/gencode.v32.basic.annotation.gtf.gz
  dl https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_mouse/release_M25/gencode.vM25.basic.annotation.gtf.gz data/ref/gencode.vM25.basic.annotation.gtf.gz
  dl https://hgdownload.soe.ucsc.edu/goldenPath/hg38/bigZips/hg38.fa.gz data/ref/hg38.fa.gz
  dl https://hgdownload.soe.ucsc.edu/goldenPath/hg38/liftOver/hg38ToMm10.over.chain.gz data/ref/hg38ToMm10.over.chain.gz
  dl https://jaspar.elixir.no/download/data/2024/CORE/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt data/ref/motifs/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt
  dl https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/GCST90027001-GCST90028000/GCST90027158/GCST90027158_buildGRCh38.tsv.gz data/ref/gwas/GCST90027158_buildGRCh38.tsv.gz
  dl https://raw.githubusercontent.com/eQTL-Catalogue/eQTL-Catalogue-resources/master/tabix/tabix_ftp_paths.tsv data/ref/eqtl/tabix_ftp_paths.tsv
  dl https://chip-atlas.dbcls.jp/data/hg38/assembled/Oth.Neu.50.RAD21.AllCell.bed data/ref/chipatlas/Oth.Neu.50.RAD21.AllCell.bed
  dl https://ftp.ncbi.nlm.nih.gov/geo/series/GSE296nnn/GSE296025/suppl/GSE296025_RAW.tar data/raw/gse296025/RAW.tar   # 5xFAD ATAC
  tar xf data/raw/gse296025/RAW.tar -C data/raw/gse296025
  [ -s data/ref/msigdb_hallmark.csv ] || "$PY" -c "import decoupler as dc; dc.op.hallmark(organism='human').to_csv('data/ref/msigdb_hallmark.csv', index=False)"
  [ -s data/ref/collectri_human.csv ] || "$PY" -c "import decoupler as dc; dc.op.collectri(organism='human').to_csv('data/ref/collectri_human.csv', index=False)"
  # Manual (see docs/REPRODUCIBILITY.md): eQTL Catalogue SuSiE credible sets QTD000559/609/434 -> data/ref/eqtl/susie/;
  # ENCODE-rE2G ENCFF789IHU / ENCFF463AGD -> data/ref/e2g/; published supplementary tables -> data/raw/published_claims/
  # and data/raw/haglund2025/; GEO datasets of the spatial stage.
}

stage_seaad() {   # SEA-AD RNA: DDR screen across cell types and regions, published sets, core question (RNA)
  run "$PY" scripts/run_celltype_screen.py                                      # ~6 min   Fig. 2a
  run "$PY" scripts/run_published_sets.py --match-length --out results/published_sets_lenmatched   # Fig. 3a
}

stage_atac() {    # SEA-AD snATAC: three streaming passes, then the chromatin analyses
  run ./scripts/stream_atac_donors.sh 3                                         # ~1.5 h  subclass pseudobulks
  run ./scripts/stream_atac_donors.sh 3 data/processed/atac_pb_micro Microglia-PVM   # ~2 h  microglial supertypes
  run ./scripts/stream_atac_micro_cells.sh 3                                    # ~2 h    per-nucleus microglia
  run "$PY" scripts/run_laminar_mismatch.py                                     # Fig. 2e,f
  run "$PY" scripts/run_dam_peaks.py                                            # Fig. 4a
  run "$PY" scripts/validate_dam_peaks.py                                       # Fig. 4b
  run "$PY" scripts/run_dam_regulatory.py                                       # Fig. 4c,d, 6a
  run "$PY" scripts/robust_homeostatic_shift.py                                 # Fig. 5a,b
  run "$PY" scripts/split_replication.py --n-splits 100                         # Fig. 3c (halves), 5c
  run "$PY" scripts/homeostatic_mixture.py
  run "$PY" scripts/seaad_nucleus_shift.py                                      # Fig. 5e,f
  run "$PY" scripts/audit_dam_de.py                                             # Supplementary Note 1
  run "$PY" scripts/audit_dam_domains_thinning.py
}

stage_hippo() {   # hippocampus multiome (GSE288063 + GSE278576)
  dl https://ftp.ncbi.nlm.nih.gov/geo/series/GSE288nnn/GSE288063/suppl/GSE288063_metadata_humanAD.tsv.gz data/raw/hippo_multiome/GSE288063_metadata_humanAD.tsv.gz
  run ./scripts/stream_hippo_multiome.sh                                        # ~6 h
  run "$PY" scripts/run_hippo_replication.py                                    # Fig. 4c,e, 5d
  run "$PY" scripts/make_supp_umap.py                                           # Fig. S1 (and per-nucleus cache)
  run "$PY" scripts/check_hippo_batch.py
  run "$PY" scripts/hippo_continuous_state.py                                   # Fig. S2e,f (and hippocampus-defined axis)
  run "$PY" scripts/homeostatic_shift_selection.py                              # Fig. S2a-d
  run "$PY" scripts/microglia_states.py                                         # Fig. S3
  run "$PY" scripts/dam_tf_grn.py                                               # ~15 min  Fig. 7
  run "$PY" scripts/tf_ranking.py                                               # ~5 min   Fig. S7
}

stage_psychad() { # PsychAD MSSM (CELLxGENE, 36 GB)
  dl https://datasets.cellxgene.cziscience.com/0e853475-e298-4b09-881a-ed0b60d5a8c9.h5ad data/raw/psychad/MSSM_cohort.h5ad
  run "$PY" scripts/run_psychad_neurons.py                                      # ~4 min   Fig. 2b
  run "$PY" scripts/replicate_cohesin_psychad.py                                # ~40 min  Fig. 3b,c
  run "$PY" scripts/psychad_extra_pb.py                                         # ~25 min
  run "$PY" scripts/psychad_subclass_pb.py                                      # ~6 min   24 subclasses
  run "$PY" scripts/ddr_equivalence.py                                          # ~25 min  Fig. S4
  run "$PY" scripts/ddr_endpoints.py                                            # Fig. S5
  run "$PY" scripts/global_vs_specific.py                                       # ~15 min  Fig. 1d-f
  run "$PY" scripts/psychad_global_vs_specific.py                               # ~8 min   Fig. S8
  run "$PY" scripts/published_claims_pilot.py                                   # ~8 min   Fig. S9
  run "$PY" scripts/published_claims_power.py                                   # ~4 min   Fig. S9a
}

stage_spatial() { # human GeoMx and mouse Stereo-seq / ATAC
  G=https://ftp.ncbi.nlm.nih.gov/geo/series/GSE306nnn/GSE306381
  dl $G/suppl/GSE306381_RAW.tar data/raw/geomx_gse306381/GSE306381_RAW.tar
  dl $G/suppl/GSE306381_Hs_R_NGS_WTA_v1.0.pkc.gz data/raw/geomx_gse306381/GSE306381_Hs_R_NGS_WTA_v1.0.pkc.gz
  dl $G/matrix/GSE306381_series_matrix.txt.gz data/raw/geomx_gse306381/GSE306381_series_matrix.txt.gz
  mkdir -p data/raw/geomx_gse306381/raw && tar xf data/raw/geomx_gse306381/GSE306381_RAW.tar -C data/raw/geomx_gse306381/raw
  run "$PY" scripts/build_geomx.py data/raw/geomx_gse306381 data/processed/geomx
  run "$PY" scripts/run_geomx_zones.py                                          # Fig. 2c
  # GSE263789 gem files and plaque masks must be in data/raw/gse263789 (docs/REPRODUCIBILITY.md)
  for P in GSM8199179_mSS_18M_AD_E3:180 GSM8199180_mSS_18M_AD_E4:220 GSM8199182_mss_3M_WT_AD_E1:170 GSM8199183_mSS_3M_WT_AD_E2:210; do
    s=${P%%:*}
    run "$PY" scripts/build_stereoseq_bins.py data/raw/gse263789/${s}_bin1_max.gem.txt.gz data/processed/stereoseq/$s
    run "$PY" scripts/register_plaque_mask.py data/raw/gse263789 "$s" "${P##*:}"
  done
  run "$PY" scripts/run_stereoseq_plaque_ddr.py                                 # Fig. 2d
}

stage_genetics() { # GWAS, eQTL, fine-mapping, RASGEF1C chain (remote tabix to EBI and 1000 Genomes)
  run "$PY" scripts/gwas_dam_peaks.py                                           # ~5 min   Fig. 6d
  run "$PY" scripts/fetch_eqtl_regions.py                                       # ~1.5 h
  run "$PY" scripts/candidate_links.py                                          # Fig. 6b,c
  run "$PY" scripts/susie_finemap.py                                            # needs R + susieR
  run "$PY" scripts/fetch_rasgef1c_qtls.py QTD000559 QTD000560 QTD000561 QTD000562 QTD000563 QTD000171 QTD000176 QTD000051 QTD000075 QTD000001 QTD000384
  run "$PY" scripts/rasgef1c_chain.py                                           # ~15 min  Fig. S6
  run "$PY" scripts/haglund_rasgef1c.py                                         # Fig. S6e (top row)
}

stage_figures() {
  run "$PY" scripts/make_paper_figures.py                                       # Fig. 1-7
  run "$PY" scripts/make_supp_fig5.py                                           # Fig. S2
  run "$PY" scripts/make_supp_states.py                                         # Fig. S3
  run "$PY" scripts/make_supp_equivalence.py                                    # Fig. S4
  run "$PY" scripts/make_supp_endpoints.py                                      # Fig. S5
  run "$PY" scripts/make_supp_chain_tf.py                                       # Fig. S6-S9
  run "$PY" scripts/export_source_data.py                                       # docs/source_data/
}

stage_drafts() {
  run "$PY" scripts/renumber_refs.py
  run "$PY" scripts/build_draft_html.py en
  run "$PY" scripts/build_draft_html.py
}

STAGES=("$@")
[ ${#STAGES[@]} -eq 0 ] && STAGES=(data seaad atac hippo psychad spatial genetics figures drafts)
for s in "${STAGES[@]}"; do
  echo; echo "######## stage: $s"
  "stage_$s"
done
