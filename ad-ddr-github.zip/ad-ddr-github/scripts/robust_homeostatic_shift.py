"""Robustness of "homeostatic microglia shift along the DAM chromatin axis with amyloid" (result 22).

    python scripts/robust_homeostatic_shift.py --out results/dam_peaks

Score per donor (Micro-PVM_2 pseudobulk, >= 30 nuclei): mean z of log2 CPM over DAM-open
peaks minus DAM-closed peaks (peaks from scripts/run_dam_peaks.py). Exposure: grey-matter
6E10 objects per area (log). Each row adds one challenge; p_set compares with 500 random
peak sets matched on homeostatic accessibility, scored the same way.

Challenges raised by the literature check:
  label contamination  DAM-like share of microglial nuclei (from the same ATAC objects) as a
                       covariate: if Micro-PVM_2 labels absorb DAM-like cells in plaque-rich
                       donors, the shift should vanish once that share is controlled
  depth / chemistry    log total fragments and multiome fraction of the Micro-PVM_2 pseudobulk;
                       and the score recomputed from ATAC-only nuclei
  APOE / progression   APOE e4 dosage; CPS (does the shift follow plaques or general progression?)
  donor selection      only donors not used to call the peaks
  other exposures      AT8 (tau), dense-core plaque area, activated Iba1 cells
  influence            leave-one-donor-out range of r
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr.stats import _covar_matrix, _resid
from run_dam_peaks import DAM, HOM, load

ROOT = Path(__file__).resolve().parents[1]
QCOL = {"6E10": "number of 6e10 positive objects per area", "AT8": "number of AT8 positive cells per area",
        "dense_core": "percent 6e10 dense core plaque area", "Iba1_activated": "number of activated Iba1 positive cells per area"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/dam_peaks")
    ap.add_argument("--n-rand", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    rng = np.random.default_rng(args.seed)

    res = pd.read_csv(out / "dam_peaks_all.csv.gz")
    d = ROOT / "data/processed/atac_pb_micro"
    rows, M = load(d)
    peaks = pd.Index((d / "peaks.txt").read_text().split())
    pix = peaks.get_indexer(res["peak"])
    call = res["call"].to_numpy()
    openi, closi, nsi = (np.flatnonzero(call == c) for c in ("DAM-open", "DAM-closed", "ns"))
    acc = np.log2(res["cpm_hom"].to_numpy() + 1)
    bins = pd.qcut(pd.Series(acc).rank(method="first"), 20, labels=False).to_numpy()
    pool = {b: nsi[bins[nsi] == b] for b in range(20)}
    rand = [(np.array([rng.choice(pool[b]) for b in bins[openi]]), np.array([rng.choice(pool[b]) for b in bins[closi]]))
            for _ in range(args.n_rand)]

    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    disc = set(pd.read_csv(out / "discovery_donors.csv")["donor"])

    micro = rows[rows["subclass"].str.startswith("Micro")]
    n_all = micro.groupby("donor")["n_nuclei"].sum()
    n_dam = micro[micro["subclass"] == DAM].groupby("donor")["n_nuclei"].sum().reindex(n_all.index).fillna(0)

    def score_matrix(method=None):
        r = rows[rows["subclass"] == HOM]
        if method:
            r = r[r["method"] == method]
        n = r.groupby("donor")["n_nuclei"].sum()
        donors = [x for x in n.index[n >= 30] if x in gm.index and x in meta.index]
        L, info = [], []
        for x in donors:
            ix = r.index[r["donor"] == x].to_numpy()
            c = np.asarray(M[ix].sum(0)).ravel()
            L.append(np.log2(c[pix] / c.sum() * 1e6 + 1))
            multi = r.loc[ix].loc[r.loc[ix, "method"] == "10xMulti", "n_nuclei"].sum() / n[x]
            info.append({"donor": x, "lognuc": np.log10(n[x]), "logfrag": np.log10(c.sum()), "frac_multi": multi})
        L = np.array(L)
        return (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1), pd.DataFrame(info)

    Lz_all, info_all = score_matrix()
    Lz_atac, info_atac = score_matrix("10xATAC_v1.1")

    def add_cols(info):
        x = info["donor"]
        info = info.assign(age=pd.to_numeric(meta.loc[x, "Age at Death"].to_numpy(), errors="coerce"),
                           sex=meta.loc[x, "Sex"].astype(str).to_numpy(),
                           pmi=pd.to_numeric(meta.loc[x, "PMI"].to_numpy(), errors="coerce"),
                           apoe4=meta.loc[x, "APOE Genotype"].astype(str).str.count("4").to_numpy().astype(float),
                           dam_share=(n_dam.reindex(x) / n_all.reindex(x)).to_numpy(),
                           cps=cps.reindex(x).to_numpy())
        for k, c in QCOL.items():
            v = pd.to_numeric(gm[c].reindex(x), errors="coerce").to_numpy()
            info[k] = np.log10(v + 1e-3) if "percent" in c else np.log10(v * 1e6 + 1)
        return info

    info_all, info_atac = add_cols(info_all), add_cols(info_atac)
    base_cov = ["age", "sex", "pmi", "lognuc"]

    def test(Lz, info, exposure, cov, keep=None, label=""):
        m = info[[exposure] + cov].notna().all(1).to_numpy()
        if keep is not None:
            m &= keep
        I, L = info[m].reset_index(drop=True), Lz[m]
        Z = _covar_matrix(I, cov)
        xr = _resid(I[exposure].to_numpy(float), Z)

        def r_of(o, c):
            s = L[:, o].mean(1) - L[:, c].mean(1)
            return np.corrcoef(xr, _resid(s, Z))[0, 1]
        obs = r_of(openi, closi)
        null = np.array([r_of(o, c) for o, c in rand])
        loo = []
        for i in range(len(I)):
            k = np.ones(len(I), bool)
            k[i] = False
            Zk = _covar_matrix(I[k], cov)
            s = L[k][:, openi].mean(1) - L[k][:, closi].mean(1)
            loo.append(np.corrcoef(_resid(I[exposure].to_numpy(float)[k], Zk), _resid(s, Zk))[0, 1])
        return {"test": label, "exposure": exposure, "covariates": "+".join(cov), "n_donors": int(m.sum()), "r": obs,
                "null_mean": null.mean(),
                "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (len(null) + 1),
                "loo_min": min(loo), "loo_max": max(loo)}

    held = ~info_all["donor"].isin(disc).to_numpy()
    # per-donor baseline score and exposure (for plotting): residualised on the baseline covariates
    mb = info_all[["6E10"] + base_cov].notna().all(1).to_numpy()
    Ib = info_all[mb].reset_index(drop=True)
    Zb = _covar_matrix(Ib, base_cov)
    sb = Lz_all[mb][:, openi].mean(1) - Lz_all[mb][:, closi].mean(1)
    Ib.assign(axis_resid=_resid(sb, Zb), x_resid=_resid(Ib["6E10"].to_numpy(float), Zb),
              held_out=~Ib["donor"].isin(disc)).to_csv(out / "homeostatic_shift_donors.csv", index=False)
    T = [
        test(Lz_all, info_all, "6E10", base_cov, label="baseline (result 22)"),
        test(Lz_all, info_all, "6E10", base_cov, held, "held-out donors"),
        test(Lz_all, info_all, "6E10", base_cov + ["dam_share"], label="+ DAM-like share (label contamination)"),
        test(Lz_all, info_all, "6E10", base_cov + ["dam_share"], held, "+ DAM-like share, held-out"),
        test(Lz_all, info_all, "6E10", base_cov + ["logfrag", "frac_multi"], label="+ depth and chemistry"),
        test(Lz_atac, info_atac, "6E10", base_cov, label="ATAC-only nuclei"),
        test(Lz_all, info_all, "6E10", base_cov + ["apoe4"], label="+ APOE e4 dosage"),
        test(Lz_all, info_all, "6E10", base_cov + ["cps"], label="+ CPS (plaques beyond progression?)"),
        test(Lz_all, info_all, "cps", base_cov, label="CPS as exposure"),
        test(Lz_all, info_all, "6E10", base_cov + ["dam_share", "logfrag", "frac_multi", "apoe4"], label="all covariates"),
        test(Lz_all, info_all, "AT8", base_cov, label="AT8 (tau) as exposure"),
        test(Lz_all, info_all, "AT8", base_cov + ["6E10"], label="AT8 adjusted for 6E10"),
        test(Lz_all, info_all, "6E10", base_cov + ["AT8"], label="6E10 adjusted for AT8"),
        test(Lz_all, info_all, "dense_core", base_cov, label="dense-core plaque area"),
        test(Lz_all, info_all, "Iba1_activated", base_cov, label="activated Iba1 cells"),
    ]
    T = pd.DataFrame(T)
    T.to_csv(out / "homeostatic_shift_robustness.csv", index=False)
    print(T.drop(columns="covariates").to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nSpearman(DAM-like share, 6E10) = {info_all[['dam_share', '6E10']].corr('spearman').iloc[0, 1]:.2f}")


if __name__ == "__main__":
    main()
