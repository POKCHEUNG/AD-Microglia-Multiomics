"""SEA-AD MTG: DDR / AD programs vs. AD pseudo-progression (CPS), donor by donor.

    python scripts/run_analysis.py --out results/v2

RNA uses all final nuclei; ATAC uses paired multiome nuclei from donors with
>= --min-paired of them. Scores are depth-adjusted within donors, pseudobulked per
(cell group, donor) and tested against CPS with permutation p-values.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from ad_ddr import io, plotting, scoring, stats
from ad_ddr.signatures import NEURONAL_REPAIR, all_programs
from ddrmulti.genome import read_gtf_genes
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
EXC, INH = "Neuronal: Glutamatergic", "Neuronal: GABAergic"

# Pre-specified primary hypotheses: (grouping, group, program). BH is applied within this family.
PRIMARY = (
    [("class", c, p) for c in (EXC, INH) for p in NEURONAL_REPAIR + ["p53_targets"]]
    + [("group", "Microglia-PVM", "DAM"),             # positive control
       ("group", "Microglia-PVM", "cGAS_STING_IFN"),
       ("group", "Astrocyte", "Reactive_astro")]
)


def stream(donors, args, programs):
    """One pass over donors: RNA scores per nucleus + ATAC count accumulators."""
    scorer = None
    acc = {"group": scoring.AtacAccumulator(), "class": scoring.AtacAccumulator()}
    obs_all, atac_donors = [], []
    for d in donors:
        rna, atac = io.load_donor(*io.donor_paths(ROOT / "data/raw", d))
        if scorer is None:
            scorer = scoring.ProgramScorer(programs, seed=args.seed).fit(rna)
        rna.obs["group"] = scoring.cell_groups(rna.obs)
        obs = rna.obs.join(scorer.score(rna))
        obs_all.append(obs[obs["group"].notna()])
        if atac.n_obs >= args.min_paired:
            g = rna.obs.loc[atac.obs_names, "group"]
            keep = g.notna().to_numpy()
            acc["group"].add(atac[keep], g[keep], d)
            acc["class"].add(atac[keep], atac.obs.loc[keep, "class"], d)
            atac_donors.append(d)
        print(f"  {d}: {rna.n_obs:6,} RNA nuclei, {atac.n_obs:5,} paired"
              f"{'' if atac.n_obs >= args.min_paired else '  (ATAC skipped)'}", flush=True)
        del rna, atac
    return pd.concat(obs_all), acc, atac_donors


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/v2")
    ap.add_argument("--donors", nargs="*", default=None)
    ap.add_argument("--min-paired", type=int, default=500, help="min paired nuclei for a donor's ATAC")
    ap.add_argument("--covariates", nargs="*", default=["age"])
    ap.add_argument("--n-perm", type=int, default=10_000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)

    programs = all_programs()
    donors = args.donors or io.selected_donors(ROOT / "data/meta/selected_donors.csv")
    obs, acc, atac_donors = stream(donors, args, programs)
    rna_cols = [c for c in obs if c.startswith("rna_")]
    print(f"RNA: {len(obs):,} nuclei, {obs['donor'].nunique()} donors; ATAC: {len(atac_donors)} donors")

    obs = scoring.depth_adjust(obs, rna_cols, groupby="group")
    obs[["donor", "group", "class", "supertype", "method", "log_umi"] + rna_cols].to_csv(
        out / "cell_scores.csv.gz")

    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    tables = {}
    for grouping in ("group", "class"):
        pb = scoring.pseudobulk(obs, rna_cols, groupby=grouping)
        pa = acc[grouping].score(genes, programs, groupby=grouping, seed=args.seed)
        pb = pb.merge(pa, on=[grouping, "donor"], how="left")
        pb.to_csv(out / f"pseudobulk_{grouping}.csv", index=False)
        atac_cols = [c for c in pa if c.startswith("atac_")]
        res = stats.cps_association(pb, rna_cols + atac_cols, groupby=grouping, covariates=args.covariates,
                                    n_perm=args.n_perm, seed=args.seed)
        res.to_csv(out / f"cps_association_{grouping}.csv", index=False)
        tables[grouping] = (pb, res, atac_cols)

    # primary family
    rows = []
    for grouping, grp, prog in PRIMARY:
        res = tables[grouping][1]
        for mod in ("rna", "atac"):
            hit = res[(res[grouping] == grp) & (res["score"] == f"{mod}_{prog}")]
            if len(hit):
                rows.append({"cells": grp, "program": prog, "modality": mod,
                             **hit.iloc[0][["r", "slope", "p_perm", "n_donors"]].to_dict()})
    primary = pd.DataFrame(rows)
    primary["q_primary"] = bh(primary["p_perm"].to_numpy())
    primary.to_csv(out / "primary_hypotheses.csv", index=False)
    print("\nPrimary hypotheses (partial r | " + "+".join(args.covariates) + "):")
    print(primary.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    pb_g, res_g, atac_g = tables["group"]
    for label, r in (("group", res_g), ("class", tables["class"][1])):
        print(f"\n[{label}] fraction p<0.05: {(r['p_perm'] < 0.05).mean():.3f} of {len(r)} tests")
    print("\nTop exploratory (cell group):")
    print(res_g.head(10).to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    conc = stats.rna_atac_concordance(pb_g[["group", "donor"] + rna_cols], pb_g[["group", "donor"] + atac_g],
                                      list(programs), groupby="group")
    conc.to_csv(out / "rna_atac_concordance.csv", index=False)
    donors_tab = obs.groupby("donor", observed=True)[["cps", "adnc", "braak", "age", "sex"]].first()
    donors_tab["n_nuclei"] = obs.groupby("donor", observed=True).size()
    donors_tab["atac"] = donors_tab.index.isin(atac_donors)
    donors_tab.sort_values("cps").to_csv(out / "donors.csv")

    cov = "+".join(args.covariates) or "none"
    plotting.association_heatmap(res_g, rna_cols, out / "heatmap_rna.png", groupby="group",
                                 title=f"RNA program vs CPS (partial r | {cov}; depth-adjusted)")
    plotting.association_heatmap(res_g, atac_g, out / "heatmap_atac.png", groupby="group",
                                 title=f"Promoter accessibility vs CPS (partial r | {cov})")
    plotting.primary_forest(primary, out / "primary_hypotheses.png")
    plotting.pvalue_qq(res_g, out / "pvalue_qq.png")
    plotting.primary_scatter(tables, PRIMARY, out / "primary_scatter.png")
    plotting.concordance(conc, out / "rna_atac_concordance.png", groupby="group")
    plt.close("all")
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
