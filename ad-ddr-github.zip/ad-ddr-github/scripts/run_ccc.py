"""Neuron <-> microglia ligand-receptor scores vs CPS (MTG, 73 non-severely-affected donors).

    python scripts/run_ccc.py --out results/ccc

Expression-based "communication" only shows that a ligand is expressed in a sender and a
receptor in a receiver; a score that tracks CPS may be driven by either side alone. Every
score is therefore reported together with its ligand-only and receptor-only components.

* score per donor = mean(log2 CPM ligand in sender, log2 CPM receptor in receiver); for
  multi-subunit receptors the least-expressed subunit is used (LIANA convention)
* pairs: LIANA consensus resource; a pair is kept if ligand and receptor each have
  CPM >= 1 in >= 50% of donors in their cell type
* pre-specified (neuron -> microglia "restraint" signals, expected to fall with CPS):
  CX3CL1-CX3CR1, CD200-CD200R1, CD47-SIRPA, IL34-CSF1R, CSF1-CSF1R. The consensus
  resource encodes CSF1/IL34 as one complex; they are alternative ligands, so they are
  tested separately. 10 tests (2 neuron classes), permutation p, BH within the family.
* exploratory: all pairs, both directions, analytic partial-r p, BH; compared with
  random pairs whose ligand is an expression-matched random gene (200 replicates).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import liana as li
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats as sst

from ad_ddr import cohort, stats
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
EXC, INH = cohort.EXC, cohort.INH
MICRO = "Microglia-PVM"
PRIMARY = [("CX3CL1", "CX3CR1"), ("CD200", "CD200R1"), ("CD47", "SIRPA"), ("IL34", "CSF1R"), ("CSF1", "CSF1R")]
COV = ["age", "sex", "pmi"]
NON_NEURONAL = ("Astrocyte", "Oligo", "OPC", "Endothelial", "VLMC", "Ependymal")


def partial_r(Y: np.ndarray, x: np.ndarray, Z: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Partial correlation of each column of Y with x given Z (intercept added); analytic p."""
    Z1 = np.column_stack([np.ones(len(x)), Z])
    H = Z1 @ np.linalg.pinv(Z1)
    xr = x - H @ x
    Yr = Y - H @ Y
    r = (xr @ Yr) / (np.linalg.norm(xr) * np.linalg.norm(Yr, axis=0))
    df = len(x) - Z1.shape[1] - 1
    t = r * np.sqrt(df / np.maximum(1 - r ** 2, 1e-12))
    return r, 2 * sst.t.sf(np.abs(t), df)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/ccc")
    ap.add_argument("--n-random", type=int, default=200)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
    donors = (s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]])
    donors[["age", "pmi"]] = donors[["age", "pmi"]].apply(pd.to_numeric, errors="coerce")
    donors = donors.dropna()

    paths = [p for p in sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad")) if not any(k in p.stem for k in NON_NEURONAL)]
    idx, C, genes, _ = cohort.aggregate(paths, regions=["MTG"])
    cells = {EXC: ("class", EXC), INH: ("class", INH), MICRO: ("group", MICRO)}
    L, expressed = {}, {}
    for name, (level, grp) in cells.items():
        m = ((idx.level == level) & (idx.group == grp) & idx.donor.isin(donors.index) & (idx.n_nuclei >= 20)).to_numpy()
        d = idx[m]
        cpm = C[m] / C[m].sum(1, keepdims=True) * 1e6
        L[name] = pd.DataFrame(np.log2(cpm + 1), index=d.donor.to_numpy(), columns=genes)
        L[name] = L[name].loc[:, ~L[name].columns.duplicated()]
        expressed[name] = pd.Series((cpm >= 1).mean(0) >= 0.5, index=genes).groupby(level=0).first()
    common = sorted(set.intersection(*[set(v.index) for v in L.values()]))
    donors = donors.loc[common]
    L = {k: v.loc[common] for k, v in L.items()}
    Z = pd.get_dummies(donors[COV], drop_first=True, dtype=float).to_numpy()
    x = donors["cps"].to_numpy(float)
    print(f"donors: {len(common)}")

    def subunit_expr(cell, gene_field):
        parts = gene_field.split("_")
        if not all(p in L[cell].columns and expressed[cell].get(p, False) for p in parts):
            return None
        return L[cell][parts].min(1).to_numpy() if len(parts) > 1 else L[cell][parts[0]].to_numpy()

    res = li.resource.select_resource("consensus")
    pairs = pd.concat([res, pd.DataFrame(PRIMARY, columns=["ligand", "receptor"])]).drop_duplicates()
    directions = [(EXC, MICRO), (INH, MICRO), (MICRO, EXC), (MICRO, INH)]
    rows, mats = [], {}
    for snd, rcv in directions:
        cols, meta = [], []
        for lg, rc in pairs.itertuples(index=False):
            le, re_ = subunit_expr(snd, lg), subunit_expr(rcv, rc)
            if le is None or re_ is None:
                continue
            cols += [(le + re_) / 2, le, re_]
            meta.append((lg, rc))
        Y = np.column_stack(cols)
        r, p = partial_r(Y, x, Z)
        r, p = r.reshape(-1, 3), p.reshape(-1, 3)
        for (lg, rc), rr, pp in zip(meta, r, p):
            rows.append({"sender": snd.replace("Neuronal: ", ""), "receiver": rcv.replace("Neuronal: ", ""),
                         "ligand": lg, "receptor": rc, "r_score": rr[0], "p_score": pp[0],
                         "r_ligand": rr[1], "r_receptor": rr[2]})
        mats[(snd, rcv)] = meta
    allres = pd.DataFrame(rows)
    allres["q_score"] = bh(allres["p_score"].to_numpy())
    allres.sort_values("p_score").to_csv(out / "lr_vs_cps_all.csv", index=False)

    # primary: permutation p for the pre-specified neuron -> microglia pairs
    prim = []
    for snd in (EXC, INH):
        for lg, rc in PRIMARY:
            le, re_ = subunit_expr(snd, lg), subunit_expr(MICRO, rc)
            if le is None or re_ is None:
                prim.append({"sender": snd.split(": ")[1], "pair": f"{lg}-{rc}", "note": "not expressed"})
                continue
            d = donors.assign(score=(le + re_) / 2, lig=le, rec=re_, k="x").reset_index(names="donor")
            a = stats.cps_association(d, ["score", "lig", "rec"], groupby="k", covariates=COV, n_perm=10_000,
                                      seed=args.seed, min_donors=10).set_index("score")
            prim.append({"sender": snd.split(": ")[1], "pair": f"{lg}-{rc}", "r_score": a.loc["score", "r"],
                         "p_perm": a.loc["score", "p_perm"], "r_ligand": a.loc["lig", "r"],
                         "p_ligand": a.loc["lig", "p_perm"], "r_receptor": a.loc["rec", "r"],
                         "p_receptor": a.loc["rec", "p_perm"]})
    prim = pd.DataFrame(prim)
    if "p_perm" in prim:
        ok = prim["p_perm"].notna()
        prim.loc[ok, "q"] = bh(prim.loc[ok, "p_perm"].to_numpy())
    prim.to_csv(out / "primary_restraint_signals.csv", index=False)
    print("\nPrimary: neuron -> microglia restraint signals vs CPS (partial r | age+sex+pmi)")
    print(prim.to_string(index=False, float_format=lambda v: f"{v:.3f}"))

    # exploratory vs random pairs (random ligand matched on sender expression)
    print("\nExploratory, all pairs: fraction with p < 0.05 (score), real vs random-ligand pairs")
    summ = []
    for snd, rcv in directions:
        meta = mats[(snd, rcv)]
        real = allres[(allres.sender == snd.replace("Neuronal: ", "")) & (allres.receiver == rcv.replace("Neuronal: ", ""))]
        Ls = L[snd].loc[:, expressed[snd].reindex(L[snd].columns).fillna(False).to_numpy()]
        mean = Ls.mean()
        bins = pd.qcut(mean.rank(method="first"), 10, labels=False)
        by_bin = {b: mean.index[bins == b].to_numpy() for b in range(10)}
        lig_bin = {lg: bins.get(lg.split("_")[0], 5) for lg, _ in meta}
        R = np.column_stack([subunit_expr(rcv, rc) for _, rc in meta])
        frac_null = []
        for _ in range(args.n_random):
            rl = np.column_stack([Ls[rng.choice(by_bin[lig_bin[lg]])].to_numpy() for lg, _ in meta])
            _, p = partial_r((rl + R) / 2, x, Z)
            frac_null.append((p < 0.05).mean())
        frac_null = np.array(frac_null)
        fr = (real.p_score < 0.05).mean()
        summ.append({"direction": f"{snd.replace('Neuronal: ', '')} -> {rcv.replace('Neuronal: ', '')}",
                     "n_pairs": len(real), "frac_p05_real": fr, "frac_p05_random": frac_null.mean(),
                     "random_95": f"{np.quantile(frac_null, .025):.3f}..{np.quantile(frac_null, .975):.3f}",
                     "p_vs_random": (np.sum(frac_null >= fr) + 1) / (len(frac_null) + 1),
                     "n_q_lt_0.1": int((real.q_score < 0.1).sum())})
    summ = pd.DataFrame(summ)
    summ.to_csv(out / "exploratory_vs_random.csv", index=False)
    print(summ.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    top = allres.sort_values("p_score").head(15)
    print("\nTop exploratory pairs (BH over all pairs and directions):")
    print(top[["sender", "receiver", "ligand", "receptor", "r_score", "p_score", "q_score", "r_ligand", "r_receptor"]]
          .to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # figure
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    pp = prim.dropna(subset=["r_score"]).reset_index(drop=True)
    lab = pp.sender.str[:3] + " " + pp.pair
    y = np.arange(len(pp))
    for col, mk, c, nm in (("r_score", "o", "#3b6fb6", "L-R score"), ("r_ligand", "<", "#d9822b", "ligand (neuron)"),
                           ("r_receptor", ">", "#2e8b57", "receptor (microglia)")):
        ax[0].scatter(pp[col], y, marker=mk, color=c, s=30, label=nm, zorder=3)
    ax[0].axvline(0, color="0.6", lw=0.8)
    ax[0].set_yticks(y, lab, fontsize=8)
    ax[0].invert_yaxis()
    ax[0].set_xlabel("partial r with CPS")
    ax[0].set_title("Neuron -> microglia restraint signals", fontsize=9)
    ax[0].legend(fontsize=7, frameon=False)
    ax[1].bar(range(len(summ)), summ.frac_p05_random, color="0.7", label="random-ligand pairs")
    ax[1].scatter(range(len(summ)), summ.frac_p05_real, color="#c0392b", zorder=3, label="curated pairs")
    ax[1].axhline(0.05, color="0.4", ls="--", lw=0.8)
    ax[1].set_xticks(range(len(summ)), summ.direction, fontsize=7, rotation=15)
    ax[1].set_ylabel("fraction of pairs with p < 0.05")
    ax[1].set_title("Are curated L-R pairs more CPS-associated than random?", fontsize=9)
    ax[1].legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(out / "ccc.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
