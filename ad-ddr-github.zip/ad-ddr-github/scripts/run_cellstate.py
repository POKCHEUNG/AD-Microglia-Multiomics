"""Is there a minority, coordinated DDR state in neurons? (12-donor multiome subset)

    python scripts/run_cellstate.py --out results/cellstate

A. Coherence: within-nucleus correlation of NHEJ / BER / NER / Checkpoint / p53 scores
   (donor-centred, within supertype) vs expression-matched random programs. Positive
   control: three fixed thirds of the DAM set in microglia.
B. Chromatin: nuclei in the top 5% of the RNA composite (per donor x supertype) vs the
   rest - is promoter accessibility of the same genes higher, beyond all promoters?
   Null: the same procedure with random programs.
C. Fraction of nuclei above a global per-supertype threshold vs CPS (descriptive; n = 12).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from anndata import AnnData
from scipy import stats as sst

from ad_ddr import cellstate as cs
from ad_ddr import io, scoring
from ad_ddr.signatures import DAM, NEURONAL_REPAIR, all_programs
from ddrmulti import atac as datac
from ddrmulti.genome import read_gtf_genes

ROOT = Path(__file__).resolve().parents[1]
EXC, INH = "Neuronal: Glutamatergic", "Neuronal: GABAergic"
DDR = NEURONAL_REPAIR + ["p53_targets"]
DAM_PARTS = ["DAM_a", "DAM_b", "DAM_c"]


def programs() -> dict[str, list[str]]:
    p = {k: v for k, v in all_programs().items() if k in DDR}
    dam = sorted(DAM)
    p.update({"DAM_a": dam[0::3], "DAM_b": dam[1::3], "DAM_c": dam[2::3]})
    return p


def pass_rna(donors, progs, n_random, seed):
    scorer, reps, obs_all = None, None, []
    for d in donors:
        rna, _ = io.load_donor(*io.donor_paths(ROOT / "data/raw", d))
        if scorer is None:
            ref = scoring.ProgramScorer(progs, seed=seed).fit(rna)
            reps = cs.matched_random_programs(ref.mean_, rna.var_names, progs, n_random, seed=seed)
            allp = dict(progs)
            for k, rep in enumerate(reps):
                allp.update({f"r{k}_{name}": g for name, g in rep.items()})
            scorer = scoring.ProgramScorer(allp, seed=seed).fit(rna)
        rna.obs["group"] = scoring.cell_groups(rna.obs)
        o = rna.obs.join(scorer.score(rna))
        obs_all.append(o[o["group"].notna()])
        print(f"  RNA {d}: {rna.n_obs:,}", flush=True)
        del rna
    obs = pd.concat(obs_all)
    cols = [c for c in obs if c.startswith("rna_")]
    return scoring.depth_adjust(obs, cols, groupby="group"), reps


def summarise_coherence(z, groups, real_cols, n_random, prefix_fmt):
    real = cs.coherence(z, groups, real_cols)
    null = pd.concat([cs.coherence(z, groups, [prefix_fmt.format(k=k, c=c[4:]) for c in real_cols])
                      for k in range(n_random)], axis=1)
    return real, null


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/cellstate")
    ap.add_argument("--n-random", type=int, default=50)
    ap.add_argument("--n-random-atac", type=int, default=20)
    ap.add_argument("--min-paired", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    donors = io.selected_donors(ROOT / "data/meta/selected_donors.csv")
    progs = programs()

    obs, reps = pass_rna(donors, progs, args.n_random, args.seed)
    real_ddr = [f"rna_{p}" for p in DDR]
    rows = []

    # ---- A. coherence -------------------------------------------------------
    neur = obs[obs["class"].isin([EXC, INH])]
    allcols = [c for c in obs if c.startswith("rna_")]
    zn = cs.donor_centred_z(neur, allcols, groupby="supertype")
    real, null = summarise_coherence(zn, neur["supertype"], real_ddr, args.n_random, "rna_r{k}_{c}")
    micro = obs[obs["group"] == "Microglia-PVM"]
    zm = cs.donor_centred_z(micro, allcols, groupby="group")
    real_m, null_m = summarise_coherence(zm, micro["group"], [f"rna_{p}" for p in DAM_PARTS], args.n_random,
                                         "rna_r{k}_{c}")
    coh = pd.DataFrame({"real": real, "null_mean": null.mean(1), "null_sd": null.std(1),
                        "frac_null_ge_real": (null.ge(real, axis=0)).mean(1)})
    coh.to_csv(out / "coherence_by_supertype.csv")
    med_real, med_null = real.median(), null.median(0)
    print(f"\nA. DDR coherence across {len(real)} neuronal supertypes: median r = {med_real:.3f}; "
          f"random programs median {med_null.mean():.3f} (95% {med_null.quantile(.025):.3f}..{med_null.quantile(.975):.3f}); "
          f"empirical p = {(np.sum(med_null >= med_real) + 1) / (len(med_null) + 1):.3f}")
    print(f"   supertypes with real > all {args.n_random} random: {(coh.frac_null_ge_real == 0).sum()} of {len(coh)}")
    print(f"   positive control, microglia DAM thirds: r = {real_m.iloc[0]:.3f}; random "
          f"{null_m.iloc[0].mean():.3f} (95% {null_m.iloc[0].quantile(.025):.3f}..{null_m.iloc[0].quantile(.975):.3f})")
    rows.append({"test": "A coherence (neurons, median over supertypes)", "real": med_real,
                 "null_mean": med_null.mean(), "p": (np.sum(med_null >= med_real) + 1) / (len(med_null) + 1)})
    rows.append({"test": "A coherence (microglia DAM thirds; positive control)", "real": real_m.iloc[0],
                 "null_mean": null_m.iloc[0].mean(),
                 "p": (np.sum(null_m.iloc[0] >= real_m.iloc[0]) + 1) / (args.n_random + 1)})

    # ---- B. chromatin of high-composite nuclei ------------------------------
    sets = {"real": (real_ddr, sorted({g for p in DDR for g in progs[p]}))}
    for k in range(args.n_random_atac):
        sets[f"r{k}"] = ([f"rna_r{k}_{p}" for p in DDR], sorted({g for p in DDR for g in reps[k][p]}))
    labels = {name: cs.top_fraction_labels(cs.composite(zn, cols), neur, groupby="supertype")
              for name, (cols, _) in sets.items()}
    acc = {name: scoring.AtacAccumulator() for name in sets}
    for d in donors:
        _, atac = io.load_donor(*io.donor_paths(ROOT / "data/raw", d))
        atac = atac[atac.obs_names.isin(neur.index)]
        if atac.n_obs < args.min_paired:
            print(f"  ATAC {d}: {atac.n_obs} paired neurons, skipped")
            continue
        for name in sets:
            lab = labels[name].reindex(atac.obs_names)
            ok = lab.notna().to_numpy()
            g = atac.obs.loc[ok, "class"].str.replace("Neuronal: ", "") + "|" + lab[ok]
            acc[name].add(atac[ok], g, d)
        print(f"  ATAC {d}: {atac.n_obs:,} paired neurons", flush=True)
        del atac
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    var = acc["real"].var
    holder = AnnData(np.zeros((1, len(var)), np.float32), var=var)
    all_prom = datac.peakset_mask(holder, scoring.promoter_regions(genes, list(genes.index)))

    def lfc(name):
        gs = sets[name][1]
        prom = datac.peakset_mask(holder, scoring.promoter_regions(genes, gs))
        a = acc[name]
        res = []
        for cls in ("Glutamatergic", "GABAergic"):
            for d in {k[1] for k in a.counts}:
                hi, re_ = a.counts.get((f"{cls}|high", d)), a.counts.get((f"{cls}|rest", d))
                if hi is None or re_ is None:
                    continue
                f = lambda c, m: (c[m].sum() + 1) / c.sum()
                res.append({"cls": cls, "donor": d, "n_high": a.n_cells[(f"{cls}|high", d)],
                            "lfc_set": np.log2(f(hi, prom) / f(re_, prom)),
                            "lfc_all_prom": np.log2(f(hi, all_prom) / f(re_, all_prom))})
        r = pd.DataFrame(res)
        r["excess"] = r["lfc_set"] - r["lfc_all_prom"]
        return r

    real_lfc = lfc("real")
    real_lfc.to_csv(out / "atac_high_vs_rest.csv", index=False)
    null_ex = np.array([lfc(f"r{k}")["excess"].mean() for k in range(args.n_random_atac)])
    obs_ex = real_lfc["excess"].mean()
    p_b = (np.sum(null_ex >= obs_ex) + 1) / (len(null_ex) + 1)
    print(f"\nB. high-DDR vs rest nuclei ({len(real_lfc)} class x donor units, median {real_lfc.n_high.median():.0f} "
          f"high nuclei each): DDR-promoter log2FC = {real_lfc.lfc_set.mean():.3f}, all promoters "
          f"{real_lfc.lfc_all_prom.mean():.3f}, excess {obs_ex:.3f}; random programs excess "
          f"{null_ex.mean():.3f} (range {null_ex.min():.3f}..{null_ex.max():.3f}); p = {p_b:.3f}")
    rows.append({"test": "B chromatin excess (high vs rest)", "real": obs_ex, "null_mean": null_ex.mean(), "p": p_b})

    # ---- C. fraction above global threshold vs CPS --------------------------
    comp_global = neur[real_ddr].groupby(neur["supertype"]).transform(lambda x: (x - x.mean()) / x.std()).mean(1)
    thr = comp_global.groupby(neur["supertype"]).transform(lambda x: x.quantile(0.95))
    frac = (comp_global > thr).groupby(neur["donor"]).mean()
    cps = neur.groupby("donor")["cps"].first()
    rho = sst.spearmanr(frac, cps.loc[frac.index])
    print(f"\nC. fraction of neurons above the 95th-percentile threshold vs CPS (12 donors): "
          f"Spearman rho = {rho.statistic:.2f}, p = {rho.pvalue:.2f}  (descriptive only)")
    rows.append({"test": "C high fraction vs CPS (Spearman, 12 donors)", "real": rho.statistic, "null_mean": 0.0,
                 "p": rho.pvalue})
    pd.DataFrame(rows).to_csv(out / "summary.csv", index=False)

    # ---- figure ---------------------------------------------------------------
    fig, ax = plt.subplots(1, 3, figsize=(13, 3.8))
    ax[0].hist(med_null, bins=15, color="0.7", label="random programs")
    ax[0].axvline(med_real, color="#c0392b", lw=2, label="DDR programs")
    ax[0].set_xlabel("median within-nucleus r across supertypes")
    ax[0].set_title("A. Coherence of DDR programs (neurons)", fontsize=9)
    ax[0].legend(fontsize=7, frameon=False)
    ax[1].hist(null_ex, bins=10, color="0.7", label="random programs")
    ax[1].axvline(obs_ex, color="#c0392b", lw=2, label="DDR programs")
    ax[1].set_xlabel("promoter log2FC excess, top-5% vs rest")
    ax[1].set_title("B. Same-nucleus chromatin (paired ATAC)", fontsize=9)
    ax[1].legend(fontsize=7, frameon=False)
    ax[2].scatter(cps.loc[frac.index], frac, s=30, c="#3b6fb6", edgecolor="k", lw=0.4)
    ax[2].set_xlabel("CPS")
    ax[2].set_ylabel("fraction of high-DDR neurons")
    ax[2].set_title(f"C. rho = {rho.statistic:.2f} (n = {len(frac)}; descriptive)", fontsize=9)
    fig.tight_layout()
    fig.savefig(out / "cellstate.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
