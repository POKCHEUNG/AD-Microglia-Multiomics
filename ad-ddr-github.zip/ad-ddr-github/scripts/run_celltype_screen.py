"""Which cell types show DDR dysregulation along AD progression, and is it DDR-specific?

    python scripts/run_celltype_screen.py --out results/screen

For every (region, cell group, program): partial r of the program score with local CPS
(age, sex, PMI, log #nuclei; severely affected donors excluded), with two p-values:
  p_perm - self-contained: permute CPS across donors (is the program associated at all?)
  p_set  - competitive: compare with 200 random expression-matched gene sets in the same
           cells (is the association stronger than for arbitrary genes?)
A cell type counts as "DDR-specific" only when both hold in MTG; replication is the
number of other regions with the same sign and p_perm < 0.05. Regions share donors, so
replication counts are descriptive, not independent tests.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr import cohort
from ad_ddr.signatures import all_programs
from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
COV = ["age", "sex", "pmi", "log_nuclei"]
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]


def _corr_rows(xr: np.ndarray, Y: np.ndarray) -> np.ndarray:
    """Pearson r of vector ``xr`` with each column of ``Y``."""
    xc, Yc = xr - xr.mean(), Y - Y.mean(0)
    return (xc @ Yc) / (np.linalg.norm(xc) * np.linalg.norm(Yc, axis=0))


def screen_group(M: np.ndarray, base: pd.DataFrame, genes: pd.Index, programs: dict, rng, n_sets: int,
                 n_perm: int, gene_len: pd.Series | None = None) -> list[dict]:
    """``gene_len`` (log10 length, indexed by upper-case symbol): if given, random genes are
    matched on expression decile x gene-length quintile instead of expression alone."""
    cpm = M / M.sum(1, keepdims=True) * 1e6
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    sd = L.std(0)
    Z = (L - L.mean(0)) / np.where(sd > 0, sd, 1)
    bins = pd.qcut(pd.Series(L.mean(0)).rank(method="first"), 10, labels=False).to_numpy()
    if gene_len is not None:
        gl = gene_len.reindex(genes.str.upper()).to_numpy()
        ok = np.isfinite(gl)
        lq = np.full(len(gl), -1)
        lq[ok] = pd.qcut(pd.Series(gl[ok]).rank(method="first"), 5, labels=False).to_numpy()
        bins = np.where(ok, bins * 5 + lq, -1)
        expressed = expressed & ok
    pool = np.flatnonzero(expressed)
    by_bin = {b: pool[bins[pool] == b] for b in np.unique(bins[pool])}
    upper = pd.Series(np.arange(len(genes)), index=genes.str.upper())
    upper = upper[~upper.index.duplicated()]

    Zc = _covar_matrix(base, COV)
    xr = _resid(base["cps"].to_numpy(float), Zc)
    perms = np.stack([rng.permutation(xr) for _ in range(n_perm)], 1)
    rows = []
    for name, gs in programs.items():
        gi = upper.reindex([g.upper() for g in gs]).dropna().astype(int).to_numpy()
        gi = gi[expressed[gi]]
        if len(gi) < 3:
            continue
        rand = np.stack([np.array([rng.choice(by_bin[b]) for b in bins[gi]]) for _ in range(n_sets)])
        S = np.column_stack([Z[:, gi].mean(1), Z[:, rand].mean(2)])
        R = np.column_stack([_resid(S[:, j], Zc) for j in range(S.shape[1])])
        r = _corr_rows(xr, R)
        obs, null = r[0], r[1:]
        yr = R[:, 0]
        rp = _corr_rows(yr, perms)
        rows.append({"program": name, "n_genes": len(gi), "r": obs, "null_mean": null.mean(),
                     "null_sd": null.std(), "r_excess": obs - null.mean(),
                     "p_perm": (np.sum(np.abs(rp) >= abs(obs) - 1e-12) + 1) / (n_perm + 1),
                     "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (n_sets + 1)})
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/screen")
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--n-perm", type=int, default=2000)
    ap.add_argument("--min-donors", type=int, default=10)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    programs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")[["Donor ID", "Brain Region", "CPS_Local"]]
    cps.columns = ["donor", "region", "cps"]

    rows = []
    for p in sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad")):
        idx, C, genes, meta = cohort.aggregate([p])
        meta = meta.assign(age=pd.to_numeric(meta["age"], errors="coerce"),
                           pmi=pd.to_numeric(meta["pmi"], errors="coerce"),
                           severe=meta["severe"].astype(str).eq("Y"))
        idx = idx.merge(cps, on=["donor", "region"], how="left").join(meta[["age", "sex", "pmi", "severe"]], on="donor")
        keep = (idx["level"] == "group") & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool) \
            & idx[["cps", "age", "pmi"]].notna().all(1)
        for (region, group), d in idx[keep].groupby(["region", "group"]):
            if len(d) < args.min_donors:
                continue
            base = d.assign(log_nuclei=np.log10(d["n_nuclei"])).reset_index(drop=True)
            for r in screen_group(C[d.index.to_numpy()], base, genes, programs, rng, args.n_sets, args.n_perm):
                rows.append({"region": region, "group": group, "n_donors": len(d), **r})
        print(f"  {p.stem}: {len(rows)} tests so far", flush=True)

    res = pd.DataFrame(rows)
    res["family"] = np.where(res["program"].isin(DDR), "DDR", "control")
    ddr = res["family"] == "DDR"
    for col in ("p_perm", "p_set"):
        res[f"q_{col[2:]}_region"] = np.nan
        for region, d in res[ddr].groupby("region"):
            res.loc[d.index, f"q_{col[2:]}_region"] = bh(d[col].to_numpy())
    res.to_csv(out / "screen_all.csv", index=False)

    # MTG calls + replication in the other regions
    mtg = res[res["region"] == "MTG"].copy()
    other = res[res["region"] != "MTG"]
    rep = []
    for _, row in mtg.iterrows():
        o = other[(other["group"] == row["group"]) & (other["program"] == row["program"])]
        rep.append({"n_regions_tested": len(o),
                    "n_regions_same_sign_p05": int(((np.sign(o["r"]) == np.sign(row["r"])) & (o["p_perm"] < 0.05)).sum()),
                    "n_regions_same_sign": int((np.sign(o["r"]) == np.sign(row["r"])).sum()),
                    "n_regions_set_p05": int(((np.sign(o["r_excess"]) == np.sign(row["r_excess"])) & (o["p_set"] < 0.05)).sum())})
    mtg = pd.concat([mtg.reset_index(drop=True), pd.DataFrame(rep)], axis=1)
    mtg["call"] = np.select(
        [(mtg["q_perm_region"] < 0.1) & (mtg["p_set"] < 0.05),
         mtg["q_perm_region"] < 0.1],
        ["DDR-specific", "associated, not specific"], "none")
    mtg.loc[mtg["family"] == "control", "call"] = "control"
    mtg.sort_values(["family", "p_perm"]).to_csv(out / "screen_MTG.csv", index=False)

    d = mtg[mtg["family"] == "DDR"]
    print(f"\nMTG: {d['group'].nunique()} cell groups x {d['program'].nunique()} DDR programs = {len(d)} tests")
    print(f"p_perm<0.05: {(d['p_perm'] < .05).mean():.3f}   p_set<0.05: {(d['p_set'] < .05).mean():.3f}   (expected 0.05)")
    print(d["call"].value_counts().to_string())
    cols = ["group", "program", "n_donors", "r", "null_mean", "r_excess", "p_perm", "q_perm_region", "p_set",
            "n_regions_same_sign_p05", "n_regions_tested", "call"]
    print("\nTop 20 MTG DDR tests by p_perm:")
    print(d.sort_values("p_perm")[cols].head(20).to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\nPositive control (DAM):")
    print(mtg[(mtg["program"] == "DAM") & (mtg["group"] == "Microglia-PVM")][cols].to_string(index=False))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
