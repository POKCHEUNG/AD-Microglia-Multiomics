"""Cognition and APOE4 vs the pre-specified programs (MTG, non-severely-affected donors).

    python scripts/run_cognition.py --out results/cognition

Uses results/cohort/scores.csv.gz from run_cohort.py. Each analysis is a partial
correlation with a permutation p; BH is applied within each analysis across the 13
pre-specified hypotheses. Analyses B-D adjust for CPS, so they ask whether a program
relates to cognition / APOE4 *beyond* the amount of AD pathology (resilience).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ad_ddr import stats
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
BASE = ["age", "sex", "pmi", "log_nuclei"]
ANALYSES = {
    "A: dementia": ("dementia", BASE),
    "B: dementia | CPS": ("dementia", BASE + ["cps"]),
    "C: CASI | CPS": ("casi", BASE + ["casi_interval", "cps"]),
    "D: APOE4 | CPS": ("apoe4", BASE + ["cps"]),
}


def main():
    from run_cohort import PRIMARY  # same pre-specified family as the CPS analysis

    ap = argparse.ArgumentParser()
    ap.add_argument("--scores", default="results/cohort/scores.csv.gz")
    ap.add_argument("--out", default="results/cognition")
    ap.add_argument("--n-perm", type=int, default=10_000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)

    s = pd.read_csv(ROOT / args.scores)
    s = s[(s["region"] == "MTG") & ~s["severe"]].copy()
    for c in ("age", "pmi", "casi", "casi_interval"):
        s[c] = pd.to_numeric(s[c], errors="coerce")
    s["key"] = s["level"] + "|" + s["group"]
    keys = {f"{lvl}|{grp}" for lvl, grp, _ in PRIMARY}
    s = s[s["key"].isin(keys)]

    rows = []
    for name, (x, cov) in ANALYSES.items():
        d = s.dropna(subset=[x] + [c for c in cov if c != "sex"])
        for lvl, grp, prog in PRIMARY:
            sub = d[d["key"] == f"{lvl}|{grp}"]
            res = stats.cps_association(sub, [f"rna_{prog}"], groupby="key", x=x, covariates=cov,
                                        n_perm=args.n_perm, seed=args.seed, min_donors=10)
            if len(res):
                rows.append({"analysis": name, "cells": grp, "program": prog,
                             **res.iloc[0][["r", "p_perm", "n_donors"]].to_dict()})
    res = pd.DataFrame(rows)
    res["q"] = res.groupby("analysis")["p_perm"].transform(lambda p: bh(p.to_numpy()))
    res.to_csv(out / "cognition_primary.csv", index=False)

    res["label"] = res["cells"].str.replace("Neuronal: ", "") + " | " + res["program"]
    for name in ANALYSES:
        d = res[res["analysis"] == name]
        print(f"\n[{name}]  n donors = {int(d['n_donors'].max())}")
        print(d[["label", "r", "p_perm", "q"]].to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    labels = list(dict.fromkeys(res["label"]))
    cols = list(ANALYSES)
    r = res.pivot(index="label", columns="analysis", values="r").reindex(index=labels, columns=cols)
    p = res.pivot(index="label", columns="analysis", values="p_perm").reindex(index=labels, columns=cols)
    q = res.pivot(index="label", columns="analysis", values="q").reindex(index=labels, columns=cols)
    fig, ax = plt.subplots(figsize=(6.4, 0.36 * len(labels) + 1.8))
    im = ax.imshow(r.to_numpy(float), cmap="RdBu_r", vmin=-0.5, vmax=0.5, aspect="auto")
    for i in range(r.shape[0]):
        for j in range(r.shape[1]):
            mark = "**" if q.iat[i, j] < 0.1 else "*" if p.iat[i, j] < 0.05 else ""
            ax.text(j, i, mark, ha="center", va="center", fontsize=8)
    ns = res.groupby("analysis")["n_donors"].max().reindex(cols)
    ax.set_xticks(range(len(cols)), [f"{c}\n(n={int(n)})" for c, n in zip(cols, ns)], fontsize=7)
    ax.set_yticks(range(len(labels)), labels, fontsize=8)
    ax.set_title("Partial r (MTG)   * p<0.05   ** q<0.1\nCASI: higher = better cognition", fontsize=9)
    fig.colorbar(im, ax=ax, shrink=0.6, label="r")
    fig.tight_layout()
    fig.savefig(out / "cognition_primary.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    main()
