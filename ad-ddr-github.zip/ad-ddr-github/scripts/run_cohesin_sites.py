"""Does chromatin at cohesin-bound sites change with AD in the cells where cohesin rises? (follow-up of result 26)

    python scripts/run_cohesin_sites.py --out results/cohesin_sites

Cohesin sites: RAD21 ChIP-Atlas "Neural" peaks (hg38) merged across experiments
(scripts/build_chip_consensus.py), kept if seen in >= 2 experiments; robust sites are
those in >= 10. Each SEA-AD snATAC peak overlapping a site is classed by whether it
contains a CTCF motif (JASPAR MA0139, own PWM scan, 85% threshold): CTCF-anchored loop
sites vs CTCF-free cohesin sites (enhancer / promoter loading, NIPBL-dependent).

Per (cell group, donor) pseudobulk (scripts/extract_atac_pseudobulk.py, chemistries
summed; excitatory and inhibitory classes are sums of their subclasses): set score = mean
z of log2 CPM over the set's peaks, residualised on log fragments, multiome fraction,
log nuclei, age, sex, PMI. Exposures: MTG local CPS, and the donor's cohesin RNA score
(mean z of RAD21, SMC1A, SMC3, STAG1, STAG2, NIPBL in the same cell group's RNA
pseudobulk) - does chromatin at cohesin sites follow cohesin expression?
Test: per donor, set score minus the score of a matched background (3 non-cohesin peaks per
set peak, matched on accessibility decile and promoter / distal class), correlated with the
exposure across donors, p from permuting the exposure. A first version compared the set
score with random peak sets instead; with thousands of peaks per set that null ignores
donor sampling error and called almost every test, including control cell types,
significant. A TSS-enrichment proxy (fraction of fragments in promoter peaks) is added to
the covariates because CTCF-site accessibility is sensitive to data quality.
Severely affected donors excluded.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ad_ddr import cohort
from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.genome import overlap, parse_peak_names
from ddrmulti.stats import bh
from motif_dam_peaks import fetch, has_motif, onehot, read_jaspar
from run_dam_peaks import annotate, load

ROOT = Path(__file__).resolve().parents[1]
EXC = ["L2/3 IT", "L4 IT", "L5 IT", "L6 IT", "L6 IT Car3", "L5 ET", "L5/6 NP", "L6 CT", "L6b"]
INH = ["Lamp5", "Lamp5 Lhx6", "Pax6", "Sncg", "Vip", "Sst", "Sst Chodl", "Pvalb", "Chandelier"]
GROUPS = {"Excitatory": (EXC, ["L23-IT", "L4-IT", "L5-IT", "L5-ET", "L56-NP", "L6-IT", "L6-IT-Car3", "L6-CT", "L6b"]),
          "Oligodendrocyte": (["Oligodendrocyte"], ["Oligodendrocyte"]),
          "Inhibitory": (INH, ["Lamp5", "Lamp5-Lhx6", "Pax6", "Sncg", "Vip", "Sst", "Sst-Chodl", "Pvalb", "Chandelier"]),
          "Microglia-PVM": (["Microglia-PVM"], ["Immune"]), "Astrocyte": (["Astrocyte"], ["Astrocyte"])}
COHESIN = ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2", "NIPBL"]


def site_classes(peaks: pd.DataFrame, rng) -> pd.DataFrame:
    sites = pd.read_csv(ROOT / "data/ref/chipatlas/RAD21_neural_ge2.bed", sep="\t", header=None,
                        names=["chrom", "start", "end", "n_exp"])
    pairs = overlap(peaks.reset_index(drop=True), sites)
    n_exp = pd.Series(sites["n_exp"].to_numpy()[pairs["b_idx"]]).groupby(pairs["a_idx"].to_numpy()).max()
    cls = pd.DataFrame({"n_exp": n_exp.reindex(np.arange(len(peaks))).fillna(0).astype(int).to_numpy()})
    bound = np.flatnonzero(cls["n_exp"] >= 2)
    mid = ((peaks["start"] + peaks["end"]) // 2).to_numpy()
    reg = pd.DataFrame({"chrom": peaks["chrom"].to_numpy()[bound], "start": np.maximum(mid[bound] - 250, 0),
                        "end": mid[bound] + 250}, index=bound)
    seqs = fetch(ROOT / "data/ref/hg38.fa.gz", reg)
    ctcf = read_jaspar(ROOT / "data/ref/motifs/JASPAR2024_CORE_vertebrates_non-redundant_pfms_jaspar.txt")
    ctcf = ctcf[next(k for k in ctcf if k.startswith("MA0139"))]
    hit = has_motif(onehot(seqs, 500), ctcf)
    cls["ctcf_motif"] = False
    cls.loc[bound, "ctcf_motif"] = hit
    cls["set"] = np.select([(cls["n_exp"] >= 2) & cls["ctcf_motif"], (cls["n_exp"] >= 2) & ~cls["ctcf_motif"]],
                           ["cohesin + CTCF motif", "cohesin, no CTCF motif"], "not cohesin-bound")
    cls["robust"] = cls["n_exp"] >= 10
    return cls


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/cohesin_sites")
    ap.add_argument("--n-rand", type=int, default=2000, help="exposure permutations")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    d = ROOT / "data/processed/atac_pb"
    peaks = parse_peak_names((d / "peaks.txt").read_text().split())
    rows, M = load(d)
    cls = site_classes(peaks, rng)
    cls["class"] = annotate(peaks.reset_index(drop=True), ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz")["class"].to_numpy()
    print(cls.groupby(["set", "class"]).size().unstack(fill_value=0).to_string())
    print(f"robust (>= 10 experiments) sites with CTCF motif: {(cls['robust'] & cls['ctcf_motif']).mean() / cls['robust'].mean():.2f}")

    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    severe = set(meta.index[meta["Severely Affected Donor"].astype(str).eq("Y")])
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    sets = {"cohesin + CTCF motif": np.flatnonzero((cls["set"] == "cohesin + CTCF motif").to_numpy()),
            "cohesin, no CTCF motif": np.flatnonzero((cls["set"] == "cohesin, no CTCF motif").to_numpy()),
            "robust cohesin + CTCF motif": np.flatnonzero((cls["robust"] & cls["ctcf_motif"]).to_numpy()),
            "robust cohesin, no CTCF motif": np.flatnonzero((cls["robust"] & ~cls["ctcf_motif"]).to_numpy())}
    nonc = np.flatnonzero((cls["set"] == "not cohesin-bound").to_numpy())

    res, scores = [], []
    for grp, (subs, rna_files) in GROUPS.items():
        r = rows[rows["subclass"].isin(subs)]
        n = r.groupby("donor")["n_nuclei"].sum()
        donors = [x for x in n.index[n >= 50] if x not in severe and x in cps.index and x in meta.index]
        C = np.vstack([np.asarray(M[r.index[r["donor"] == x].to_numpy()].sum(0)).ravel() for x in donors])
        tot = C.sum(1)
        cpm = C / tot[:, None] * 1e6
        use = (cpm >= 1).mean(0) >= 0.5
        L = np.log2(cpm + 1)
        Lz = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
        multi = r[r["method"] == "10xMulti"].groupby("donor")["n_nuclei"].sum().reindex(donors).fillna(0) / n.reindex(donors)
        info = pd.DataFrame({"donor": donors, "cps": cps.reindex(donors).to_numpy(), "logfrag": np.log10(tot),
                             "frac_multi": multi.to_numpy(), "lognuc": np.log10(n.reindex(donors).to_numpy(float)),
                             "age": pd.to_numeric(meta.loc[donors, "Age at Death"], errors="coerce").to_numpy(),
                             "sex": meta.loc[donors, "Sex"].astype(str).to_numpy(),
                             "pmi": pd.to_numeric(meta.loc[donors, "PMI"], errors="coerce").to_numpy()})
        # cohesin RNA score in the same cell group (MTG RNA pseudobulk)
        idx, RC, genes, _ = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{f}.h5ad" for f in rna_files], regions=["MTG"])
        lvl = "class" if grp in ("Excitatory", "Inhibitory") else "group"
        gname = {"Excitatory": cohort.EXC, "Inhibitory": cohort.INH}.get(grp, grp)
        k = ((idx["level"] == lvl) & (idx["group"] == gname) & (idx["n_nuclei"] >= 20)).to_numpy()
        ri, RCk = idx[k].set_index("donor"), RC[k]
        rl = np.log2(RCk / RCk.sum(1, keepdims=True) * 1e6 + 1)
        rz = (rl - rl.mean(0)) / np.where(rl.std(0) > 0, rl.std(0), 1)
        up = pd.Series(np.arange(len(genes)), index=genes.str.upper())
        coh = pd.Series(rz[:, up.reindex(COHESIN).dropna().astype(int).to_numpy()].mean(1), index=ri.index)
        info["cohesin_rna"] = coh.reindex(donors).to_numpy()
        ok = info[["age", "pmi"]].notna().all(1).to_numpy()
        info, Lz = info[ok].reset_index(drop=True), Lz[ok]
        Z = _covar_matrix(info, ["logfrag", "frac_multi", "lognuc", "age", "sex", "pmi"])

        acc = np.log2(cpm.mean(0) + 1)
        bins = np.full(len(acc), -1)
        bins[use] = pd.qcut(pd.Series(acc[use]).rank(method="first"), 10, labels=False).to_numpy()
        strat = np.where(bins >= 0, bins * 2 + (cls["class"].to_numpy() == "promoter"), -1)
        pool = {s: nonc[(strat[nonc] == s)] for s in np.unique(strat[strat >= 0])}
        prom = np.flatnonzero((cls["class"].to_numpy() == "promoter") & use)
        info["promoter_frac"] = (C[ok][:, prom].sum(1) / tot[ok])          # TSS-enrichment proxy (data quality)
        Z = _covar_matrix(info, ["logfrag", "frac_multi", "lognuc", "promoter_frac", "age", "sex", "pmi"])
        for sname, si in sets.items():
            si = si[use[si]]
            if len(si) < 20:
                continue
            # matched background: 3 accessibility/class-matched non-cohesin peaks per set peak
            bg = np.concatenate([[rng.choice(pool[s]) for s in strat[si]] for _ in range(3)])
            diff = Lz[:, si].mean(1) - Lz[:, bg].mean(1)                     # per donor: set minus matched background
            scores.append(info.assign(cells=grp, set=sname, diff=diff))
            for exposure in ("cps", "cohesin_rna"):
                m = info[exposure].notna().to_numpy()
                Zm = Z[m]
                xr = _resid(info.loc[m, exposure].to_numpy(float), Zm)
                yr = _resid(diff[m], Zm)
                obs = np.corrcoef(xr, yr)[0, 1]
                null = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(args.n_rand)])
                raw = np.corrcoef(xr, _resid(Lz[m][:, si].mean(1), Zm))[0, 1]
                res.append({"cells": grp, "set": sname, "exposure": exposure, "n_donors": int(m.sum()), "n_peaks": len(si),
                            "r_set_minus_matched": obs, "r_set_alone": raw,
                            "p_perm": (np.sum(np.abs(null) >= abs(obs)) + 1) / (len(null) + 1)})
        print(f"  {grp}: {len(info)} donors", flush=True)
    res = pd.DataFrame(res)
    res["q_perm"] = bh(res["p_perm"].to_numpy())                       # across all 40 tests (sets overlap, so conservative)
    res.to_csv(out / "cohesin_sites.csv", index=False)
    cls.to_csv(out / "peak_cohesin_classes.csv.gz", index=False)
    pd.concat(scores, ignore_index=True).to_csv(out / "donor_scores.csv.gz", index=False)
    print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
