"""Full SEA-AD cohort: program scores vs local CPS from released pseudobulk objects.

    python scripts/run_cohort.py --out results/cohort

Primary: MTG, all non-severely-affected donors, adjusted for age, sex, PMI and
log(#nuclei). Secondary: the same tests in each of the 10 regions (local CPS) and a
sensitivity run including severely affected donors.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ad_ddr import cohort, plotting, stats
from ad_ddr.signatures import NEURONAL_REPAIR, all_programs
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
EXC, INH = cohort.EXC, cohort.INH
PRIMARY = (
    [("class", c, p) for c in (EXC, INH) for p in NEURONAL_REPAIR + ["p53_targets"]]
    + [("group", "Microglia-PVM", "DAM"),             # positive control
       ("group", "Microglia-PVM", "cGAS_STING_IFN"),
       ("group", "Astrocyte", "Reactive_astro")]
)
REGION_ORDER = ["MEC", "LEC", "HIP", "ITG", "MTG", "STG", "FI", "AnG", "DFC", "V1C"]  # ~ cortical arc of tau spread


def primary_table(res: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for level, grp, prog in PRIMARY:
        hit = res[(res["level"] == level) & (res["group"] == grp) & (res["score"] == f"rna_{prog}")]
        if len(hit):
            rows.append({"cells": grp, "program": prog, **hit.iloc[0][["r", "slope", "p_perm", "n_donors"]].to_dict()})
    t = pd.DataFrame(rows)
    t["q_primary"] = bh(t["p_perm"].to_numpy())
    return t


def associate(scores: pd.DataFrame, cols: list[str], covariates: list[str], n_perm: int, seed: int) -> pd.DataFrame:
    s = scores.assign(key=scores["level"] + "|" + scores["group"])
    res = stats.cps_association(s, cols, groupby="key", covariates=covariates, n_perm=n_perm, seed=seed,
                                min_donors=10)
    res[["level", "group"]] = res["key"].str.split("|", n=1, expand=True)
    return res.drop(columns="key")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/cohort")
    ap.add_argument("--covariates", nargs="*", default=["age", "sex", "pmi", "log_nuclei"])
    ap.add_argument("--n-perm", type=int, default=10_000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)

    programs = all_programs()
    cache = out / "scores.csv.gz"
    if cache.exists():
        scores = pd.read_csv(cache)
    else:
        paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
        idx, C, genes, meta = cohort.aggregate(paths)
        scores = cohort.score_programs(idx, C, genes, programs)
        scores = cohort.attach_donor_info(scores, meta, ROOT / "data/meta/Global_and_Local_CPS.csv")
        scores.to_csv(cache, index=False)
    cols = [f"rna_{p}" for p in programs]
    scores["age"] = pd.to_numeric(scores["age"], errors="coerce")
    scores["pmi"] = pd.to_numeric(scores["pmi"], errors="coerce")
    scores = scores.dropna(subset=["cps", "age", "pmi"])

    mtg = scores[scores["region"] == "MTG"]
    print(f"MTG donors: {mtg['donor'].nunique()} ({mtg.loc[mtg['severe'], 'donor'].nunique()} severely affected)")

    runs = {"primary": mtg[~mtg["severe"]], "with_severe": mtg}
    tables = {}
    for name, d in runs.items():
        res = associate(d, cols, args.covariates, args.n_perm, args.seed)
        res.to_csv(out / f"cps_association_MTG_{name}.csv", index=False)
        prim = primary_table(res)
        prim.to_csv(out / f"primary_MTG_{name}.csv", index=False)
        tables[name] = (res, prim)
        print(f"\n[MTG {name}: {d['donor'].nunique()} donors | {'+'.join(args.covariates)}]")
        print(prim.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
        print(f"fraction p<0.05 over {len(res)} exploratory tests: {(res['p_perm'] < 0.05).mean():.3f}")

    # regions
    reg_rows = []
    for region, d in scores[~scores["severe"]].groupby("region"):
        res = associate(d, cols, args.covariates, max(2000, args.n_perm // 5), args.seed)
        reg_rows.append(primary_table(res).assign(region=region, n_donors_region=d["donor"].nunique()))
    regions = pd.concat(reg_rows, ignore_index=True)
    regions.to_csv(out / "primary_by_region.csv", index=False)

    res, prim = tables["primary"]
    prim_plot = prim.assign(modality="rna")
    plotting.primary_forest(prim_plot, out / "primary_MTG.png")
    grp_res = res[res["level"] == "group"].rename(columns={"group": "subclass"})
    plotting.association_heatmap(grp_res, cols, out / "heatmap_MTG.png",
                                 title=f"MTG, {runs['primary']['donor'].nunique()} donors: partial r with CPS "
                                       f"| {'+'.join(args.covariates)}")
    plotting.region_heatmap(regions, out / "primary_by_region.png", order=REGION_ORDER)
    plotting.pvalue_qq(res, out / "pvalue_qq_MTG.png")
    plt.close("all")
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
