"""Peaks specifically opened or closed in DAM-like microglia (SEA-AD MTG snATAC, 86 donors).

    python scripts/run_dam_peaks.py --out results/dam_peaks

DAM-like state = Micro-PVM_3-SEAAD (highest DAM and interferon genes among microglial
supertypes; its share of microglia rises with CPS, Spearman 0.48). Reference = Micro-PVM_2
(homeostatic, the largest supertype). Pseudobulks per (donor, supertype) come from
scripts/stream_atac_donors.sh ... Microglia-PVM, summed over chemistry.

Within donor (paired), after binomially thinning the deeper pseudobulk to the depth of the
shallower one (DAM-like pseudobulks are much shallower, and log2(CPM + 1) of a shallow
pseudobulk is biased toward 0 at low-count peaks, which otherwise produces spurious
"closed" calls): d = log2(CPM_DAM + 1) - log2(CPM_homeostatic + 1) per peak, averaged over
20 independent thinning draws (a single draw adds enough noise that only ~half of the calls
recur in another draw; scripts/audit_dam_de.py); the statistic is the paired t over donors. FDR (q) comes from 2,000 random sign flips applied
to all peaks of a donor at once, so donor is the unit and peak-peak correlation is kept;
BH on t-distribution p-values is reported as q_bh. A peak is "DAM-open" / "DAM-closed"
at q < 0.05 and |mean d| >= 0.5.

Donors: not severely affected, >= 10 DAM-like and >= 30 homeostatic nuclei. Peaks: mean
CPM >= 5 in either state (pooled). Chemistry sensitivity: the same paired statistic on
donors' 10x Multiome-only and ATAC-only pseudobulks, compared by correlation of effects.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from ddrmulti.genome import parse_peak_names, read_gtf_genes
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
DAM, HOM = "Micro-PVM_3-SEAAD", "Micro-PVM_2"
N_DRAW = 20


def thin_mean_diff(a: np.ndarray, b: np.ndarray, rng, feat, n_draw: int = N_DRAW) -> np.ndarray:
    """feat(a) - feat(b), averaged over binomial thinnings of the deeper of a, b to the other's total."""
    deep_a = a.sum() > b.sum()
    deep, shallow = (a, b) if deep_a else (b, a)
    f_sh = feat(shallow)
    acc = 0.0
    for _ in range(n_draw):
        f_th = feat(rng.binomial(np.round(deep).astype(np.int64), shallow.sum() / deep.sum()).astype(float))
        acc = acc + (f_th - f_sh if deep_a else f_sh - f_th)
    return acc / n_draw


def load(d: Path):
    rows, mats = [], []
    for f in sorted(d.glob("*.npz")):
        rows.append(pd.read_csv(f.with_suffix(".csv")))
        mats.append(sp.load_npz(f))
    return pd.concat(rows, ignore_index=True), sp.vstack(mats).tocsr()


def paired(rows: pd.DataFrame, M: sp.csr_matrix, donors: list[str], peaks_ix: np.ndarray, method: str | None = None,
           rng=None):
    """Donor x peak matrix of log2 CPM differences (DAM - homeostatic).

    With ``rng``, the deeper of the two pseudobulks is binomially thinned to the shallower
    one's total (difference averaged over N_DRAW draws), so log2(CPM + 1) is not biased
    toward 0 in the shallow (DAM-like) state."""
    r = rows if method is None else rows[rows["method"] == method]
    out, used = [], []
    for d in donors:
        cs = []
        for st in (DAM, HOM):
            ix = r.index[(r["donor"] == d) & (r["subclass"] == st)].to_numpy()
            if len(ix) == 0:
                break
            cs.append(np.asarray(M[ix].sum(0)).ravel())
        if len(cs) < 2:
            continue
        feat = lambda c: np.log2(c[peaks_ix] / c.sum() * 1e6 + 1)
        out.append(thin_mean_diff(cs[0], cs[1], rng, feat) if rng is not None else feat(cs[0]) - feat(cs[1]))
        used.append(d)
    return np.array(out), used


def flip_test(D: np.ndarray, n_flip: int, rng, chunk: int = 20000):
    """Paired t per peak; p from the t distribution, FDR from sign flips.

    For each peak, q_flip = (mean number of peaks with |t| >= its |t| across sign-flipped
    data) / (number of peaks with |t| >= its |t| in the observed data), made monotone.
    Flipping all peaks of a donor together keeps the correlation between peaks."""
    n = D.shape[0]
    mean = D.mean(0)
    ss = (D ** 2).sum(0)
    sd = np.sqrt(np.maximum(ss - n * mean ** 2, 1e-12) / (n - 1))
    t = mean / (sd / np.sqrt(n))
    p = 2 * stats.t.sf(np.abs(t), n - 1)
    grid = np.sort(np.abs(t))
    null_counts = np.zeros(len(grid))
    S = rng.choice([-1.0, 1.0], size=(n_flip, n))
    for s in range(0, D.shape[1], chunk):
        m = S @ D[:, s:s + chunk] / n
        sdp = np.sqrt(np.maximum(ss[s:s + chunk] - n * m ** 2, 1e-12) / (n - 1))
        tp = np.abs(m / (sdp / np.sqrt(n))).ravel()
        null_counts += len(tp) - np.searchsorted(np.sort(tp), grid, side="left")
    null_counts /= n_flip
    obs_counts = len(grid) - np.arange(len(grid))                 # peaks with |t| >= grid[i]
    fdr = np.minimum.accumulate(np.minimum(null_counts / obs_counts, 1))   # q(t) = min FDR over thresholds <= |t|
    q_flip = fdr[np.searchsorted(grid, np.abs(t), side="left")]
    return mean, t, p, q_flip


def annotate(peaks: pd.DataFrame, gtf: Path) -> pd.DataFrame:
    genes = read_gtf_genes(str(gtf))
    out = []
    mid = ((peaks["start"] + peaks["end"]) // 2).to_numpy()
    for chrom, idx in peaks.groupby("chrom").indices.items():
        g = genes[genes["chrom"] == chrom]
        if g.empty:
            out.append(pd.DataFrame({"i": idx, "nearest_gene": "", "dist_tss": np.nan}))
            continue
        order = np.argsort(g["tss"].to_numpy())
        tss = g["tss"].to_numpy()[order]
        names = g.index.to_numpy()[order]
        pos = np.searchsorted(tss, mid[idx])
        lo, hi = np.clip(pos - 1, 0, len(tss) - 1), np.clip(pos, 0, len(tss) - 1)
        pick = np.where(np.abs(mid[idx] - tss[lo]) <= np.abs(tss[hi] - mid[idx]), lo, hi)
        out.append(pd.DataFrame({"i": idx, "nearest_gene": names[pick], "dist_tss": mid[idx] - tss[pick]}))
    a = pd.concat(out).set_index("i").sort_index()
    a["class"] = np.where(a["dist_tss"].abs() <= 1000, "promoter", "distal")
    return a


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--atac", default="data/processed/atac_pb_micro")
    ap.add_argument("--out", default="results/dam_peaks")
    ap.add_argument("--min-dam", type=int, default=10)
    ap.add_argument("--min-hom", type=int, default=30)
    ap.add_argument("--n-flip", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    d = ROOT / args.atac
    peaks = parse_peak_names((d / "peaks.txt").read_text().split())
    rows, M = load(d)
    donor_tab = pd.read_csv(ROOT / "data/meta/donor_table.csv")
    severe = set(donor_tab.loc[donor_tab["Severely Affected Donor"].astype(str).eq("Y"), "Donor ID"].astype(str))
    n = rows.groupby(["donor", "subclass"])["n_nuclei"].sum().unstack(fill_value=0)
    donors = [x for x in n.index if n.at[x, DAM] >= args.min_dam and n.at[x, HOM] >= args.min_hom and x not in severe]
    print(f"donors with >= {args.min_dam} DAM-like and >= {args.min_hom} homeostatic nuclei (non-severe): {len(donors)} "
          f"of {len(n)}; DAM-like nuclei in them: {int(n.loc[donors, DAM].sum())}")

    pooled = {}
    for st in (DAM, HOM):
        ix = rows.index[rows["donor"].isin(donors) & (rows["subclass"] == st)].to_numpy()
        c = np.asarray(M[ix].sum(0)).ravel()
        pooled[st] = c / c.sum() * 1e6
    keep = np.flatnonzero((pooled[DAM] >= 5) | (pooled[HOM] >= 5))
    print(f"peaks tested: {len(keep)} of {len(peaks)}")

    D, used = paired(rows, M, donors, keep, rng=rng)
    pd.Series(used, name="donor").to_csv(out / "discovery_donors.csv", index=False)
    mean, t, p, q_flip = flip_test(D, args.n_flip, rng)
    res = peaks.iloc[keep].copy()
    res["peak"] = res.index
    res = res.reset_index(drop=True)
    res["log2fc"], res["t"], res["p"] = mean, t, p
    res["q_bh"], res["q"] = bh(p), q_flip
    res["cpm_dam"], res["cpm_hom"] = pooled[DAM][keep], pooled[HOM][keep]
    res["frac_donors_up"] = (D > 0).mean(0)
    ann = annotate(res, ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz")
    res = pd.concat([res, ann.reset_index(drop=True)], axis=1)
    res["call"] = np.select([(res["q"] < 0.05) & (res["log2fc"] >= 0.5), (res["q"] < 0.05) & (res["log2fc"] <= -0.5)],
                            ["DAM-open", "DAM-closed"], "ns")

    # chemistry sensitivity
    for method in ("10xMulti", "10xATAC_v1.1"):
        Dm, um = paired(rows, M, donors, keep, method, rng=rng)
        res[f"log2fc_{method}"] = Dm.mean(0) if len(um) >= 5 else np.nan
        print(f"  {method}: {len(um)} donors with both states")
    res.to_csv(out / "dam_peaks_all.csv.gz", index=False)

    sig = res[res["call"] != "ns"]
    print(f"\nDAM-open: {(res['call'] == 'DAM-open').sum()}, DAM-closed: {(res['call'] == 'DAM-closed').sum()} "
          f"(q < 0.05, |log2FC| >= 0.5); q < 0.05 any size: {(res['q'] < 0.05).sum()}")
    print(pd.crosstab(sig["call"], sig["class"]))
    for method in ("10xMulti", "10xATAC_v1.1"):
        c = res[f"log2fc_{method}"]
        if c.notna().any():
            print(f"effect correlation, all peaks vs {method}-only: r = {np.corrcoef(res['log2fc'], c.fillna(0))[0, 1]:.2f}; "
                  f"significant peaks same sign: {(np.sign(sig['log2fc']) == np.sign(sig[f'log2fc_{method}'])).mean():.2f}")
    print("\nTop DAM-open peaks:")
    cols = ["peak", "nearest_gene", "dist_tss", "class", "log2fc", "q", "frac_donors_up", "cpm_dam", "cpm_hom"]
    print(res[res["call"] == "DAM-open"].sort_values("t", ascending=False)[cols].head(25).to_string(index=False,
                                                                                              float_format=lambda v: f"{v:.3g}"))
    print("\nTop DAM-closed peaks:")
    print(res[res["call"] == "DAM-closed"].sort_values("t")[cols].head(15).to_string(index=False,
                                                                                   float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
