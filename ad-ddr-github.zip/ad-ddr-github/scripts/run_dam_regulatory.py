"""DAM chromatin beyond single peaks: mouse-anchored peaks and gene regulatory domains.

    python scripts/run_dam_regulatory.py --out results/dam_regulatory

Human: SEA-AD MTG snATAC, DAM-like (Micro-PVM_3-SEAAD) vs homeostatic (Micro-PVM_2)
microglia, within donor, deeper pseudobulk binomially thinned to the shallower one and the
difference averaged over 20 draws (same donors and rules as scripts/run_dam_peaks.py). Mouse: GSE296025 5xFAD CD11c+ (PAM) vs
CD11c- microglia bulk ATAC, peak fold enrichment rank-normalised within sample, replicates
paired by number. The two data sets are independent, so selecting on mouse and testing on
human is not double dipping.

A. Mouse-anchored peaks. Human tested peaks are lifted to mm10 (peak centre). A peak is
   anchored if a mouse peak lies within 250 bp in >= 4 of the 6 PAM / CD11c- samples, all 3
   replicate differences have the same sign and |mean difference| >= 0.05. Human p-values
   (paired t) are then BH-corrected within the anchored set only, and a call also needs the
   human sign to match mouse. Conservation overall: sign agreement among anchored peaks
   against the agreement expected from each species' share of up / down peaks.
B. Gene regulatory domains. All peaks with >= 1 pooled CPM overlapping +/- 50 kb of a
   gene's TSS are summed per (donor, state); paired t per gene with sign-flip FDR. Sets
   defined in RNA (independent modality; released pseudobulks, 66 donors): the 200 most
   DAM-up and 200 most DAM-down expressed genes; plus canonical DAM and homeostatic genes.
   Set statistic: mean gene t vs 1,000 random gene sets matched on number of domain peaks
   and domain accessibility (z; genes as the unit, so z is inflated by between-donor
   correlation), and with donor as the unit: per-donor set-minus-matched-genes contrast,
   sign flips over donors (p_flip_donor; the statistic to report). Mouse gene domains (summed fold enrichment within 50 kb, rank
   normalised) give the cross-species check, with orthologs by symbol capitalisation.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from ad_ddr.signatures import DAM as DAM_GENES
from ddrmulti.genome import parse_peak_names, peaks_near_genes, read_gtf_genes
from ddrmulti.stats import bh
from run_dam_peaks import DAM, HOM, flip_test, load, thin_mean_diff
from validate_dam_peaks import liftover_points, read_chain

ROOT = Path(__file__).resolve().parents[1]
HOMEO = ["P2RY12", "CX3CR1", "TMEM119", "CSF1R", "SELPLG", "SALL1", "FCRLS", "GPR34", "OLFML3", "SIGLECH"]
NAMED = ["CD9", "ANXA2", "PTPRG", "RASGEF1C", "VIM", "HBEGF", "RGCC", "DAPK2", "TREM2", "APOE", "SPP1", "GPNMB",
         "LPL", "CST7", "ITGAX", "AXL", "P2RY12", "CX3CR1", "TMEM119", "CSF1R", "BIN1", "SPI1"]
WINDOW = 50_000


def donor_counts(rows, M, donors):
    """Per donor: (DAM, homeostatic) count vectors over all peaks (not yet depth-matched)."""
    out = {}
    for d in donors:
        cs = []
        for st in (DAM, HOM):
            ix = rows.index[(rows["donor"] == d) & (rows["subclass"] == st)].to_numpy()
            cs.append(np.asarray(M[ix].sum(0)).ravel())
        out[d] = cs
    return out


def domain_diffs(cnt, donors, P, rng):
    """Donor x domain log2 CPM differences (DAM - homeostatic), depth-matched, averaged over draws."""
    feat = lambda c: np.log2(c @ P / c.sum() * 1e6 + 1)
    return np.array([thin_mean_diff(cnt[d][0], cnt[d][1], rng, feat) for d in donors])


def mouse_samples(data: Path):
    smp = {}
    for f in sorted(data.glob("*narrowPeaks_.bed.gz")):
        name = f.name.split("MACS2callpeakon")[1].split("_")[0]
        pk = pd.read_csv(gzip.open(f, "rt"), sep="\t", header=None, usecols=[0, 1, 2, 6], names=["chrom", "start", "end", "fe"])
        pk["rank"] = pk["fe"].rank(pct=True)
        smp[name] = pk
    return smp


def mouse_at_points(smp, chroms, pos):
    """Sample x point matrix of mouse peak rank within 250 bp of each lifted point (0 = no peak)."""
    out = {}
    pts = pd.DataFrame({"chrom": chroms, "pos": pos})
    for name, pk in smp.items():
        v = np.zeros(len(pts))
        for chrom, idx in pts.dropna().groupby("chrom").indices.items():
            idx = pts.dropna().index.to_numpy()[idx]
            p = pk[pk["chrom"] == chrom].sort_values("start")
            if p.empty:
                continue
            s, e, rk = p["start"].to_numpy(), p["end"].to_numpy(), p["rank"].to_numpy()
            q = pts.loc[idx, "pos"].to_numpy().astype(int)
            j = np.searchsorted(s, q + 250) - 1
            hit = (j >= 0) & (e[np.clip(j, 0, None)] >= q - 250)
            v[idx[hit]] = rk[j[hit]]
        out[name] = v
    return pd.DataFrame(out)


def mouse_gene_domains(smp, gtf: Path):
    genes = read_gtf_genes(str(gtf))
    genes = genes[genes["chrom"].str.match(r"^chr[0-9XY]+$")]
    cols = {}
    for name, pk in smp.items():
        pk2 = pk.set_index(pk["chrom"] + ":" + pk["start"].astype(str) + "-" + pk["end"].astype(str))
        pk2 = pk2[~pk2.index.duplicated()]
        pairs = peaks_near_genes(pk2, genes, WINDOW)
        pairs["fe"] = pk2.loc[pairs["peak"], "fe"].to_numpy()
        cols[name] = pairs.groupby("gene")["fe"].sum().reindex(genes.index).fillna(0)
    S = pd.DataFrame(cols)
    R = S.rank(pct=True)
    R[S == 0] = 0
    d = np.column_stack([R[f"PAMrep{r}"] - R[f"nonPAMrep{r}"] for r in (1, 2, 3)])
    return pd.DataFrame({"mm_delta": d.mean(1), "mm_reps_up": (d > 0).sum(1), "mm_reps_down": (d < 0).sum(1)},
                        index=R.index.str.upper())


def rna_lfc():
    a = ad.read_h5ad(ROOT / "data/raw/pseudobulk/Immune.h5ad")
    a = a[a.obs["Brain Region"] == "MTG"]
    o, X = a.obs, sp.csr_matrix(a.X)
    L, E = [], []
    for d in o["Donor ID"].unique():
        v = []
        for st in (DAM, HOM):
            m = (o["Donor ID"] == d).to_numpy() & (o["Supertype"].astype(str) == st).to_numpy()
            if o.loc[m, "Number of nuclei"].sum() < 20:
                break
            c = np.asarray(X[m].sum(0)).ravel()
            v.append(c / c.sum() * 1e6)
        if len(v) == 2:
            L.append(np.log2(v[0] + 1) - np.log2(v[1] + 1))
            E.append(np.minimum(v[0], v[1]))
    L, E = np.array(L), np.array(E)
    t = L.mean(0) / (L.std(0, ddof=1) / np.sqrt(len(L)) + 1e-9)
    return pd.DataFrame({"rna_log2fc": L.mean(0), "rna_t": t, "rna_expressed": (E >= 5).mean(0) >= 0.5},
                        index=a.var_names.str.upper()).groupby(level=0).first(), len(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/dam_regulatory")
    ap.add_argument("--n-flip", type=int, default=2000)
    ap.add_argument("--n-sets", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    d = ROOT / "data/processed/atac_pb_micro"
    peaks = parse_peak_names((d / "peaks.txt").read_text().split())
    rows, M = load(d)
    donors = pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"].tolist()
    cnt = donor_counts(rows, M, donors)
    pooled = sum(c[0] / c[0].sum() + c[1] / c[1].sum() for c in cnt.values())     # equal weight per pool
    pooled = pooled / pooled.sum() * 1e6
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    smp = mouse_samples(ROOT / "data/raw/gse296025")

    # ---------- A. mouse-anchored peaks
    chain = read_chain(ROOT / "data/ref/hg38ToMm10.over.chain.gz")
    mid = ((res["start"] + res["end"]) // 2).to_numpy()
    lift = liftover_points(chain, res["chrom"], mid)
    res["mm_chrom"], res["mm_pos"] = [a for a, _ in lift], [b for _, b in lift]
    MS = mouse_at_points(smp, res["mm_chrom"], res["mm_pos"])
    dd = np.column_stack([MS[f"PAMrep{r}"] - MS[f"nonPAMrep{r}"] for r in (1, 2, 3)])
    pres = (MS[[c for c in MS if c.startswith(("PAM", "nonPAM"))]] > 0).sum(1).to_numpy()
    res["mm_delta"], res["mm_present"] = dd.mean(1), pres
    res["mm_consistent"] = (np.abs(np.sign(dd).sum(1)) == 3) & (np.abs(dd.mean(1)) >= 0.05) & (pres >= 4)
    anc = res[res["mm_consistent"]].copy()
    anc["q_anchored"] = bh(anc["p"].to_numpy())
    anc["same_sign"] = np.sign(anc["log2fc"]) == np.sign(anc["mm_delta"])
    anc["call_anchored"] = np.where((anc["q_anchored"] < 0.05) & anc["same_sign"],
                                    np.where(anc["log2fc"] > 0, "conserved-open", "conserved-closed"), "ns")
    agree = anc["same_sign"].mean()
    ph, pm = (anc["log2fc"] > 0).mean(), (anc["mm_delta"] > 0).mean()
    expected = ph * pm + (1 - ph) * (1 - pm)                         # agreement expected from the marginals alone
    binom = stats.binomtest(int(anc["same_sign"].sum()), len(anc), expected)
    lifted = res["mm_chrom"].notna() & (res["mm_present"] >= 4)
    rr = stats.spearmanr(res.loc[lifted, "t"], res.loc[lifted, "mm_delta"])
    print(f"A. lifted with a mouse peak in >= 4 samples: {int(lifted.sum())}; Spearman(human t, mouse delta) = "
          f"{rr.statistic:.3f} (p = {rr.pvalue:.2g})")
    print(f"   mouse-anchored peaks: {len(anc)}; human sign agrees with mouse: {agree:.3f}, expected from marginals "
          f"{expected:.3f} (human up {ph:.2f}, mouse up {pm:.2f}); binomial p = {binom.pvalue:.2g}")
    print(anc["call_anchored"].value_counts().to_string())
    new = anc[(anc["call_anchored"] != "ns") & (res.loc[anc.index, "call"] == "ns")]
    print(f"   of these, missed by the genome-wide scan: {len(new)}")
    cols = ["peak", "nearest_gene", "dist_tss", "class", "log2fc", "p", "q", "q_anchored", "mm_delta", "call", "call_anchored"]
    anc.sort_values("p")[cols].to_csv(out / "anchored_peaks.csv", index=False)
    print(anc[anc["call_anchored"] != "ns"].sort_values("p")[cols].head(30).to_string(index=False,
                                                                                    float_format=lambda v: f"{v:.3g}"))

    # ---------- B. gene regulatory domains
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    use = np.flatnonzero(pooled >= 1)
    pairs = peaks_near_genes(peaks.iloc[use], genes, WINDOW)
    gidx = pd.Index(sorted(pairs["gene"].unique()))
    P = sp.csr_matrix((np.ones(len(pairs)), (peaks.index.get_indexer(pairs["peak"]), gidx.get_indexer(pairs["gene"]))),
                      shape=(len(peaks), len(gidx)))
    P.data[:] = 1
    D = domain_diffs(cnt, donors, P, rng)
    npk = np.asarray(P.sum(0)).ravel()
    acc = np.log2(pooled @ P + 1)
    ok = npk >= 1
    D, gidx, npk, acc = D[:, ok], gidx[ok], npk[ok], acc[ok]
    mean, t, p, q = flip_test(D, args.n_flip, rng)
    G = pd.DataFrame({"gene": gidx, "n_peaks": npk, "domain_log2cpm": acc, "log2fc": mean, "t": t, "p": p, "q": q})
    G["gene_u"] = G["gene"].str.upper()
    rna, n_rna = rna_lfc()
    G = G.join(rna, on="gene_u")
    mm = mouse_gene_domains(smp, ROOT / "data/ref/gencode.vM25.basic.annotation.gtf.gz")
    G = G.join(mm, on="gene_u")
    G.drop(columns="gene_u").to_csv(out / "gene_domains.csv.gz", index=False)
    print(f"\nB. gene domains (+/- {WINDOW // 1000} kb, >= 1 accessible peak): {len(G)} genes; q < 0.05: {(G['q'] < 0.05).sum()} "
          f"(up {((G['q'] < 0.05) & (G['t'] > 0)).sum()}, down {((G['q'] < 0.05) & (G['t'] < 0)).sum()})")
    both = G.dropna(subset=["mm_delta"])
    rho = stats.spearmanr(both["t"], both["mm_delta"])
    print(f"   human gene t vs mouse gene-domain delta: Spearman {rho.statistic:.3f} (p = {rho.pvalue:.2g}, n = {len(both)})")
    rho2 = stats.spearmanr(G["t"], G["rna_t"], nan_policy="omit")
    print(f"   human chromatin t vs human RNA t (RNA {n_rna} donors): Spearman {rho2.statistic:.3f}")

    # set tests
    expr = G[G["rna_expressed"].astype("boolean").fillna(False).astype(bool)]
    sets = {"RNA DAM-up top 200": expr.nlargest(200, "rna_t")["gene"].tolist(),
            "RNA DAM-down top 200": expr.nsmallest(200, "rna_t")["gene"].tolist(),
            "canonical DAM (Keren-Shaul)": [g for g in DAM_GENES if g in set(G["gene"])],
            "homeostatic": [g for g in HOMEO if g in set(G["gene"])]}
    strat = (pd.qcut(G["n_peaks"].rank(method="first"), 5, labels=False).to_numpy() * 5
             + pd.qcut(G["domain_log2cpm"].rank(method="first"), 5, labels=False).to_numpy())
    pos = pd.Series(np.arange(len(G)), index=G["gene"])
    by = {s: np.flatnonzero(strat == s) for s in np.unique(strat)}
    tv, mv = G["t"].to_numpy(), G["mm_delta"].to_numpy()
    srows = []
    rng2 = np.random.default_rng(args.seed + 1)            # separate stream: earlier results unchanged
    for name, gs in sets.items():
        gi = pos.reindex(gs).dropna().astype(int).to_numpy()
        null = np.array([tv[[rng.choice(by[s]) for s in strat[gi]]].mean() for _ in range(args.n_sets)])
        obs = tv[gi].mean()
        mnull = np.array([np.nanmean(mv[[rng.choice(by[s]) for s in strat[gi]]]) for _ in range(200)])
        srows.append({"set": name, "n_genes": len(gi), "mean_t": obs, "null_mean": null.mean(), "null_sd": null.std(),
                      "z": (obs - null.mean()) / null.std(),
                      "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (args.n_sets + 1),
                      "frac_genes_t_pos": (tv[gi] > 0).mean(), "mouse_mean_delta": np.nanmean(mv[gi]),
                      "mouse_null_mean": mnull.mean(), "mouse_z": (np.nanmean(mv[gi]) - mnull.mean()) / mnull.std()})
        # donor as the unit: per-donor mean domain log2FC of the set minus matched random genes, sign flips over donors
        bg = np.array([[rng2.choice(by[s_]) for s_ in strat[gi]] for _ in range(50)])
        ctr = D[:, gi].mean(1) - np.mean([D[:, b_].mean(1) for b_ in bg], axis=0)
        flips = np.abs(rng2.choice([-1.0, 1.0], size=(10000, len(ctr))) @ ctr)
        srows[-1].update(donor_contrast=ctr.mean(), donors_same_sign=int((np.sign(ctr) == np.sign(ctr.mean())).sum()),
                         n_donors=len(ctr), t_donor=stats.ttest_1samp(ctr, 0).statistic,
                         p_flip_donor=(np.sum(flips >= abs(ctr.sum())) + 1) / (len(flips) + 1))
    S = pd.DataFrame(srows)
    S.to_csv(out / "set_tests.csv", index=False)
    print("\nSet tests (mean gene-domain t, DAM vs homeostatic chromatin):")
    print(S.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    named = G.set_index("gene").reindex(NAMED)[["n_peaks", "log2fc", "t", "p", "q", "rna_log2fc", "mm_delta",
                                                 "mm_reps_up", "mm_reps_down"]]
    named.to_csv(out / "named_genes.csv")
    print("\nNamed genes (regulatory domain +/- 50 kb):")
    print(named.to_string(float_format=lambda v: f"{v:.3g}"))
    mm3 = np.where(G["t"] > 0, G["mm_reps_up"] == 3, G["mm_reps_down"] == 3)
    conserved = G[(G["q"] < 0.1) & mm3 & (np.sign(G["t"]) == np.sign(G["mm_delta"]))].sort_values("p")
    sig = G[(G["q"] < 0.1) & G["mm_delta"].notna()]
    base_up, base_dn = (G["mm_reps_up"] == 3).mean(), (G["mm_reps_down"] == 3).mean()
    exp_n = (sig["t"] > 0).sum() * base_up + (sig["t"] < 0).sum() * base_dn
    print(f"\n{len(sig)} human gene domains at q < 0.1 with a mouse ortholog; expected with all 3 mouse replicates in the "
          f"same direction by chance: {exp_n:.1f} (genome-wide 3/3 up {base_up:.2f}, 3/3 down {base_dn:.2f})")
    conserved.drop(columns="gene_u").to_csv(out / "conserved_gene_domains.csv", index=False)
    bt = stats.binomtest(len(conserved), len(sig), exp_n / len(sig), alternative="greater")
    print(f"\nGene domains q < 0.1 in human AND same direction in all 3 mouse replicates: {len(conserved)} "
          f"(expected {exp_n:.1f}; binomial p = {bt.pvalue:.2g})")
    print(conserved[["gene", "n_peaks", "log2fc", "t", "q", "rna_log2fc", "mm_delta"]].head(40).to_string(
        index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
