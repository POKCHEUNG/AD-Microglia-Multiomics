"""Genome-wide discovery -> replication screen for genes tracking AD progression, per cell type.

    python scripts/run_discovery_screen.py --out results/discovery

Fixed before running:
* cell types: excitatory and inhibitory neurons, microglia, astrocytes, oligodendrocytes, OPCs
* discovery: SEA-AD MTG, non-severely-affected donors; partial r of each expressed gene
  (log2 CPM) with local CPS, adjusting for age, sex, PMI, log #nuclei and mitochondrial
  fraction (technical proxy of the neuronal drift factor F1)
* calibration: empirical null per cell type, z = (r - median) / (1.4826 * MAD) over all
  genes, so a global shift is removed and a gene must move more than most genes
* discovery hits: BH q < 0.05 on the empirical-null p (two-sided), per cell type
* replication 1 (independent cohort): Morabito 2021 PFC, AD vs control (age, sex, log
  #nuclei), same empirical-null z, one-sided p < 0.05 in the discovery direction
* replication 2 (descriptive; regions share donors): number of the other 8 SEA-AD regions
  with the same sign
* "replicated" = discovery hit + replication 1 + same sign in >= 4 of 8 other regions
* expected chance replications = (#hits with a Morabito test) x 0.05 x P(>=4/8 same sign)
Post hoc (added after the pre-specified q < 0.05 gave no MTG hits): --discovery-p for a
two-stage design where replication, not the discovery threshold, controls false positives.
"""

from __future__ import annotations

import argparse
import sys
import time
import urllib.parse
from pathlib import Path

import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
from scipy import stats as sst

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402

from ad_ddr import cohort
from ddrmulti.stats import bh

CELLS = {"Exc": ("class", cohort.EXC, "EX"), "Inh": ("class", cohort.INH, "INH"),
         "Micro": ("group", "Microglia-PVM", "MG"), "Astro": ("group", "Astrocyte", "ASC"),
         "Oligo": ("group", "Oligodendrocyte", "ODC"), "OPC": ("group", "OPC", "OPC")}


def empirical_z(r: pd.Series) -> tuple[pd.Series, pd.Series]:
    med = r.median()
    mad = 1.4826 * (r - med).abs().median()
    z = (r - med) / mad
    return z, pd.Series(2 * sst.norm.sf(z.abs()), index=r.index)


def gene_r(M: np.ndarray, genes: pd.Index, x: np.ndarray, cov: pd.DataFrame, mito: bool = True) -> pd.Series:
    cpm = M / M.sum(1, keepdims=True) * 1e6
    keep = (cpm >= 1).mean(0) >= 0.5
    L = np.log2(cpm[:, keep] + 1)
    Z = cov.copy()
    if mito:
        Z["mito"] = M[:, genes.str.startswith("MT-")].sum(1) / M.sum(1)
    r, _ = partial_r(L, x, pd.get_dummies(Z, drop_first=True, dtype=float).to_numpy(float))
    s = pd.Series(r, index=genes[keep])
    return s[~s.index.duplicated()]


def pubmed_count(term: str) -> int:
    """PubMed hit count via curl (python.org urllib on this Mac lacks root certificates)."""
    import json
    import subprocess
    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?" + urllib.parse.urlencode(
        {"db": "pubmed", "term": term, "retmode": "json", "retmax": 0})
    for _ in range(3):
        try:
            r = subprocess.run(["curl", "-sS", "-m", "30", url], capture_output=True, text=True, check=True)
            return int(json.loads(r.stdout)["esearchresult"]["count"])
        except Exception:
            time.sleep(1)
    return -1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/discovery")
    ap.add_argument("--no-pubmed", action="store_true")
    ap.add_argument("--discovery-p", type=float, default=None,
                    help="post hoc two-stage design: discovery by nominal empirical-null p < value instead of q < 0.05")
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)

    s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
    paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
    idx, C, genes, _ = cohort.aggregate(paths)
    genes = pd.Index(genes)

    # SEA-AD: every region x cell type
    sea = {}
    for region in sorted(idx.region.unique()):
        info = s[(s.region == region) & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]]
        info[["cps", "age", "pmi"]] = info[["cps", "age", "pmi"]].apply(pd.to_numeric, errors="coerce")
        info = info.dropna()
        for ct, (level, grp, _) in CELLS.items():
            m = ((idx.region == region) & (idx.level == level) & (idx.group == grp) & idx.donor.isin(info.index)
                 & (idx.n_nuclei >= 20)).to_numpy()
            if m.sum() < 20:
                continue
            d = idx[m]
            cov = info.loc[d.donor, ["age", "sex", "pmi"]].reset_index(drop=True).assign(log_nuclei=np.log10(d.n_nuclei.to_numpy()))
            r = gene_r(C[m], genes, info.loc[d.donor, "cps"].to_numpy(float), cov)
            z, p = empirical_z(r)
            sea[(region, ct)] = pd.DataFrame({"r": r, "z": z, "p": p, "n": m.sum()})
        print(f"  {region}: done", flush=True)

    # Morabito
    X = sc.read_10x_h5(ROOT / "data/raw/morabito/GSE174367_snRNA-seq_filtered_feature_bc_matrix.h5")
    X.var_names_make_unique()
    meta = pd.read_csv(ROOT / "data/raw/morabito/GSE174367_snRNA-seq_cell_meta.csv.gz").set_index("Barcode")
    X = X[X.obs_names.isin(meta.index)]
    mm = meta.loc[X.obs_names]
    mor = {}
    for ct, (_, _, mlabel) in CELLS.items():
        sel = (mm["Cell.Type"] == mlabel).to_numpy()
        cat = pd.Categorical(mm.SampleID[sel])
        A = sp.csr_matrix((np.ones(sel.sum()), (cat.codes, np.arange(sel.sum()))))
        M = np.asarray((A @ sp.csr_matrix(X.X[sel])).todense())
        n = np.bincount(cat.codes)
        ok = n >= 20
        d = mm[sel].drop_duplicates("SampleID").set_index("SampleID").loc[pd.Index(cat.categories)[ok]]
        cov = pd.DataFrame({"age": d.Age.to_numpy(float), "sex": d.Sex.to_numpy(), "log_nuclei": np.log10(n[ok])})
        r = gene_r(M[ok], pd.Index(X.var_names), (d.Diagnosis == "AD").astype(float).to_numpy(), cov, mito=False)
        z, p = empirical_z(r)
        mor[ct] = pd.DataFrame({"r": r, "z": z, "n": ok.sum()})
    print("  Morabito: done", flush=True)

    rows = []
    others = [r for r in sorted(idx.region.unique()) if r != "MTG"]
    for ct in CELLS:
        if ("MTG", ct) not in sea:
            continue
        dsc = sea[("MTG", ct)].copy()
        dsc["q"] = bh(dsc.p.to_numpy())
        hits = dsc[dsc.p < args.discovery_p] if args.discovery_p else dsc[dsc.q < 0.05]
        for gene, h in hits.iterrows():
            sign = np.sign(h.z)
            reg_same = sum(1 for rg in others if (rg, ct) in sea and gene in sea[(rg, ct)].index
                           and np.sign(sea[(rg, ct)].loc[gene, "z"]) == sign)
            reg_tested = sum(1 for rg in others if (rg, ct) in sea and gene in sea[(rg, ct)].index)
            mz = mor[ct].loc[gene, "z"] if gene in mor[ct].index else np.nan
            rows.append({"cell_type": ct, "gene": gene, "r_MTG": h.r, "z_MTG": h.z, "q_MTG": h.q,
                         "regions_same_sign": reg_same, "regions_tested": reg_tested,
                         "r_Morabito": mor[ct].loc[gene, "r"] if gene in mor[ct].index else np.nan, "z_Morabito": mz,
                         "p_Morabito_one_sided": sst.norm.sf(sign * mz) if np.isfinite(mz) else np.nan})
    res = pd.DataFrame(rows, columns=["cell_type", "gene", "r_MTG", "z_MTG", "q_MTG", "regions_same_sign", "regions_tested",
                                      "r_Morabito", "z_Morabito", "p_Morabito_one_sided"])
    for ct in CELLS:
        if ("MTG", ct) in sea:
            d = sea[("MTG", ct)]
            top = d.p.idxmin()
            print(f"  MTG {ct:6} genes={len(d):5d}  min p={d.p.min():.2g} ({top}, r={d.loc[top, 'r']:+.2f})  "
                  f"min q={bh(d.p.to_numpy()).min():.3f}  null sd(r)={1.4826 * (d.r - d.r.median()).abs().median():.3f}")
    res["replicated"] = (res.p_Morabito_one_sided < 0.05) & (res.regions_same_sign >= 4)
    res.to_csv(out / "discovery_hits.csv", index=False)

    print("\nSummary per cell type (discovery q<0.05 in MTG; replication = Morabito one-sided p<0.05 + >=4/8 regions same sign)")
    summ = []
    for ct, d in res.groupby("cell_type"):
        tested = d.p_Morabito_one_sided.notna()
        p_reg = (d.regions_same_sign >= 4).mean()
        summ.append({"cell_type": ct, "n_genes_MTG": len(sea[("MTG", ct)]), "discovery_hits": len(d),
                     "up": int((d.z_MTG > 0).sum()), "down": int((d.z_MTG < 0).sum()),
                     "tested_in_Morabito": int(tested.sum()), "Morabito_p05": int((d.p_Morabito_one_sided < 0.05).sum()),
                     "replicated": int(d.replicated.sum()), "expected_by_chance": round(tested.sum() * 0.05 * p_reg, 1)})
    summ = pd.DataFrame(summ)
    summ.to_csv(out / "summary.csv", index=False)
    print(summ.to_string(index=False))

    rep = res[res.replicated].sort_values(["cell_type", "q_MTG"])
    if not args.no_pubmed and len(rep):
        cnt_ad, cnt_ct = [], []
        ctword = {"Exc": "neuron", "Inh": "interneuron", "Micro": "microglia", "Astro": "astrocyte",
                  "Oligo": "oligodendrocyte", "OPC": "oligodendrocyte precursor"}
        for _, row in rep.iterrows():
            cnt_ad.append(pubmed_count(f'{row.gene}[tiab] AND (alzheimer*[tiab])'))
            cnt_ct.append(pubmed_count(f'{row.gene}[tiab] AND (alzheimer*[tiab]) AND ({ctword[row.cell_type]}*[tiab])'))
            time.sleep(0.4)
        rep = rep.assign(pubmed_gene_AD=cnt_ad, pubmed_gene_AD_celltype=cnt_ct)
    rep.to_csv(out / "replicated.csv", index=False)
    print(f"\nReplicated genes ({len(rep)}):")
    print(rep.to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
