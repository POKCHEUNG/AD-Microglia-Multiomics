"""Is the neuronal drift axis (F1) general, and how much does it change pathway conclusions?

    python scripts/run_f1_generality.py --out results/f1_generality

Drift axis per dataset = PC1 of the concatenated, covariate-residualised and z-scored
excitatory + inhibitory neuron pseudobulks (top 1,000 variance genes per class), oriented
so that its gene loadings fall with gene length (as for MOFA F1). In MTG it is compared with
MOFA F1 (README result 18).
For every SEA-AD region and for Morabito 2021:
  variance share of PC1; r with neuronal mitochondrial fraction; Spearman(gene-PC1 r,
  log10 gene length); r with the disease exposure; and calibration: share of 300 random
  20-gene neuronal sets with p < 0.05 for the exposure, without vs with PC1 as covariate.
Impact (MTG, dementia; Morabito, AD vs control): 50 MSigDB Hallmark module scores per donor
(mean z of expressed set genes) tested self-contained (BH q < 0.05) and competitively (vs 200
expression-matched random sets), without vs with PC1.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
from scipy import stats as sst

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402

from ad_ddr import cohort
from ddrmulti.genome import read_gtf_genes
from ddrmulti.stats import bh

GLEN = None


def residual(M: np.ndarray, genes: pd.Index, cov: pd.DataFrame):
    cpm = M / M.sum(1, keepdims=True) * 1e6
    keep = (cpm >= 1).mean(0) >= 0.5
    L = np.log2(cpm[:, keep] + 1)
    Z1 = np.column_stack([np.ones(len(L)), pd.get_dummies(cov, drop_first=True, dtype=float).to_numpy(float)])
    R = L - Z1 @ np.linalg.lstsq(Z1, L, rcond=None)[0]
    R = pd.DataFrame(R, columns=genes[keep]).T.groupby(level=0).first().T
    R = (R - R.mean()) / R.std().replace(0, 1)
    mito = M[:, genes.str.startswith("MT-")].sum(1) / M.sum(1)
    mean = pd.Series(L.mean(0), index=genes[keep]).groupby(level=0).first()
    return R, mito, mean


def drift_axis(views: dict[str, pd.DataFrame]) -> tuple[np.ndarray, float]:
    X = np.hstack([v[v.var().sort_values(ascending=False).index[:1000]].to_numpy() for v in views.values()])
    U, S, _ = np.linalg.svd(X - X.mean(0), full_matrices=False)
    pc1 = U[:, 0] * S[0]
    share = S[0] ** 2 / (S ** 2).sum()
    # orient: loadings should fall with gene length (as MOFA F1)
    R = views["Exc"]
    load = pd.Series(R.to_numpy().T @ ((pc1 - pc1.mean()) / pc1.std()) / len(pc1), index=R.columns)
    ok = [g for g in load.index if g in GLEN.index and not g.startswith("MT-")]
    if sst.spearmanr(load[ok], GLEN[ok]).statistic > 0:
        pc1 = -pc1
    return pc1, share


def describe(name, views, mitos, x, exposure, Zc, rng):
    pc1, share = drift_axis(views)
    out = {"dataset": name, "n_donors": len(pc1), "exposure": exposure, "pc1_variance_share": share,
           "r_pc1_exposure": np.corrcoef(pc1, x)[0, 1]}
    for v, R in views.items():
        out[f"r_pc1_mito_{v}"] = np.corrcoef(pc1, mitos[v])[0, 1]
        load = pd.Series(R.to_numpy().T @ ((pc1 - pc1.mean()) / pc1.std()) / len(pc1), index=R.columns)
        ok = [g for g in load.index if g in GLEN.index and not g.startswith("MT-")]
        out[f"rho_loading_length_{v}"] = sst.spearmanr(load[ok], GLEN[ok]).statistic
        sets = [rng.choice(R.columns, 20, replace=False) for _ in range(300)]
        scm = np.column_stack([R[list(s_)].mean(1) for s_ in sets])
        for tag, Z in (("without", Zc), ("with", np.column_stack([Zc, pc1]))):
            _, p = partial_r(scm, x, Z)
            out[f"random_p05_{v}_{tag}_pc1"] = float((p < 0.05).mean())
    return out, pc1


def hallmark_impact(name, views, means, x, Zc, pc1, hallmark, rng):
    rows = []
    for v, R in views.items():
        bins = pd.qcut(means[v].reindex(R.columns).rank(method="first"), 10, labels=False)
        for hs, gs in hallmark.groupby("source").target:
            gi = [g for g in gs if g in R.columns]
            if len(gi) < 10:
                continue
            sets = [gi] + [[rng.choice(R.columns[(bins == bins[g]).to_numpy()]) for g in gi] for _ in range(200)]
            scm = np.column_stack([R[s_].mean(1) for s_ in sets])
            for tag, Z in (("without", Zc), ("with", np.column_stack([Zc, pc1]))):
                r, p = partial_r(scm, x, Z)
                null = r[1:]
                rows.append({"dataset": name, "cells": v, "hallmark": hs, "model": f"{tag} PC1", "r": r[0], "p": p[0],
                             "p_competitive": (np.sum(np.abs(null - null.mean()) >= abs(r[0] - null.mean())) + 1) / 201})
    t = pd.DataFrame(rows)
    t["q"] = t.groupby(["cells", "model"]).p.transform(lambda p: bh(p.to_numpy()))
    t["q_competitive"] = t.groupby(["cells", "model"]).p_competitive.transform(lambda p: bh(p.to_numpy()))
    return t


def main():
    global GLEN
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/f1_generality")
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(0)
    gtf = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    GLEN = np.log10((gtf.end - gtf.start).clip(lower=1))
    hallmark = pd.read_csv(ROOT / "data/ref/msigdb_hallmark.csv")

    s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
    paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
    paths = [p for p in paths if not any(k in p.stem for k in ("Astrocyte", "Immune", "Oligo", "OPC", "Endothelial", "VLMC", "Ependymal"))]
    idx, C, genes, _ = cohort.aggregate(paths)
    genes = pd.Index(genes)
    summary, impact = [], []

    for region in sorted(idx.region.unique()):
        info = s[(s.region == region) & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "dementia", "age", "sex", "pmi"]]
        for c in ("cps", "dementia", "age", "pmi"):
            info[c] = pd.to_numeric(info[c], errors="coerce")
        info = info.dropna()
        for lvl_grp in ((cohort.EXC,), (cohort.INH,)):
            have = idx[(idx.region == region) & (idx.level == "class") & (idx.group == lvl_grp[0]) & (idx.n_nuclei >= 20)].donor
            info = info[info.index.isin(have)]
        if len(info) < 20:
            continue
        views, mitos, means = {}, {}, {}
        for v, grp in (("Exc", cohort.EXC), ("Inh", cohort.INH)):
            m = ((idx.region == region) & (idx.level == "class") & (idx.group == grp)).to_numpy()
            d = idx[m].set_index("donor")
            rows = d.index.get_indexer(info.index)
            M = C[np.flatnonzero(m)[rows]]
            cov = info[["age", "sex", "pmi"]].assign(log_nuclei=np.log10(d.n_nuclei.iloc[rows].to_numpy()))
            views[v], mitos[v], means[v] = residual(M, genes, cov)
            views[v].index = info.index
        Zc = pd.get_dummies(info[["age", "sex", "pmi"]], drop_first=True, dtype=float).to_numpy()
        for exposure in (["cps", "dementia"] if region == "MTG" else ["cps"]):
            o, pc1 = describe(f"SEA-AD {region}", views, mitos, info[exposure].to_numpy(float), exposure, Zc, rng)
            summary.append(o)
        if region == "MTG":
            f1 = pd.read_csv(ROOT / "results/mofa/factor_scores.csv", index_col=0)
            common = f1.index.intersection(info.index)
            pos = info.index.get_indexer(common)
            print(f"MTG: r(PC1 drift axis, MOFA F1) = {np.corrcoef(pc1[pos], f1.loc[common, 'F1'])[0, 1]:+.3f} "
                  f"({len(common)} donors)", flush=True)
            impact.append(hallmark_impact("SEA-AD MTG", views, means, info.dementia.to_numpy(float), Zc, pc1, hallmark, rng))
        print(f"  {region}: done", flush=True)

    # Morabito
    X = sc.read_10x_h5(ROOT / "data/raw/morabito/GSE174367_snRNA-seq_filtered_feature_bc_matrix.h5")
    X.var_names_make_unique()
    meta = pd.read_csv(ROOT / "data/raw/morabito/GSE174367_snRNA-seq_cell_meta.csv.gz").set_index("Barcode")
    X = X[X.obs_names.isin(meta.index)]
    mm = meta.loc[X.obs_names]
    mgenes = pd.Index(X.var_names)
    views, mitos, means, donors = {}, {}, {}, None
    for v, lab in (("Exc", "EX"), ("Inh", "INH")):
        sel = (mm["Cell.Type"] == lab).to_numpy()
        cat = pd.Categorical(mm.SampleID[sel])
        A = sp.csr_matrix((np.ones(sel.sum()), (cat.codes, np.arange(sel.sum()))))
        M = pd.DataFrame(np.asarray((A @ sp.csr_matrix(X.X[sel])).todense()), index=cat.categories)
        n = pd.Series(np.bincount(cat.codes), index=cat.categories)
        donors = M.index if donors is None else donors.intersection(M.index)
        views[v] = (M, n)
    d = mm.drop_duplicates("SampleID").set_index("SampleID").loc[donors]
    info = pd.DataFrame({"ad": (d.Diagnosis == "AD").astype(float).to_numpy(), "age": d.Age.to_numpy(float),
                         "sex": d.Sex.to_numpy()}, index=donors)
    for v in list(views):
        M, n = views[v]
        M = M.loc[donors].to_numpy()
        cov = info[["age", "sex"]].assign(log_nuclei=np.log10(n.loc[donors].to_numpy()))
        views[v], mitos[v], means[v] = residual(M, mgenes, cov)
        views[v].index = donors
    Zc = pd.get_dummies(info[["age", "sex"]], drop_first=True, dtype=float).to_numpy()
    o, pc1 = describe("Morabito PFC", views, mitos, info.ad.to_numpy(float), "AD vs control", Zc, rng)
    summary.append(o)
    impact.append(hallmark_impact("Morabito PFC", views, means, info.ad.to_numpy(float), Zc, pc1, hallmark, rng))

    S = pd.DataFrame(summary)
    S.to_csv(out / "drift_axis_by_dataset.csv", index=False)
    I = pd.concat(impact, ignore_index=True)
    I.to_csv(out / "hallmark_impact.csv", index=False)
    pd.set_option("display.width", 250)
    cols = ["dataset", "exposure", "n_donors", "pc1_variance_share", "r_pc1_exposure", "r_pc1_mito_Exc", "r_pc1_mito_Inh",
            "rho_loading_length_Exc", "rho_loading_length_Inh", "random_p05_Exc_without_pc1", "random_p05_Exc_with_pc1",
            "random_p05_Inh_without_pc1", "random_p05_Inh_with_pc1"]
    print("\nDrift axis (PC1 of neurons) per dataset")
    print(S[cols].to_string(index=False, float_format=lambda v: f"{v:+.2f}"))
    print("\nHallmark pathways vs disease (50 sets per neuron class): number with q < 0.05")
    hs = I.groupby(["dataset", "cells", "model"]).agg(self_contained_q05=("q", lambda q: int((q < 0.05).sum())),
                                                    competitive_q05=("q_competitive", lambda q: int((q < 0.05).sum())),
                                                    n_sets=("hallmark", "size"))
    print(hs.to_string())

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    lab = S.dataset.str.replace("SEA-AD ", "") + np.where(S.exposure == "dementia", " (dem.)", "")
    x = np.arange(len(S))
    ax[0].bar(x - 0.2, S.random_p05_Inh_without_pc1, width=0.4, color="0.6", label="without drift axis")
    ax[0].bar(x + 0.2, S.random_p05_Inh_with_pc1, width=0.4, color="#3b6fb6", label="with drift axis")
    ax[0].axhline(0.05, color="#c0392b", ls="--", lw=1)
    ax[0].set_xticks(x, lab, rotation=45, ha="right", fontsize=7)
    ax[0].set_ylabel("random inhibitory-neuron gene sets with p < 0.05")
    ax[0].set_title("Calibration of random gene sets, by dataset", fontsize=9)
    ax[0].legend(fontsize=7, frameon=False)
    hs2 = hs.reset_index()
    for i, (key, g) in enumerate(hs2.groupby(["dataset", "cells"])):
        w = g.set_index("model")
        ax[1].bar(i - 0.2, w.loc["without PC1", "self_contained_q05"], width=0.4, color="0.6")
        ax[1].bar(i + 0.2, w.loc["with PC1", "self_contained_q05"], width=0.4, color="#3b6fb6")
    ax[1].set_xticks(range(len(hs2.groupby(["dataset", "cells"]))), [f"{a.replace('SEA-AD ', '')}\n{b}" for a, b in hs2.groupby(["dataset", "cells"]).groups], fontsize=8)
    ax[1].set_ylabel("Hallmark sets with q < 0.05 (of 50)")
    ax[1].set_title("'Significant' pathways for dementia / AD, without (grey) vs with drift axis", fontsize=9)
    fig.tight_layout()
    fig.savefig(out / "f1_generality.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
