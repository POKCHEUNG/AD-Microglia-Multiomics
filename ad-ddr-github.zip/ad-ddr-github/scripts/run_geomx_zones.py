"""Do microglia in contact with Abeta plaques show altered DDR programs? (GSE306381, GeoMx WTA, human hippocampus)

    python scripts/run_geomx_zones.py --out results/spatial_geomx

AOIs are microglia-enriched regions in three zones: P (plaque contact), PP (periplaque),
A (away from plaques); donors are AD (n=20), cognitively unimpaired amyloid-positive
(CU-AP) and non-AD (A zone only). Built by scripts/build_geomx.py.

Score: log2 CPM over genes above the negative-probe background in >= 20% of AOIs, z-scored
per gene across AOIs, averaged over program genes. Zone contrasts are within donor: OLS
with donor fixed effects plus log total counts and log AOI area (contact AOIs are small).
  p_perm - zone labels permuted within donor (self-contained)
  p_set  - vs 200 random expression-matched gene sets (competitive)
Positive control: DAM (Keren-Shaul 2017) should rise in plaque-contact microglia.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr.signatures import all_programs
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
CONTRASTS = [("P", "A"), ("PP", "A"), ("P", "PP")]


def fe_beta(S: np.ndarray, x: np.ndarray, donor: np.ndarray, cov: np.ndarray) -> np.ndarray:
    """Coefficient of ``x`` for every column of ``S`` with donor fixed effects and ``cov``."""
    D = pd.get_dummies(donor, dtype=float).to_numpy()
    M = np.column_stack([x, cov, D])
    return np.linalg.lstsq(M, S, rcond=None)[0][0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/processed/geomx")
    ap.add_argument("--out", default="results/spatial_geomx")
    ap.add_argument("--groups", nargs="+", default=["AD", "CU-AP"])
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--n-perm", type=int, default=2000)
    ap.add_argument("--min-frac", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    programs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}

    C = pd.read_csv(ROOT / args.data / "counts_genes_x_aoi.csv.gz", index_col=0)
    meta = pd.read_csv(ROOT / args.data / "aoi_meta.csv").set_index("geo_accession").loc[C.columns]
    above = C.gt(meta["neg_geomean"], axis=1)
    keep = above.mean(1) >= args.min_frac
    C = C[keep]
    print(f"{keep.sum()} genes above background in >= {args.min_frac:.0%} of AOIs")
    L = np.log2(C / C.sum(0) * 1e6 + 1).T                     # AOIs x genes
    Z = ((L - L.mean(0)) / L.std(0).replace(0, 1)).to_numpy()
    genes = C.index.str.upper()
    bins = pd.qcut(L.mean(0).rank(method="first"), 10, labels=False).to_numpy()
    by_bin = {b: np.flatnonzero(bins == b) for b in range(10)}
    upper = pd.Series(np.arange(len(genes)), index=genes)
    upper = upper[~upper.index.duplicated()]

    sets = {}
    for name, gs in programs.items():
        gi = upper.reindex([g.upper() for g in gs]).dropna().astype(int).to_numpy()
        rand = np.stack([np.array([rng.choice(by_bin[b]) for b in bins[gi]]) for _ in range(args.n_sets)])
        sets[name] = (gi, rand)
    scores = pd.DataFrame({n: Z[:, gi].mean(1) for n, (gi, _) in sets.items()}, index=meta.index)
    pd.concat([meta, scores], axis=1).to_csv(out / "aoi_scores.csv")

    rows = []
    for case, ref in CONTRASTS:
        m = (meta["group"].isin(args.groups) & meta["zone"].isin([case, ref])).to_numpy()
        d = meta[m]
        both = d.groupby("donor")["zone"].nunique() == 2
        m &= meta["donor"].isin(both[both].index).to_numpy()
        d = meta[m]
        x = (d["zone"] == case).to_numpy(float)
        donor = d["donor"].to_numpy()
        cov = np.column_stack([np.log(d["total_counts"]), np.log(d["area"].astype(float))])
        # within-donor label permutations, shared across programs
        groups = [np.flatnonzero(donor == u) for u in np.unique(donor)]
        perms = []
        for _ in range(args.n_perm):
            xp = x.copy()
            for g in groups:
                xp[g] = rng.permutation(x[g])
            perms.append(xp)
        for name, (gi, rand) in sets.items():
            S = np.column_stack([Z[m][:, gi].mean(1), Z[m][:, rand].mean(2)])
            S = S / S[:, :1].std()
            b = fe_beta(S, x, donor, cov)
            obs, null = b[0], b[1:]
            bp = np.array([fe_beta(S[:, :1], xp, donor, cov)[0] for xp in perms])
            rows.append({"contrast": f"{case}_vs_{ref}", "program": name, "family": "DDR" if name in DDR else "control",
                         "n_genes": len(gi), "n_aoi": int(m.sum()), "n_donors": len(groups), "beta_sd": obs,
                         "null_mean": null.mean(), "null_lo": np.quantile(null, 0.025),
                         "null_hi": np.quantile(null, 0.975), "excess": obs - null.mean(),
                         "p_perm": (np.sum(np.abs(bp) >= abs(obs)) + 1) / (args.n_perm + 1),
                         "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (args.n_sets + 1)})
        print(f"  {case} vs {ref}: {m.sum()} AOIs, {len(groups)} donors", flush=True)
    res = pd.DataFrame(rows)
    for col in ("p_perm", "p_set"):
        res[f"q_{col[2:]}"] = np.nan
        for c, d in res[res["family"] == "DDR"].groupby("contrast"):
            res.loc[d.index, f"q_{col[2:]}"] = bh(d[col].to_numpy())
    res = res.sort_values(["contrast", "family", "p_perm"])
    res.to_csv(out / "zone_effects.csv", index=False)
    print("\nZone effects (beta in SD units of the program score; donor fixed effects + log counts + log area):")
    print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # per-gene P vs A for DDR genes, for leads
    m = (meta["group"].isin(args.groups) & meta["zone"].isin(["P", "A"])).to_numpy()
    d = meta[m]
    cov = np.column_stack([np.log(d["total_counts"]), np.log(d["area"].astype(float))])
    ddr_genes = sorted({g.upper() for k in DDR for g in programs[k]} & set(upper.index))
    gi = upper.reindex(ddr_genes).to_numpy()
    b = fe_beta(Z[m][:, gi], (d["zone"] == "P").to_numpy(float), d["donor"].to_numpy(), cov)
    pd.DataFrame({"gene": ddr_genes, "beta_P_vs_A": b}).sort_values("beta_P_vs_A").to_csv(out / "ddr_genes_P_vs_A.csv",
                                                                                       index=False)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
