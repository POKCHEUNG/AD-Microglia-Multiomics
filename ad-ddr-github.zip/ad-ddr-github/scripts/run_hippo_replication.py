"""Independent chromatin replication in human hippocampus multiome (GSE288063 + GSE278576; 22 donors aged 75-97).

    python scripts/run_hippo_replication.py --out results/hippo_replication

Inputs: data/processed/hippo (scripts/stream_hippo_multiome.sh): counts on the SEA-AD peak
set, so the SEA-AD-defined elements are tested as fixed hypotheses (no new discovery, no
genome-wide FDR). Exposures: Braak stage (0-6, continuous; donors without Braak are left
out of Braak tests) and group (AD or high-pathology vs normal). Covariates: age, sex, and
the technical terms named per test. Every test is two-sided, p from 5,000 permutations
of the exposure, and set scores are compared with matched random sets.

1. DAM chromatin (results 22, 24). Microglial state is defined from RNA in the same nuclei:
   score = mean z of log-normalised SEA-AD RNA DAM-up top-200 genes minus DAM-down top-200
   (both from SEA-AD RNA pseudobulks, a different cohort). Within each donor, nuclei in the
   top vs bottom third are pseudobulked (depth-matched, averaged over 20 thinning draws). Tested: mean log2FC (DAM-high minus
   DAM-low) of SEA-AD DAM-open and DAM-closed peaks and of the gene domains called in SEA-AD
   (q < 0.05 up / down), each against 1,000 accessibility-matched random peak / gene sets,
   across donors.
2. Homeostatic shift (results 22, 25, 28). Microglia with a DAM RNA score below the cohort
   median are pseudobulked per donor; the SEA-AD DAM axis (DAM-open minus DAM-closed peaks)
   is related to Braak / group, adjusting for the donor's share of high-score microglia, log
   fragments, age and sex, against 500 matched random axes.
3. Oligodendrocyte cohesin (results 26, 27, 30). RNA: cohesin score (Mathys set) in the
   oligodendrocyte RNA pseudobulk vs Braak / group. Chromatin: SEA-AD robust cohesin sites
   (with / without CTCF motif, from scripts/run_cohesin_sites.py) minus matched background in
   the oligodendrocyte ATAC pseudobulk, vs Braak / group, with log fragments and the promoter
   fragment share as covariates.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.genome import parse_peak_names, peaks_near_genes, read_gtf_genes
from run_dam_peaks import thin_mean_diff
from run_dam_regulatory import rna_lfc

ROOT = Path(__file__).resolve().parents[1]
H = ROOT / "data/processed/hippo"
COHESIN = ["RAD21", "SMC1A", "SMC3", "STAG1", "STAG2"]


def load_libs():
    libs = sorted(p.name[:-len("_rna_cells.npz")] for p in H.glob("*_rna_cells.npz"))
    genes = pd.Index((H / "rna_genes.txt").read_text().split())
    L = {}
    for lib in libs:
        L[lib] = {"cells": pd.read_csv(H / f"{lib}_cells.csv"), "subs": (H / f"{lib}_subclasses.txt").read_text().split(),
                  "atac_cells": sp.load_npz(H / f"{lib}_atac_cells.npz").tocsr(),
                  "rna_cells": sp.load_npz(H / f"{lib}_rna_cells.npz").tocsr(),
                  "atac_pb": sp.load_npz(H / f"{lib}_atac_pb.npz").tocsr(), "rna_pb": sp.load_npz(H / f"{lib}_rna_pb.npz").tocsr()}
    return L, genes


def assoc(y: np.ndarray, x: np.ndarray, Z: np.ndarray, rng, n_perm: int = 5000):
    xr, yr = _resid(x, Z), _resid(y, Z)
    r = np.corrcoef(xr, yr)[0, 1]
    null = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(n_perm)])
    return r, (np.sum(np.abs(null) >= abs(r)) + 1) / (n_perm + 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/hippo_replication")
    ap.add_argument("--n-sets", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    L, genes = load_libs()
    peaks = parse_peak_names((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    pix = peaks.index.get_indexer(res["peak"])
    call = res["call"].to_numpy()
    open_i, clos_i, ns_i = (pix[call == c] for c in ("DAM-open", "DAM-closed", "ns"))
    print(f"libraries: {len(L)}; donors: {len({l['cells']['donor'].iat[0] for l in L.values()})}")

    # SEA-AD RNA-defined DAM state genes
    rna, _ = rna_lfc()
    expr = rna[rna["rna_expressed"].astype("boolean").fillna(False).astype(bool)]
    up = [g for g in expr.nlargest(200, "rna_t").index if g in set(genes.str.upper())]
    dn = [g for g in expr.nsmallest(200, "rna_t").index if g in set(genes.str.upper())]
    gu = pd.Series(np.arange(len(genes)), index=genes.str.upper())
    gu = gu[~gu.index.duplicated()]
    up_i, dn_i = gu.reindex(up).to_numpy(), gu.reindex(dn).to_numpy()

    # microglia cells across libraries
    mic = []
    for lib, D in L.items():
        c = D["cells"]
        m = (c["subclass"] == "Microglia").to_numpy()
        if m.sum() == 0:
            continue
        R = D["rna_cells"][m]
        tot = np.asarray(R.sum(1)).ravel()
        Ln = sp.diags(1e4 / np.maximum(tot, 1)) @ R
        Ln.data = np.log1p(Ln.data)
        mic.append({"lib": lib, "donor": c["donor"].iat[0], "atac": D["atac_cells"][m], "ln": Ln, "tot": tot})
    allLn = sp.vstack([x["ln"] for x in mic]).tocsc()
    mu = np.asarray(allLn.mean(0)).ravel()
    sd = np.sqrt(np.maximum(np.asarray(allLn.multiply(allLn).mean(0)).ravel() - mu ** 2, 1e-12))
    def score(Ln):
        Z_up = (Ln[:, up_i].toarray() - mu[up_i]) / sd[up_i]
        Z_dn = (Ln[:, dn_i].toarray() - mu[dn_i]) / sd[dn_i]
        return Z_up.mean(1) - Z_dn.mean(1)
    for x in mic:
        x["score"] = score(x["ln"])
    med = np.median(np.concatenate([x["score"] for x in mic]))

    donors = pd.concat([D["cells"].drop_duplicates("donor") for D in L.values()])[["donor", "age", "sex", "Braak", "group"]]
    donors = donors.drop_duplicates("donor").set_index("donor")
    donors["path"] = donors["group"].isin(["AD", "HP"]).astype(float)

    # ---------- 1. DAM chromatin: high vs low tertile within donor
    gtf = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    pairs = peaks_near_genes(peaks, gtf, 50_000)
    gidx = pd.Index(sorted(pairs["gene"].unique()))
    P = sp.csr_matrix((np.ones(len(pairs)), (peaks.index.get_indexer(pairs["peak"]), gidx.get_indexer(pairs["gene"]))),
                      shape=(len(peaks), len(gidx)))
    P.data[:] = 1
    dom = pd.read_csv(ROOT / "results/dam_regulatory/gene_domains.csv.gz")
    dom_up = gidx.get_indexer(dom.loc[(dom["q"] < 0.05) & (dom["t"] > 0), "gene"])
    dom_dn = gidx.get_indexer(dom.loc[(dom["q"] < 0.05) & (dom["t"] < 0), "gene"])
    dom_up, dom_dn = dom_up[dom_up >= 0], dom_dn[dom_dn >= 0]
    by_donor = {}
    for x in mic:
        by_donor.setdefault(x["donor"], []).append(x)
    Dp, Dg, dlist, pool_cpm = [], [], [], 0
    for dn_, xs in by_donor.items():
        A = sp.vstack([x["atac"] for x in xs]).tocsr()
        s = np.concatenate([x["score"] for x in xs])
        if len(s) < 30:
            continue
        lo, hi = np.quantile(s, [1 / 3, 2 / 3])
        ch = np.asarray(A[s >= hi].sum(0)).ravel()
        cl = np.asarray(A[s <= lo].sum(0)).ravel()
        Dp.append(thin_mean_diff(ch, cl, rng, lambda c: np.log2(c / c.sum() * 1e6 + 1)))
        Dg.append(thin_mean_diff(ch, cl, rng, lambda c: np.log2(c @ P / c.sum() * 1e6 + 1)))
        pool_cpm = pool_cpm + ch / ch.sum() + cl / cl.sum()
        dlist.append(dn_)
    Dp, Dg = np.array(Dp), np.array(Dg)
    pool_cpm = pool_cpm / pool_cpm.sum() * 1e6
    acc = np.log2(pool_cpm + 1)
    usable = pool_cpm >= 1
    pb = np.full(len(acc), -1)
    pb[usable] = pd.qcut(pd.Series(acc[usable]).rank(method="first"), 20, labels=False).to_numpy()
    ppool = {b: np.flatnonzero((pb == b) & np.isin(np.arange(len(acc)), ns_i)) for b in range(20)}
    gacc = np.log2(pool_cpm @ P + 1)
    gn = np.asarray(P.sum(0)).ravel()
    gstr = (pd.qcut(pd.Series(gn).rank(method="first"), 5, labels=False).to_numpy() * 5
            + pd.qcut(pd.Series(gacc).rank(method="first"), 5, labels=False).to_numpy())
    gpool = {s: np.flatnonzero(gstr == s) for s in np.unique(gstr)}
    rows1, donor_rows = [], []
    for name, ix, D, pool, strat in (("SEA-AD DAM-open peaks", open_i, Dp, ppool, pb),
                                     ("SEA-AD DAM-closed peaks", clos_i, Dp, ppool, pb),
                                     ("SEA-AD opened gene domains", dom_up, Dg, gpool, gstr),
                                     ("SEA-AD closed gene domains", dom_dn, Dg, gpool, gstr)):
        ix = ix[strat[ix] >= 0]
        per_donor = D[:, ix].mean(1)
        obs = per_donor.mean()
        null = np.array([D[:, [rng.choice(pool[b]) for b in strat[ix]]].mean() for _ in range(args.n_sets)])
        bg = np.array([D[:, [rng.choice(pool[b]) for b in strat[ix]]].mean(1) for _ in range(50)]).mean(0)
        donor_rows += [{"test": name, "donor": dn_, "set_log2fc": v, "background_log2fc": b}
                       for dn_, v, b in zip(dlist, per_donor, bg)]
        rows1.append({"test": name, "n_elements": len(ix), "n_donors": len(dlist), "mean_log2fc": obs,
                      "null_mean": null.mean(), "z": (obs - null.mean()) / null.std(),
                      "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (len(null) + 1),
                      "donors_same_sign_vs_bg": int(np.sum(np.sign(per_donor - bg) == np.sign(obs - null.mean())))})
    pd.DataFrame(donor_rows).to_csv(out / "dam_chromatin_donors.csv", index=False)
    T1 = pd.DataFrame(rows1)
    T1.to_csv(out / "dam_chromatin.csv", index=False)
    print("\n1. DAM chromatin (RNA-defined DAM-high vs DAM-low microglia, within donor):")
    print(T1.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- 2. homeostatic shift
    rows2 = []
    H_ = []
    for dn_, xs in by_donor.items():
        A = sp.vstack([x["atac"] for x in xs]).tocsr()
        s = np.concatenate([x["score"] for x in xs])
        low = s < med
        if low.sum() < 20:
            continue
        c = np.asarray(A[low].sum(0)).ravel()
        H_.append({"donor": dn_, "L": np.log2(c / c.sum() * 1e6 + 1), "share_high": (~low).mean(),
                   "logfrag": np.log10(c.sum()), "n": int(low.sum())})
    HL = np.array([h["L"] for h in H_])
    HZ = (HL - HL.mean(0)) / np.where(HL.std(0) > 0, HL.std(0), 1)
    hi_ = pd.DataFrame([{k: v for k, v in h.items() if k != "L"} for h in H_]).join(donors, on="donor")
    for expo in ("Braak", "path"):
        m = hi_[[expo, "age"]].notna().all(1).to_numpy()
        I = hi_[m].reset_index(drop=True)
        Z = _covar_matrix(I, ["age", "sex", "logfrag", "share_high"])
        def ax(o, c):
            return HZ[m][:, o].mean(1) - HZ[m][:, c].mean(1)
        r, p = assoc(ax(open_i, clos_i), I[expo].to_numpy(float), Z, rng)
        I.assign(axis_resid=_resid(ax(open_i, clos_i), Z), x=I[expo].to_numpy(float)).to_csv(
            out / f"homeostatic_shift_donors_{expo}.csv", index=False)
        nl = []
        for _ in range(500):
            ro = np.array([rng.choice(ppool[b]) for b in pb[open_i] if b >= 0])
            rc = np.array([rng.choice(ppool[b]) for b in pb[clos_i] if b >= 0])
            nl.append(np.corrcoef(_resid(I[expo].to_numpy(float), Z), _resid(ax(ro, rc), Z))[0, 1])
        nl = np.array(nl)
        rows2.append({"exposure": expo, "n_donors": int(m.sum()), "r": r, "p_perm": p, "null_mean": nl.mean(),
                      "p_set": (np.sum(np.abs(nl - nl.mean()) >= abs(r - nl.mean())) + 1) / (len(nl) + 1)})
    T2 = pd.DataFrame(rows2)
    T2.to_csv(out / "homeostatic_shift.csv", index=False)
    print("\n2. Homeostatic (DAM-score below median) microglia: SEA-AD DAM axis vs pathology:")
    print(T2.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

    # ---------- 3. oligodendrocyte cohesin RNA and cohesin-site chromatin
    cls = pd.read_csv(ROOT / "results/cohesin_sites/peak_cohesin_classes.csv.gz")
    sets = {"robust cohesin, no CTCF motif": np.flatnonzero((cls["robust"] & ~cls["ctcf_motif"]).to_numpy()),
            "robust cohesin + CTCF motif": np.flatnonzero((cls["robust"] & cls["ctcf_motif"]).to_numpy())}
    nonc = np.flatnonzero((cls["set"] == "not cohesin-bound").to_numpy())
    prom = np.flatnonzero((cls["class"] == "promoter").to_numpy())
    O = {}
    for lib, D in L.items():
        if "Oligo" not in D["subs"]:
            continue
        k = D["subs"].index("Oligo")
        dn_ = D["cells"]["donor"].iat[0]
        a = np.asarray(D["atac_pb"][k].todense()).ravel()
        r_ = np.asarray(D["rna_pb"][k].todense()).ravel()
        if dn_ in O:
            O[dn_][0] += a
            O[dn_][1] += r_
        else:
            O[dn_] = [a, r_]
    od = list(O)
    A = np.array([O[x][0] for x in od])
    Rm = np.array([O[x][1] for x in od])
    acpm = A / A.sum(1, keepdims=True) * 1e6
    use = (acpm >= 1).mean(0) >= 0.5
    AL = np.log2(acpm + 1)
    AZ = (AL - AL.mean(0)) / np.where(AL.std(0) > 0, AL.std(0), 1)
    rl = np.log2(Rm / Rm.sum(1, keepdims=True) * 1e6 + 1)
    rz = (rl - rl.mean(0)) / np.where(rl.std(0) > 0, rl.std(0), 1)
    oinfo = pd.DataFrame({"donor": od, "logfrag": np.log10(A.sum(1)), "prom": A[:, prom].sum(1) / A.sum(1),
                          "cohesin_rna": rz[:, gu.reindex(COHESIN).dropna().astype(int).to_numpy()].mean(1)}).join(donors, on="donor")
    oacc = np.log2(acpm.mean(0) + 1)
    ob = np.full(len(oacc), -1)
    ob[use] = pd.qcut(pd.Series(oacc[use]).rank(method="first"), 10, labels=False).to_numpy()
    ostr = np.where(ob >= 0, ob * 2 + (cls["class"].to_numpy() == "promoter"), -1)
    opool = {s: nonc[ostr[nonc] == s] for s in np.unique(ostr[ostr >= 0])}
    rows3 = []
    for expo in ("Braak", "path"):
        m = oinfo[[expo, "age"]].notna().all(1).to_numpy()
        I = oinfo[m].reset_index(drop=True)
        Zr = _covar_matrix(I, ["age", "sex"])
        r, p = assoc(I["cohesin_rna"].to_numpy(float), I[expo].to_numpy(float), Zr, rng)
        rows3.append({"exposure": expo, "measure": "cohesin RNA", "n_donors": int(m.sum()), "r": r, "p_perm": p})
        Za = _covar_matrix(I, ["age", "sex", "logfrag", "prom"])
        for sname, si in sets.items():
            si = si[use[si]]
            bg = np.concatenate([[rng.choice(opool[s]) for s in ostr[si]] for _ in range(3)])
            diff = AZ[m][:, si].mean(1) - AZ[m][:, bg].mean(1)
            r, p = assoc(diff, I[expo].to_numpy(float), Za, rng)
            rows3.append({"exposure": expo, "measure": sname + " (minus matched)", "n_donors": int(m.sum()), "r": r,
                          "p_perm": p})
    T3 = pd.DataFrame(rows3)
    T3.to_csv(out / "oligo_cohesin.csv", index=False)
    print("\n3. Oligodendrocytes: cohesin RNA and cohesin-site accessibility vs pathology:")
    print(T3.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
