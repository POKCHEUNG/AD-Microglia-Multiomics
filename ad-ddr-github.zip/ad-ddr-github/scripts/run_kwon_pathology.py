"""Is DDR program expression higher next to amyloid plaques or in pTau+ spots? (Kwon et al. 2023, Visium-SPG, human ITC)

    python scripts/run_kwon_pathology.py --out results/spatial_kwon

Data: 10 sections from 4 donors (1 control, 3 AD), with Abeta and pTau immunofluorescence
quantified on the same section (Kwon et al. 2023 GEN Biotechnol; exported by
scripts/export_kwon.R). Grey-matter spots of the 7 AD sections.

Contrasts, within each section:
  Abeta_near - spots within 1 spot-step of an Abeta+ spot vs spots >= 4 steps away
  Abeta_spot - Abeta+ spots themselves vs spots >= 4 steps away (tighter, fewer spots)
  pTau       - pTau+ vs pTau- spots (pTau+ covers 40-60% of spots in two donors, so no
               distance contrast; one donor has almost no pTau and is skipped)
DDR genes are detected in a median ~2% of spots, so spot-level scores are mostly zeros.
Instead counts are summed into case / reference pseudobulks within each BayesSpace domain
(laminar position matched), the per-gene log2 fold change is averaged over domains
(weighted by the smaller spot count), and a program effect is the mean log2FC of its genes.
This is the total niche effect: it includes changes in cell composition.

Spot-level SEs are meaningless (spatial autocorrelation; 3 AD donors), so inference is
competitive: the same statistic for 200 random expression-matched gene sets per section;
the pooled effect (mean over sections within donor, then over donors) is compared with
the same pooling of the null. Positive controls: microglial markers and DAM near plaques
(plaque-associated microgliosis).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse as sp
from scipy.spatial import cKDTree

from ad_ddr.signatures import all_programs
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
MICROGLIA = ["P2RY12", "CX3CR1", "CSF1R", "C1QA", "C1QB", "C1QC", "TREM2", "TYROBP", "AIF1", "LAPTM5"]
NEURON = ["SNAP25", "SYT1", "STMN2", "GAP43", "NRGN", "VSNL1", "ENC1", "CALM1"]
NEAR, FAR = 1, 4


def load(d: Path):
    X = sp.csr_matrix(scipy.io.mmread(d / "counts_genes_x_spots.mtx").T)
    genes = pd.read_csv(d / "genes.csv")
    spots = pd.read_csv(d / "spots.csv")
    return X, genes["gene_name"].astype(str).str.upper(), spots


def hex_steps(spots: pd.DataFrame, mask: np.ndarray) -> np.ndarray:
    """Distance (in spot steps) from each spot to the nearest ``mask`` spot, within a section.
    Visium array: neighbours differ by (row +-1, col +-1) or (row 0, col +-2)."""
    xy = np.column_stack([spots["array_col"].to_numpy() / 2, spots["array_row"].to_numpy() * np.sqrt(3) / 2])
    if mask.sum() == 0:
        return np.full(len(spots), np.inf)
    dist, _ = cKDTree(xy[mask]).query(xy)
    return np.round(dist, 6)


def domain_lfc(Xs: sp.csr_matrix, case: np.ndarray, ref: np.ndarray, domain: np.ndarray, min_spots: int):
    """Per-gene log2((CPM_case + 1) / (CPM_ref + 1)) within each domain, averaged with weight
    min(n_case, n_ref). Returns (lfc, total weight, number of domains used)."""
    num, wsum, used = np.zeros(Xs.shape[1]), 0.0, 0
    for dm in np.unique(domain):
        a, b = case & (domain == dm), ref & (domain == dm)
        if a.sum() < min_spots or b.sum() < min_spots:
            continue
        ca, cb = np.asarray(Xs[a].sum(0)).ravel(), np.asarray(Xs[b].sum(0)).ravel()
        lfc = np.log2(ca / ca.sum() * 1e6 + 1) - np.log2(cb / cb.sum() * 1e6 + 1)
        w = min(a.sum(), b.sum())
        num += w * lfc
        wsum += w
        used += 1
    return (num / wsum if wsum else None), wsum, used


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/processed/kwon")
    ap.add_argument("--out", default="results/spatial_kwon")
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--min-cpm", type=float, default=5.0, help="gene CPM in the section grey-matter pseudobulk")
    ap.add_argument("--min-spots", type=int, default=15, help="per group and domain")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    programs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}
    programs |= {"Microglia_markers": MICROGLIA, "Neuron_markers": NEURON}

    X, gene_names, spots = load(ROOT / args.data)
    # grey matter: drop the BayesSpace k=2 domain that is oligodendrocyte-rich (white matter)
    oli = spots.groupby("BayesSpace_harmony_k02")["c2l_oli"].median()
    wm = oli.idxmax()
    print("c2l_oli median by BayesSpace k02 domain:", oli.round(3).to_dict(), "-> white matter =", wm)
    gm = (spots["BayesSpace_harmony_k02"] != wm).to_numpy()
    upper = pd.Series(np.arange(len(gene_names)), index=gene_names)
    upper = upper[~upper.index.duplicated()]

    rows, null_store, gene_rows = [], {}, []
    for sid, s in spots[gm].groupby("sample_id"):
        if s["diagnosis"].iloc[0] != "AD":
            continue
        Xs = X[s.index.to_numpy()]
        tot = np.asarray(Xs.sum(0)).ravel()
        cpm = tot / tot.sum() * 1e6
        expressed = cpm >= args.min_cpm
        pool = np.flatnonzero(expressed)
        bins = np.full(len(cpm), -1)
        bins[pool] = pd.qcut(pd.Series(np.log2(cpm[pool])).rank(method="first"), 10, labels=False).to_numpy()
        by_bin = {b: pool[bins[pool] == b] for b in range(10)}
        domain = s["BayesSpace_harmony_k09"].to_numpy()
        steps = hex_steps(s, (s["path_Abeta"] == "Abeta+").to_numpy())
        ptau = (s["path_pTau"] == "pTau+").to_numpy()
        tests = {"Abeta_near": (steps <= NEAR, steps >= FAR), "Abeta_spot": (steps == 0, steps >= FAR),
                 "pTau": (ptau, ~ptau)}
        for test, (case, ref) in tests.items():
            lfc, w, used = domain_lfc(Xs, case, ref, domain, args.min_spots)
            if lfc is None:
                print(f"  {sid} {test}: skipped ({case.sum()} vs {ref.sum()} spots, no domain with enough of both)")
                continue
            for name, gs in programs.items():
                gi = upper.reindex([g.upper() for g in gs]).dropna().astype(int).to_numpy()
                gi = gi[expressed[gi]]
                if len(gi) < 3:
                    continue
                rand = np.stack([np.array([rng.choice(by_bin[b]) for b in bins[gi]]) for _ in range(args.n_sets)])
                obs, null = lfc[gi].mean(), lfc[rand].mean(1)
                null_store[(sid, test, name)] = null
                rows.append({"sample_id": sid, "subject": s["subject"].iloc[0], "test": test,
                             "n_case": int(case.sum()), "n_ref": int(ref.sum()), "n_domains": used, "program": name,
                             "n_genes": len(gi), "lfc": obs, "null_mean": null.mean(), "null_sd": null.std(),
                             "excess": obs - null.mean()})
                if name in DDR + ["Microglia_markers"]:
                    gene_rows += [{"sample_id": sid, "test": test, "program": name, "gene": gene_names.iloc[i],
                                   "lfc": lfc[i]} for i in gi]
            print(f"  {sid} {test}: {case.sum()} vs {ref.sum()} spots, {used} domains", flush=True)
    sec = pd.DataFrame(rows)
    sec.to_csv(out / "section_effects.csv", index=False)
    pd.DataFrame(gene_rows).to_csv(out / "gene_lfc.csv", index=False)

    # pool: mean over sections within donor, then mean over donors; same pooling for each null draw
    pooled = []
    for (test, prog), d in sec.groupby(["test", "program"]):
        nulls = np.stack([null_store[(r.sample_id, test, prog)] for r in d.itertuples()])
        donors = d["subject"].to_numpy()
        ud = np.unique(donors)
        obs = np.mean([d.loc[donors == u, "lfc"].mean() for u in ud])
        nl = np.mean([nulls[donors == u].mean(0) for u in ud], axis=0)
        ex = obs - nl.mean()
        donor_excess = [d.loc[donors == u, "excess"].mean() for u in ud]
        pooled.append({"test": test, "program": prog, "family": "DDR" if prog in DDR else "control",
                       "n_sections": len(d), "n_donors": len(ud), "n_genes": int(d["n_genes"].median()), "lfc": obs,
                       "null_mean": nl.mean(), "excess": ex, "z_vs_null": ex / nl.std(),
                       "p_set": (np.sum(np.abs(nl - nl.mean()) >= abs(ex)) + 1) / (len(nl) + 1),
                       "donors_same_sign": int(np.sum(np.sign(donor_excess) == np.sign(ex))),
                       "sections_same_sign": int(np.sum(np.sign(d["excess"]) == np.sign(ex)))})
    pooled = pd.DataFrame(pooled)
    pooled["q_set"] = np.nan
    for test, d in pooled[pooled["family"] == "DDR"].groupby("test"):
        pooled.loc[d.index, "q_set"] = bh(d["p_set"].to_numpy())
    pooled = pooled.sort_values(["test", "family", "p_set"])
    pooled.to_csv(out / "pooled_effects.csv", index=False)
    print("\nPooled effects (mean log2FC of program genes; excess = lfc - random-set null mean):")
    print(pooled.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
