"""Does layer-local pathology go with a mismatch between DNA-repair expression and promoter chromatin? (SEA-AD MTG)

    python scripts/run_laminar_mismatch.py --out results/laminar

No public human AD dataset measures chromatin in space, so the cortical layer is used as
the neighbourhood: SEA-AD quantitative neuropathology (QNP) gives AT8 and 6E10 per layer
for 84 MTG donors, and excitatory subclasses live in known layers (L2/3 IT in L2-3, L4 IT
in L4, L5/L6 types in L5-6).

Per (subclass, donor): RNA program score = mean z of log2 CPM of program genes (released
RNA pseudobulks); ATAC program score = mean z of log2 CPM of the same genes' promoter
accessibility (peaks within 1 kb of the TSS; SEA-AD ATAC donor objects, extracted by
scripts/extract_atac_pseudobulk.py). Both are residualised on technical covariates across
donors within subclass (RNA: log #nuclei; ATAC: log #nuclei, log total counts, multiome
fraction) and re-standardised. mismatch = RNA - ATAC (positive: expression high relative
to promoter chromatin).

Tests (non-severe donors with both modalities):
  laminar - stacked layer-resident excitatory subclasses; mismatch ~ own-layer pathology
            (log rate, z within layer) with donor fixed effects, so only within-donor
            differences between layers count. p_perm: own-layer pathology values shuffled
            among layers within donor. p_set: 200 random gene sets matched on RNA
            expression and promoter accessibility.
  donor   - per subclass, mismatch ~ grey-matter pathology + age, sex, PMI (partial r).
Controls: laminar composition (resident subclass share of excitatory nuclei ~ own-layer
NeuN density); microglial DAM RNA and ATAC ~ grey-matter 6E10 (donor test).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ad_ddr import cohort
from ad_ddr.signatures import all_programs
from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.genome import parse_peak_names, peaks_near_genes, read_gtf_genes
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
HOME = {"L2/3 IT": ["Layer2", "Layer3"], "L4 IT": ["Layer4"], "L5 IT": ["Layer5-6"], "L5 ET": ["Layer5-6"],
        "L5/6 NP": ["Layer5-6"], "L6 IT": ["Layer5-6"], "L6 IT Car3": ["Layer5-6"], "L6 CT": ["Layer5-6"],
        "L6b": ["Layer5-6"]}
PATH = {"AT8": "number of AT8 positive cells per area", "6E10": "number of 6e10 positive objects per area",
        "NeuN": "number of NeuN positive cells per area"}
RNA_FILES = ["L23-IT", "L4-IT", "L5-IT", "L5-ET", "L56-NP", "L6-IT", "L6-IT-Car3", "L6-CT", "L6b", "Immune"]
MIN_NUC = 20


def zcols(M: np.ndarray) -> np.ndarray:
    sd = M.std(0)
    return (M - M.mean(0)) / np.where(sd > 0, sd, 1)


def resid_z(y: np.ndarray, Z: np.ndarray) -> np.ndarray:
    r = _resid(y, Z)
    return (r - r.mean()) / r.std() if r.std() > 0 else r * 0


def load_qnp() -> pd.DataFrame:
    q = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    return q.rename(columns={"Donor ID": "donor", "analysis region": "layer"})[["donor", "layer", *PATH.values()]]


def load_atac(d: Path):
    peaks = parse_peak_names((d / "peaks.txt").read_text().split())
    rows, mats = [], []
    for f in sorted(d.glob("*.npz")):
        rows.append(pd.read_csv(f.with_suffix(".csv")))
        mats.append(sp.load_npz(f))
    rows = pd.concat(rows, ignore_index=True)
    M = sp.vstack(mats).tocsr()
    rows["multi"] = rows["method"].eq("10xMulti") * rows["n_nuclei"]
    cat = pd.Categorical(rows["donor"] + "|" + rows["subclass"])
    A = sp.csr_matrix((np.ones(len(rows)), (cat.codes, np.arange(len(rows)))))
    M = sp.csr_matrix(A @ M)
    info = rows.groupby(cat.codes).agg(donor=("donor", "first"), subclass=("subclass", "first"),
                                       n_nuclei=("n_nuclei", "sum"), multi=("multi", "sum")).reset_index(drop=True)
    info["frac_multi"] = info["multi"] / info["n_nuclei"]
    info["total"] = np.asarray(M.sum(1)).ravel()
    return info, M, peaks


def promoter_matrix(peaks: pd.DataFrame, gtf: Path, flank: int = 1000) -> tuple[sp.csr_matrix, pd.Index]:
    genes = read_gtf_genes(str(gtf))
    pairs = peaks_near_genes(peaks, genes, flank)
    g = pd.Index(sorted(pairs["gene"].unique()))
    P = sp.csr_matrix((np.ones(len(pairs)), (peaks.index.get_indexer(pairs["peak"]), g.get_indexer(pairs["gene"]))),
                      shape=(len(peaks), len(g)))
    P.data[:] = 1
    return P, g


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--atac", default="data/processed/atac_pb")
    ap.add_argument("--out", default="results/laminar")
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--n-perm", type=int, default=2000)
    ap.add_argument("--min-donors", type=int, default=15)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    programs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}

    # --- RNA pseudobulks (MTG, group level) and donor covariates
    idx, C, rgenes, meta = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{f}.h5ad" for f in RNA_FILES], regions=["MTG"])
    meta = meta.assign(age=pd.to_numeric(meta["age"], errors="coerce"), pmi=pd.to_numeric(meta["pmi"], errors="coerce"),
                       severe=meta["severe"].astype(str).eq("Y"))
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    rkeep = (idx["level"] == "group").to_numpy()
    idx, C = idx[rkeep].reset_index(drop=True), C[rkeep]

    # --- ATAC pseudobulks -> gene promoter counts
    ainfo, AM, peaks = load_atac(ROOT / args.atac)
    P, agenes = promoter_matrix(peaks, ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz")
    AG = np.asarray((AM @ P).todense())
    print(f"ATAC: {ainfo['donor'].nunique()} donors, {len(agenes)} genes with promoter peaks")

    qnp = load_qnp()
    shared = pd.Index(rgenes.str.upper()).intersection(agenes.str.upper()).drop_duplicates()
    r_ix = pd.Series(np.arange(len(rgenes)), index=rgenes.str.upper()).groupby(level=0).first().reindex(shared).to_numpy()
    a_ix = pd.Series(np.arange(len(agenes)), index=agenes.str.upper()).groupby(level=0).first().reindex(shared).to_numpy()

    rpos = {(g, d): i for i, (g, d) in enumerate(zip(idx["group"], idx["donor"]))}
    apos = {(g, d): i for i, (g, d) in enumerate(zip(ainfo["subclass"], ainfo["donor"]))}
    per_group = {}
    for grp in list(HOME) + ["Microglia-PVM"]:
        donors = [d for d in meta.index
                  if (grp, d) in rpos and (grp, d) in apos and idx.at[rpos[grp, d], "n_nuclei"] >= MIN_NUC
                  and ainfo.at[apos[grp, d], "n_nuclei"] >= MIN_NUC and not meta.loc[d, "severe"] and d in cps.index
                  and pd.notna(meta.loc[d, "age"]) and pd.notna(meta.loc[d, "pmi"])]
        if len(donors) < args.min_donors:
            continue
        ri = [rpos[grp, d] for d in donors]
        ai = [apos[grp, d] for d in donors]
        Rc, Ac, a = C[ri], AG[ai], ainfo.iloc[ai]
        rcpm = Rc[:, r_ix] / Rc.sum(1, keepdims=True) * 1e6
        acpm = Ac[:, a_ix] / a["total"].to_numpy()[:, None] * 1e6
        ok = ((rcpm >= 1).mean(0) >= 0.5) & ((acpm > 0).mean(0) >= 0.5)
        RL, AL = np.log2(rcpm + 1), np.log2(acpm + 1)
        RZ, AZ = zcols(RL), zcols(AL)
        dinfo = pd.DataFrame({"donor": donors, "cps": cps.reindex(donors).to_numpy(),
                              "age": meta.loc[donors, "age"].to_numpy(), "sex": meta.loc[donors, "sex"].astype(str).to_numpy(),
                              "pmi": meta.loc[donors, "pmi"].to_numpy(),
                              "log_nuc_r": np.log10(idx.loc[ri, "n_nuclei"].to_numpy(float)),
                              "log_nuc_a": np.log10(a["n_nuclei"].to_numpy(float)),
                              "log_tot_a": np.log10(a["total"].to_numpy(float)), "frac_multi": a["frac_multi"].to_numpy()})
        # matched random-gene pools: bins of RNA mean x ATAC mean among usable genes
        pool = np.flatnonzero(ok)
        rb = pd.qcut(pd.Series(RL[:, pool].mean(0)).rank(method="first"), 5, labels=False).to_numpy()
        ab = pd.qcut(pd.Series(AL[:, pool].mean(0)).rank(method="first"), 5, labels=False).to_numpy()
        binid = np.full(len(shared), -1)
        binid[pool] = rb * 5 + ab
        by_bin = {b: pool[binid[pool] == b] for b in np.unique(binid[pool])}
        sets = {}
        for name, gs in programs.items():
            gi = shared.get_indexer([g.upper() for g in gs])
            gi = gi[(gi >= 0)]
            gi = gi[ok[gi]]
            if len(gi) < 3:
                continue
            rand = np.stack([np.array([rng.choice(by_bin[b]) for b in binid[gi]]) for _ in range(args.n_sets)])
            sets[name] = (gi, rand)
        Zr = _covar_matrix(dinfo, ["log_nuc_r"])
        Za = _covar_matrix(dinfo, ["log_nuc_a", "log_tot_a", "frac_multi"])
        scores = {}
        for name, (gi, rand) in sets.items():
            allsets = np.vstack([gi[None, :], rand])                     # (1 + n_sets) x k
            rs = RZ[:, allsets].mean(2)                                   # donors x (1 + n_sets)
            as_ = AZ[:, allsets].mean(2)
            rr = np.column_stack([resid_z(rs[:, j], Zr) for j in range(rs.shape[1])])
            aa = np.column_stack([resid_z(as_[:, j], Za) for j in range(as_.shape[1])])
            scores[name] = {"rna": rr, "atac": aa, "mismatch": rr - aa, "n_genes": len(gi)}
        per_group[grp] = (dinfo, scores)
        print(f"  {grp}: {len(donors)} donors, {ok.sum()} usable genes, programs {len(scores)}", flush=True)

    # --- donor-level tests
    gm = qnp[qnp["layer"] == "Grey matter"].set_index("donor")
    rows = []
    for grp, (dinfo, scores) in per_group.items():
        for pname, col in PATH.items():
            if pname == "NeuN":
                continue
            x = np.log10(gm[col].reindex(dinfo["donor"]).to_numpy(float) * 1e6 + 1)
            m = np.isfinite(x)
            d = dinfo[m].reset_index(drop=True)
            Z = _covar_matrix(d, ["age", "sex", "pmi"])
            xr = _resid(x[m], Z)
            perms = np.stack([rng.permutation(xr) for _ in range(args.n_perm)], 1)
            for prog, s in scores.items():
                for kind in ("rna", "atac", "mismatch"):
                    Y = np.column_stack([_resid(s[kind][m, j], Z) for j in range(s[kind].shape[1])])
                    rv = np.array([np.corrcoef(xr, Y[:, j])[0, 1] for j in range(Y.shape[1])])
                    obs, null = rv[0], rv[1:]
                    rp = ((perms - perms.mean(0)).T @ (Y[:, 0] - Y[:, 0].mean())) / (
                        np.linalg.norm(perms - perms.mean(0), axis=0) * np.linalg.norm(Y[:, 0] - Y[:, 0].mean()))
                    rows.append({"group": grp, "pathology": pname, "program": prog, "measure": kind,
                                 "n_donors": int(m.sum()), "n_genes": s["n_genes"], "r": obs, "null_mean": null.mean(),
                                 "excess": obs - null.mean(),
                                 "p_perm": (np.sum(np.abs(rp) >= abs(obs)) + 1) / (args.n_perm + 1),
                                 "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (len(null) + 1)})
    donor_res = pd.DataFrame(rows)
    donor_res["family"] = np.where(donor_res["program"].isin(DDR), "DDR", "control")
    donor_res["q_perm"] = np.nan
    for key, d in donor_res[(donor_res["family"] == "DDR") & (donor_res["measure"] == "mismatch")].groupby("pathology"):
        donor_res.loc[d.index, "q_perm"] = bh(d["p_perm"].to_numpy())
    donor_res.to_csv(out / "donor_level.csv", index=False)

    # --- laminar within-donor test
    lay = qnp[qnp["layer"].str.startswith("Layer")]
    lam_rows = []
    stacked = []
    for grp in HOME:
        if grp not in per_group:
            continue
        dinfo, scores = per_group[grp]
        stacked.append((grp, dinfo, scores))
    for pname, col in PATH.items():
        own = {}
        for grp, dinfo, _ in stacked:
            v = lay[lay["layer"].isin(HOME[grp])].groupby("donor")[col].mean()
            own[grp] = np.log10(v.reindex(dinfo["donor"]).to_numpy(float) * 1e6 + 1)
        # z within layer group across donors (layer-resident subclasses sharing a layer share x)
        progs = DDR + ["DAM"] if pname != "NeuN" else []
        for prog in progs:
            for kind in ("mismatch", "rna", "atac"):
                X, Y, D = [], [], []
                for grp, dinfo, scores in stacked:
                    if prog not in scores:
                        continue
                    x = own[grp]
                    m = np.isfinite(x)
                    X.append((x[m] - np.nanmean(x)) / np.nanstd(x))
                    Y.append(scores[prog][kind][m])
                    D.append(dinfo["donor"].to_numpy()[m])
                if len(X) < 3:
                    continue
                x, Ym, dn = np.concatenate(X), np.vstack(Y), np.concatenate(D)
                lam_rows.append(laminar_fit(prog, kind, pname, x, Ym, dn, rng, args.n_perm))
        if pname == "NeuN":
            # composition control: resident share of excitatory nuclei ~ own-layer NeuN density
            exc = idx[idx["group"].isin(list(HOME))].groupby("donor")["n_nuclei"].sum()
            X, Y, D = [], [], []
            for grp, dinfo, _ in stacked:
                share = idx[idx["group"] == grp].set_index("donor")["n_nuclei"].reindex(dinfo["donor"]) / exc.reindex(dinfo["donor"])
                y = np.log(share.to_numpy(float))
                x = own[grp]
                m = np.isfinite(x) & np.isfinite(y)
                X.append((x[m] - np.nanmean(x)) / np.nanstd(x))
                Y.append(((y[m] - y[m].mean()) / y[m].std())[:, None])
                D.append(dinfo["donor"].to_numpy()[m])
            lam_rows.append(laminar_fit("resident_share", "composition", "NeuN", np.concatenate(X), np.vstack(Y),
                                        np.concatenate(D), rng, args.n_perm))
    lam = pd.DataFrame(lam_rows)
    lam["family"] = np.where(lam["program"].isin(DDR), "DDR", "control")
    lam["q_perm"] = np.nan
    for key, d in lam[(lam["family"] == "DDR") & (lam["measure"] == "mismatch")].groupby("pathology"):
        lam.loc[d.index, "q_perm"] = bh(d["p_perm"].to_numpy())
    lam.to_csv(out / "laminar.csv", index=False)

    cols = ["program", "measure", "pathology", "n_obs", "n_donors", "beta", "null_mean", "p_perm", "p_set", "q_perm"]
    print("\nLaminar (within-donor) mismatch tests:")
    print(lam[lam["measure"] == "mismatch"].sort_values("p_perm")[cols].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\nControls:")
    print(lam[lam["family"] == "control"][cols].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    dm = donor_res[(donor_res["measure"] == "mismatch") & (donor_res["family"] == "DDR")]
    print(f"\nDonor-level mismatch: {len(dm)} tests, p_perm<0.05 {(dm['p_perm'] < .05).mean():.3f}, "
          f"min q {dm['q_perm'].min():.3f}")
    print(dm.sort_values("p_perm").head(8)[["group", "pathology", "program", "n_donors", "r", "excess", "p_perm",
                                              "q_perm", "p_set"]].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print("\nMicroglial DAM vs grey-matter pathology (positive control):")
    print(donor_res[(donor_res["group"] == "Microglia-PVM") & (donor_res["program"] == "DAM")][
        ["pathology", "measure", "n_donors", "r", "excess", "p_perm", "p_set"]].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


def laminar_fit(prog, kind, pname, x, Y, donor, rng, n_perm) -> dict:
    """Donor fixed-effect slope of each column of ``Y`` on ``x``; within-donor permutation of x."""
    codes = pd.factorize(donor)[0]
    def demean(v):
        mu = np.bincount(codes, weights=v) / np.bincount(codes)
        return v - mu[codes]
    keep = np.bincount(codes)[codes] >= 2                       # donors with >= 2 layer groups
    x, Y, codes = x[keep], Y[keep], pd.factorize(donor[keep])[0]
    xd = demean(x)
    Yd = np.column_stack([demean(Y[:, j]) for j in range(Y.shape[1])])
    b = (xd @ Yd) / (xd @ xd)
    groups = [np.flatnonzero(codes == c) for c in np.unique(codes)]
    bp = np.empty(n_perm)
    for i in range(n_perm):
        xp = x.copy()
        for g in groups:
            xp[g] = rng.permutation(x[g])
        xpd = demean(xp)
        bp[i] = (xpd @ Yd[:, 0]) / (xpd @ xpd)
    null = b[1:]
    return {"program": prog, "measure": kind, "pathology": pname, "n_obs": len(x), "n_donors": len(groups),
            "within_donor_sd_x": xd.std(), "beta": b[0], "perm_sd": bp.std(),
            "null_mean": null.mean() if len(null) else np.nan, "null_sd": null.std() if len(null) else np.nan,
            "p_perm": (np.sum(np.abs(bp) >= abs(b[0])) + 1) / (n_perm + 1),
            "p_set": ((np.sum(np.abs(null - null.mean()) >= abs(b[0] - null.mean())) + 1) / (len(null) + 1))
            if len(null) else np.nan}


if __name__ == "__main__":
    main()
