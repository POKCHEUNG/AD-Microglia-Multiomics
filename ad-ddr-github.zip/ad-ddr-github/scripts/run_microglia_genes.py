"""Plan A screen: are microglial PTPRG and S100A4 robust markers of AD progression?

    python scripts/run_microglia_genes.py --out results/microglia_genes

Candidates came from the exploratory L-R scan (README result 9), so MTG is the discovery
set. Checks, all on donor pseudobulks (non-severely-affected donors, age/sex/PMI/log #nuclei):
1. gene vs CPS in MTG microglia, against every expressed microglial gene (genome-wide rank)
   and against 1,000 expression-matched random genes
2. the same in the other 8 regions (descriptive replication; regions share donors)
3. which microglial supertypes carry the change (pseudobulk per supertype; composition)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402

CANDIDATES = ["PTPRG", "S100A4"]
REFERENCE = ["CD9", "GPNMB", "APOE", "SPP1", "TREM2", "P2RY12", "CX3CR1"]   # DAM / homeostatic context
COV = ["age", "sex", "pmi", "log_nuclei"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/microglia_genes")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
    a = ad.read_h5ad(ROOT / "data/raw/pseudobulk/Immune.h5ad")
    a = a[a.obs["Supertype"].astype(str).str.startswith("Micro-PVM")]
    o = a.obs
    genes = pd.Index(a.var_names)
    X = sp.csr_matrix(a.X)

    def donor_matrix(mask, by="Donor ID"):
        sub = o[mask]
        cat = pd.Categorical(sub[by].astype(str))
        A = sp.csr_matrix((np.ones(mask.sum()), (cat.codes, np.arange(mask.sum()))))
        M = np.asarray((A @ X[np.flatnonzero(mask)]).todense())
        n = sub.groupby(cat, observed=False)["Number of nuclei"].sum().to_numpy()
        return pd.Index(cat.categories), M, n

    rows, region_rows = [], []
    for region in sorted(o["Brain Region"].unique()):
        m = (o["Brain Region"] == region).to_numpy()
        donors_idx, M, n = donor_matrix(m)
        info = (s[(s.region == region) & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]])
        info[["age", "pmi"]] = info[["age", "pmi"]].apply(pd.to_numeric, errors="coerce")
        keep = donors_idx.isin(info.dropna().index) & (n >= 20)
        if keep.sum() < 15:
            continue
        d = info.loc[donors_idx[keep]].assign(log_nuclei=np.log10(n[keep]))
        cpm = M[keep] / M[keep].sum(1, keepdims=True) * 1e6
        expressed = (cpm >= 1).mean(0) >= 0.5
        L = np.log2(cpm[:, expressed] + 1)
        g = genes[expressed]
        Z = pd.get_dummies(d[COV], drop_first=True, dtype=float).to_numpy()
        r, p = partial_r(L, d.cps.to_numpy(float), Z)
        rs = pd.Series(r, index=g)
        rs = rs[~rs.index.duplicated()]
        mean = pd.Series(L.mean(0), index=g)
        mean = mean[~mean.index.duplicated()]
        bins = pd.qcut(mean.rank(method="first"), 10, labels=False)
        for gene in CANDIDATES + REFERENCE:
            if gene not in rs.index:
                continue
            pool = rs.index[(bins == bins[gene]).to_numpy() & (rs.index != gene)]
            null = rs.loc[rng.choice(pool, 1000)].to_numpy()
            row = {"region": region, "gene": gene, "r": rs[gene], "n_donors": int(keep.sum()),
                   "genome_rank_pct": float((rs >= rs[gene]).mean() * 100),
                   "p_vs_random_genes": (np.sum(np.abs(null) >= abs(rs[gene])) + 1) / 1001,
                   "null_sd": null.std(), "candidate": gene in CANDIDATES}
            (rows if region == "MTG" else region_rows).append(row)
        if region == "MTG":
            pd.DataFrame({"gene": rs.index, "r": rs.values}).sort_values("r", ascending=False).to_csv(
                out / "MTG_microglia_gene_vs_cps.csv", index=False)
            print(f"MTG: {keep.sum()} donors, {len(rs)} expressed microglial genes; genome-wide null sd of r = {rs.std():.3f}")
            print("top 15 genes by r:", ", ".join(f"{k} {v:.2f}" for k, v in rs.sort_values(ascending=False).head(15).items()))
    mtg = pd.DataFrame(rows)
    reg = pd.DataFrame(region_rows)
    print("\n1. MTG (discovery)")
    print(mtg.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print("\n2. other regions (r with local CPS)")
    print(reg.pivot(index="gene", columns="region", values="r").loc[[g for g in CANDIDATES + REFERENCE if g in set(reg.gene)]]
          .round(2).to_string())
    print("   n donors:", reg.groupby("region").n_donors.first().to_dict())
    pd.concat([mtg, reg]).to_csv(out / "candidates_by_region.csv", index=False)

    # 3. supertypes in MTG
    m = (o["Brain Region"] == "MTG").to_numpy()
    sub = o[m]
    info = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps"]]
    srows = []
    for st in sorted(sub.Supertype.astype(str).unique()):
        mm = m & (o.Supertype.astype(str) == st).to_numpy()
        donors_idx, M, n = donor_matrix(mm)
        keep = donors_idx.isin(info.index) & (n >= 10)
        if keep.sum() < 15:
            continue
        cpm = M[keep] / np.maximum(M[keep].sum(1, keepdims=True), 1) * 1e6
        cps = info.loc[donors_idx[keep], "cps"].to_numpy()
        for gene in CANDIDATES:
            gi = np.flatnonzero(genes == gene)[0]
            e = np.log2(cpm[:, gi] + 1)
            srows.append({"supertype": st, "gene": gene, "n_donors": int(keep.sum()), "median_nuclei": float(np.median(n[keep])),
                          "mean_log2cpm": e.mean(), "r_cps": np.corrcoef(e, cps)[0, 1]})
    st = pd.DataFrame(srows)
    st.to_csv(out / "supertypes_MTG.csv", index=False)
    print("\n3. MTG microglial supertypes (unadjusted r with CPS; expression level)")
    print(st.pivot(index="supertype", columns="gene", values=["mean_log2cpm", "r_cps"]).round(2).to_string())
    print(st.groupby("supertype")[["n_donors", "median_nuclei"]].first().to_string())


if __name__ == "__main__":
    main()
