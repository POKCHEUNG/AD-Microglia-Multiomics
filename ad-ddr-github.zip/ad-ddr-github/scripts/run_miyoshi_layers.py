"""Independent cohort: do DDR programs change with AD stage within cortical layers? (Miyoshi et al. 2024, Visium, human PFC)

    python scripts/run_miyoshi_layers.py --out results/spatial_miyoshi

The GEO object has no per-spot amyloid, so this is a layer-resolved replication of the
SEA-AD donor-level screen, not a plaque-proximity test. Spots are summed per (sample,
layer annotation) in scripts/export_miyoshi_pseudobulk.R, then per (donor, layer) here:
one control donor contributes 8 sections, so samples are not donors.

Primary: stage = 0 control, 1 early AD, 2 late AD (24 donors), adjusted for sex and log
mean UMI per spot; AD in Down syndrome (younger, distinct) is tested separately against
controls. Same statistics as scripts/run_celltype_screen.py: p_perm (permute stage) and
p_set (200 random expression-matched gene sets). DAM is the positive control.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

import run_celltype_screen as screen
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
STAGE = {"Control": 0, "earlyAD": 1, "AD": 2}
GREY = ["L1", "L2/3", "L3/4", "L3/4/5", "L5/6", "L6b"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/processed/miyoshi")
    ap.add_argument("--out", default="results/spatial_miyoshi")
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--n-perm", type=int, default=5000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    programs = {k: v for k, v in screen.all_programs().items() if k in screen.DDR + ["DAM"]}
    screen.COV = ["sex", "log_nuclei"]          # log_nuclei here = log mean UMI per spot

    P = pd.read_csv(ROOT / args.data / "pseudobulk_genes_x_sample_layer.csv.gz", index_col=0)
    meta = pd.read_csv(ROOT / args.data / "pseudobulk_meta.csv").set_index("key").loc[P.columns]
    meta["donor"] = meta["Case.Year"].astype(str) + "-" + meta["Case.Num"].astype(str)
    print("sections per donor:", meta.drop_duplicates("Sample").groupby("donor").size().value_counts().to_dict())
    print("donors per diagnosis:", meta.drop_duplicates("donor").groupby("Diagnosis").size().to_dict())
    genes = P.index

    rows = []
    for test, groups in (("stage", ["Control", "earlyAD", "AD"]), ("DSAD_vs_control", ["Control", "AD_DS"])):
        for layer in GREY:
            m = meta[(meta["layer"] == layer) & meta["Diagnosis"].isin(groups)]
            dkey = m["donor"].to_numpy()
            ud = pd.unique(dkey)
            C = np.column_stack([P[m.index[dkey == u]].sum(1).to_numpy() for u in ud]).T.astype(float)
            info = m.groupby("donor").agg(dx=("Diagnosis", "first"), sex=("Sex", "first"), age=("Age", "first"),
                                          n_spots=("Freq", "sum"),
                                          umi=("nCount_Spatial", "mean")).loc[ud].reset_index()
            info["cps"] = info["dx"].map(STAGE) if test == "stage" else (info["dx"] == "AD_DS").astype(float)
            info["log_nuclei"] = np.log10(info["umi"])
            keep = (info["n_spots"] >= 20).to_numpy()
            if keep.sum() < 10:
                continue
            for r in screen.screen_group(C[keep], info[keep].reset_index(drop=True), genes, programs, rng,
                                         args.n_sets, args.n_perm):
                rows.append({"test": test, "layer": layer, "n_donors": int(keep.sum()), **r})
        print(f"  {test} done", flush=True)
    res = pd.DataFrame(rows)
    res["family"] = np.where(res["program"].isin(screen.DDR), "DDR", "control")
    for col in ("p_perm", "p_set"):
        res[f"q_{col[2:]}"] = np.nan
        for t, d in res[res["family"] == "DDR"].groupby("test"):
            res.loc[d.index, f"q_{col[2:]}"] = bh(d[col].to_numpy())
    res = res.sort_values(["test", "family", "p_perm"])
    res.to_csv(out / "layer_effects.csv", index=False)
    cols = ["test", "layer", "program", "n_donors", "r", "null_mean", "r_excess", "p_perm", "q_perm", "p_set", "q_set"]
    for t, d in res.groupby("test"):
        dd = d[d["family"] == "DDR"]
        print(f"\n[{t}] {len(dd)} DDR tests: p_perm<0.05 {(dd['p_perm'] < .05).mean():.3f}, "
              f"p_set<0.05 {(dd['p_set'] < .05).mean():.3f}, min q_perm {dd['q_perm'].min():.3f}")
        print(dd[cols].head(8).to_string(index=False, float_format=lambda v: f"{v:.3g}"))
        print("positive control (DAM):")
        print(d[d["program"] == "DAM"][cols].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
