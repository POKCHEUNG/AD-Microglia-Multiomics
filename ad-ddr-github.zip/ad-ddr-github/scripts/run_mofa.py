"""Multicellular factor analysis (MOFA+) of donor pseudobulks, SEA-AD MTG.

    python scripts/run_mofa.py --out results/mofa

Design (fixed before fitting; see README result 18):
* views: excitatory, inhibitory neurons; microglia; astrocytes; oligodendrocytes
* 73 non-severely-affected donors present in every view (>= 20 nuclei)
* per view: genes with CPM >= 1 in >= 50% of donors; log2 CPM; age, sex, PMI and
  log(#nuclei) regressed out; top 1,000 genes by residual variance; z-scored
* MOFA+ with 10 factors; CPS is NOT in the model
Tests:
1. factor ~ CPS: Pearson r, permutation p (CPS shuffled across donors), BH over factors
2. multicellularity: per factor, number of views with >= 10% variance explained; null =
   donors permuted independently within each view (breaks cross-view coupling), refit x N
3. for CPS factors: gene-factor correlations for all expressed genes in each view;
   DDR programs vs expression-matched random gene sets (competitive)
4. microglial PTPRG: which factor carries it
5. stability: donor bootstrap refits, factor matched by |r| of donor scores on overlap
"""

from __future__ import annotations

import argparse
import contextlib
import io as _io
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ad_ddr import cohort
from ad_ddr.signatures import NEURONAL_REPAIR, all_programs
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
VIEWS = {"Exc": ("class", cohort.EXC), "Inh": ("class", cohort.INH), "Micro": ("group", "Microglia-PVM"),
         "Astro": ("group", "Astrocyte"), "Oligo": ("group", "Oligodendrocyte")}
COV = ["age", "sex", "pmi"]
K = 10


def residual_views(idx, C, genes, donors):
    """Per view: (z-scored top-variance residual matrix, full residual matrix of expressed genes, mean expr)."""
    sel, full, means = {}, {}, {}
    for v, (level, grp) in VIEWS.items():
        m = ((idx.level == level) & (idx.group == grp) & (idx.n_nuclei >= 20)).to_numpy()
        d = idx[m].set_index("donor")
        rows = d.index.get_indexer(donors.index)
        M = C[np.flatnonzero(m)[rows]]
        cpm = M / M.sum(1, keepdims=True) * 1e6
        keep = (cpm >= 1).mean(0) >= 0.5
        L = np.log2(cpm[:, keep] + 1)
        cov = pd.get_dummies(donors[COV], drop_first=True, dtype=float).assign(
            log_nuclei=np.log10(d.loc[donors.index, "n_nuclei"].to_numpy()))
        Z1 = np.column_stack([np.ones(len(donors)), cov.to_numpy(float)])
        R = L - Z1 @ np.linalg.lstsq(Z1, L, rcond=None)[0]
        g = genes[keep]
        R = pd.DataFrame(R, index=donors.index, columns=g).T.groupby(level=0).first().T
        full[v] = (R - R.mean()) / R.std().replace(0, 1)
        means[v] = pd.Series(L.mean(0), index=g).groupby(level=0).first()
        top = R.var().sort_values(ascending=False).index[:1000]
        sel[v] = full[v][top]
    return sel, full, means


def fit_mofa(views: dict[str, pd.DataFrame], k: int = K, seed: int = 0):
    from mofapy2.run.entry_point import entry_point

    names = list(views)
    with contextlib.redirect_stdout(_io.StringIO()):
        ent = entry_point()
        ent.set_data_options(scale_views=False)
        ent.set_data_matrix([[views[v].to_numpy(float)] for v in names], likelihoods=["gaussian"] * len(names),
                            views_names=names, samples_names=[list(views[names[0]].index)],
                            features_names=[[f"{v}:{g}" for g in views[v].columns] for v in names])  # unique across views
        ent.set_model_options(factors=k, spikeslab_weights=True, ard_weights=True)
        ent.set_train_options(iter=1000, convergence_mode="fast", seed=seed, verbose=False, quiet=True)
        ent.build()
        ent.run()
    Z = np.asarray(ent.model.nodes["Z"].getExpectation())
    W = [np.asarray(w) for w in ent.model.nodes["W"].getExpectation()]
    r2 = np.zeros((len(names), Z.shape[1]))
    for i, v in enumerate(names):
        Y = views[v].to_numpy(float)
        ss = (Y ** 2).sum()
        for f in range(Z.shape[1]):
            r2[i, f] = 1 - ((Y - np.outer(Z[:, f], W[i][:, f])) ** 2).sum() / ss
    return Z, W, pd.DataFrame(r2, index=names)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/mofa")
    ap.add_argument("--n-null", type=int, default=20)
    ap.add_argument("--n-boot", type=int, default=20)
    ap.add_argument("--n-random", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
    donors = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]]
    donors[["age", "pmi"]] = donors[["age", "pmi"]].apply(pd.to_numeric, errors="coerce")
    donors = donors.dropna()
    paths = sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad"))
    idx, C, genes, _ = cohort.aggregate(paths, regions=["MTG"])
    for level, grp in VIEWS.values():
        have = idx[(idx.level == level) & (idx.group == grp) & (idx.n_nuclei >= 20)].donor
        donors = donors[donors.index.isin(have)]
    print(f"donors in all views: {len(donors)}", flush=True)
    sel, full, means = residual_views(idx, C, genes, donors)

    # ---- fit + 1. CPS association ----------------------------------------------
    Z, W, r2 = fit_mofa(sel, seed=args.seed)
    k = Z.shape[1]
    cps = donors.cps.to_numpy(float)
    r_cps = np.array([np.corrcoef(Z[:, f], cps)[0, 1] for f in range(k)])
    perm = np.array([[np.corrcoef(Z[:, f], rng.permutation(cps))[0, 1] for f in range(k)] for _ in range(10_000)])
    p_cps = (np.sum(np.abs(perm) >= np.abs(r_cps), axis=0) + 1) / 10_001
    fac = pd.DataFrame({"factor": [f"F{f + 1}" for f in range(k)], "r_cps": r_cps, "p_perm": p_cps, "q": bh(p_cps),
                        "total_r2": r2.sum(0).to_numpy(), "views_ge10pct": (r2 >= 0.10).sum(0).to_numpy()})
    for v in r2.index:
        fac[f"r2_{v}"] = r2.loc[v].to_numpy()
    pd.DataFrame(Z, index=donors.index, columns=fac.factor).to_csv(out / "factor_scores.csv")

    # ---- 2. multicellularity null -------------------------------------------------
    null_multi, null_share = [], []
    for i in range(args.n_null):
        pv = {v: df.iloc[rng.permutation(len(df))].set_axis(df.index) for v, df in sel.items()}
        _, _, r2n = fit_mofa(pv, seed=args.seed + 100 + i)
        null_multi.append(int(((r2n >= 0.10).sum(0) >= 2).sum()))
        null_share.append(float(np.sort(r2n.to_numpy(), axis=0)[-2].max()))     # best 2nd-largest view r2
        print(f"  null fit {i + 1}/{args.n_null}", flush=True)
    obs_multi = int((fac.views_ge10pct >= 2).sum())
    obs_share = float(np.sort(r2.to_numpy(), axis=0)[-2].max())
    print(f"\n2. multicellular factors (>=10% R2 in >=2 views): observed {obs_multi}; within-view-permuted null "
          f"mean {np.mean(null_multi):.1f} (max {max(null_multi)}); best second-view R2 {obs_share:.3f} vs null max "
          f"{max(null_share):.3f}")

    # ---- 5. bootstrap stability -----------------------------------------------------
    stab = np.zeros((args.n_boot, k))
    for b in range(args.n_boot):
        bi = rng.choice(len(donors), len(donors), replace=True)
        uniq = np.unique(bi)
        bv = {v: df.iloc[uniq] for v, df in sel.items()}
        Zb, _, _ = fit_mofa(bv, seed=args.seed + 1000 + b)
        cor = np.abs(np.corrcoef(Z[uniq].T, Zb.T)[:k, k:])
        stab[b] = cor.max(1)
        print(f"  bootstrap {b + 1}/{args.n_boot}", flush=True)
    fac["bootstrap_median_match_r"] = np.median(stab, 0)
    fac.to_csv(out / "factors.csv", index=False)
    print("\n1. factors vs CPS (+ variance explained per view, bootstrap stability)")
    print(fac.to_string(index=False, float_format=lambda x: f"{x:.3f}"))

    # ---- 3. DDR enrichment for CPS factors; 4. PTPRG -------------------------------
    progs = {p: g for p, g in all_programs().items() if p in NEURONAL_REPAIR + ["p53_targets", "DAM", "cGAS_STING_IFN"]}
    targets = fac[fac.q < 0.1].factor.tolist() or [fac.loc[fac.p_perm.idxmin(), "factor"]]
    rows = []
    for fname in targets:
        f = int(fname[1:]) - 1
        z = (Z[:, f] - Z[:, f].mean()) / Z[:, f].std()
        for v, R in full.items():
            gc = pd.Series(R.to_numpy().T @ z / len(z), index=R.columns)       # gene-factor correlation
            bins = pd.qcut(means[v].reindex(gc.index).rank(method="first"), 10, labels=False)
            for pname, gs in progs.items():
                gi = [g for g in gs if g in gc.index]
                if len(gi) < 3:
                    continue
                obs = gc[gi].mean()
                null = np.array([gc[[rng.choice(gc.index[(bins == bins[g]).to_numpy()]) for g in gi]].mean()
                                 for _ in range(args.n_random)])
                rows.append({"factor": fname, "view": v, "program": pname, "n_genes": len(gi), "mean_gene_r": obs,
                             "null_mean": null.mean(), "p_vs_random": (np.sum(np.abs(null - null.mean()) >=
                                                                              abs(obs - null.mean())) + 1) / (len(null) + 1)})
        if "PTPRG" in full["Micro"].columns:
            zz = full["Micro"]["PTPRG"].to_numpy()
            print(f"   microglial PTPRG vs {fname}: r = {np.corrcoef(zz, Z[:, f])[0, 1]:+.3f}")
    enr = pd.DataFrame(rows)
    enr["q_vs_random"] = bh(enr.p_vs_random.to_numpy())
    enr.to_csv(out / "program_enrichment.csv", index=False)
    print(f"\n3. program enrichment on factors {targets} (gene-factor r, vs random genes):")
    print(enr.sort_values("p_vs_random").head(12).to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    if "PTPRG" in full["Micro"].columns:
        zz = full["Micro"]["PTPRG"].to_numpy()
        rp = pd.Series([np.corrcoef(zz, Z[:, f])[0, 1] for f in range(k)], index=fac.factor)
        print("\n4. microglial PTPRG vs every factor:", ", ".join(f"{i} {v:+.2f}" for i, v in rp.items()))

    # ---- figure ----------------------------------------------------------------
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8), gridspec_kw={"width_ratios": [1.3, 1]})
    im = ax[0].imshow(r2.to_numpy(), cmap="Blues", aspect="auto", vmin=0)
    ax[0].set_yticks(range(len(r2)), r2.index)
    ax[0].set_xticks(range(k), [f"F{f + 1}\n{'*' if q < 0.1 else ''}" for f, q in enumerate(fac.q)], fontsize=8)
    ax[0].set_title("Variance explained per view (* q<0.1 with CPS)", fontsize=9)
    fig.colorbar(im, ax=ax[0], shrink=0.7, label="R2")
    ax[1].bar(range(k), fac.r_cps, color=["#c0392b" if q < 0.1 else "0.6" for q in fac.q])
    ax[1].axhline(0, color="0.5", lw=0.8)
    ax[1].set_xticks(range(k), fac.factor, fontsize=8)
    ax[1].set_ylabel("r with CPS")
    ax[1].set_title("Factor scores vs CPS (73 donors)", fontsize=9)
    fig.tight_layout()
    fig.savefig(out / "mofa.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
