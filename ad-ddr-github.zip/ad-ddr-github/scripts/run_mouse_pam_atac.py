"""Mouse cross-check: is repair-locus chromatin different in plaque-associated microglia? (GSE296025, 5xFAD)

    python scripts/run_mouse_pam_atac.py --out results/mouse_pam

Ardura-Fabregat et al. 2025 Nat Neurosci: bulk ATAC of FACS-sorted microglia from 5xFAD
mice, CD11c+ (plaque-associated, "PAM") vs CD11c- (non-plaque-associated) plus wild-type
microglia, n = 3 each. GEO holds MACS2 narrowPeak files only, so accessibility is the
peak fold enrichment (column 7) of the strongest peak within 1 kb of each TSS (0 when no
peak), rank-normalised within sample because peak numbers differ 3-fold between samples.
With --window > 1000 the gene score is the summed fold enrichment of all peaks within that
distance of the TSS (regulatory domain), a sensitivity analysis for distal changes.

Per program (human symbols capitalised to mouse): mean over promoter genes of
(mean PAM - mean comparison group), compared with 1,000 random gene sets matched on
average promoter signal across all samples. DAM genes (minus Itgax, the sorting marker)
are the positive control. Human-to-mouse symbol conversion is naive capitalisation.
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import numpy as np
import pandas as pd

from ad_ddr.signatures import all_programs
from ddrmulti.genome import peaks_near_genes, read_gtf_genes
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
GROUP = {"WT": "WT", "nonPAM": "nonPAM", "PAM": "PAM"}


def read_peaks(path: Path) -> pd.DataFrame:
    df = pd.read_csv(gzip.open(path, "rt"), sep="\t", header=None, usecols=[0, 1, 2, 6], names=["chrom", "start", "end", "fe"])
    df.index = df["chrom"] + ":" + df["start"].astype(str) + "-" + df["end"].astype(str)
    return df[~df.index.duplicated()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/raw/gse296025")
    ap.add_argument("--out", default="results/mouse_pam")
    ap.add_argument("--n-sets", type=int, default=1000)
    ap.add_argument("--window", type=int, default=1000,
                    help="bp around the TSS; 1000 = promoter (max peak), larger = regulatory domain (summed peaks)")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.vM25.basic.annotation.gtf.gz"))
    genes = genes[genes["chrom"].str.match(r"^chr[0-9XY]+$")]
    cols, info = {}, []
    for f in sorted((ROOT / args.data).glob("*narrowPeaks_.bed.gz")):
        name = f.name.split("MACS2callpeakon")[1].split("_")[0]          # WTrep1, nonPAMrep2, PAMrep3
        grp, rep = name.split("rep")
        pk = read_peaks(f)
        pairs = peaks_near_genes(pk, genes, args.window)
        pairs["fe"] = pk.loc[pairs["peak"], "fe"].to_numpy()
        agg = pairs.groupby("gene")["fe"]
        cols[name] = (agg.max() if args.window <= 1000 else agg.sum()).reindex(genes.index).fillna(0.0)
        info.append({"sample": name, "group": GROUP[grp], "rep": int(rep), "n_peaks": len(pk),
                     "promoters_with_peak": int((cols[name] > 0).sum())})
    S = pd.DataFrame(cols)
    info = pd.DataFrame(info).set_index("sample").loc[S.columns]
    print(info.to_string())
    S = S[(S > 0).any(axis=1)]
    R = S.rank(pct=True)                                               # within-sample rank normalisation
    R[S == 0] = 0.0

    base = R.mean(1).to_numpy()
    pos = base > 0
    bins = np.full(len(base), -1)
    bins[pos] = pd.qcut(pd.Series(base[pos]).rank(method="first"), 20, labels=False).to_numpy()
    by_bin = {b: np.flatnonzero(bins == b) for b in range(20)}
    gix = pd.Series(np.arange(len(R)), index=R.index)

    programs = {k: v for k, v in all_programs().items() if k in DDR + ["DAM"]}
    programs = {k: [g.capitalize() for g in v] for k, v in programs.items()}
    programs["DAM"] = [g for g in programs["DAM"] if g != "Itgax"]

    rows, gene_rows = [], []
    contrasts = [("PAM", "nonPAM"), ("PAM", "WT"), ("nonPAM", "WT")]
    for case, ref in contrasts:
        a = R.loc[:, info["group"] == case].to_numpy()
        b = R.loc[:, info["group"] == ref].to_numpy()
        diff = a.mean(1) - b.mean(1)
        for name, gs in programs.items():
            gi = gix.reindex(gs).dropna().astype(int).to_numpy()
            gi = gi[bins[gi] >= 0]                                      # promoter peak in >= 1 sample
            if len(gi) < 3:
                continue
            rand = np.stack([np.array([rng.choice(by_bin[bb]) for bb in bins[gi]]) for _ in range(args.n_sets)])
            obs, null = diff[gi].mean(), diff[rand].mean(1)
            # replicate consistency: per-replicate program mean difference (paired by replicate number)
            reps = sorted(set(info.loc[info["group"] == case, "rep"]) & set(info.loc[info["group"] == ref, "rep"]))
            rep_d = [R.loc[gs_, f"{case}rep{r}"].mean() - R.loc[gs_, f"{ref}rep{r}"].mean()
                     for r in reps for gs_ in [R.index[gi]]]
            rows.append({"contrast": f"{case}_vs_{ref}", "program": name, "family": "DDR" if name in DDR else "control",
                         "n_genes": len(gi), "delta_rank": obs, "null_mean": null.mean(), "null_sd": null.std(),
                         "z_vs_null": (obs - null.mean()) / null.std(),
                         "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (args.n_sets + 1),
                         "reps_same_sign": int(np.sum(np.sign(rep_d) == np.sign(obs - null.mean()))), "n_reps": len(reps)})
            if case == "PAM" and ref == "nonPAM":
                gene_rows += [{"program": name, "gene": R.index[i], "delta_rank": diff[i], "mean_rank": base[i]} for i in gi]
    res = pd.DataFrame(rows)
    res["q_set"] = np.nan
    for c, d in res[res["family"] == "DDR"].groupby("contrast"):
        res.loc[d.index, "q_set"] = bh(d["p_set"].to_numpy())
    res = res.sort_values(["contrast", "family", "p_set"])
    res.to_csv(out / "program_effects.csv", index=False)
    pd.DataFrame(gene_rows).sort_values("delta_rank").to_csv(out / "genes_PAM_vs_nonPAM.csv", index=False)
    info.to_csv(out / "samples.csv")
    print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    g = pd.DataFrame(gene_rows)
    for prog in ("Checkpoint", "DAM"):
        print(f"\n{prog} genes, PAM - nonPAM promoter rank:")
        print(g[g["program"] == prog].sort_values("delta_rank").to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
