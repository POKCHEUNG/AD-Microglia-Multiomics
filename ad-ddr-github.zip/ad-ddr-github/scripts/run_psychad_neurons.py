"""Main hypothesis at scale: neuronal DDR programs in PsychAD MSSM (open, CELLxGENE; 1,042 donors).

    python scripts/run_psychad_neurons.py --h5ad data/raw/psychad/MSSM_cohort.h5ad --out results/psychad_neurons

Fixed before looking at DDR results (README result 21):
* cells: excitatory (EN) and inhibitory (IN) neuron classes; donor pseudobulks of raw counts,
  donors with >= 50 nuclei per class
* contrast: AD == 1 vs Control == 1, other neurological diagnoses excluded (as result 20);
  if the obs carry Braak / CERAD, those are a secondary exposure
* covariates: age, sex, log #nuclei, mitochondrial fraction
* 10 pre-specified tests: NHEJ, BER, NER, Checkpoint, p53 targets x EN, IN; BH within family
* primary inference: competitive, vs 500 random gene sets matched on expression decile AND
  gene-length decile; also the self-contained permutation p; sensitivity: + neuronal PC1
* positive controls in the same file: microglial DAM program (AD > control); Sst share of
  inhibitory neurons (AD < control)
* report 95% CIs and the minimal |r| detectable with 80% power
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats as sst

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_ccc import partial_r  # noqa: E402

from ad_ddr.signatures import DAM, NEURONAL_REPAIR, all_programs
from ddrmulti.stats import bh

OTHER_DX = ["PD", "DLBD", "FTD", "ALS", "Tauopathy", "MS", "Vascular", "SCZ", "MDD", "PTSD", "ADHD", "BD_ALL", "TD_ALL"]


def pseudobulk(a, keep_mask: np.ndarray, groups: np.ndarray, chunk: int = 50_000):
    """Sum raw counts over (group) labels for rows in keep_mask, reading the backed file in chunks."""
    rows = np.flatnonzero(keep_mask)
    cats = pd.Index(sorted(set(groups[rows])))
    code = pd.Series(np.arange(len(cats)), index=cats)
    raw = a.raw if a.raw is not None else a
    M = np.zeros((len(cats), raw.shape[1]))
    for i in range(0, len(rows), chunk):
        r = rows[i:i + chunk]
        X = sp.csr_matrix(raw.X[r])
        c = code[groups[r]].to_numpy()
        A = sp.csr_matrix((np.ones(len(r)), (c, np.arange(len(r)))), shape=(len(cats), len(r)))
        M += np.asarray((A @ X).todense())
        if (i // chunk) % 10 == 0:
            print(f"    {i + len(r):,}/{len(rows):,} nuclei", flush=True)
    return cats, M


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--h5ad", default="data/raw/psychad/MSSM_cohort.h5ad")
    ap.add_argument("--out", default="results/psychad_neurons")
    ap.add_argument("--inspect", action="store_true", help="print obs structure and exit")
    ap.add_argument("--n-random", type=int, default=500)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(0)

    a = ad.read_h5ad(ROOT / args.h5ad, backed="r")
    o = a.obs
    print(a)
    for c in ("class", "subclass", "Source", "AD", "Control"):
        if c in o:
            print(f"{c}: {o[c].astype(str).value_counts().head(30).to_dict()}")
    extra = [c for c in o.columns if any(k in c.lower() for k in ("braak", "cerad", "plaque", "tangle", "cdr", "mmse"))]
    print("pathology-like obs columns:", extra)
    if args.inspect:
        return

    raw_var = a.raw.var if a.raw is not None else a.var
    sym = pd.Index(raw_var["feature_name"].astype(str))
    glen_all = np.log10(np.maximum(raw_var["feature_length"].to_numpy(float), 1))
    donor = o["donor_id"].astype(str).to_numpy()
    cls = o["class"].astype(str).to_numpy()
    sub = o["subclass"].astype(str).to_numpy()
    cls = np.where(sub == "Micro", "MG", cls)          # MSSM: microglia are class "Immune", subclass "Micro"

    # donor table
    d = o.drop_duplicates("donor_id").set_index("donor_id")
    if "AD_status" in d:   # MSSM / per-cohort schema: Yes/No status columns, controls = disease "normal"
        st = ["DLBD_status", "FTD_status", "Tauopathy_status", "Vascular_status", "Schizophrenia", "Parkinson_disease",
              "Bipolar_Disorder", "Tardive_dyskinesia"]
        ad_ = (d["AD_status"].astype(str) == "Yes").astype(float)
        control = (d["disease"].astype(str) == "normal").astype(float)
        other_neuro = d[[c for c in st if c in d]].astype(str).eq("Yes").any(axis=1)
    else:                  # myeloid schema: numeric 0/1 columns incl. Control
        ad_ = pd.to_numeric(d["AD"], errors="coerce")
        control = pd.to_numeric(d["Control"], errors="coerce")
        other_neuro = d[[c for c in OTHER_DX if c in d]].apply(pd.to_numeric, errors="coerce").fillna(0).sum(1) > 0
    info = pd.DataFrame({"ad": ad_.to_numpy(), "control": control.to_numpy(),
                         "age": d["development_stage"].astype(str).str.extract(r"(\d+)-year")[0].astype(float).to_numpy(),
                         "sex": d["sex"].astype(str).to_numpy(), "other_neuro": other_neuro.to_numpy()}, index=d.index.astype(str))
    for c in extra:
        info[c] = pd.to_numeric(d[c], errors="coerce").to_numpy()
    contrast = info[(((info.ad == 1) & ~info.other_neuro) | ((info.control == 1) & (info.ad != 1))) & info.age.notna()].copy()
    contrast["x"] = (contrast.ad == 1).astype(float)
    print(f"donors in AD vs control contrast: {len(contrast)} (AD {int(contrast.x.sum())})", flush=True)

    # positive control 2: Sst share among inhibitory neurons (composition, from obs only)
    in_mask = cls == "IN"
    if not in_mask.any():
        print("no IN class in this file; Sst control skipped")
    comp = pd.crosstab(donor[in_mask], sub[in_mask]) if in_mask.any() else pd.DataFrame()
    sst_cols = [c for c in comp.columns if "SST" in c.upper()]
    if sst_cols:
        share = (comp[sst_cols].sum(1) + 0.5) / (comp.sum(1) + 1)
        cs = contrast.join(share.rename("sst_share")).dropna(subset=["sst_share"])
        Zc = pd.get_dummies(cs[["age", "sex"]], drop_first=True, dtype=float).assign(
            log_n=np.log10(comp.sum(1).reindex(cs.index))).to_numpy(float)
        r_sst, p_sst = partial_r(np.log(cs.sst_share / (1 - cs.sst_share)).to_numpy()[:, None], cs.x.to_numpy(float), Zc)
        print(f"positive control, Sst share of IN (logit) AD vs control: r = {r_sst[0]:+.3f}, p = {p_sst[0]:.2g} "
              f"(n = {len(cs)}); Sst subclasses: {sst_cols}")

    progs = {p: g for p, g in all_programs().items() if p in NEURONAL_REPAIR + ["p53_targets"]}
    rows, views = [], {}
    for cname in ("EN", "IN", "MG"):
        keep = (cls == cname) & np.isin(donor, contrast.index)
        if keep.sum() == 0:
            print(f"class {cname} not found; skipping")
            continue
        print(f"  pseudobulk {cname}: {keep.sum():,} nuclei", flush=True)
        cats, M = pseudobulk(a, keep, donor)
        n = pd.Series(donor[keep]).value_counts().reindex(cats).to_numpy()
        ok = n >= (50 if cname != "MG" else 20)
        cats, M, n = cats[ok], M[ok], n[ok]
        dd = contrast.loc[cats]
        cpm = M / M.sum(1, keepdims=True) * 1e6
        expressed = (cpm >= 1).mean(0) >= 0.5
        L = pd.DataFrame(np.log2(cpm[:, expressed] + 1), columns=sym[expressed], index=cats)
        glen = pd.Series(glen_all[expressed], index=sym[expressed])
        L, glen = L.loc[:, ~L.columns.duplicated()], glen[~glen.index.duplicated()]
        cov = dd[["age", "sex"]].assign(log_n=np.log10(n), mito=M[:, sym.str.startswith("MT-")].sum(1) / M.sum(1))
        Z = pd.get_dummies(cov, drop_first=True, dtype=float).to_numpy(float)
        Z1 = np.column_stack([np.ones(len(L)), Z])
        R = L - Z1 @ np.linalg.lstsq(Z1, L.to_numpy(), rcond=None)[0]
        R = (R - R.mean()) / R.std().replace(0, 1)
        views[cname] = (R, dd, Z, L.mean(), glen)
        print(f"  {cname}: {len(R)} donors (AD {int(dd.x.sum())}), {R.shape[1]:,} expressed genes", flush=True)

    # neuronal drift axis (sensitivity)
    pc1 = None
    if "EN" in views and "IN" in views:
        common = views["EN"][0].index.intersection(views["IN"][0].index)
        Xc = np.hstack([views[v][0].loc[common, views[v][0].var().sort_values(ascending=False).index[:1000]].to_numpy() for v in ("EN", "IN")])
        U, S, _ = np.linalg.svd(Xc - Xc.mean(0), full_matrices=False)
        pc1 = pd.Series(U[:, 0] * S[0], index=common)
        print(f"neuronal PC1 explains {S[0] ** 2 / (S ** 2).sum():.1%} of concatenated variance; "
              f"r(PC1, AD) = {np.corrcoef(pc1, contrast.loc[common, 'x'])[0, 1]:+.3f}")

    for cname, (R, dd, Z, mean, glen) in views.items():
        ebin = pd.qcut(mean.rank(method="first"), 10, labels=False)
        lbin = pd.qcut(glen.reindex(R.columns).rank(method="first"), 10, labels=False)
        plist = dict(progs) if cname != "MG" else {"DAM": list(DAM)}
        # calibration: plain random 20-gene sets
        rs_ = np.column_stack([R[list(rng.choice(R.columns, 20, replace=False))].mean(1) for _ in range(300)])
        _, pcal = partial_r(rs_, dd.x.to_numpy(float), Z)
        print(f"  {cname}: random 20-gene sets with p < 0.05 for AD: {(pcal < 0.05).mean():.2f}")
        for prog, gs in plist.items():
            gi = [g for g in gs if g in R.columns]
            sets = [gi] + [[rng.choice(R.columns[((ebin == ebin[g]) & (lbin == lbin[g])).to_numpy()]) for g in gi]
                           for _ in range(args.n_random)]
            scm = np.column_stack([R[s_].mean(1) for s_ in sets])
            for tag in (["primary"] + (["+PC1"] if pc1 is not None and cname != "MG" else [])):
                if tag == "+PC1":
                    common = R.index.intersection(pc1.index)
                    pos = R.index.get_indexer(common)
                    Zx, xx, sc_ = np.column_stack([Z[pos], pc1.loc[common]]), dd.x.to_numpy(float)[pos], scm[pos]
                else:
                    Zx, xx, sc_ = Z, dd.x.to_numpy(float), scm
                r, p = partial_r(sc_, xx, Zx)
                null = r[1:]
                nn = len(xx)
                se = 1 / np.sqrt(max(nn - 3 - Zx.shape[1], 1))
                rows.append({"cells": cname, "program": prog, "model": tag, "n_donors": nn, "n_AD": int(xx.sum()),
                             "n_genes": len(gi), "r": r[0], "ci_lo": np.tanh(np.arctanh(r[0]) - 1.96 * se),
                             "ci_hi": np.tanh(np.arctanh(r[0]) + 1.96 * se), "p_self": p[0],
                             "random_mean_r": null.mean(), "random_sd_r": null.std(),
                             "p_vs_random": (np.sum(np.abs(null - null.mean()) >= abs(r[0] - null.mean())) + 1) / (len(null) + 1),
                             "mde_r_80pct": float(np.tanh((1.96 + 0.84) * se))})
    res = pd.DataFrame(rows)
    fam = (res.cells != "MG")
    for tag in res.model.unique():
        m = fam & (res.model == tag)
        res.loc[m, "q_self"] = bh(res.loc[m, "p_self"].to_numpy())
        res.loc[m, "q_vs_random"] = bh(res.loc[m, "p_vs_random"].to_numpy())
    res.to_csv(out / "ddr_neurons.csv", index=False)
    pd.set_option("display.width", 250)
    print(res.to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
