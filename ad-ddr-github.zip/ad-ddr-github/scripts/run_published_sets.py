"""Head-to-head: do the published AD "DNA damage" gene sets replicate in SEA-AD at the donor level?

    python scripts/run_published_sets.py --out results/published_sets

Gene sets (data/meta/published_sets, with provenance):
  Mathys 2023 Cell   cohesin complex (CORUM SA1 / SA2), claimed up with AD in excitatory
                     neurons and oligodendrocytes (their DDR-factor list is not open access)
  Mathys 2024 Nature immune p53 / DNA-damage module M22 (core 24, all 58 genes); EC genes
                     up in >= 3 cell types with pathologic AD (reconstructed, 39 genes)
  Fancy 2024         microglia trajectory module 8 (43 genes, includes ATM)
Cell groups: excitatory neurons (class), oligodendrocytes, microglia, astrocytes. Contrasts:
local CPS in each region, and dementia vs no dementia in MTG; age, sex, PMI, log nuclei
adjusted; severely affected donors excluded. Each test reports p_perm (exposure permuted
across donors) and p_set (vs 200 expression-matched random gene sets), as in
scripts/run_celltype_screen.py. The question is whether a set changes at all (p_perm) and
whether it changes more than arbitrary genes (p_set).
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

import run_celltype_screen as screen
from ad_ddr import cohort
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
SETS = {"Mathys2023_cohesin": ["mathys2023_cohesin_CORUM165_SA1.txt", "mathys2023_cohesin_CORUM166_SA2.txt"],
        "Mathys2024_M22_core": ["mathys2024_Mic_Immune_M22_core.txt"],
        "Mathys2024_M22_all": ["mathys2024_Mic_Immune_M22_all.txt"],
        "Mathys2024_EC_shared_up": ["mathys2024_EC_nrad_up_shared3plus_celltypes.txt"],
        "Fancy2024_microglia_M8": ["fancy2024_microglia_Module8.txt"]}
EXC_FILES = ["L23-IT", "L4-IT", "L5-IT", "L5-ET", "L56-NP", "L6-IT", "L6-IT-Car3", "L6-CT", "L6b", "EC-IT", "CA2-4",
             "DG", "Sub-CA1"]
GROUPS = {("class", cohort.EXC): EXC_FILES, ("group", "Oligodendrocyte"): ["Oligodendrocyte"],
          ("group", "Microglia-PVM"): ["Immune"], ("group", "Astrocyte"): ["Astrocyte"]}
CLAIMED = {"Mathys2023_cohesin": {cohort.EXC, "Oligodendrocyte"}, "Mathys2024_M22_core": {"Microglia-PVM"},
           "Mathys2024_M22_all": {"Microglia-PVM"}, "Fancy2024_microglia_M8": {"Microglia-PVM"},
           "Mathys2024_EC_shared_up": {cohort.EXC, "Oligodendrocyte", "Microglia-PVM", "Astrocyte"}}


def load_sets() -> dict[str, list[str]]:
    d = ROOT / "data/meta/published_sets"
    return {k: sorted({g.strip() for f in fs for g in (d / f).read_text().split() if g.strip()}) for k, fs in SETS.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/published_sets")
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--n-perm", type=int, default=2000)
    ap.add_argument("--match-length", action="store_true",
                    help="random genes matched on expression x gene length (SEA-AD has a gene-length drift axis)")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    programs = load_sets()
    gene_len = None
    if args.match_length:
        from ddrmulti.genome import read_gtf_genes
        gtf = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
        gene_len = np.log10((gtf["end"] - gtf["start"]).clip(lower=1))
        gene_len.index = gene_len.index.str.upper()
        gene_len = gene_len[~gene_len.index.duplicated()]
    print({k: len(v) for k, v in programs.items()})
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")[["Donor ID", "Brain Region", "CPS_Local"]]
    cps.columns = ["donor", "region", "cps"]

    rows = []
    for (level, grp), files in GROUPS.items():
        idx, C, genes, meta = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{f}.h5ad" for f in files])
        meta = meta.assign(age=pd.to_numeric(meta["age"], errors="coerce"), pmi=pd.to_numeric(meta["pmi"], errors="coerce"),
                           severe=meta["severe"].astype(str).eq("Y"),
                           dementia=meta["cognition"].astype(str).eq("Dementia").astype(float))
        idx = idx.merge(cps, on=["donor", "region"], how="left").join(meta[["age", "sex", "pmi", "severe", "dementia"]],
                                                                       on="donor")
        keep = (idx["level"] == level) & (idx["group"] == grp) & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool) \
            & idx[["age", "pmi"]].notna().all(1)
        for region, d in idx[keep].groupby("region"):
            for contrast in ("CPS", "dementia"):
                if contrast == "dementia" and region != "MTG":
                    continue
                col = "cps" if contrast == "CPS" else "dementia"
                dd = d[d[col].notna()]
                if len(dd) < 10:
                    continue
                base = dd.assign(cps=dd[col], log_nuclei=np.log10(dd["n_nuclei"])).reset_index(drop=True)
                for r in screen.screen_group(C[dd.index.to_numpy()], base, genes, programs, rng, args.n_sets, args.n_perm,
                                             gene_len):
                    rows.append({"cells": grp, "region": region, "contrast": contrast, "n_donors": len(dd),
                                 "claimed_here": grp in CLAIMED.get(r["program"], set()), **r})
        print(f"  {grp}: done", flush=True)
    res = pd.DataFrame(rows)
    res["q_perm"] = np.nan
    res["q_set"] = np.nan
    for key, d in res.groupby(["contrast"]):
        res.loc[d.index, "q_perm"] = bh(d["p_perm"].to_numpy())
        res.loc[d.index, "q_set"] = bh(d["p_set"].to_numpy())
    res.to_csv(out / "published_sets.csv", index=False)
    cols = ["program", "cells", "region", "contrast", "n_donors", "n_genes", "r", "null_mean", "r_excess", "p_perm",
            "q_perm", "p_set", "q_set"]
    print("\nClaimed cell type, MTG (CPS and dementia):")
    print(res[res["claimed_here"] & (res["region"] == "MTG")][cols].to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    s = res[res["claimed_here"] & (res["contrast"] == "CPS")].groupby(["program", "cells"]).agg(
        regions=("region", "size"), median_r=("r", "median"), median_null=("null_mean", "median"),
        regions_p_perm05_up=("p_perm", lambda p: int(((p < .05) & (res.loc[p.index, "r"] > 0)).sum())),
        regions_p_set05=("p_set", lambda p: int((p < .05).sum())), min_q_set=("q_set", "min"))
    s.to_csv(out / "published_sets_summary.csv")
    print("\nAcross regions (claimed cell types, CPS):")
    print(s.to_string(float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
