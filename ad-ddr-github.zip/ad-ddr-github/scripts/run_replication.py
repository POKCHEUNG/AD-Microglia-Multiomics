"""Independent-cohort replication: Morabito et al. 2021 (GSE174367), prefrontal cortex snRNA-seq.

    python scripts/run_replication.py --out results/replication

Fixed before running, to match the SEA-AD primary analysis:
* donor pseudobulks per cell type (EX, INH, MG, ASC), scored exactly like the cohort
  analysis (mean z-scored log2 CPM of expressed program genes across donors)
* exposure: AD vs control (binary), partial r adjusting for age, sex, log(#nuclei);
  sensitivity: Braak (tangle) stage as an ordinal exposure
* the same 13 pre-specified hypotheses, BH within the family
* each hypothesis vs 500 expression-matched random gene sets
* consistency: is the SEA-AD effect inside the Morabito 95% CI, and is the sign the same?
Limitations: 18 donors (11 AD / 7 control), extreme groups only, ages censored at 90.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp

from ad_ddr import cohort, stats
from ad_ddr.signatures import all_programs
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data/raw/morabito"
GROUPS = {"EX": cohort.EXC, "INH": cohort.INH, "MG": "Microglia-PVM", "ASC": "Astrocyte"}
COV = ["age", "sex", "log_nuclei"]


def load() -> tuple[pd.DataFrame, np.ndarray, pd.Index, pd.DataFrame]:
    a = sc.read_10x_h5(RAW / "GSE174367_snRNA-seq_filtered_feature_bc_matrix.h5")
    a.var_names_make_unique()
    m = pd.read_csv(RAW / "GSE174367_snRNA-seq_cell_meta.csv.gz").set_index("Barcode")
    a = a[a.obs_names.isin(m.index)]
    obs = m.loc[a.obs_names]
    obs = obs[obs["Cell.Type"].isin(GROUPS)]
    a = a[obs.index]
    key = obs["Cell.Type"].map(GROUPS) + "|" + obs["SampleID"]
    cat = pd.Categorical(key)
    A = sp.csr_matrix((np.ones(a.n_obs), (cat.codes, np.arange(a.n_obs))))
    C = np.asarray((A @ sp.csr_matrix(a.X)).todense())
    parts = pd.Series(cat.categories).str.split("|", expand=True)
    idx = pd.DataFrame({"level": np.where(parts[0].str.startswith("Neuronal"), "class", "group"), "region": "PFC",
                        "group": parts[0], "donor": parts[1],
                        "n_nuclei": pd.Series(cat.codes).value_counts().sort_index().to_numpy(), "multiome_nuclei": 0})
    d = m.drop_duplicates("SampleID").set_index("SampleID")
    donors = pd.DataFrame({"ad": (d["Diagnosis"] == "AD").astype(float), "age": d["Age"].astype(float),
                           "sex": d["Sex"], "braak": d["Tangle.Stage"].str.extract(r"(\d)")[0].astype(float),
                           "rin": d["RIN"], "pmi": d["PMI"]})
    return idx, C, a.var_names, donors


def random_null(idx, C, genes, donors, level, grp, prog_genes, x, n, rng, min_nuclei=20):
    m = ((idx.level == level) & (idx.group == grp) & (idx.n_nuclei >= min_nuclei)).to_numpy()
    d, M = idx[m].reset_index(drop=True), C[m]
    cpm = M / M.sum(1, keepdims=True) * 1e6
    L = np.log2(cpm + 1)
    expressed = (cpm >= 1).mean(0) >= 0.5
    Z = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
    bins = pd.qcut(pd.Series(L.mean(0)).rank(method="first"), 10, labels=False).to_numpy()
    upper = pd.Series(np.arange(len(genes)), index=genes.str.upper())
    upper = upper[~upper.index.duplicated()]
    gi = upper.reindex([g.upper() for g in prog_genes]).dropna().astype(int).to_numpy()
    gi = gi[expressed[gi]]
    pool = np.flatnonzero(expressed)
    sets = [gi] + [np.array([rng.choice(pool[bins[pool] == bins[g]]) for g in gi]) for _ in range(n)]
    base = d[["donor", "n_nuclei"]].join(donors, on="donor").assign(log_nuclei=lambda t: np.log10(t.n_nuclei))
    sc_ = pd.DataFrame({f"s{i}": Z[:, s].mean(1) for i, s in enumerate(sets)})
    r = stats.cps_association(pd.concat([base, sc_], axis=1).assign(k=grp), list(sc_.columns), groupby="k", x=x,
                              covariates=COV, n_perm=200, min_donors=10).set_index("score")["r"]
    obs, null = r["s0"], r.drop("s0").to_numpy()
    return obs, null


def main():
    from run_cohort import PRIMARY

    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/replication")
    ap.add_argument("--n-random", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    idx, C, genes, donors = load()
    print(f"donors: {len(donors)} ({int(donors.ad.sum())} AD); pseudobulks: {len(idx)}; "
          f"median nuclei per donor: " + ", ".join(f"{g} {int(idx[idx.group == f].n_nuclei.median())}"
                                                   for g, f in GROUPS.items()))
    programs = all_programs()
    scores = cohort.score_programs(idx, C, genes, programs)
    scores = scores.join(donors, on="donor")
    scores["key"] = scores["level"] + "|" + scores["group"]

    sea = pd.read_csv(ROOT / "results/cohort/primary_MTG_primary.csv").set_index(["cells", "program"])
    rows = []
    for x in ("ad", "braak"):
        res = stats.cps_association(scores, [f"rna_{p}" for p in programs], groupby="key", x=x, covariates=COV,
                                    n_perm=10_000, seed=args.seed, min_donors=10)
        for level, grp, prog in PRIMARY:
            hit = res[(res.key == f"{level}|{grp}") & (res.score == f"rna_{prog}")]
            if not len(hit):
                continue
            h = hit.iloc[0]
            n = h.n_donors
            se = 1 / np.sqrt(max(n - 3 - len(COV), 1))
            lo, hi = np.tanh(np.arctanh(h.r) - 1.96 * se), np.tanh(np.arctanh(h.r) + 1.96 * se)
            row = {"exposure": x, "cells": grp, "program": prog, "r": h.r, "ci_lo": lo, "ci_hi": hi,
                   "p_perm": h.p_perm, "n_donors": int(n), "sea_ad_r": sea.loc[(grp, prog), "r"]}
            if x == "ad":
                o, null = random_null(idx, C, genes, donors, level, grp, programs[prog], "ad", args.n_random, rng)
                row.update({"null_mean": null.mean(), "p_vs_random": (np.sum(np.abs(null - null.mean()) >=
                                                                             abs(o - null.mean())) + 1) / (len(null) + 1)})
            rows.append(row)
    t = pd.DataFrame(rows)
    t["q"] = t.groupby("exposure")["p_perm"].transform(lambda p: bh(p.to_numpy()))
    t["sea_in_ci"] = (t.sea_ad_r >= t.ci_lo) & (t.sea_ad_r <= t.ci_hi)
    t["same_sign"] = np.sign(t.r) == np.sign(t.sea_ad_r)
    t.to_csv(out / "replication_primary.csv", index=False)
    show = ["cells", "program", "r", "ci_lo", "ci_hi", "p_perm", "q", "null_mean", "p_vs_random", "sea_ad_r", "sea_in_ci", "same_sign"]
    for x in ("ad", "braak"):
        d = t[t.exposure == x]
        print(f"\n[{x}] partial r | {'+'.join(COV)}; n donors = {d.n_donors.max()}")
        print(d[[c for c in show if c in d and d[c].notna().any()]].to_string(index=False, float_format=lambda v: f"{v:.3f}"))
        print(f"SEA-AD r inside Morabito 95% CI: {int(d.sea_in_ci.sum())}/{len(d)}; same sign: {int(d.same_sign.sum())}/{len(d)}")

    d = t[t.exposure == "ad"].reset_index(drop=True)
    lab = d.cells.str.replace("Neuronal: ", "") + " | " + d.program
    fig, ax = plt.subplots(figsize=(6.8, 0.36 * len(d) + 1.4))
    y = np.arange(len(d))
    ax.hlines(y, d.ci_lo, d.ci_hi, color="#d9822b", lw=1.4, alpha=0.7)
    ax.scatter(d.r, y, color="#d9822b", s=30, label=f"Morabito PFC, AD vs control (n={d.n_donors.max()})", zorder=3)
    ax.scatter(d.sea_ad_r, y, marker="D", color="#3b6fb6", s=24, label="SEA-AD MTG, CPS (n=73)", zorder=3)
    ax.axvline(0, color="0.6", lw=0.8)
    ax.set_yticks(y, lab, fontsize=8)
    ax.invert_yaxis()
    ax.set_xlim(-1, 1)
    ax.set_xlabel("partial r (95% CI)")
    ax.legend(fontsize=7, frameon=False, loc="lower left")
    ax.set_title("Independent cohort: pre-specified hypotheses", fontsize=9)
    fig.tight_layout()
    fig.savefig(out / "replication.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    main()
