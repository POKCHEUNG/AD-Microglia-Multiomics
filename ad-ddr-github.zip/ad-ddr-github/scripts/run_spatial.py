"""MERFISH (SEA-AD MTG, 27 donors): are vulnerable neurons locally depleted around
disease-associated microglia, and does this grow with CPS?

    python scripts/run_spatial.py --out results/spatial

Pre-specified before looking at the spatial data:
* focal centres: Micro-PVM_3-SEAAD; reference centres: other Micro-PVM_* (monocytes excluded)
* targets (primary): the neuronal supertypes depleted along CPS in the 73-donor cohort
  (results/vulnerability, q < 0.1, slope < 0); secondary: subclasses Sst, Sncg, L2/3 IT
* radius 50 um (sensitivity 30, 100); null = focal label permuted within section x depth decile
* sensitivity: only cells with supertype confidence >= 0.5
* positive control: astrocytes around endothelial cells vs around OPCs (30 um)

Post hoc (after the run): the astrocyte-endothelium control rested on a wrong premise
(astrocyte end-feet, not somata, contact vessels) and is kept only for transparency.
It is complemented by a spike-in control: in the real sections, a fixed share of target
neurons within the radius of focal centres is relabelled as non-target, and the same
test is rerun. Ages come from the SEA-AD donor table because MERFISH obs censors ages
at "90+".
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ad_ddr import neighborhood as nb
from ad_ddr import stats

ROOT = Path(__file__).resolve().parents[1]
EXC, INH = "Neuronal: Glutamatergic", "Neuronal: GABAergic"
VULN_SUBCLASSES = ["Sst", "Sncg", "L2/3 IT"]


def run_analysis(o, xy, bins, centre, focal, target, other, radius, n_perm, seed):
    rows = []
    for k, (sec, idx) in enumerate(o.groupby("Section", observed=True).indices.items()):
        r = nb.section_test(xy[idx], bins[idx], centre[idx], focal[idx], target[idx], other[idx],
                            radius=radius, n_perm=n_perm, seed=seed + k)
        if r is not None:
            rows.append({"section": sec, "donor": o["Donor ID"].iloc[idx[0]], **r})
    return pd.DataFrame(rows)


def donor_level(sec: pd.DataFrame, donors: pd.DataFrame) -> pd.DataFrame:
    w = sec["n_focal"]
    g = sec.assign(wf=sec.frac_excess * w, wd=sec.dens_excess * w).groupby("donor")
    d = pd.DataFrame({"frac_excess": g.wf.sum() / g.n_focal.sum(), "dens_excess": g.wd.sum() / g.n_focal.sum(),
                      "n_focal": g.n_focal.sum(), "n_sections": g.size()})
    return d.join(donors)


def sign_flip_p(x: np.ndarray, n: int = 20000, seed: int = 0) -> float:
    rng = np.random.default_rng(seed)
    obs = x.mean()
    null = (rng.choice([-1, 1], (n, len(x))) * x).mean(1)
    return (np.sum(np.abs(null) >= abs(obs)) + 1) / (n + 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/spatial")
    ap.add_argument("--n-perm", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)

    a = ad.read_h5ad(ROOT / "data/raw/merfish/SEAAD_MTG_MERFISH.2024-12-11.h5ad", backed="r")
    o = a.obs[["Donor ID", "Section", "Class", "Subclass", "Supertype", "Supertype confidence",
               "Normalized depth from pia", "Age at Death", "Sex"]].copy()
    for c in ("Donor ID", "Section", "Class", "Subclass", "Supertype", "Sex"):
        o[c] = o[c].astype(str)
    o = o.reset_index(drop=True)
    xy = np.asarray(a.obsm["spatial"], float)
    bins = nb.depth_bins(o["Normalized depth from pia"], o["Section"])

    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv").query("`Brain Region` == 'MTG'").set_index("Donor ID")
    donor_table = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    donors = (o.drop_duplicates("Donor ID").set_index("Donor ID")[["Sex"]].rename(columns={"Sex": "sex"})
              .join(pd.to_numeric(donor_table["Age at Death"], errors="coerce").rename("age"))
              .join(cps["CPS_Local"].rename("cps")))
    print(f"donors with age and CPS: {donors[['age', 'cps']].notna().all(1).sum()} of {len(donors)}")

    vul = pd.read_csv(ROOT / "results/vulnerability/supertype_vulnerability.csv")
    vuln_st = vul.loc[(vul.q < 0.1) & (vul.slope < 0), "supertype"].tolist()
    print(f"vulnerable supertypes ({len(vuln_st)}): {', '.join(vuln_st)}")

    st = o["Supertype"]
    micro = st.str.startswith("Micro-PVM").to_numpy()
    focal = (st == "Micro-PVM_3-SEAAD").to_numpy()
    neuron = o["Class"].isin([EXC, INH]).to_numpy()
    conf = (o["Supertype confidence"] >= 0.5).to_numpy()
    print(f"microglia {micro.sum():,} (focal {focal.sum():,}); neurons {neuron.sum():,}; "
          f"confidence>=0.5: {conf.mean():.0%} of cells")

    designs = {
        "primary (vulnerable supertypes, 50um)": (micro, focal, neuron & st.isin(vuln_st).to_numpy(), 50),
        "secondary (Sst/Sncg/L2/3 IT subclasses, 50um)": (micro, focal, neuron & o.Subclass.isin(VULN_SUBCLASSES).to_numpy(), 50),
        "sensitivity radius 30um": (micro, focal, neuron & st.isin(vuln_st).to_numpy(), 30),
        "sensitivity radius 100um": (micro, focal, neuron & st.isin(vuln_st).to_numpy(), 100),
        "sensitivity confidence>=0.5": (micro & conf, focal & conf, neuron & conf & st.isin(vuln_st).to_numpy(), 50),
    }
    summary, per_donor = [], {}
    for name, (centre, foc, target, radius) in designs.items():
        other = neuron & ~target if "confidence" not in name else neuron & conf & ~target
        sec = run_analysis(o, xy, bins, centre, foc, target, other, radius, args.n_perm, args.seed)
        d = donor_level(sec, donors).dropna(subset=["cps", "age"])
        per_donor[name] = d
        assoc = stats.cps_association(d.assign(k="all").reset_index(names="donor"), ["frac_excess", "dens_excess"],
                                      groupby="k", covariates=["age", "sex"], n_perm=10_000, min_donors=10)
        assoc = assoc.set_index("score")
        summary.append({"analysis": name, "n_donors": len(d), "n_sections": len(sec),
                        "frac_excess_mean": d.frac_excess.mean(), "p_frac_nonzero": sign_flip_p(d.frac_excess.to_numpy()),
                        "r_frac_cps": assoc.loc["frac_excess", "r"], "p_frac_cps": assoc.loc["frac_excess", "p_perm"],
                        "dens_excess_mean": d.dens_excess.mean(), "p_dens_nonzero": sign_flip_p(d.dens_excess.to_numpy()),
                        "r_dens_cps": assoc.loc["dens_excess", "r"], "p_dens_cps": assoc.loc["dens_excess", "p_perm"]})
        sec.to_csv(out / f"sections_{name.split(' ')[0]}_{radius}.csv", index=False)
        print(f"  done: {name}", flush=True)

    # spike-in control: deplete a share of targets near focal centres, then rerun the primary test
    from scipy.spatial import cKDTree
    target0 = neuron & st.isin(vuln_st).to_numpy()
    near = np.zeros(len(o), bool)
    for _, idx in o.groupby("Section", observed=True).indices.items():
        f = idx[focal[idx]]
        if len(f):
            near[idx] = np.asarray(cKDTree(xy[f]).query_ball_point(xy[idx], r=50, return_length=True)) > 0
    rng = np.random.default_rng(args.seed)
    for share in (0.10, 0.25):
        drop = target0 & near & (rng.random(len(o)) < share)
        tgt = target0 & ~drop
        sec = run_analysis(o, xy, bins, micro, focal, tgt, neuron & ~tgt, 50, args.n_perm, args.seed)
        d = donor_level(sec, donors)
        summary.append({"analysis": f"spike-in: {share:.0%} of targets near DA microglia removed (50um)",
                        "n_donors": len(d), "n_sections": len(sec), "frac_excess_mean": d.frac_excess.mean(),
                        "p_frac_nonzero": sign_flip_p(d.frac_excess.to_numpy())})
        print(f"  done: spike-in {share:.0%}", flush=True)

    # positive control: astrocytes near endothelium vs near OPCs
    sub = o["Subclass"]
    centre = sub.isin(["Endothelial", "OPC"]).to_numpy()
    foc = (sub == "Endothelial").to_numpy()
    target = (sub == "Astrocyte").to_numpy()
    other = ~centre & ~target
    sec = run_analysis(o, xy, bins, centre, foc, target, other, 30, args.n_perm, args.seed)
    d = donor_level(sec, donors)
    summary.append({"analysis": "positive control: astrocytes around endothelium vs OPC (30um)", "n_donors": len(d),
                    "n_sections": len(sec), "frac_excess_mean": d.frac_excess.mean(),
                    "p_frac_nonzero": sign_flip_p(d.frac_excess.to_numpy())})
    summ = pd.DataFrame(summary)
    summ.to_csv(out / "summary.csv", index=False)
    print("\nfrac_excess = log2(target fraction among neighbours, focal vs reference centres) minus "
          "depth-matched null; negative = targets depleted near focal centres")
    print(summ.to_string(index=False, float_format=lambda v: f"{v:.3f}"))

    prim = per_donor["primary (vulnerable supertypes, 50um)"]
    prim.to_csv(out / "donor_primary.csv")
    fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.8))
    ax[0].scatter(prim.cps, prim.frac_excess, s=30, c="#3b6fb6", edgecolor="k", lw=0.4)
    ax[0].axhline(0, color="0.5", lw=0.8)
    row = summ.iloc[0]
    ax[0].set_xlabel("CPS (local, MTG)")
    ax[0].set_ylabel("vulnerable-neuron fraction near DA microglia\n(log2, minus depth-matched null)")
    ax[0].set_title(f"mean {row.frac_excess_mean:.3f} (p={row.p_frac_nonzero:.2f}); "
                    f"r with CPS {row.r_frac_cps:.2f} (p={row.p_frac_cps:.2f})", fontsize=9)
    colors = ["#2e8b57" if a.startswith("spike") else "0.6" if a.startswith("positive") else "#3b6fb6"
              for a in summ.analysis]
    ax[1].barh(range(len(summ)), summ.frac_excess_mean, color=colors)
    ax[1].set_yticks(range(len(summ)), [s.replace(" (vulnerable supertypes, 50um)", "").replace("positive control: ", "pos. ctrl: ").replace(" near DA microglia removed (50um)", " removed")[:44] for s in summ.analysis], fontsize=7)
    ax[1].axvline(0, color="0.5", lw=0.8)
    ax[1].invert_yaxis()
    ax[1].set_xlabel("mean excess across donors (log2)")
    fig.tight_layout()
    fig.savefig(out / "spatial.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
