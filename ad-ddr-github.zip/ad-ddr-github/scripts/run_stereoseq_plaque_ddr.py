"""Local DDR expression next to amyloid plaques at 25 um resolution (GSE263789 Stereo-seq, App NL-G-F mice).

    python scripts/run_stereoseq_plaque_ddr.py --out results/stereoseq_plaque

Inputs per section: bin50 counts from scripts/build_stereoseq_bins.py and the registered
plaque grid from scripts/register_plaque_mask.py (plaque staining is on the adjacent
section; registration precision is ~25-50 um, so nothing finer than that is claimed).

Fixed before looking at DDR results:
  bins      25 um bins with >= 200 UMI
  contrast  near = <= 25 um from a registered plaque (including plaque bins) vs
            ref = 100-300 um away, so both sit in the same brain region
  estimate  Mantel-Haenszel rate ratio (program counts per UMI), stratified by section
            quintiles of neuron x oligodendrocyte x astrocyte marker fractions (125 strata):
            the total plaque-niche effect, including microglial accumulation.
            Secondary: also stratified by microglial fraction (within-composition effect).
  nulls     p_set: 200 random gene sets matched on section-level expression;
            p_spatial: plaque grid shifted toroidally by >= 1 mm in x and y (200 shifts).
  controls  Trem2 + Cd68 (not used to fit the registration) must rise near plaques.
  QC        a section enters only if its registration r >= 3x the block-shuffled null maximum
            and held-out Trem2 and Cd68 are each > 1.2x enriched within 25 um of plaques.
  pooling   18-month AD sections: mean log RR; nulls pooled index-wise.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import ndimage

from ad_ddr.signatures import all_programs
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
DDR = ["HR", "NHEJ", "MMR", "BER", "NER", "FA", "Checkpoint", "p53_targets", "Senescence", "cGAS_STING_IFN"]
MARKERS = {"neuron": ["Snap25", "Syt1", "Stmn2", "Meg3"], "oligo": ["Mbp", "Plp1", "Mobp", "Mag"],
           "astro": ["Gfap", "Aqp4", "Slc1a2", "Aldoc"], "micro": ["Hexb", "P2ry12", "Csf1r", "Cx3cr1"]}
CONTROL = {"Trem2_Cd68": ["Trem2", "Cd68"]}
SECTIONS = {"GSM8199179_mSS_18M_AD_E3": ("AD_18M", "180"), "GSM8199180_mSS_18M_AD_E4": ("AD_18M", "220"),
            "GSM8199182_mss_3M_WT_AD_E1": ("mixed_3M", "170"), "GSM8199183_mSS_3M_WT_AD_E2": ("mixed_3M", "210")}
UM_PER_BIN = 25.0


def quintile(v):
    return pd.qcut(pd.Series(v).rank(method="first"), 5, labels=False).to_numpy()


def mh_logrr(N, R, T1, T0):
    """Mantel-Haenszel log rate ratio. N, R: strata x k counts (near, ref); T1, T0: strata UMI."""
    T = T1 + T0
    ok = (T1 > 0) & (T0 > 0)
    num = (N[ok] * (T0[ok] / T[ok])[:, None]).sum(0)
    den = (R[ok] * (T1[ok] / T[ok])[:, None]).sum(0)
    return np.log(num / den)


def indicator(strata: np.ndarray, mask: np.ndarray, n_strata: int) -> sp.csr_matrix:
    idx = np.flatnonzero(mask)
    return sp.csr_matrix((np.ones(len(idx)), (strata[idx], idx)), shape=(n_strata, len(mask)))


def distances(pl: np.ndarray) -> np.ndarray:
    return ndimage.distance_transform_edt(~pl) * UM_PER_BIN


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bins", default="data/processed/stereoseq")
    ap.add_argument("--reg", default="results/stereoseq_audit")
    ap.add_argument("--out", default="results/stereoseq_plaque")
    ap.add_argument("--n-sets", type=int, default=200)
    ap.add_argument("--n-shift", type=int, default=200)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)
    progs = {k: [g.capitalize() for g in v] for k, v in all_programs().items() if k in DDR}
    sets_all = {**progs, **CONTROL}

    rows, store = [], {}
    for prefix, (group, thr) in SECTIONS.items():
        bdir, rdir = ROOT / args.bins / prefix, ROOT / args.reg / prefix
        if not (bdir / "counts.npz").exists() or not (rdir / f"plaque_grid_{thr}.npy").exists():
            print(f"  {prefix}: missing inputs, skipped")
            continue
        reg = pd.read_csv(rdir / f"registration_best_{thr}.csv", index_col=0).iloc[:, 0]
        val = pd.read_csv(rdir / f"registration_validation_{thr}.csv").set_index("gene")["ratio"]
        passed = reg["r"] >= 3 * reg["null_max"] and val["Trem2"] > 1.2 and val["Cd68"] > 1.2
        if not passed:
            print(f"  {prefix}: registration fails QC (r {reg['r']:.3f} vs null max {reg['null_max']:.3f}; "
                  f"held-out Trem2 {val['Trem2']:.2f}, Cd68 {val['Cd68']:.2f}), skipped")
            continue
        X = sp.load_npz(bdir / "counts.npz").tocsc()
        genes = pd.Index((bdir / "genes.txt").read_text().split())
        bins = pd.read_csv(bdir / "bins.csv")
        keep = (bins["umi"] >= 200).to_numpy()
        X, bins = X[keep].tocsr(), bins[keep].reset_index(drop=True)
        umi = bins["umi"].to_numpy(float)
        gpos = pd.Series(np.arange(len(genes)), index=genes)

        frac = {k: np.asarray(X[:, gpos.reindex(v).dropna().astype(int).to_numpy()].sum(1)).ravel() / umi
                for k, v in MARKERS.items()}
        strata = {"total": quintile(frac["neuron"]) * 25 + quintile(frac["oligo"]) * 5 + quintile(frac["astro"])}
        strata["within_composition"] = strata["total"] * 5 + quintile(frac["micro"])
        pl0 = np.load(rdir / f"plaque_grid_{thr}.npy")
        pl0 = pl0 > 0.25 * pl0.max()
        by = np.clip(bins["by"].to_numpy(), 0, pl0.shape[0] - 1)
        bx = np.clip(bins["bx"].to_numpy(), 0, pl0.shape[1] - 1)

        tot = np.asarray(X.sum(0)).ravel()
        pool = np.flatnonzero(tot >= 50)
        gb = np.full(len(genes), -1)
        gb[pool] = pd.qcut(pd.Series(np.log(tot[pool])).rank(method="first"), 20, labels=False).to_numpy()
        by_bin = {b: pool[gb[pool] == b] for b in range(20)}
        sets = {}
        for name, gs in sets_all.items():
            gi = gpos.reindex(gs).dropna().astype(int).to_numpy()
            gi = gi[gb[gi] >= 0]
            if len(gi) < 2:
                continue
            rand = np.stack([np.array([rng.choice(by_bin[b]) for b in gb[gi]]) for _ in range(args.n_sets)])
            sets[name] = (gi, rand)
        prog_cols = np.unique(np.concatenate([gi for gi, _ in sets.values()]))
        Xp = X[:, prog_cols]
        colpos = pd.Series(np.arange(len(prog_cols)), index=prog_cols)

        def contrast(pl, stratum, which_cols=None):
            d = distances(pl)[by, bx]
            near, ref = d <= 25, (d > 100) & (d <= 300)
            ns = int(stratum.max()) + 1
            In, Ir = indicator(stratum, near, ns), indicator(stratum, ref, ns)
            M = X if which_cols is None else Xp
            N, R = np.asarray((In @ M).todense()), np.asarray((Ir @ M).todense())
            return N, R, In @ umi, Ir @ umi, near.sum(), ref.sum()

        d0 = distances(pl0)[by, bx]
        for est, st in strata.items():
            N, R, T1, T0, n_near, n_ref = contrast(pl0, st)
            # spatial null: shifted plaque grids, program genes only
            shifts = []
            n = pl0.shape[0]
            while len(shifts) < args.n_shift:
                sy, sx = rng.integers(40, n - 40, size=2)
                shifts.append((sy, sx))
            sp_null = {name: [] for name in sets}
            for sy, sx in shifts:
                Ns, Rs, T1s, T0s, *_ = contrast(np.roll(np.roll(pl0, sy, 0), sx, 1), st, "prog")
                for name, (gi, _) in sets.items():
                    c = colpos[gi].to_numpy()
                    sp_null[name].append(mh_logrr(Ns[:, c].sum(1, keepdims=True), Rs[:, c].sum(1, keepdims=True), T1s, T0s)[0])
            for name, (gi, rand) in sets.items():
                obs = mh_logrr(N[:, gi].sum(1, keepdims=True), R[:, gi].sum(1, keepdims=True), T1, T0)[0]
                nl = mh_logrr(N[:, rand].sum(2), R[:, rand].sum(2), T1, T0)
                spn = np.array(sp_null[name])
                store[(prefix, est, name)] = (obs, nl, spn)
                rows.append({"section": prefix, "group": group, "estimand": est, "set": name,
                             "family": "DDR" if name in DDR else "control", "n_genes": len(gi), "n_near": int(n_near),
                             "n_ref": int(n_ref), "rr": np.exp(obs), "null_set_rr": np.exp(nl.mean()),
                             "excess_log": obs - nl.mean(),
                             "p_set": (np.sum(np.abs(nl - nl.mean()) >= abs(obs - nl.mean())) + 1) / (len(nl) + 1),
                             "null_spatial_rr": np.exp(spn.mean()),
                             "p_spatial": (np.sum(np.abs(spn - spn.mean()) >= abs(obs - spn.mean())) + 1) / (len(spn) + 1),
                             "registration_r": reg["r"], "registration_null_max": reg["null_max"]})
        print(f"  {prefix}: {keep.sum()} bins, near {int((d0 <= 25).sum())}, ref {int(((d0 > 100) & (d0 <= 300)).sum())}",
              flush=True)

    sec = pd.DataFrame(rows)
    sec.to_csv(out / "section_effects.csv", index=False)
    pooled = []
    for (group, est, name), d in sec.groupby(["group", "estimand", "set"]):
        obs = np.mean([store[(p, est, name)][0] for p in d["section"]])
        nl = np.mean([store[(p, est, name)][1] for p in d["section"]], axis=0)
        spn = np.mean([store[(p, est, name)][2] for p in d["section"]], axis=0)
        pooled.append({"group": group, "estimand": est, "set": name, "family": d["family"].iloc[0],
                       "n_sections": len(d), "rr": np.exp(obs), "excess_log_vs_sets": obs - nl.mean(),
                       "p_set": (np.sum(np.abs(nl - nl.mean()) >= abs(obs - nl.mean())) + 1) / (len(nl) + 1),
                       "excess_log_vs_spatial": obs - spn.mean(),
                       "p_spatial": (np.sum(np.abs(spn - spn.mean()) >= abs(obs - spn.mean())) + 1) / (len(spn) + 1),
                       "sections_same_sign": int(np.sum(np.sign(d["excess_log"]) == np.sign(obs - nl.mean()))),
                       "null_set_sd_log": nl.std(), "null_spatial_sd_log": spn.std()})
    pooled = pd.DataFrame(pooled)
    for col in ("p_set", "p_spatial"):
        pooled[f"q_{col[2:]}"] = np.nan
        for key, d in pooled[pooled["family"] == "DDR"].groupby(["group", "estimand"]):
            pooled.loc[d.index, f"q_{col[2:]}"] = bh(d[col].to_numpy())
    pooled = pooled.sort_values(["group", "estimand", "family", "p_set"])
    pooled.to_csv(out / "pooled_effects.csv", index=False)
    print(pooled.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
