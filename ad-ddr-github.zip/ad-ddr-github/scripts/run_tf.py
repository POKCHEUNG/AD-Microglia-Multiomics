"""Transcription-factor activity vs CPS (RNA, 73 donors) and TP53-site accessibility (multiome).

    python scripts/run_tf.py --out results/tf

A. RNA (MTG, 73 non-severely-affected donors). Per cell class, log2 CPM of expressed genes
   is z-scored across donors; TF activity per donor = decoupler ULM on CollecTRI. Partial r
   with CPS (age, sex, PMI). Pre-specified: TP53 in excitatory and inhibitory neurons
   (expected to rise). Null: 500 random regulons per TF with the same number of targets and
   the same signs, targets matched on mean expression.
   Exploratory: every TF with >= 15 expressed targets, in neurons and microglia.
B. Multiome (10 donors with >= 500 paired nuclei). Accessibility of consensus TP53 ChIP-seq
   sites (ChIP-Atlas, >= 10 experiments) vs accessibility-matched background peaks, per
   (cell class, donor); compared with RNA TP53 activity in the same donors.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import decoupler as dc
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ad_ddr import cohort, io, scoring, stats
from ddrmulti import atac as datac
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
EXC, INH, MICRO = cohort.EXC, cohort.INH, "Microglia-PVM"
COV = ["age", "sex", "pmi"]
NON_NEURONAL = ("Astrocyte", "Oligo", "OPC", "Endothelial", "VLMC", "Ependymal")


def zmatrix(idx, C, genes, donors, level, grp):
    m = ((idx.level == level) & (idx.group == grp) & idx.donor.isin(donors.index) & (idx.n_nuclei >= 20)).to_numpy()
    d = idx[m]
    cpm = C[m] / C[m].sum(1, keepdims=True) * 1e6
    keep = (cpm >= 1).mean(0) >= 0.5
    L = np.log2(cpm[:, keep] + 1)
    Z = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
    df = pd.DataFrame(Z, index=d.donor.to_numpy(), columns=genes[keep])
    mean_expr = pd.Series(L.mean(0), index=genes[keep])
    dup = df.columns.duplicated()
    return df.loc[:, ~dup], mean_expr[~dup]


def ulm(Z: pd.DataFrame, net: pd.DataFrame, tmin: int = 15) -> pd.DataFrame:
    est, _ = dc.mt.ulm(data=Z, net=net, tmin=tmin, verbose=False)
    return est


def random_regulons(net_tf: pd.DataFrame, genes: pd.Index, mean_expr: pd.Series, n: int, rng) -> pd.DataFrame:
    """n random regulons with the same size and signs as ``net_tf``, targets matched on expression decile."""
    bins = pd.qcut(mean_expr.rank(method="first"), 10, labels=False)
    by_bin = {b: genes[(bins == b).to_numpy()].to_numpy() for b in range(10)}
    tb = bins.reindex(net_tf.target).to_numpy()
    rows = []
    for k in range(n):
        tg = [rng.choice(by_bin[b]) for b in tb]
        rows.append(pd.DataFrame({"source": f"R{k}", "target": tg, "weight": net_tf.weight.to_numpy()}))
    return pd.concat(rows).drop_duplicates(["source", "target"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/tf")
    ap.add_argument("--n-random", type=int, default=500)
    ap.add_argument("--min-paired", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    s = pd.read_csv(ROOT / "results/cohort/scores.csv.gz")
    donors = s[(s.region == "MTG") & ~s.severe].drop_duplicates("donor").set_index("donor")[["cps", "age", "sex", "pmi"]]
    donors[["age", "pmi"]] = donors[["age", "pmi"]].apply(pd.to_numeric, errors="coerce")
    donors = donors.dropna()
    net = pd.read_csv(ROOT / "data/ref/collectri_human.csv")[["source", "target", "weight"]]

    paths = [p for p in sorted((ROOT / "data/raw/pseudobulk").glob("*.h5ad")) if not any(k in p.stem for k in NON_NEURONAL)]
    idx, C, genes, _ = cohort.aggregate(paths, regions=["MTG"])

    # ---- A. RNA TF activity --------------------------------------------------
    allres, prim, acts, tp53_null = [], [], {}, {}
    for name, (level, grp) in {"Glutamatergic": ("class", EXC), "GABAergic": ("class", INH),
                               "Microglia": ("group", MICRO)}.items():
        Z, mexpr = zmatrix(idx, C, genes, donors, level, grp)
        d = donors.loc[Z.index]
        act = ulm(Z, net)
        acts[name] = act
        tab = d.join(act).reset_index(names="donor").assign(k=name)
        res = stats.cps_association(tab, list(act.columns), groupby="k", covariates=COV, n_perm=2000,
                                    seed=args.seed, min_donors=10)
        res["cells"] = name
        # random-regulon null for every TF: 500 draws for TP53 (primary), 100 for the others
        expressed_net = net[net.target.isin(Z.columns)]
        p_rand, null_mean, null_frac05 = {}, {}, {}
        for tf in res.score:
            nt = expressed_net[expressed_net.source == tf]
            rr = random_regulons(nt, Z.columns, mexpr, args.n_random if tf == "TP53" else 100, rng)
            ra = ulm(Z, rr, tmin=max(5, len(nt) // 2))
            r_null, p_null = _partial_r(ra.to_numpy(), d, COV)
            obs = res.loc[res.score == tf, "r"].iloc[0]
            null_mean[tf] = r_null.mean()
            null_frac05[tf] = (p_null < 0.05).mean()
            if tf == "TP53":
                tp53_null[name] = r_null
            p_rand[tf] = (np.sum(np.abs(r_null - r_null.mean()) >= abs(obs - r_null.mean())) + 1) / (len(r_null) + 1)
        res["null_mean"] = res.score.map(null_mean)
        res["p_vs_random"] = res.score.map(p_rand)
        res["null_frac_p05"] = res.score.map(null_frac05)
        allres.append(res)
        if name != "Microglia":
            row = res[res.score == "TP53"].iloc[0]
            prim.append({"cells": name, "tf": "TP53", "r": row.r, "p_perm": row.p_perm, "null_mean": row.null_mean,
                         "null_sd": tp53_null[name].std(), "null_frac_p05": row.null_frac_p05,
                         "p_vs_random": row.p_vs_random, "n_donors": row.n_donors,
                         "n_targets": int((expressed_net.source == "TP53").sum())})
        print(f"  done {name}: {len(res)} TFs", flush=True)
    allres = pd.concat(allres, ignore_index=True)
    allres["q"] = allres.groupby("cells")["p_perm"].transform(lambda p: bh(p.to_numpy()))
    allres["q_vs_random"] = allres.groupby("cells")["p_vs_random"].transform(lambda p: bh(p.to_numpy()))
    allres.rename(columns={"score": "tf"}).sort_values("p_perm").to_csv(out / "tf_vs_cps_all.csv", index=False)
    prim = pd.DataFrame(prim)
    prim["q"] = bh(prim.p_perm.to_numpy())
    prim.to_csv(out / "tf_primary_TP53.csv", index=False)
    print("\nA. Pre-specified: TP53 activity vs CPS (partial r | age+sex+pmi)")
    print(prim.to_string(index=False, float_format=lambda v: f"{v:.3f}"))
    for name, d in allres.groupby("cells"):
        print(f"\n[{name}] {len(d)} TFs: p<0.05 {(d.p_perm < 0.05).mean():.2f}; q<0.1 {(d.q < 0.1).sum()}; "
              f"random regulons with p<0.05: {d.null_frac_p05.mean():.2f}; beyond random (q_vs_random<0.1): {(d.q_vs_random < 0.1).sum()}")
        top = d[d.q_vs_random < 0.1].sort_values("p_vs_random").head(8)
        if len(top):
            print(top[["score", "r", "p_perm", "null_mean", "p_vs_random", "q_vs_random"]].to_string(
                index=False, float_format=lambda v: f"{v:.3g}"))

    # ---- B. multiome: TP53-site accessibility --------------------------------
    sites = pd.read_csv(ROOT / "data/ref/chipatlas/TP53_consensus_ge10.bed", sep="\t", header=None,
                        names=["chrom", "start", "end", "n_exp"])
    acc = scoring.AtacAccumulator()
    for d in io.selected_donors(ROOT / "data/meta/selected_donors.csv"):
        rna, atac = io.load_donor(*io.donor_paths(ROOT / "data/raw", d))
        del rna
        keep = atac.obs["class"].isin([EXC, INH]).to_numpy()
        if atac.n_obs < args.min_paired:
            continue
        acc.add(atac[keep], atac.obs.loc[keep, "class"].str.replace("Neuronal: ", ""), d)
        del atac
    from anndata import AnnData
    holder = AnnData(np.zeros((1, len(acc.var)), np.float32), var=acc.var)
    mask = datac.peakset_mask(holder, sites[["chrom", "start", "end"]])
    keys = [k for k in acc.counts if acc.n_cells[k] >= 20]
    Cm = np.vstack([acc.counts[k] for k in keys])
    frac = Cm.sum(0) / Cm.sum()
    strata = pd.qcut(np.log(frac + 1e-12), 20, labels=False, duplicates="drop")
    peaks = np.flatnonzero(mask)
    bg = np.stack([np.concatenate([rng.choice(np.flatnonzero(strata == b), (strata[peaks] == b).sum())
                                   for b in np.unique(strata[peaks])]) for _ in range(100)])
    atac_score = np.log2((Cm[:, peaks].sum(1) + 1) / (Cm[:, bg].sum(2).mean(1) + 1))
    B = pd.DataFrame(keys, columns=["cells", "donor"]).assign(tp53_sites=atac_score)
    B["rna_TP53"] = [acts[c].loc[dn, "TP53"] if dn in acts[c].index else np.nan for c, dn in keys]
    B = B.join(donors[["cps"]], on="donor")
    B.to_csv(out / "tp53_sites_multiome.csv", index=False)
    print(f"\nB. TP53 ChIP-site accessibility: {mask.sum()} snATAC peaks overlap {len(sites)} consensus sites")
    for c, d in B.groupby("cells"):
        d2 = d.dropna()
        r1 = np.corrcoef(d2.tp53_sites, d2.rna_TP53)[0, 1] if len(d2) > 3 else np.nan
        r2 = np.corrcoef(d2.tp53_sites, d2.cps)[0, 1] if len(d2) > 3 else np.nan
        print(f"  {c}: n={len(d2)} donors (in both datasets); r(site accessibility, RNA TP53 activity) = {r1:+.2f}; "
              f"r(site accessibility, CPS) = {r2:+.2f}  (descriptive)")

    # ---- figure ----------------------------------------------------------------
    fig, ax = plt.subplots(1, 2, figsize=(10.5, 3.8))
    for name, color in (("Glutamatergic", "#d9822b"), ("GABAergic", "#3b6fb6")):
        ax[0].hist(tp53_null[name], bins=30, alpha=0.45, color=color, label=f"{name}: random regulons")
        obs = prim.loc[prim.cells == name, "r"].iloc[0]
        ax[0].axvline(obs, color=color, lw=2)
    ax[0].set_xlabel("partial r with CPS")
    ax[0].set_ylabel("random regulons")
    ax[0].set_title("TP53 activity (lines) vs 500 matched random regulons", fontsize=9)
    ax[0].legend(fontsize=7, frameon=False)
    for c, d in B.groupby("cells"):
        ax[1].scatter(d.rna_TP53, d.tp53_sites, s=30, label=c)
    ax[1].set_xlabel("RNA TP53 activity (ULM)")
    ax[1].set_ylabel("TP53 ChIP-site accessibility (log2 vs background)")
    ax[1].set_title("Multiome: RNA activity vs chromatin at TP53 sites", fontsize=9)
    ax[1].legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(out / "tf.png", dpi=160)
    print(f"\nwrote {out}")


def _partial_r(Y: np.ndarray, d: pd.DataFrame, cov: list[str]) -> tuple[np.ndarray, np.ndarray]:
    from run_ccc import partial_r
    Z = pd.get_dummies(d[cov], drop_first=True, dtype=float).to_numpy()
    return partial_r(Y, d["cps"].to_numpy(float), Z)


if __name__ == "__main__":
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    main()
