"""Whole-transcriptome spatial DDR: Miyoshi et al. 2024 (GSE233208), human PFC Visium.

    python scripts/run_visium.py --out results/visium

Fixed before looking at the scores:
* spot scores: ln(CP10K+1); programs scored with fixed expression-matched control genes
* each score is residualised at spot level on the authors' deconvolved cell fractions
  (EX, INH, MG, ASC, ODC, OPC; VASC dropped as reference), log UMI and layer annotation,
  so a score reflects expression per cell type mix, not composition or depth
* spot sets: neuronal (EX + INH >= 0.5) for DDR programs; microglia-rich (MG >= 0.2)
  for DAM and cGAS-STING/IFN
* unit = donor (one control donor has 8 sections); Control / earlyAD / AD as ordinal
  0/1/2 (24 donors), partial r adjusting for age and sex, permutation p, BH within the 7
  pre-specified tests; AD_DS donors (ages 43-66) have no age-matched controls here, so
  their difference from controls is reported descriptively only
* every test is also compared with 100 random expression-matched programs
A. disease trend; B. per cortical layer (exploratory); C. within-section association of
   neuronal DDR residual with microglial fraction in neighbouring spots.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import anndata as ad
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats as sst

from ad_ddr import cellstate as cs
from ad_ddr import scoring, stats
from ad_ddr.signatures import NEURONAL_REPAIR, all_programs
from ddrmulti.stats import bh

ROOT = Path(__file__).resolve().parents[1]
DECONV = ["EX_deconv", "INH_deconv", "MG_deconv", "ASC_deconv", "ODC_deconv", "OPC_deconv"]
DX_ORDER = {"Control": 0, "earlyAD": 1, "AD": 2}
DDR = NEURONAL_REPAIR + ["p53_targets"]
GLIA = ["DAM", "cGAS_STING_IFN"]


def residualise(obs: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    Z = pd.concat([obs[DECONV], np.log10(obs["nCount_Spatial"]).rename("log_umi"),
                   pd.get_dummies(obs["annotation"], drop_first=True, dtype=float)], axis=1).to_numpy(float)
    Z1 = np.column_stack([np.ones(len(Z)), Z])
    Y = obs[cols].to_numpy(float)
    beta, *_ = np.linalg.lstsq(Z1, Y, rcond=None)
    return pd.DataFrame(Y - Z1 @ beta, index=obs.index, columns=cols)


def neighbour_mean(obs: pd.DataFrame, value: str) -> pd.Series:
    """Mean of ``value`` over the 6 hexagonal neighbours on the Visium grid, within each section."""
    out = pd.Series(np.nan, index=obs.index)
    offsets = [(0, 2), (0, -2), (1, 1), (1, -1), (-1, 1), (-1, -1)]
    for _, d in obs.groupby("Sample"):
        key = pd.Series(d[value].to_numpy(), index=pd.MultiIndex.from_arrays([d["row"].astype(int), d["col"].astype(int)]))
        vals = np.column_stack([key.reindex(pd.MultiIndex.from_arrays([d["row"].astype(int) + dr, d["col"].astype(int) + dc])).to_numpy()
                                for dr, dc in offsets])
        out.loc[d.index] = np.nanmean(np.where(np.isnan(vals), np.nan, vals), axis=1)
    return out


def donor_table(res: pd.DataFrame, obs: pd.DataFrame, mask: np.ndarray, cols: list[str]) -> pd.DataFrame:
    g = res[mask].groupby(obs.loc[mask, "donor"])
    t = g[cols].mean()
    t["n_spots"] = g.size()
    info = obs.drop_duplicates("donor").set_index("donor")[["Diagnosis", "Age", "Sex"]]
    return t.join(info).rename(columns={"Age": "age", "Sex": "sex"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/visium")
    ap.add_argument("--n-random", type=int, default=100)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--spots", choices=["prespecified", "grey_matter"], default="prespecified",
                    help="grey_matter (post hoc sensitivity): all non-white-matter spots for every program")
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    a = ad.read_h5ad(ROOT / "data/raw/miyoshi/miyoshi_visium.h5ad")
    X = sp.csr_matrix(a.X, dtype=np.float32)
    X = sp.diags(1e4 / np.maximum(np.asarray(X.sum(1)).ravel(), 1)) @ X
    X.data = np.log1p(X.data)
    a.X = X
    progs = {k: v for k, v in all_programs().items() if k in DDR + GLIA}
    ref = a[rng.choice(a.n_obs, 20000, replace=False)]
    base = scoring.ProgramScorer(progs, seed=args.seed).fit(ref)
    reps = cs.matched_random_programs(base.mean_, a.var_names, progs, args.n_random, seed=args.seed)
    allp = dict(progs)
    for k, rep in enumerate(reps):
        allp.update({f"r{k}_{n}": g for n, g in rep.items()})
    scorer = scoring.ProgramScorer(allp, seed=args.seed).fit(ref)
    sc_ = scorer.score(a)
    print(f"spots {a.n_obs:,}; scored {sc_.shape[1]} programs", flush=True)

    obs = a.obs.copy()
    res = residualise(obs.join(sc_), list(sc_.columns))
    neuro = (obs.EX_deconv + obs.INH_deconv >= 0.5).to_numpy()
    micro = (obs.MG_deconv >= 0.2).to_numpy()
    if args.spots == "grey_matter":
        neuro = micro = ~obs.annotation.astype(str).str.startswith("WM").to_numpy()
    print(f"neuronal spots {neuro.sum():,}; microglia-rich spots {micro.sum():,}")

    # ---- A. disease trend ---------------------------------------------------
    rows, donor_tabs = [], {}
    for prog in DDR + GLIA:
        mask = micro if prog in GLIA else neuro
        cols = [f"rna_{prog}"] + [f"rna_r{k}_{prog}" for k in range(args.n_random)]
        t = donor_table(res, obs, mask, cols)
        donor_tabs[prog] = t
        tt = t[t.Diagnosis.isin(DX_ORDER)].assign(dx=lambda d: d.Diagnosis.map(DX_ORDER), k="x").reset_index(names="donor")
        r = stats.cps_association(tt, cols, groupby="k", x="dx", covariates=["age", "sex"], n_perm=5000,
                                  seed=args.seed, min_donors=10).set_index("score")
        obs_r, null = r.loc[cols[0], "r"], r.loc[cols[1:], "r"].to_numpy()
        ds = t[t.Diagnosis.isin(["AD_DS", "Control"])]
        rows.append({"program": prog, "spots": "microglia-rich" if prog in GLIA else "neuronal", "r_trend": obs_r,
                     "p_perm": r.loc[cols[0], "p_perm"], "n_donors": int(r.loc[cols[0], "n_donors"]),
                     "null_mean": null.mean(), "null_sd": null.std(),
                     "p_vs_random": (np.sum(np.abs(null - null.mean()) >= abs(obs_r - null.mean())) + 1) / (len(null) + 1),
                     "AD_DS_minus_control": ds.loc[ds.Diagnosis == "AD_DS", cols[0]].mean() - ds.loc[ds.Diagnosis == "Control", cols[0]].mean()})
    A = pd.DataFrame(rows)
    A["q"] = bh(A.p_perm.to_numpy())
    A.to_csv(out / "visium_disease_trend.csv", index=False)
    print("\nA. Control -> earlyAD -> AD trend (donor means of composition/depth/layer-adjusted spot scores)")
    print(A.to_string(index=False, float_format=lambda v: f"{v:.3f}"))

    # ---- B. per layer (exploratory) -------------------------------------------
    brow = []
    for layer in ["L1", "L2/3", "L3/4", "L3/4/5", "L5/6", "L6b"]:
        lm = neuro & (obs.annotation == layer).to_numpy()
        for prog in DDR:
            cols = [f"rna_{prog}"] + [f"rna_r{k}_{prog}" for k in range(args.n_random)]
            t = donor_table(res, obs, lm, cols)
            tt = t[t.Diagnosis.isin(DX_ORDER) & (t.n_spots >= 20)].assign(dx=lambda d: d.Diagnosis.map(DX_ORDER), k="x").reset_index(names="donor")
            if len(tt) < 10:
                continue
            r = stats.cps_association(tt, cols, groupby="k", x="dx", covariates=["age", "sex"], n_perm=1000,
                                      seed=args.seed, min_donors=10).set_index("score")
            o, null = r.loc[cols[0], "r"], r.loc[cols[1:], "r"].to_numpy()
            brow.append({"layer": layer, "program": prog, "r_trend": o, "p_perm": r.loc[cols[0], "p_perm"],
                         "p_vs_random": (np.sum(np.abs(null - null.mean()) >= abs(o - null.mean())) + 1) / (len(null) + 1),
                         "n_donors": len(tt)})
    B = pd.DataFrame(brow)
    B["q_vs_random"] = bh(B.p_vs_random.to_numpy())
    B.to_csv(out / "visium_layers.csv", index=False)
    print(f"\nB. per layer: {len(B)} tests; p_perm<0.05: {(B.p_perm < 0.05).sum()}; beyond random (q<0.1): {(B.q_vs_random < 0.1).sum()}")
    print(B.sort_values("p_vs_random").head(6).to_string(index=False, float_format=lambda v: f"{v:.3f}"))

    # ---- C. neuronal DDR vs neighbouring microglia --------------------------
    obs["MG_neigh"] = neighbour_mean(obs, "MG_deconv")
    crow = []
    comp = [f"rna_{p}" for p in DDR]
    rand_comp = [[f"rna_r{k}_{p}" for p in DDR] for k in range(args.n_random)]
    for sample, d in obs[neuro].groupby("Sample"):
        dd = d.dropna(subset=["MG_neigh"])
        if len(dd) < 100:
            continue
        rr = res.loc[dd.index]
        real = sst.spearmanr(rr[comp].mean(1), dd.MG_neigh).statistic
        null = np.array([sst.spearmanr(rr[c].mean(1), dd.MG_neigh).statistic for c in rand_comp])
        crow.append({"Sample": sample, "donor": dd.donor.iloc[0], "Diagnosis": dd.Diagnosis.iloc[0], "rho": real,
                     "rho_null_mean": null.mean(), "excess": real - null.mean(), "n_spots": len(dd)})
    Csec = pd.DataFrame(crow)
    Cd = Csec.groupby("donor").agg(Diagnosis=("Diagnosis", "first"), rho=("rho", "mean"), excess=("excess", "mean"))
    rng2 = np.random.default_rng(1)
    flips = (rng2.choice([-1, 1], (20000, len(Cd))) * Cd.excess.to_numpy()).mean(1)
    p_c = (np.sum(np.abs(flips) >= abs(Cd.excess.mean())) + 1) / 20001
    Csec.to_csv(out / "visium_ddr_vs_neighbour_microglia.csv", index=False)
    print(f"\nC. neuronal DDR composite vs neighbouring microglial fraction (within section, {len(Csec)} sections, "
          f"{len(Cd)} donors): mean rho {Cd.rho.mean():+.3f}; excess over random programs {Cd.excess.mean():+.3f} (p = {p_c:.3f})")
    print(Cd.groupby("Diagnosis")[["rho", "excess"]].mean().round(3).to_string())

    # ---- figure ----------------------------------------------------------------
    fig, ax = plt.subplots(1, 3, figsize=(14, 3.9))
    y = np.arange(len(A))
    ax[0].errorbar(A.null_mean, y, xerr=1.96 * A.null_sd, fmt="none", ecolor="0.7", elinewidth=6, alpha=0.6)
    ax[0].scatter(A.r_trend, y, color="#c0392b", zorder=3, label="program")
    ax[0].axvline(0, color="0.5", lw=0.8)
    ax[0].set_yticks(y, A.program + " (" + A.spots.str[:5] + ")", fontsize=8)
    ax[0].invert_yaxis()
    ax[0].set_xlabel("partial r with Control/earlyAD/AD (grey: random 95%)")
    ax[0].set_title(f"A. Disease trend ({A.n_donors.max()} donors)", fontsize=9)
    for prog, color in (("BER", "#3b6fb6"), ("DAM", "#2e8b57")):
        t = donor_tabs[prog]
        for dx, i in {"Control": 0, "earlyAD": 1, "AD": 2, "AD_DS": 3}.items():
            v = t.loc[t.Diagnosis == dx, f"rna_{prog}"]
            ax[1].scatter(np.full(len(v), i) + (0.12 if prog == "DAM" else -0.12) + rng.uniform(-0.05, 0.05, len(v)), v,
                          s=18, color=color, label=prog if dx == "Control" else None)
    ax[1].set_xticks(range(4), ["Control", "earlyAD", "AD", "AD_DS"], fontsize=8)
    ax[1].axhline(0, color="0.6", lw=0.8)
    ax[1].set_ylabel("donor mean residual score")
    ax[1].set_title("Donor-level residual scores", fontsize=9)
    ax[1].legend(fontsize=7, frameon=False)
    order = ["Control", "earlyAD", "AD", "AD_DS"]
    ax[2].boxplot([Cd.loc[Cd.Diagnosis == g, "excess"] for g in order], tick_labels=order)
    ax[2].axhline(0, color="0.6", lw=0.8)
    ax[2].set_ylabel("rho excess over random programs")
    ax[2].set_title(f"C. Neuronal DDR vs neighbouring microglia (p = {p_c:.2f})", fontsize=9)
    fig.tight_layout()
    fig.savefig(out / "visium.png", dpi=160)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
