"""Nucleus-level test of the homeostatic shift in SEA-AD: location shift or a growing DAM-like tail? (README 42)

    ./scripts/stream_atac_micro_cells.sh 3      # first: per-nucleus microglia counts of the 86 donors
    python scripts/seaad_nucleus_shift.py       # writes results/homeostatic_shift/nucleus_*.csv

Per nucleus (Micro-PVM_2 unless stated): chromatin DAM score = log((counts in DAM-open peaks + 0.5) /
(counts in DAM-closed peaks + 0.5)), minus its expectation for the nucleus' depth (quadratic in log
counts in tested peaks, fitted on all microglia). A second score, the mean SEA-AD DAM t of the
fragments over all 32,481 tested peaks, is the sensitivity analysis.

Per donor (>= 30 Micro-PVM_2 nuclei, grey-matter 6E10 available; covariates age, sex, PMI, mean log
depth, multiome share), against log plaque density, permutation p (5,000):
  mean        the nucleus-level counterpart of the pseudobulk axis
  q10 ... q90 quantiles: a location shift moves every quantile; contamination by DAM-like nuclei
              moves mainly the upper ones
  tail        fraction of homeostatic nuclei scoring above the median DAM-like nucleus
  subsets     ATAC-only nuclei (labels transferred) vs multiome nuclei (labels from their own RNA), and
              multiome nuclei above / below the median supertype confidence or >= 0.9 (>= 15 nuclei per
              donor): label contamination predicts a shift concentrated in the less reliably labelled nuclei
Donor design: the shift in multiome donors (some nuclei labelled from their own RNA) vs ATAC-only donors
(all labels transferred through chromatin), with a Fisher-z heterogeneity test, and ATAC-only vs multiome
nuclei within the multiome donors.
Expected signature of contamination: in every donor a fraction f (rising linearly with plaque rank to
match the observed mean shift) of homeostatic nuclei is replaced by the donor's own (or pooled) DAM-like
nuclei; the quantile profile of that simulation is compared with the observed one.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp

from ad_ddr.stats import _covar_matrix, _resid
from run_dam_peaks import DAM, HOM

ROOT = Path(__file__).resolve().parents[1]
CELLS = ROOT / "data/processed/atac_micro_cells"
OUT = ROOT / "results/homeostatic_shift"
QS = [10, 25, 50, 75, 90]


def part_r(x, y, C, rng, n_perm=5000):
    xr, yr = _resid(x, C), _resid(y, C)
    r = np.corrcoef(xr, yr)[0, 1]
    null = np.array([np.corrcoef(rng.permutation(xr), yr)[0, 1] for _ in range(n_perm)])
    return r, (np.sum(np.abs(null) >= abs(r)) + 1) / (n_perm + 1)


def main():
    rng = np.random.default_rng(0)
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    op = (res["call"] == "DAM-open").to_numpy()
    cl = (res["call"] == "DAM-closed").to_numpy()
    t = res["t"].to_numpy()
    frames, Xs = [], []
    for f in sorted(CELLS.glob("*.npz")):
        frames.append(pd.read_csv(f.with_suffix(".csv")))
        Xs.append(sp.load_npz(f))
    cells = pd.concat(frames, ignore_index=True)
    X = sp.vstack(Xs).tocsr()
    depth = np.asarray(X.sum(1)).ravel()
    o = np.asarray(X[:, op].sum(1)).ravel()
    c = np.asarray(X[:, cl].sum(1)).ravel()
    lr = np.log((o + 0.5) / (c + 0.5))
    ts = np.asarray(X @ t).ravel() / np.maximum(depth, 1)
    ld = np.log10(np.maximum(depth, 1))
    good = depth >= 300
    for name, v in (("lr", lr), ("ts", ts)):
        coef = np.polyfit(ld[good], v[good], 2)
        cells[name] = v - np.polyval(coef, ld)
    cells["log_depth"] = ld
    cells = cells[good].reset_index(drop=True)
    print(f"{cells['donor'].nunique()} donors, {len(cells):,} microglia with >= 300 counts in tested peaks; "
          f"median {np.median(depth[good]):.0f}")
    print(cells.groupby("supertype")[["lr", "ts"]].mean().round(3).to_string())

    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")["number of 6e10 positive objects per area"]
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    dam_med = {k: cells.loc[cells["supertype"] == DAM, k].median() for k in ("lr", "ts")}

    def donor_table(sub, score, min_n=30):
        rows = []
        for d, g in sub.groupby("donor"):
            if len(g) < min_n or d not in gm.index or d not in meta.index:
                continue
            v = g[score].to_numpy()
            rows.append({"donor": d, "n": len(g), "mean": v.mean(), **{f"q{q}": np.percentile(v, q) for q in QS},
                         "tail": (v > dam_med[score]).mean(), "log_depth": g["log_depth"].mean(),
                         "multi": (g["method"] == "10xMulti").mean(),
                         "age": pd.to_numeric(meta.at[d, "Age at Death"], errors="coerce"), "sex": str(meta.at[d, "Sex"]),
                         "pmi": pd.to_numeric(meta.at[d, "PMI"], errors="coerce"),
                         "plaque": np.log10(float(gm.get(d)) * 1e6 + 1)})
        return pd.DataFrame(rows).dropna(subset=["age", "pmi", "plaque"]).reset_index(drop=True)

    out = []
    hom = cells[cells["supertype"] == HOM]
    for score in ("lr", "ts"):
        D = donor_table(hom, score)
        C = _covar_matrix(D, ["age", "sex", "pmi", "log_depth", "multi"])
        for stat in ["mean"] + [f"q{q}" for q in QS] + ["tail"]:
            r, p = part_r(D["plaque"].to_numpy(float), D[stat].to_numpy(float), C, rng)
            out.append({"score": score, "nuclei": "Micro-PVM_2, all", "statistic": stat, "n_donors": len(D), "r": r, "p_perm": p})
        D.to_csv(OUT / f"nucleus_donors_{score}.csv", index=False)
        multi = hom["method"] == "10xMulti"
        conf = hom["supertype_conf"]
        cq = conf[multi].median()
        subsets = {"Micro-PVM_2, ATAC-only (transferred labels)": hom[~multi],
                   "Micro-PVM_2, multiome (labels from own RNA)": hom[multi],
                   f"Micro-PVM_2, multiome, confidence >= median ({cq:.2f})": hom[multi & (conf >= cq)],
                   f"Micro-PVM_2, multiome, confidence < median": hom[multi & (conf < cq)],
                   "Micro-PVM_2, multiome, confidence >= 0.9": hom[multi & (conf >= 0.9)]}
        for lab, sub in subsets.items():
            Dh = donor_table(sub, score, min_n=15)
            if len(Dh) < 12:
                continue
            Ch = _covar_matrix(Dh, ["age", "sex", "pmi", "log_depth"])
            for stat in ("mean", "q50"):
                r, p = part_r(Dh["plaque"].to_numpy(float), Dh[stat].to_numpy(float), Ch, rng)
                out.append({"score": score, "nuclei": lab, "statistic": stat, "n_donors": len(Dh), "r": r, "p_perm": p})

    # donor design: multiome donors (part of their nuclei labelled from their own RNA) vs ATAC-only donors
    # (every label transferred from RNA through chromatin); within-donor chemistry comparison
    for score in ("lr", "ts"):
        D = pd.read_csv(OUT / f"nucleus_donors_{score}.csv")
        D["design"] = np.where(D["multi"] > 0.2, "multiome donors", "ATAC-only donors")
        zs = {}
        for des, S in D.groupby("design"):
            S = S.reset_index(drop=True)
            Cs = _covar_matrix(S, ["age", "sex", "pmi", "log_depth"])
            r, p = part_r(S["plaque"].to_numpy(float), S["mean"].to_numpy(float), Cs, rng)
            bs = []
            for _ in range(2000):
                ix = rng.choice(len(S), len(S))
                if np.linalg.matrix_rank(np.column_stack([np.ones(len(ix)), Cs[ix]])) < Cs.shape[1] + 1:
                    continue
                bs.append(np.corrcoef(_resid(S["plaque"].to_numpy(float)[ix], Cs[ix]), _resid(S["mean"].to_numpy(float)[ix], Cs[ix]))[0, 1])
            zs[des] = (np.arctanh(r), len(S) - 3 - Cs.shape[1])
            out.append({"score": score, "nuclei": f"Micro-PVM_2, {des}", "statistic": "mean", "n_donors": len(S), "r": r,
                        "p_perm": p, "ci_lo": np.nanpercentile(bs, 2.5), "ci_hi": np.nanpercentile(bs, 97.5)})
        (z1, n1), (z2, n2) = zs["ATAC-only donors"], zs["multiome donors"]
        zdiff = (z1 - z2) / np.sqrt(1 / n1 + 1 / n2)
        from scipy import stats as st_
        out.append({"score": score, "nuclei": "heterogeneity ATAC-only vs multiome donors", "statistic": "Fisher z difference",
                    "n_donors": len(D), "r": zdiff, "p_perm": 2 * st_.norm.sf(abs(zdiff))})
    both = [d for d, g in hom.groupby("donor") if (g["method"] == "10xMulti").sum() >= 15 and (g["method"] != "10xMulti").sum() >= 15]
    for chem, lab in (("10xATAC_v1.1", "ATAC-only nuclei"), ("10xMulti", "multiome nuclei")):
        Dc = donor_table(hom[hom["donor"].isin(both) & (hom["method"] == chem)], "lr", min_n=15)
        Cc = _covar_matrix(Dc, ["age", "sex", "pmi", "log_depth"])
        r, p = part_r(Dc["plaque"].to_numpy(float), Dc["mean"].to_numpy(float), Cc, rng)
        out.append({"score": "lr", "nuclei": f"multiome donors, {lab}", "statistic": "mean", "n_donors": len(Dc), "r": r, "p_perm": p})

    # contamination signature by simulation (primary score)
    D = donor_table(hom, "lr")
    C = _covar_matrix(D, ["age", "sex", "pmi", "log_depth", "multi"])
    dam_cells = cells[cells["supertype"] == DAM]
    obs_mean_slope = np.linalg.lstsq(np.column_stack([D["plaque"], C]), D["mean"], rcond=None)[0][0]
    gap = dam_cells["lr"].mean() - hom["lr"].mean()
    rank = (D["plaque"].rank() - 1) / (len(D) - 1)
    span = D["plaque"].max() - D["plaque"].min()
    f_max = float(np.clip(obs_mean_slope * span / gap, 0, 0.9))
    sims = []
    for rep in range(50):
        rows = []
        for i, d in enumerate(D["donor"]):
            v = hom.loc[hom["donor"] == d, "lr"].to_numpy().copy()
            k = rng.random(len(v)) < f_max * rank.iat[i]
            own = dam_cells.loc[dam_cells["donor"] == d, "lr"].to_numpy()
            pool = own if len(own) >= 5 else dam_cells["lr"].to_numpy()
            v[k] = rng.choice(pool, k.sum())
            rows.append([v.mean()] + [np.percentile(v, q) for q in QS])
        S = np.array(rows)
        sims.append([np.corrcoef(_resid(D["plaque"].to_numpy(float), C), _resid(S[:, j], C))[0, 1] for j in range(S.shape[1])])
    sims = np.array(sims)
    for j, stat in enumerate(["mean"] + [f"q{q}" for q in QS]):
        out.append({"score": "lr", "nuclei": f"simulated contamination (f up to {f_max:.0%})", "statistic": stat,
                    "n_donors": len(D), "r": sims[:, j].mean(), "p_perm": np.nan})
    O = pd.DataFrame(out)
    O.to_csv(OUT / "nucleus_shift.csv", index=False)
    pd.set_option("display.width", 200)
    print(f"\nDAM-like minus homeostatic nucleus score gap {gap:.3f}; contamination needed to match the mean shift: "
          f"f rising to {f_max:.0%}")
    print(O.to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
