"""Pick a balanced donor subset of SEA-AD MTG for multiome DDR analysis.

Rules: has snMultiome and per-donor RNA+ATAC objects on S3, not a severely affected
donor, prefer MERFISH-profiled donors and no neocortical Lewy body disease;
N donors per ADNC level, spread across age. Writes data/meta/selected_donors.csv.
"""
import csv
import re
import sys

N_PER_GROUP = int(sys.argv[1]) if len(sys.argv) > 1 else 3
LEVELS = ["Not AD", "Low", "Intermediate", "High"]

keys = open("data/meta/s3_donor_objects.txt").read().split()
rna = {re.match(r"(H\d+\.\d+\.\d+)_", k.split("/")[-1]).group(1): k for k in keys if "/RNAseq/" in k}
atac = {re.match(r"(H\d+\.\d+\.\d+)_", k.split("/")[-1]).group(1): k for k in keys if "/ATACseq/" in k}

rows = [r for r in csv.DictReader(open("data/meta/donor_table.csv"))]
ok = [
    r for r in rows
    if r["snMultiome"] == "Y" and r["Severely Affected Donor"] != "Y"
    and r["Donor ID"] in rna and r["Donor ID"] in atac
]

def rank(r):
    lewy = "Neocortical" in r["Highest Lewy Body Disease"]
    return (lewy, r["MERFISH2"] != "Y")

out = []
for lvl in LEVELS:
    grp = sorted((r for r in ok if r["Overall AD neuropathological Change"] == lvl), key=rank)
    best = [r for r in grp if rank(r) == rank(grp[0])] if grp else []
    pool = best if len(best) >= N_PER_GROUP else grp
    pool = sorted(pool[: max(N_PER_GROUP, len(best))], key=lambda r: int(r["Age at Death"]))
    # spread across age: take evenly spaced picks
    step = max(1, len(pool) / N_PER_GROUP)
    picks = [pool[int(i * step)] for i in range(min(N_PER_GROUP, len(pool)))]
    print(f"{lvl:13} eligible={len(grp):2} picked={len(picks)}")
    out += picks

fields = ["Donor ID", "Overall AD neuropathological Change", "Braak", "Thal", "CERAD score",
          "Age at Death", "Sex", "APOE Genotype", "Cognitive Status", "Highest Lewy Body Disease",
          "LATE", "PMI", "RIN", "MERFISH2"]
with open("data/meta/selected_donors.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(fields + ["rna_key", "atac_key"])
    for r in out:
        w.writerow([r[c] for c in fields] + [rna[r["Donor ID"]], atac[r["Donor ID"]]])
