"""Within-SEA-AD replication by random donor splits (no independent cohort is available yet).

    python scripts/split_replication.py --out results/split_replication --n-splits 100

For each split the donors are divided at random into halves A and B. Each claim is
discovered or estimated in A and tested in B (donor-disjoint), and the split is repeated
to show how stable the result is.

1. DAM peaks (23 donors with enough DAM-like nuclei; halves of 11 / 12). Per peak: paired
   t in A and in B (depth-matched, as scripts/run_dam_peaks.py). Reported: Spearman of t
   across all tested peaks; for the 100 most DAM-open and 100 most DAM-closed peaks in A,
   the share with the same sign in B and with one-sided p < 0.05 in B. Same for gene
   regulatory domains (scripts/run_dam_regulatory.py definition) plus the RNA DAM-up set z.
2. Homeostatic shift. DAM axis defined in A only (top 50 open, top 75 closed peaks by t
   with |log2FC| >= 0.5, mirroring result 22); tested in every donor not in A (Micro-PVM_2,
   >= 30 nuclei, 6E10; age, sex, PMI, log nuclei) against 200 accessibility-matched random
   axes.
3. Cohesin RNA (Mathys 2023 set) vs CPS in MTG excitatory neurons and oligodendrocytes:
   partial r in A and in B (all 73 donors split), expression- and length-matched null.
4. Oligodendrocyte cohesin-site mismatch: per-donor contrast from scripts/run_cohesin_sites.py
   (robust sites), r with CPS in A and in B.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

import run_celltype_screen as screen
import run_published_sets as pubs
from ad_ddr import cohort
from ad_ddr.stats import _covar_matrix, _resid
from ddrmulti.genome import parse_peak_names, peaks_near_genes, read_gtf_genes
from run_dam_peaks import DAM, HOM, load
from run_dam_peaks import thin_mean_diff
from run_dam_regulatory import domain_diffs, donor_counts, rna_lfc

ROOT = Path(__file__).resolve().parents[1]


def paired_t(D: np.ndarray):
    n = D.shape[0]
    m, s = D.mean(0), D.std(0, ddof=1)
    t = m / (s / np.sqrt(n) + 1e-12)
    return m, t, stats.t.sf(t, n - 1), stats.t.cdf(t, n - 1)          # mean, t, p_up, p_down


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/split_replication")
    ap.add_argument("--n-splits", type=int, default=100)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    # ---------- shared inputs: DAM peaks
    d = ROOT / "data/processed/atac_pb_micro"
    peaks = parse_peak_names((d / "peaks.txt").read_text().split())
    rows, M = load(d)
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    pix = peaks.index.get_indexer(res["peak"])
    disc = pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"].tolist()
    cnt = donor_counts(rows, M, disc)
    Dpk = np.array([thin_mean_diff(cnt[x][0], cnt[x][1], rng, lambda c: np.log2(c[pix] / c.sum() * 1e6 + 1)) for x in disc])
    # gene domains
    pooled = sum(c[0] / c[0].sum() + c[1] / c[1].sum() for c in cnt.values())
    pooled = pooled / pooled.sum() * 1e6
    genes = read_gtf_genes(str(ROOT / "data/ref/gencode.v32.basic.annotation.gtf.gz"))
    use = np.flatnonzero(pooled >= 1)
    pairs = peaks_near_genes(peaks.iloc[use], genes, 50_000)
    gidx = pd.Index(sorted(pairs["gene"].unique()))
    P = sp.csr_matrix((np.ones(len(pairs)), (peaks.index.get_indexer(pairs["peak"]), gidx.get_indexer(pairs["gene"]))),
                      shape=(len(peaks), len(gidx)))
    P.data[:] = 1
    Dg = domain_diffs(cnt, disc, P, rng)
    rna, _ = rna_lfc()
    rna = rna.reindex(gidx.str.upper())
    up200 = np.flatnonzero(rna["rna_t"].rank(ascending=False).to_numpy() <= 200)
    npk = np.asarray(P.sum(0)).ravel()
    acc_g = np.log2(pooled @ P + 1)
    gstrat = (pd.qcut(pd.Series(npk).rank(method="first"), 5, labels=False).to_numpy() * 5
              + pd.qcut(pd.Series(acc_g).rank(method="first"), 5, labels=False).to_numpy())
    gby = {s: np.flatnonzero(gstrat == s) for s in np.unique(gstrat)}

    # homeostatic pool
    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")["number of 6e10 positive objects per area"]
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    severe = set(meta.index[meta["Severely Affected Donor"].astype(str).eq("Y")])
    hr = rows[rows["subclass"] == HOM]
    hn = hr.groupby("donor")["n_nuclei"].sum()
    hdon = [x for x in hn.index[hn >= 30] if x in gm.index and x in meta.index and x not in severe]
    HL = []
    for x in hdon:
        c = np.asarray(M[hr.index[hr["donor"] == x].to_numpy()].sum(0)).ravel()
        HL.append(np.log2(c[pix] / c.sum() * 1e6 + 1))
    HL = np.array(HL)
    HZ = (HL - HL.mean(0)) / np.where(HL.std(0) > 0, HL.std(0), 1)
    hinfo = pd.DataFrame({"age": pd.to_numeric(meta.loc[hdon, "Age at Death"], errors="coerce").to_numpy(),
                          "sex": meta.loc[hdon, "Sex"].astype(str).to_numpy(),
                          "pmi": pd.to_numeric(meta.loc[hdon, "PMI"], errors="coerce").to_numpy(),
                          "lognuc": np.log10(hn.loc[hdon].to_numpy(float)),
                          "x": np.log10(gm.loc[hdon].to_numpy(float) * 1e6 + 1)})
    hok = hinfo.notna().all(1).to_numpy()
    acc = np.log2(res["cpm_hom"].to_numpy() + 1)
    pbins = pd.qcut(pd.Series(acc).rank(method="first"), 20, labels=False).to_numpy()

    # cohesin RNA (excitatory, oligodendrocyte) and oligodendrocyte cohesin-site scores
    gene_len_gtf = np.log10((genes["end"] - genes["start"]).clip(lower=1))
    gene_len_gtf.index = gene_len_gtf.index.str.upper()
    gene_len_gtf = gene_len_gtf[~gene_len_gtf.index.duplicated()]
    cps = pd.read_csv(ROOT / "data/meta/Global_and_Local_CPS.csv")
    cps = cps[cps["Brain Region"] == "MTG"].set_index("Donor ID")["CPS_Local"]
    coh = {"Mathys2023_cohesin": pubs.load_sets()["Mathys2023_cohesin"]}
    rna_groups = {}
    for (level, grp), files in [(("class", cohort.EXC), pubs.EXC_FILES[:9]), (("group", "Oligodendrocyte"), ["Oligodendrocyte"])]:
        idx, C, rg, rmeta = cohort.aggregate([ROOT / f"data/raw/pseudobulk/{f}.h5ad" for f in files], regions=["MTG"])
        rmeta = rmeta.assign(age=pd.to_numeric(rmeta["age"], errors="coerce"), pmi=pd.to_numeric(rmeta["pmi"], errors="coerce"),
                             severe=rmeta["severe"].astype(str).eq("Y"))
        idx = idx.join(rmeta[["age", "sex", "pmi", "severe"]], on="donor").assign(cps=lambda z: cps.reindex(z["donor"]).to_numpy())
        k = ((idx["level"] == level) & (idx["group"] == grp) & (idx["n_nuclei"] >= 20) & ~idx["severe"].astype(bool)
             & idx[["cps", "age", "pmi"]].notna().all(1)).to_numpy()
        rna_groups[grp] = (idx[k].reset_index(drop=True).assign(log_nuclei=lambda z: np.log10(z["n_nuclei"])), C[k], rg)
    cs = pd.read_csv(ROOT / "results/cohesin_sites/donor_scores.csv.gz")
    oligo = {s: cs[(cs["cells"] == "Oligodendrocyte") & (cs["set"] == s)].reset_index(drop=True)
             for s in ("robust cohesin, no CTCF motif", "robust cohesin + CTCF motif")}
    oligo_cov = ["logfrag", "frac_multi", "lognuc", "promoter_frac", "age", "sex", "pmi"]

    rec = []
    for sp_i in range(args.n_splits):
        perm = rng.permutation(len(disc))
        A, B = perm[: len(disc) // 2], perm[len(disc) // 2:]
        mA, tA, _, _ = paired_t(Dpk[A])
        mB, tB, puB, pdB = paired_t(Dpk[B])
        topo = np.argsort(-tA)[:100]
        topc = np.argsort(tA)[:100]
        gA = paired_t(Dg[A])[1]
        gBm, gB, gpuB, gpdB = paired_t(Dg[B])
        # RNA DAM-up domain set z in B
        null = np.array([gB[[rng.choice(gby[s]) for s in gstrat[up200]]].mean() for _ in range(100)])
        r_ = {"split": sp_i,
              "peak_t_spearman_AB": stats.spearmanr(tA, tB).statistic,
              "top100_open_same_sign_B": (tB[topo] > 0).mean(), "top100_open_p05_B": (puB[topo] < 0.05).mean(),
              "top100_closed_same_sign_B": (tB[topc] < 0).mean(), "top100_closed_p05_B": (pdB[topc] < 0.05).mean(),
              "bg_frac_t_pos_B": (tB > 0).mean(),
              "domain_t_spearman_AB": stats.spearmanr(gA, gB, nan_policy="omit").statistic,
              "rna_up_domains_z_B": (np.nanmean(gB[up200]) - null.mean()) / null.std()}
        # homeostatic shift: axis from A, test on donors not in A
        cand = np.abs(mA) >= 0.5
        o = np.flatnonzero(cand & (tA > 0))[np.argsort(-tA[cand & (tA > 0)])][:50]
        c = np.flatnonzero(cand & (tA < 0))[np.argsort(tA[cand & (tA < 0)])][:75]
        keep = hok & ~np.isin(hdon, np.array(disc)[A])
        I, Lk = hinfo[keep].reset_index(drop=True), HZ[keep]
        Z = _covar_matrix(I, ["age", "sex", "pmi", "lognuc"])
        xr = _resid(I["x"].to_numpy(float), Z)
        def rax(oo, cc):
            return np.corrcoef(xr, _resid(Lk[:, oo].mean(1) - Lk[:, cc].mean(1), Z))[0, 1]
        obs = rax(o, c)
        ns = np.setdiff1d(np.arange(len(res)), np.concatenate([o, c]))
        pool = {b: ns[pbins[ns] == b] for b in range(20)}
        nl = np.array([rax(np.array([rng.choice(pool[b]) for b in pbins[o]]), np.array([rng.choice(pool[b]) for b in pbins[c]]))
                       for _ in range(200)])
        r_ |= {"shift_n_test_donors": int(keep.sum()), "shift_r": obs,
               "shift_p_set": (np.sum(np.abs(nl - nl.mean()) >= abs(obs - nl.mean())) + 1) / 201}
        # cohesin RNA halves (all MTG donors split independently)
        for grp, (base, C, rg) in rna_groups.items():
            h = rng.permutation(len(base))
            for half, ix in (("A", h[: len(h) // 2]), ("B", h[len(h) // 2:])):
                rr = screen.screen_group(C[ix], base.iloc[ix].reset_index(drop=True), rg, coh, rng, 100, 200, gene_len_gtf)[0]
                r_[f"cohesin_rna_{grp[:5]}_{half}_r"] = rr["r"]
                r_[f"cohesin_rna_{grp[:5]}_{half}_p_set"] = rr["p_set"]
        # oligodendrocyte cohesin-site mismatch halves
        for sname, df in oligo.items():
            h = rng.permutation(len(df))
            for half, ix in (("A", h[: len(h) // 2]), ("B", h[len(h) // 2:])):
                dd = df.iloc[ix].reset_index(drop=True)
                Zh = _covar_matrix(dd, oligo_cov)
                r_[f"oligo_{'noCTCF' if 'no' in sname else 'CTCF'}_{half}_r"] = np.corrcoef(
                    _resid(dd["cps"].to_numpy(float), Zh), _resid(dd["diff"].to_numpy(float), Zh))[0, 1]
        rec.append(r_)
        if sp_i % 10 == 9:
            print(f"  {sp_i + 1} splits", flush=True)
    R = pd.DataFrame(rec)
    R.to_csv(out / "splits.csv", index=False)
    summ = R.drop(columns="split").describe(percentiles=[0.05, 0.5, 0.95]).T[["mean", "5%", "50%", "95%"]]
    extra = {"shift_frac_p05": (R["shift_p_set"] < 0.05).mean(), "shift_frac_r_pos": (R["shift_r"] > 0).mean()}
    for grp in ("Neuro", "Oligo"):
        extra[f"cohesin_rna_{grp}_both_halves_p05"] = ((R[f"cohesin_rna_{grp}_A_p_set"] < 0.05)
                                                      & (R[f"cohesin_rna_{grp}_B_p_set"] < 0.05)).mean()
        extra[f"cohesin_rna_{grp}_both_halves_r_pos"] = ((R[f"cohesin_rna_{grp}_A_r"] > 0) & (R[f"cohesin_rna_{grp}_B_r"] > 0)).mean()
    for s in ("noCTCF", "CTCF"):
        extra[f"oligo_{s}_both_halves_r_neg"] = ((R[f"oligo_{s}_A_r"] < 0) & (R[f"oligo_{s}_B_r"] < 0)).mean()
    summ.to_csv(out / "summary.csv")
    pd.Series(extra).to_csv(out / "summary_fractions.csv")
    print(summ.to_string(float_format=lambda v: f"{v:.3f}"))
    print("\n" + pd.Series(extra).to_string(float_format=lambda v: f"{v:.3f}"))


if __name__ == "__main__":
    main()
