#!/usr/bin/env bash
# Stream all 86 SEA-AD MTG ATAC donor objects through extract_atac_pseudobulk.py.
# Each file is downloaded to a temporary directory, reduced to pseudobulks and deleted;
# donors already in data/raw/atac are read in place. Skips donors already extracted.
#   ./scripts/stream_atac_donors.sh [n_parallel] [out_dir] [subclass]
# With a subclass, that subclass is split by supertype (see extract_atac_pseudobulk.py).
set -euo pipefail
B=https://sea-ad-single-cell-profiling.s3.amazonaws.com
cd "$(dirname "$0")/.."
OUT=${2:-data/processed/atac_pb}
SUB=${3:-}
TMP=${TMPDIR:-/tmp}/seaad_atac_stream
mkdir -p "$OUT" "$TMP"
PY=.venv/bin/python
export B OUT TMP PY SUB

one() {
  key=$1
  d=$(basename "$key" | cut -d_ -f1)
  [ -f "$OUT/$d.npz" ] && { echo "skip $d"; return; }
  if [ -f "data/raw/atac/$d.h5ad" ]; then
    "$PY" scripts/extract_atac_pseudobulk.py "data/raw/atac/$d.h5ad" "$OUT" $SUB
  else
    f="$TMP/$d.h5ad"
    # no `curl -C - --retry`: internal retries re-append from the old offset and corrupt the file.
    # Fresh download per attempt, accepted only if the size matches Content-Length.
    want=$(curl -sI "$B/$key" | awk 'tolower($1)=="content-length:"{print $2}' | tr -d '\r')
    for attempt in 1 2 3; do
      rm -f "$f"
      curl -sS --speed-limit 100000 --speed-time 120 -o "$f" "$B/$key" || true
      [ -n "$want" ] && [ "$(stat -f %z "$f" 2>/dev/null || echo 0)" = "$want" ] && break
      echo "retry $d (attempt $attempt)"
    done
    "$PY" scripts/extract_atac_pseudobulk.py "$f" "$OUT" $SUB && rm -f "$f"
  fi
}
export -f one

# extract the first donor alone so peaks.txt is written once, then run the rest in parallel
keys=$(grep "ATACseq/donor_objects/" data/meta/s3_donor_objects.txt)
one "$(echo "$keys" | head -1)"
echo "$keys" | tail -n +2 | xargs -P "${1:-3}" -I{} bash -c 'one "$@"' _ {}
echo "extracted $(ls "$OUT"/*.npz | wc -l) donors"
