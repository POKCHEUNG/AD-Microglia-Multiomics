#!/usr/bin/env bash
# Second pass over the 23 hippocampus multiome fragment files: keep base-resolution Tn5 cut sites
# of microglia near the tested DAM peaks (extract_microglia_cuts.py) for TF footprinting.
# Fragments go to a temp file and are deleted after extraction.
# Downloads are fresh per attempt and accepted only if the size matches Content-Length
# (no `curl -C - --retry`, which can re-append and corrupt).
#   ./scripts/stream_hippo_cuts.sh [library ...]
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=data/processed/hippo_cuts
TMP=${TMPDIR:-/tmp}/hippo_cuts
mkdir -p "$OUT" "$TMP"
PY=.venv/bin/python
G=https://ftp.ncbi.nlm.nih.gov/geo

get() {   # url dest
  want=$(curl -sI "$1" | awk 'tolower($1)=="content-length:"{print $2}' | tr -d '\r')
  for attempt in 1 2 3 4 5; do
    rm -f "$2"
    curl -sS --speed-limit 50000 --speed-time 120 -o "$2" "$1" || true
    [ -n "$want" ] && [ "$(stat -f %z "$2" 2>/dev/null || echo 0)" = "$want" ] && return 0
    echo "  retry $(basename "$2") (attempt $attempt)"
    sleep 10
  done
  return 1
}

LIBS=$(cat <<'EOF'
GSM8758397 hp30 GSE288063
GSM8758398 hp32 GSE288063
GSM8758399 hp18 GSE288063
GSM8758400 ad671 GSE288063
GSM8758401 ad1551 GSE288063
GSM8758402 ad13 GSE288063
GSM8758403 ad22rep1 GSE288063
GSM8758404 ad22rep2 GSE288063
GSM8758405 ad24 GSE288063
GSM8549641 hc1153 GSE278576
GSM8549642 hc1203 GSE278576
GSM8549643 hc69984 GSE278576
GSM8549644 hc1216 GSE278576
GSM8549645 hc98 GSE278576
GSM8549646 hc12 GSE278576
GSM8549647 hc11 GSE278576
GSM8549648 hc73 GSE278576
GSM8549649 hc19 GSE278576
GSM8549650 hc26 GSE278576
GSM8549651 hc40 GSE278576
GSM8549652 hc212191 GSE278576
GSM8549653 hc35 GSE278576
GSM8549654 hc9 GSE278576
EOF
)
echo "$LIBS" | while read -r gsm lib gse; do
  if [ $# -gt 0 ] && ! printf '%s\n' "$@" | grep -qx "$lib"; then continue; fi
  [ -f "$OUT/$lib.npz" ] && { echo "skip $lib"; continue; }
  if [ "$gse" = GSE288063 ]; then
    furl="$G/samples/${gsm:0:7}nnn/$gsm/suppl/${gsm}_${lib}_fragments.tsv.gz"
  else
    furl="$G/samples/${gsm:0:7}nnn/$gsm/suppl/${gsm}_${lib}_atac_fragments.tsv.gz"
  fi
  get "$furl" "$TMP/$lib.tsv.gz"
  "$PY" scripts/extract_microglia_cuts.py "$lib" "$TMP/$lib.tsv.gz" "$OUT" && rm -f "$TMP/$lib.tsv.gz"
done
echo "extracted $(ls "$OUT"/*.npz 2>/dev/null | wc -l) libraries"
