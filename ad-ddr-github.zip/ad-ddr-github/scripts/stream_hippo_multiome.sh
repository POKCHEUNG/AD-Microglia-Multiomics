#!/usr/bin/env bash
# Stream the 23 hippocampus multiome libraries (22 donors aged 75-97; GSE288063 AD / high
# pathology, GSE278576 age-matched normals) through extract_hippo_multiome.py.
# Fragments go to a temp file and are deleted after extraction; RNA h5 files are kept.
# Downloads are fresh per attempt and accepted only if the size matches Content-Length
# (no `curl -C - --retry`, which can re-append and corrupt).
#   ./scripts/stream_hippo_multiome.sh [library ...]
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=data/processed/hippo
RNA=data/raw/hippo_multiome/rna
TMP=${TMPDIR:-/tmp}/hippo_stream
mkdir -p "$OUT" "$RNA" "$TMP"
PY=.venv/bin/python
G=https://ftp.ncbi.nlm.nih.gov/geo

get() {   # url dest
  want=$(curl -sI "$1" | awk 'tolower($1)=="content-length:"{print $2}' | tr -d '\r')
  for attempt in 1 2 3 4 5; do
    rm -f "$2"
    curl -sS --speed-limit 50000 --speed-time 120 -o "$2" "$1" || true
    [ -n "$want" ] && [ "$(stat -f %z "$2" 2>/dev/null || echo 0)" = "$want" ] && return 0
    echo "  retry $(basename "$2") (attempt $attempt)"
    sleep 10
  done
  return 1
}

LIBS=$(cat <<'EOF'
GSM8758397 hp30 GSE288063
GSM8758398 hp32 GSE288063
GSM8758399 hp18 GSE288063
GSM8758400 ad671 GSE288063
GSM8758401 ad1551 GSE288063
GSM8758402 ad13 GSE288063
GSM8758403 ad22rep1 GSE288063
GSM8758404 ad22rep2 GSE288063
GSM8758405 ad24 GSE288063
GSM8549641 hc1153 GSE278576
GSM8549642 hc1203 GSE278576
GSM8549643 hc69984 GSE278576
GSM8549644 hc1216 GSE278576
GSM8549645 hc98 GSE278576
GSM8549646 hc12 GSE278576
GSM8549647 hc11 GSE278576
GSM8549648 hc73 GSE278576
GSM8549649 hc19 GSE278576
GSM8549650 hc26 GSE278576
GSM8549651 hc40 GSE278576
GSM8549652 hc212191 GSE278576
GSM8549653 hc35 GSE278576
GSM8549654 hc9 GSE278576
EOF
)
echo "$LIBS" | while read -r gsm lib gse; do
  if [ $# -gt 0 ] && ! printf '%s\n' "$@" | grep -qx "$lib"; then continue; fi
  [ -f "$OUT/${lib}_rna_cells.npz" ] && { echo "skip $lib"; continue; }
  if [ "$gse" = GSE288063 ]; then
    furl="$G/samples/${gsm:0:7}nnn/$gsm/suppl/${gsm}_${lib}_fragments.tsv.gz"
    rurl="$G/series/GSE288nnn/GSE288063/suppl/GSE288063_${lib}_filtered_feature_bc_matrix.h5"
  else
    furl="$G/samples/${gsm:0:7}nnn/$gsm/suppl/${gsm}_${lib}_atac_fragments.tsv.gz"
    rurl="$G/series/GSE278nnn/GSE278576/suppl/GSE278576_${lib}_raw_feature_bc_matrix.h5"
  fi
  [ -f "$RNA/$lib.h5" ] || get "$rurl" "$RNA/$lib.h5"
  get "$furl" "$TMP/$lib.tsv.gz"
  "$PY" scripts/extract_hippo_multiome.py "$lib" "$TMP/$lib.tsv.gz" "$RNA/$lib.h5" "$OUT" && rm -f "$TMP/$lib.tsv.gz"
done
echo "extracted $(ls "$OUT"/*_rna_cells.npz 2>/dev/null | wc -l) libraries"
