"""Multi-signal fine-mapping (SuSiE-RSS) at the candidate AD loci with a 1000 Genomes EUR LD reference.

    python scripts/susie_finemap.py             # writes results/candidate_links/susie_*.csv

Extends scripts/candidate_links.py, whose Wakefield ABF assumed one causal variant. For each locus
(lead SNP +/- 500 kb): 1000 Genomes phase 3 on GRCh38 (20190312 biallelic release, remote tabix),
503 EUR samples, biallelic SNVs with EUR MAF >= 1%; GWAS (Bellenguez 2022) z aligned to the ALT
allele, matched by position and alleles; LD = Pearson r of ALT dosages. susieR::susie_rss with
L = 10, n = median effective sample size 4 / (1 / cases + 1 / controls). LD consistency:
susieR::estimate_s_rss (s near 0 = consistent) and kriging_rss outliers. Credible sets (95%,
purity >= 0.5) are intersected with the DAM elements and microglia-accessible peaks.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import pysam

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/candidate_links"
KG = ("https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/data_collections/1000_genomes_project/release/"
      "20190312_biallelic_SNV_and_INDEL/ALL.chr{c}.shapeit2_integrated_snvindels_v2a_27022019.GRCh38.phased.vcf.gz")
PANEL = ROOT / "data/ref/1kg/integrated_call_samples_v3.20130502.ALL.panel"   # from ftp.1000genomes.ebi.ac.uk release/20130502
LOCI = {"RASGEF1C": ("5", 180_201_150), "chr5_87.1M": ("5", None), "DAPK2": ("15", None)}
WIN = 500_000

R_CODE = r"""
suppressMessages(library(susieR))
a <- commandArgs(TRUE)
z <- scan(a[1], quiet = TRUE)
R <- as.matrix(read.table(a[2]))
n <- as.numeric(a[3])
s <- estimate_s_rss(z, R, n = n)
kr <- kriging_rss(z, R, n = n)$conditional_dist
fit <- susie_rss(z = z, R = R, n = n, L = 10, max_iter = 500, coverage = 0.95, min_abs_corr = 0.5)
cs <- fit$sets$cs
out <- list(pip = as.numeric(fit$pip), s = s, converged = fit$converged,
            cs = lapply(cs, function(x) as.integer(x)),
            purity = if (is.null(fit$sets$purity)) list() else as.list(fit$sets$purity$min.abs.corr),
            outlier = which(kr$logLR > 2 & abs(kr$z) > 2))
writeLines(jsonlite::toJSON(out, auto_unbox = TRUE, digits = 8), a[4])
"""


def eur_samples() -> list[str]:
    p = pd.read_csv(PANEL, sep="\t")
    return p.loc[p["super_pop"] == "EUR", "sample"].tolist()


def main():
    fm = pd.read_csv(OUT / "gwas_finemap.csv")
    els = pd.read_csv(OUT / "elements.csv")
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz", usecols=["chrom", "start", "end"])
    eur = eur_samples()
    cols = ["variant_id", "p_value", "chromosome", "base_pair_location", "effect_allele", "other_allele", "beta",
            "standard_error", "n_cases", "n_controls"]
    gw = pd.concat([c[c["chromosome"].isin({v[0] for v in LOCI.values()})] for c in pd.read_csv(
        ROOT / "data/ref/gwas/GCST90027158_buildGRCh38.tsv.gz", sep="\t", usecols=cols, dtype={"chromosome": str},
        chunksize=2_000_000)]).dropna(subset=["beta", "standard_error"])
    tbi = ROOT / "data/ref/1kg"
    tbi.mkdir(parents=True, exist_ok=True)
    os.chdir(tbi)
    rows, sets = [], []
    for locus, (ch, lead_pos) in LOCI.items():
        if lead_pos is None:
            lead = fm.loc[fm["locus"] == locus, "lead_snp"].iat[0]
            lead_pos = int(gw.loc[gw["variant_id"] == lead, "base_pair_location"].iat[0])
        g = gw[(gw["chromosome"] == ch) & ((gw["base_pair_location"] - lead_pos).abs() <= WIN)].copy()
        vf = pysam.VariantFile(KG.format(c=ch))
        names = [s for s in eur if s in set(vf.header.samples)]
        vf.subset_samples(names)
        idx = names
        recs = []
        for r in vf.fetch(ch if ch in vf.header.contigs else f"chr{ch}", lead_pos - WIN, lead_pos + WIN):
            if len(r.alts or ()) != 1 or len(r.ref) != 1 or len(r.alts[0]) != 1:
                continue
            gt = np.array([sum(x for x in smp["GT"] if x is not None) for smp in r.samples.values()], float)
            af = gt.mean() / 2
            if min(af, 1 - af) < 0.01:
                continue
            recs.append((r.pos, r.ref, r.alts[0], gt))
        kg = pd.DataFrame([(p, a, b) for p, a, b, _ in recs], columns=["pos", "ref", "alt"])
        G = np.array([x[3] for x in recs])
        m = g.merge(kg.reset_index(), left_on="base_pair_location", right_on="pos")
        fwd = (m["effect_allele"] == m["alt"]) & (m["other_allele"] == m["ref"])
        rev = (m["effect_allele"] == m["ref"]) & (m["other_allele"] == m["alt"])
        m = m[fwd | rev].copy()
        m["z"] = np.where(fwd[fwd | rev], 1, -1) * m["beta"] / m["standard_error"]
        m = m.drop_duplicates("pos").sort_values("pos").reset_index(drop=True)
        X = G[m["index"].to_numpy()]
        Rld = np.corrcoef(X)
        n_eff = float(np.median(4 / (1 / m["n_cases"] + 1 / m["n_controls"])))
        with tempfile.TemporaryDirectory() as td:
            np.savetxt(f"{td}/z.txt", m["z"].to_numpy())
            np.savetxt(f"{td}/R.txt", Rld, fmt="%.6f")
            Path(f"{td}/run.R").write_text(R_CODE)
            subprocess.run(["Rscript", f"{td}/run.R", f"{td}/z.txt", f"{td}/R.txt", str(n_eff), f"{td}/out.json"],
                           check=True)
            fit = json.loads(Path(f"{td}/out.json").read_text())
        m["pip"] = fit["pip"]
        sub = res[res["chrom"] == f"chr{ch}"]
        st, en = sub["start"].to_numpy(), sub["end"].to_numpy()
        pos = m["pos"].to_numpy()
        m["in_microglia_peak"] = [bool(((st <= p) & (en >= p)).any()) for p in pos]
        el = els[els["chrom"] == f"chr{ch}"]
        m["element"] = ""
        for _, e in el.iterrows():
            m.loc[(m["pos"] >= e["start"]) & (m["pos"] <= e["end"]), "element"] = e["element"]
        cs_list = fit["cs"] if isinstance(fit["cs"], dict) else {}
        for k, (name, members) in enumerate(cs_list.items()):
            mem = np.atleast_1d(members) - 1
            d = m.iloc[mem]
            sets.append({"locus": locus, "cs": name, "size": len(d), "purity": fit["purity"][k] if fit["purity"] else np.nan,
                         "lead_snp": d.loc[d["pip"].idxmax(), "variant_id"], "lead_pip": d["pip"].max(),
                         "min_gwas_p": d["p_value"].min(), "pip_in_dam_elements": d.loc[d["element"] != "", "pip"].sum(),
                         "pip_in_microglia_peaks": d.loc[d["in_microglia_peak"], "pip"].sum(),
                         "snps": ",".join(d["variant_id"])})
        rows.append({"locus": locus, "n_snps": len(m), "n_eur": len(idx), "n_eff": n_eff, "s_ld_consistency": fit["s"],
                     "n_ld_outliers": len(np.atleast_1d(fit["outlier"])) if fit["outlier"] else 0,
                     "converged": fit["converged"], "n_credible_sets": len(cs_list),
                     "pip_in_dam_elements_total": m.loc[m["element"] != "", "pip"].sum()})
        m[["variant_id", "pos", "ref", "alt", "z", "p_value", "pip", "in_microglia_peak", "element"]].to_csv(
            OUT / f"susie_{locus}.csv.gz", index=False)
        print(f"{locus}: {len(m)} SNPs, s = {fit['s']:.3g}, credible sets {len(cs_list)}", flush=True)
    S, L = pd.DataFrame(sets), pd.DataFrame(rows)
    S.to_csv(OUT / "susie_credible_sets.csv", index=False)
    L.to_csv(OUT / "susie_loci.csv", index=False)
    print(L.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    print(S.drop(columns=["snps"]).to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    for _, s in S.iterrows():
        print(f"  {s['locus']} {s['cs']}: {s['snps']}")


if __name__ == "__main__":
    main()
