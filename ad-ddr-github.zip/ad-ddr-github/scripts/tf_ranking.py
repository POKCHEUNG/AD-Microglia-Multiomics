"""Candidate driver TFs of DAM chromatin: an explicit, multi-evidence ranking with stability (README 45, Fig. S7).

    python scripts/tf_ranking.py                # writes results/tf_ranking/

Candidates: every TF with a JASPAR motif kept in scripts/dam_tf_grn.py (expressed in microglia,
motif in 0.5-60% of tested peaks), each TF represented by its strongest motif (max |SEA-AD t|).
Evidence lines (sign s = direction of the motif's activity change; an activator should move with it):
  L1 chromatin       |t| of the motif activity, DAM-like vs homeostatic, SEA-AD discovery donors
  L2 replication     s x t in SEA-AD 10x Multiome nuclei only (labels from the nuclei's own RNA)
  L3 replication     s x t in the hippocampus cohort (DAM-high vs DAM-low thirds, state from same-nucleus RNA)
  L4 TF induction    s x t of the TF's own RNA, DAM-like vs homeostatic (SEA-AD, donor-paired)
  L5 coupling        hippocampus metacells: correlation of the TF's RNA with its own motif's activity,
                     as a z against its correlation with every motif of other families (TF-specific
                     coupling, not a global state axis)
  L6 abundance       log2 CPM of the TF in SEA-AD MTG microglia
  L7 paralog share   the TF's share of the RNA of all candidates whose motif falls in the same family
                     (motifs cannot separate paralogs; expression can)
  L8 known targets   CollecTRI targets (>= 10 expressed): s x z of their mean DAM RNA t against random
                     gene sets of the same size
Per line, TFs are ranked (missing = worst). Aggregates: mean percentile rank, and robust rank
aggregation (RRA, Kolde 2012: min over k of the beta p of the k-th smallest normalised rank,
Bonferroni over lines), with a permutation null (lines shuffled independently over TFs, 2,000x).
A second ranking for repressor-like drivers reverses the sign of L4, L5 and L8.
Stability of the top rank:
  bootstrap  200 resamples of donors (SEA-AD ATAC donors for L1-L2, hippocampus donors for L3 and L5,
             SEA-AD RNA donors for L4), all lines recomputed
  leave-one-line-out, and grouped weighting (chromatin L1; replication L2-L3; TF RNA L4, L6, L7;
             coupling L5; targets L8; one vote per group)
"""

from __future__ import annotations

from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from dam_tf_grn import MotifScorer, lcpm, motif_genes, resid
from run_dam_peaks import DAM, HOM, flip_test, load, paired, thin_mean_diff
from run_hippo_replication import load_libs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/tf_ranking"
OUT.mkdir(parents=True, exist_ok=True)
LINES = ["L1_chromatin", "L2_multiome", "L3_hippocampus", "L4_tf_rna", "L5_coupling", "L6_abundance",
         "L7_paralog_share", "L8_targets"]
GROUPS = {"chromatin": ["L1_chromatin"], "replication": ["L2_multiome", "L3_hippocampus"],
          "TF RNA": ["L4_tf_rna", "L6_abundance", "L7_paralog_share"], "coupling": ["L5_coupling"],
          "targets": ["L8_targets"]}
N_BOOT = 200


def tstat(X):
    return X.mean(0) / (X.std(0, ddof=1) / np.sqrt(len(X)) + 1e-12)


def pct_rank(v):
    """Percentile rank in (0, 1], 1 = best; NaN ranked worst."""
    v = np.where(np.isfinite(v), v, -np.inf)
    return stats.rankdata(v, method="average") / len(v)


def rra(R):
    """R: TFs x lines normalised ranks in (0, 1], small = good. Kolde's rho score (Bonferroni over lines)."""
    n, k = R.shape
    Rs = np.sort(R, 1)
    p = np.array([stats.beta.cdf(Rs[:, j], j + 1, k - j) for j in range(k)]).T
    return np.minimum(p.min(1) * k, 1)


def corr_cols(A, B):
    A = (A - A.mean(0)) / np.where(A.std(0) > 0, A.std(0), 1)
    B = (B - B.mean(0)) / np.where(B.std(0) > 0, B.std(0), 1)
    return A.T @ B / len(A)


def main():
    rng = np.random.default_rng(0)
    TFA = pd.read_csv(ROOT / "results/dam_tf/tf_activity.csv")
    res = pd.read_csv(ROOT / "results/dam_peaks/dam_peaks_all.csv.gz")
    peaks = pd.Index((ROOT / "data/processed/atac_pb/peaks.txt").read_text().split())
    pix = peaks.get_indexer(res["peak"])
    z = np.load(ROOT / "results/dam_tf/motif_hits_p1e4.npz", allow_pickle=True)
    hits, mnames, gc = z["hits"], list(z["names"]), z["gc"]
    frac = hits.mean(0)
    use = (frac >= 0.005) & (frac <= 0.6)
    hits, mnames = hits[:, use], [m for m, u in zip(mnames, use) if u]
    acc = np.log2((res["cpm_dam"] + res["cpm_hom"]).to_numpy() / 2 + 1)
    bins = (pd.qcut(pd.Series(gc).rank(method="first"), 10, labels=False).to_numpy() * 10
            + pd.qcut(pd.Series(acc).rank(method="first"), 10, labels=False).to_numpy())
    S = MotifScorer(hits, bins)
    fam_of = TFA.drop_duplicates("motif").set_index("motif")["family"].reindex(mnames).to_numpy()

    # ---------- per-donor matrices (motif scores) for SEA-AD and the hippocampus
    rows, Mx = load(ROOT / "data/processed/atac_pb_micro")
    disc = pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"].tolist()
    D, _ = paired(rows, Mx, disc, pix, rng=rng)
    C = S(D)
    Dm, _ = paired(rows, Mx, disc, pix, method="10xMulti", rng=rng)
    Cm = S(Dm)
    L, gnames = load_libs()
    cache = pd.read_csv(ROOT / "results/paper_figures/hippo_microglia_umap.csv.gz")
    libs = cache["library"].unique()
    R_ = sp.vstack([L[l]["rna_cells"][(L[l]["cells"]["subclass"] == "Microglia").to_numpy()] for l in libs]).tocsr()
    A_ = sp.vstack([L[l]["atac_cells"][(L[l]["cells"]["subclass"] == "Microglia").to_numpy()] for l in libs]).tocsr()[:, pix]
    gsym = pd.Index(gnames.str.upper())
    score, donor = cache["score"].to_numpy(), cache["donor"].to_numpy()
    Dh, hd = [], []
    for dn in np.unique(donor):
        m = np.flatnonzero(donor == dn)
        if len(m) < 30:
            continue
        lo, hi = np.quantile(score[m], [1 / 3, 2 / 3])
        Dh.append(thin_mean_diff(np.asarray(A_[m[score[m] >= hi]].sum(0)).ravel(),
                                 np.asarray(A_[m[score[m] <= lo]].sum(0)).ravel(), rng, lcpm))
        hd.append(dn)
    Ch = S(np.array(Dh))
    # metacells (as in dam_tf_grn.py), residualised on donor and depth
    order = np.lexsort((score, donor))
    mc_d, mc_a, mc_r = [], [], []
    for dn in np.unique(donor):
        m = order[donor[order] == dn]
        for k in range(0, len(m) - 14, 25):
            cells = m[k:k + 25]
            mc_a.append(np.asarray(A_[cells].sum(0)).ravel())
            r_ = np.asarray(R_[cells].sum(0)).ravel()
            mc_r.append(r_)
            mc_d.append(dn)
    mc_d = np.array(mc_d)
    LA = np.array([lcpm(a) for a in mc_a])
    ZA = (LA - LA.mean(0)) / np.where(LA.std(0) > 0, LA.std(0), 1)
    RA = np.array(mc_r)
    Cv = np.column_stack([pd.get_dummies(mc_d).to_numpy(float), np.log10(RA.sum(1) + 1),
                          np.log10(np.array([a.sum() for a in mc_a]) + 1)])
    Cmc = resid(S(ZA), Cv)

    # ---------- candidates and RNA
    cand = TFA[["tf", "motif"]].drop_duplicates()
    cand = cand[cand["motif"].isin(mnames)]
    tfs = sorted(cand["tf"].unique())
    tf_g = {g: int(np.flatnonzero(gsym == g)[0]) for g in tfs if (gsym == g).any()}
    E_tf = np.column_stack([np.log1p(RA[:, tf_g.get(g, 0)] / RA.sum(1) * 1e4) if g in tf_g else np.zeros(len(RA)) for g in tfs])
    E_tf = resid(E_tf, Cv)
    a = ad.read_h5ad(ROOT / "data/raw/pseudobulk/Immune.h5ad")
    a = a[a.obs["Brain Region"] == "MTG"]
    o, X = a.obs, sp.csr_matrix(a.X)
    var = pd.Index(a.var_names.str.upper())
    sup = o["Supertype"].astype(str)
    micro = sup.str.startswith("Micro-PVM").to_numpy()
    cm = np.asarray(X[micro].sum(0)).ravel()
    cpm_micro = pd.Series(cm / cm.sum() * 1e6, index=var).groupby(level=0).max()
    Lr = []
    for d in o["Donor ID"].unique():
        v = []
        for st in (DAM, HOM):
            m = (o["Donor ID"] == d).to_numpy() & (sup == st).to_numpy()
            if o.loc[m, "Number of nuclei"].sum() < 20:
                break
            c = np.asarray(X[m].sum(0)).ravel()
            v.append(c / c.sum() * 1e6)
        if len(v) == 2:
            Lr.append(np.log2(v[0] + 1) - np.log2(v[1] + 1))
    Lr = np.array(Lr)
    expressed = (cpm_micro >= 5)
    col = pd.Series(np.arange(len(var)), index=var)
    col = col[~col.index.duplicated()]
    ct = pd.read_csv(ROOT / "data/ref/collectri_human.csv")
    ct = ct[ct["target"].isin(expressed.index[expressed])]
    tgt = {g: col.reindex(d["target"].unique()).dropna().astype(int).to_numpy() for g, d in ct.groupby("source")}
    tgt_sign = {g: d.drop_duplicates("target").set_index("target")["weight"].reindex(var[tgt[g]]).to_numpy()
                for g, d in ct.groupby("source")}
    pool = col.reindex(expressed.index[expressed]).dropna().astype(int).to_numpy()
    print(f"{len(tfs)} candidate TFs; SEA-AD ATAC {len(C)} donors (multiome-only {len(Cm)}), hippocampus {len(Ch)} donors / "
          f"{len(Cmc)} metacells, SEA-AD RNA {len(Lr)} donors; CollecTRI TFs with >= 10 expressed targets: "
          f"{sum(len(v) >= 10 for v in tgt.values())}", flush=True)

    best = {}
    t_full = tstat(C)
    mi = {m: j for j, m in enumerate(mnames)}
    for g, d in cand.groupby("tf"):
        js = [mi[m] for m in d["motif"]]
        best[g] = js[int(np.argmax(np.abs(t_full[js])))]
    fam_members = pd.Series({g: fam_of[best[g]] for g in tfs})

    def lines(C_, Cm_, Ch_, Lr_, Cmc_, E_):
        t1, tm, th = tstat(C_), tstat(Cm_), tstat(Ch_)
        rt = tstat(Lr_)
        rt_s = pd.Series(rt, index=var).groupby(level=0).first()
        R = corr_cols(E_, Cmc_)                                # TFs x motifs
        out = {}
        for i, g in enumerate(tfs):
            j = best[g]
            s = np.sign(t1[j])
            other = fam_of != fam_of[j]
            cpl = (R[i, j] - R[i, other].mean()) / R[i, other].std() if g in tf_g else np.nan
            tg = np.nan
            if g in tgt and len(tgt[g]) >= 10:
                w = np.where(np.isfinite(tgt_sign[g]), tgt_sign[g], 1)
                obs = np.mean(w * rt[tgt[g]])
                null = np.array([np.mean(w * rt[rng.choice(pool, len(w), replace=False)]) for _ in range(200)])
                tg = s * (obs - null.mean()) / null.std()
            out[g] = {"motif": mnames[j], "family": fam_of[j], "direction": "open" if s > 0 else "closed",
                      "L1_chromatin": abs(t1[j]), "L2_multiome": s * tm[j], "L3_hippocampus": s * th[j],
                      "L4_tf_rna": s * rt_s.get(g, np.nan), "L5_coupling": cpl,
                      "L6_abundance": np.log2(cpm_micro.get(g, 0) + 1), "L8_targets": tg}
        T = pd.DataFrame(out).T
        ab = 2 ** T["L6_abundance"].astype(float) - 1
        T["L7_paralog_share"] = ab / ab.groupby(T["family"]).transform("sum").replace(0, np.nan)
        for c in LINES:
            T[c] = T[c].astype(float)
        return T

    def aggregate(T, use_lines=LINES, grouped=False):
        P = np.column_stack([pct_rank(T[c].to_numpy()) for c in use_lines])
        if grouped:
            P = np.column_stack([P[:, [use_lines.index(c) for c in cs if c in use_lines]].mean(1)
                                 for cs in GROUPS.values() if any(c in use_lines for c in cs)])
        mean_pct = P.mean(1)
        rho = rra(1 - P + 1 / len(P))
        return mean_pct, rho

    T = lines(C, Cm, Ch, Lr, Cmc, E_tf)
    mean_pct, rho = aggregate(T)
    T["mean_pct_rank"], T["rra_rho"] = mean_pct, rho
    # permutation null for the aggregate: each line shuffled independently over TFs
    nullm, nullr = [], []
    for _ in range(2000):
        Tp = T.copy()
        for c in LINES:
            Tp[c] = rng.permutation(Tp[c].to_numpy())
        m_, r_ = aggregate(Tp)
        nullm.append(m_.max())
        nullr.append(r_.min())
    nullm, nullr = np.array(nullm), np.array(nullr)
    T["p_mean_rank_perm"] = [(np.sum(nullm >= v) + 1) / (len(nullm) + 1) for v in T["mean_pct_rank"]]
    T["p_rra_perm"] = [(np.sum(nullr <= v) + 1) / (len(nullr) + 1) for v in T["rra_rho"]]
    T["rank_mean"] = stats.rankdata(-T["mean_pct_rank"], method="min").astype(int)
    T["rank_rra"] = stats.rankdata(T["rra_rho"], method="min").astype(int)
    g_mean, _ = aggregate(T, grouped=True)
    T["rank_grouped"] = stats.rankdata(-g_mean, method="min").astype(int)
    for c in LINES:
        T[f"rank_{c}"] = stats.rankdata(-np.where(np.isfinite(T[c]), T[c], -np.inf), method="min").astype(int)
    T = T.sort_values("rank_mean")
    T.index.name = "tf"
    T.to_csv(OUT / "tf_ranking.csv")
    # repressor-like drivers: the TF's RNA, coupling and targets move against its motif's activity
    TR = T[LINES + ["motif", "family", "direction"]].copy()
    for c in ("L4_tf_rna", "L5_coupling", "L8_targets"):
        TR[c] = -TR[c]
    m_, r_ = aggregate(TR)
    TR["mean_pct_rank"], TR["rank_mean"], TR["rank_rra"] = m_, stats.rankdata(-m_, method="min"), stats.rankdata(r_, method="min")
    TR.sort_values("rank_mean").to_csv(OUT / "tf_ranking_repressor_like.csv")

    # leave-one-line-out
    lolo = []
    for c in LINES:
        ul = [x for x in LINES if x != c]
        m_, r_ = aggregate(T, ul)
        rk = pd.Series(stats.rankdata(-m_, method="min"), index=T.index)
        rr = pd.Series(stats.rankdata(r_, method="min"), index=T.index)
        top = rk.sort_values().index[:5]
        lolo.append({"dropped": c, "top1": top[0], "top5": ",".join(top), "MITF_rank_mean": int(rk["MITF"]),
                     "MITF_rank_rra": int(rr["MITF"])})
    LO = pd.DataFrame(lolo)
    LO.to_csv(OUT / "leave_one_line_out.csv", index=False)

    # donor bootstrap
    hd = np.array(hd)
    mc_groups = {d_: np.flatnonzero(mc_d == d_) for d_ in np.unique(mc_d)}
    boot = []
    for b in range(N_BOOT):
        i1 = rng.integers(0, len(C), len(C))
        im = rng.integers(0, len(Cm), len(Cm))
        ih = rng.integers(0, len(Ch), len(Ch))
        ir = rng.integers(0, len(Lr), len(Lr))
        dons = rng.choice(list(mc_groups), len(mc_groups))
        imc = np.concatenate([mc_groups[d_] for d_ in dons])
        Tb = lines(C[i1], Cm[im], Ch[ih], Lr[ir], Cmc[imc], E_tf[imc])
        m_, r_ = aggregate(Tb)
        rk = pd.Series(stats.rankdata(-m_, method="min"), index=Tb.index)
        rr = pd.Series(stats.rankdata(r_, method="min"), index=Tb.index)
        boot.append(pd.DataFrame({"boot": b, "tf": Tb.index, "rank_mean": rk.to_numpy(), "rank_rra": rr.to_numpy()}))
        if b % 50 == 0:
            print(f"   bootstrap {b}/{N_BOOT}", flush=True)
    B = pd.concat(boot)
    B.to_csv(OUT / "bootstrap_ranks.csv.gz", index=False)
    BS = B.groupby("tf").agg(median_rank=("rank_mean", "median"), lo=("rank_mean", lambda v: np.percentile(v, 2.5)),
                             hi=("rank_mean", lambda v: np.percentile(v, 97.5)),
                             p_top1=("rank_mean", lambda v: np.mean(v == 1)), p_top3=("rank_mean", lambda v: np.mean(v <= 3)),
                             p_top10=("rank_mean", lambda v: np.mean(v <= 10)),
                             rra_median_rank=("rank_rra", "median")).sort_values("median_rank")
    BS.to_csv(OUT / "bootstrap_summary.csv")

    pd.set_option("display.width", 250)
    show = ["motif", "family", "direction"] + LINES + ["mean_pct_rank", "rank_mean", "rank_rra", "rank_grouped", "p_mean_rank_perm",
                                                    "p_rra_perm"]
    print("\nTop 20 candidate drivers:")
    print(T[show].head(20).to_string(float_format=lambda v: f"{v:.3g}"))
    print("\nMiT/TFE family members:")
    print(T.loc[T["family"] == T.at["MITF", "family"], show + [f"rank_{c}" for c in LINES]].to_string(float_format=lambda v: f"{v:.3g}"))
    print("\nRepressor-like ranking (L4, L5, L8 sign-reversed), top 10:")
    print(TR.sort_values("rank_mean").head(10)[["motif", "family", "direction", "L4_tf_rna", "L5_coupling", "mean_pct_rank",
                                                 "rank_rra"]].to_string(float_format=lambda v: f"{v:.3g}"))
    print("\nLeave one line out:\n", LO.to_string(index=False))
    print("\nBootstrap (200 donor resamples), top 15 by median rank:\n", BS.head(15).to_string(float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
