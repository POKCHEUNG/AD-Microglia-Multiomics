"""Independent checks of the DAM-open / DAM-closed peaks from scripts/run_dam_peaks.py.

    python scripts/validate_dam_peaks.py --out results/dam_peaks

1. RNA: genes nearest to DAM-open (closed) peaks should be up (down) in DAM-like vs
   homeostatic microglia RNA (released pseudobulks, paired within donor, MTG).
2. Pathology: do homeostatic (Micro-PVM_2) microglia move toward the DAM chromatin state
   in donors with more plaques? Also restricted to donors not used for peak discovery. Per donor, mean log2 CPM of DAM-open minus DAM-closed peaks
   in Micro-PVM_2 vs grey-matter 6E10 density (age, sex, PMI adjusted), against random peak
   sets matched on accessibility. This asks about the state continuum, not composition.
3. Mouse: DAM peaks lifted to mm10 (UCSC chain, single-base liftover of the peak centre) and compared with 5xFAD CD11c+ vs CD11c-
   microglia peak fold enrichment (GSE296025, rank-normalised within sample).
"""

from __future__ import annotations

import argparse
import gzip
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

from ad_ddr.stats import _covar_matrix, _resid

ROOT = Path(__file__).resolve().parents[1]
DAM, HOM = "Micro-PVM_3-SEAAD", "Micro-PVM_2"


def rna_check(res: pd.DataFrame) -> pd.DataFrame:
    a = ad.read_h5ad(ROOT / "data/raw/pseudobulk/Immune.h5ad")
    a = a[a.obs["Brain Region"] == "MTG"]
    o = a.obs
    X = sp.csr_matrix(a.X)
    genes = a.var_names.str.upper()
    lfc = []
    for d, od in o.groupby("Donor ID", observed=True):
        v = []
        for st in (DAM, HOM):
            m = (o["Donor ID"] == d).to_numpy() & (o["Supertype"].astype(str) == st).to_numpy()
            if o.loc[m, "Number of nuclei"].sum() < 20:
                break
            c = np.asarray(X[m].sum(0)).ravel()
            v.append(np.log2(c / c.sum() * 1e6 + 1))
        if len(v) == 2:
            lfc.append(v[0] - v[1])
    L = np.array(lfc)
    g = pd.DataFrame({"gene": genes, "rna_log2fc": L.mean(0), "rna_cpm_expressed": True}).drop_duplicates("gene")
    g = g.set_index("gene")["rna_log2fc"]
    print(f"RNA: {len(lfc)} donors with >= 20 nuclei in both states")
    r = res.assign(gene=res["nearest_gene"].str.upper())
    r["rna_log2fc"] = g.reindex(r["gene"]).to_numpy()
    r[["peak", "nearest_gene", "class", "call", "log2fc", "rna_log2fc"]].to_csv(
        ROOT / "results/dam_peaks/peak_rna_pairs.csv.gz", index=False)
    rows = []
    for cls in ("all", "promoter", "distal"):
        rr = r if cls == "all" else r[r["class"] == cls]
        base = rr.loc[rr["call"] == "ns"].drop_duplicates("gene")["rna_log2fc"].dropna()
        for call in ("DAM-open", "DAM-closed"):
            x = rr.loc[rr["call"] == call].drop_duplicates("gene")["rna_log2fc"].dropna()
            if len(x) < 5:
                continue
            u = stats.mannwhitneyu(x, base, alternative="two-sided")
            rows.append({"peaks": cls, "call": call, "n_genes": len(x), "median_rna_log2fc": x.median(),
                         "median_background": base.median(), "frac_rna_up": (x > 0).mean(), "p_mwu": u.pvalue})
    return pd.DataFrame(rows)


def pathology_check(res: pd.DataFrame, n_rand: int, rng) -> pd.DataFrame:
    from run_dam_peaks import load
    d = ROOT / "data/processed/atac_pb_micro"
    rows, M = load(d)
    peaks = pd.Index((d / "peaks.txt").read_text().split())
    pix = peaks.get_indexer(res["peak"])
    qnp = pd.read_excel(ROOT / "data/meta/qnp/sea-ad-quantitative-neuropathology-063026.xlsx", sheet_name="MTG")
    gm = qnp[qnp["analysis region"] == "Grey matter"].set_index("Donor ID")["number of 6e10 positive objects per area"]
    meta = pd.read_csv(ROOT / "data/meta/donor_table.csv").set_index("Donor ID")
    disc = set(pd.read_csv(ROOT / "results/dam_peaks/discovery_donors.csv")["donor"])
    out = []
    for st, min_n, held in ((HOM, 30, False), (HOM, 30, True), (DAM, 10, False)):
        n = rows[rows["subclass"] == st].groupby("donor")["n_nuclei"].sum()
        donors = [x for x in n.index[n >= min_n] if x in gm.index and x in meta.index and not (held and x in disc)]
        L = []
        for x in donors:
            ix = rows.index[(rows["donor"] == x) & (rows["subclass"] == st)].to_numpy()
            c = np.asarray(M[ix].sum(0)).ravel()[pix]
            tot = np.asarray(M[ix].sum()).ravel()[0]
            L.append(np.log2(c / tot * 1e6 + 1))
        L = np.array(L)
        Lz = (L - L.mean(0)) / np.where(L.std(0) > 0, L.std(0), 1)
        info = pd.DataFrame({"age": pd.to_numeric(meta.loc[donors, "Age at Death"], errors="coerce").to_numpy(),
                             "sex": meta.loc[donors, "Sex"].astype(str).to_numpy(),
                             "pmi": pd.to_numeric(meta.loc[donors, "PMI"], errors="coerce").to_numpy(),
                             "lognuc": np.log10(n.loc[donors].to_numpy(float))})
        x = np.log10(gm.loc[donors].to_numpy(float) * 1e6 + 1)
        ok = info.notna().all(1).to_numpy() & np.isfinite(x)
        info, x, Lz = info[ok].reset_index(drop=True), x[ok], Lz[ok]
        Z = _covar_matrix(info, ["age", "sex", "pmi", "lognuc"])
        xr = _resid(x, Z)
        openi = np.flatnonzero(res["call"].to_numpy() == "DAM-open")
        closi = np.flatnonzero(res["call"].to_numpy() == "DAM-closed")
        nsi = np.flatnonzero(res["call"].to_numpy() == "ns")
        acc = np.log2(res["cpm_hom"].to_numpy() + 1)
        bins = pd.qcut(pd.Series(acc).rank(method="first"), 20, labels=False).to_numpy()
        pool = {b: nsi[bins[nsi] == b] for b in range(20)}

        def score(o, c):
            s = Lz[:, o].mean(1) - (Lz[:, c].mean(1) if len(c) else 0)
            return np.corrcoef(xr, _resid(s, Z))[0, 1]
        obs = score(openi, closi)
        null = []
        for _ in range(n_rand):
            ro = np.array([rng.choice(pool[b]) for b in bins[openi]])
            rc = np.array([rng.choice(pool[b]) for b in bins[closi]]) if len(closi) else closi
            null.append(score(ro, rc))
        null = np.array(null)
        out.append({"state": st, "donors": "not used for peak discovery" if held else "all", "n_donors": int(ok.sum()), "r_dam_axis_vs_6E10": obs, "null_mean": null.mean(),
                    "p_set": (np.sum(np.abs(null - null.mean()) >= abs(obs - null.mean())) + 1) / (n_rand + 1),
                    "r_open_only": score(openi, np.array([], int)),
                    "r_closed_only": -score(closi, np.array([], int)) if len(closi) else np.nan})
    return pd.DataFrame(out)


def read_chain(path: Path) -> dict[str, pd.DataFrame]:
    """UCSC chain file -> per target chromosome, aligned blocks (t_start, t_end, q_chrom, q_start, q_strand, q_size)."""
    blocks = []
    with gzip.open(path, "rt") as fh:
        for line in fh:
            f = line.split()
            if not f:
                continue
            if f[0] == "chain":
                t_chrom, t_pos = f[2], int(f[5])
                q_chrom, q_size, q_strand, q_pos = f[7], int(f[8]), f[9], int(f[10])
                continue
            size = int(f[0])
            blocks.append((t_chrom, t_pos, t_pos + size, q_chrom, q_pos, q_strand, q_size))
            if len(f) == 3:
                t_pos += size + int(f[1])
                q_pos += size + int(f[2])
    b = pd.DataFrame(blocks, columns=["t_chrom", "t_start", "t_end", "q_chrom", "q_start", "q_strand", "q_size"])
    return {c: d.sort_values("t_start").reset_index(drop=True) for c, d in b.groupby("t_chrom")}


def liftover_points(chain: dict, chroms, pos) -> list[tuple]:
    """Single-base liftover (first block containing the position); None when unmapped."""
    out = []
    for c, p in zip(chroms, pos):
        b = chain.get(c)
        if b is None:
            out.append((None, None))
            continue
        i = np.searchsorted(b["t_start"].to_numpy(), p, side="right") - 1
        if i < 0 or p >= b.at[i, "t_end"]:
            out.append((None, None))
            continue
        q = b.at[i, "q_start"] + (p - b.at[i, "t_start"])
        if b.at[i, "q_strand"] == "-":
            q = b.at[i, "q_size"] - q - 1
        out.append((b.at[i, "q_chrom"], int(q)))
    return out


def mouse_check(res: pd.DataFrame) -> pd.DataFrame:
    chain = read_chain(ROOT / "data/ref/hg38ToMm10.over.chain.gz")
    mid = ((res["start"] + res["end"]) // 2).to_numpy()
    lifted = liftover_points(chain, res["chrom"], mid)
    res = res.assign(mm_chrom=[a for a, _ in lifted], mm_pos=[b for _, b in lifted])
    cols = {}
    for f in sorted((ROOT / "data/raw/gse296025").glob("*narrowPeaks_.bed.gz")):
        name = f.name.split("MACS2callpeakon")[1].split("_")[0]
        pk = pd.read_csv(gzip.open(f, "rt"), sep="\t", header=None, usecols=[0, 1, 2, 6], names=["chrom", "s", "e", "fe"])
        pk["rank"] = pk["fe"].rank(pct=True)
        v = np.zeros(len(res))
        for chrom, idx in res.groupby("mm_chrom").indices.items():
            p = pk[pk["chrom"] == chrom].sort_values("s")
            if p.empty:
                continue
            s, e, rk = p["s"].to_numpy(), p["e"].to_numpy(), p["rank"].to_numpy()
            pos = res["mm_pos"].to_numpy()[idx].astype(int)
            j = np.searchsorted(s, pos + 250) - 1                    # peak starting before the 500 bp window end
            hit = (j >= 0) & (e[np.clip(j, 0, None)] >= pos - 250)
            v[idx[hit]] = rk[j[hit]]
        cols[name] = v
    S = pd.DataFrame(cols)
    pam = S[[c for c in S if c.startswith("PAMrep")]].mean(1)
    non = S[[c for c in S if c.startswith("nonPAMrep")]].mean(1)
    res = res.assign(mm_delta=(pam - non).to_numpy(), mm_any=(S > 0).any(axis=1).to_numpy())
    rows = []
    lifted_ok = res["mm_chrom"].notna()
    base = res.loc[lifted_ok & res["mm_any"] & (res["call"] == "ns"), "mm_delta"]
    for call in ("DAM-open", "DAM-closed"):
        sel = res["call"] == call
        x = res.loc[sel & lifted_ok & res["mm_any"], "mm_delta"]
        rows.append({"call": call, "n_peaks": int(sel.sum()), "lifted": int((sel & lifted_ok).sum()),
                     "with_mouse_peak": len(x), "frac_with_mouse_peak": len(x) / max((sel & lifted_ok).sum(), 1),
                     "bg_frac_with_mouse_peak": (lifted_ok & res["mm_any"] & (res["call"] == "ns")).sum()
                     / max((lifted_ok & (res["call"] == "ns")).sum(), 1),
                     "median_PAM_minus_nonPAM": x.median() if len(x) else np.nan, "median_background": base.median(),
                     "p_mwu": stats.mannwhitneyu(x, base).pvalue if len(x) >= 5 else np.nan})
    return pd.DataFrame(rows), res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/dam_peaks")
    ap.add_argument("--n-rand", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    out = ROOT / args.out
    rng = np.random.default_rng(args.seed)
    res = pd.read_csv(out / "dam_peaks_all.csv.gz")

    r1 = rna_check(res)
    r1.to_csv(out / "validation_rna.csv", index=False)
    print(r1.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    r2 = pathology_check(res, args.n_rand, rng)
    r2.to_csv(out / "validation_pathology.csv", index=False)
    print("\n" + r2.to_string(index=False, float_format=lambda v: f"{v:.3g}"))
    r3, lifted = mouse_check(res)
    r3.to_csv(out / "validation_mouse.csv", index=False)
    lifted[lifted["call"] != "ns"].to_csv(out / "dam_peaks_sig_with_mouse.csv", index=False)
    print("\n" + r3.to_string(index=False, float_format=lambda v: f"{v:.3g}"))


if __name__ == "__main__":
    main()
