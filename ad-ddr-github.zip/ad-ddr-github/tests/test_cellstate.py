import numpy as np
import pandas as pd

from ad_ddr.cellstate import coherence, donor_centred_z, top_fraction_labels


def _obs(n=2000, shared=0.0, seed=0):
    rng = np.random.default_rng(seed)
    state = rng.random(n) < 0.05                       # minority state
    obs = pd.DataFrame({"donor": rng.choice(["d1", "d2", "d3"], n), "supertype": "A"})
    for c in ("p1", "p2", "p3"):
        obs[c] = rng.normal(0, 1, n) + shared * state + obs["donor"].map({"d1": 0, "d2": 2, "d3": -2})
    return obs


def test_coherence_detects_coordinated_minority_state_and_ignores_donor_offsets():
    cols = ["p1", "p2", "p3"]
    null = coherence(donor_centred_z(_obs(shared=0.0), cols), pd.Series("A", index=range(2000)), cols)
    real = coherence(donor_centred_z(_obs(shared=3.0), cols), pd.Series("A", index=range(2000)), cols)
    assert abs(null["A"]) < 0.05            # donor offsets alone must not create coherence
    assert real["A"] > 0.15


def test_top_fraction_labels_within_donor():
    obs = _obs()
    lab = top_fraction_labels(obs["p1"], obs, frac=0.05)
    frac = (lab == "high").groupby(obs["donor"]).mean()
    assert np.allclose(frac, 0.05, atol=0.01)
