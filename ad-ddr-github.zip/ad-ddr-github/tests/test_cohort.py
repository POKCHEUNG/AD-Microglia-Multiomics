import numpy as np
import pandas as pd
import scipy.sparse as sp
from anndata import AnnData

from ad_ddr.cohort import DONOR_COLS, aggregate, score_programs


def _write(tmp_path):
    obs = pd.DataFrame({
        "Brain Region": ["MTG"] * 4,
        "Subclass": ["Immune", "Immune", "Immune", "Immune"],
        "Supertype": ["Micro-PVM_2", "Micro-PVM_3-SEAAD", "Lymphocyte", "Micro-PVM_2"],
        "Class": ["Non-neuronal and Non-neural"] * 4,
        "Donor ID": ["d1", "d1", "d1", "d2"],
        "Number of nuclei": [10, 5, 3, 20],
        "method": ["10xMulti", "10Xv3.1", "10xMulti", "10xMulti"],
        **{c: ["x"] * 4 for c in DONOR_COLS},
    }, index=[f"r{i}" for i in range(4)])
    X = sp.csr_matrix(np.array([[1, 0], [2, 1], [100, 100], [4, 4]], float))
    p = tmp_path / "Immune.h5ad"
    AnnData(X, obs=obs, var=pd.DataFrame(index=["G1", "G2"])).write_h5ad(p)
    return p


def test_aggregate_sums_supertypes_and_drops_lymphocytes(tmp_path):
    idx, C, genes, meta = aggregate([_write(tmp_path)])
    g = idx.assign(c0=C[:, 0], c1=C[:, 1]).set_index("donor")
    assert set(idx["group"]) == {"Microglia-PVM"}
    assert g.loc["d1", "c0"] == 3 and g.loc["d1", "c1"] == 1          # lymphocyte row excluded
    assert g.loc["d1", "n_nuclei"] == 15 and g.loc["d1", "multiome_nuclei"] == 10


def test_score_programs_ranks_donors():
    idx = pd.DataFrame({"level": "group", "region": "MTG", "group": "A", "donor": [f"d{i}" for i in range(8)],
                        "n_nuclei": 100, "multiome_nuclei": 50})
    rng = np.random.default_rng(0)
    C = rng.poisson(200, (8, 50)).astype(float)
    C[:, :5] *= np.linspace(1, 3, 8)[:, None]
    s = score_programs(idx, C, pd.Index([f"G{i}" for i in range(50)]), {"P": [f"G{i}" for i in range(5)]})
    assert np.corrcoef(s["rna_P"], np.arange(8))[0, 1] > 0.9
