import numpy as np
import pandas as pd

from ad_ddr.neighborhood import depth_bins, section_test


def _section(local_effect: bool, seed=0, n=20000):
    """Cortex-like strip: depth along y. Targets and focal centres are both enriched in the
    upper layer (a pure laminar confound). If ``local_effect``, targets are additionally
    removed near focal centres."""
    rng = np.random.default_rng(seed)
    xy = np.column_stack([rng.uniform(0, 3000, n), rng.uniform(0, 3000, n)])
    upper = xy[:, 1] < 1500
    kind = rng.choice(["neuron", "centre"], n, p=[0.9, 0.1])
    target = (kind == "neuron") & (rng.random(n) < np.where(upper, 0.5, 0.1))
    other = (kind == "neuron") & ~target
    centre = kind == "centre"
    focal = centre & (rng.random(n) < np.where(upper, 0.5, 0.1))
    if local_effect:
        from scipy.spatial import cKDTree
        near = cKDTree(xy[focal]).query_ball_point(xy, r=40, return_length=True) > 0
        drop = target & near & (rng.random(n) < 0.7)
        target, other = target & ~drop, other | drop
    depth = pd.Series(xy[:, 1])
    bins = depth_bins(depth, pd.Series(np.zeros(n)))
    return xy, bins, centre, focal, target, other


def test_laminar_confound_is_removed_by_depth_matched_null():
    xy, bins, centre, focal, target, other = _section(local_effect=False)
    r = section_test(xy, bins, centre, focal, target, other, radius=50, n_perm=200)
    assert r["frac_obs"] > 0.3                 # naive comparison is confounded by layer
    assert abs(r["frac_excess"]) < 0.1         # depth-matched null removes it


def test_local_depletion_is_detected():
    xy, bins, centre, focal, target, other = _section(local_effect=True)
    r = section_test(xy, bins, centre, focal, target, other, radius=50, n_perm=200)
    assert r["frac_excess"] < -0.3
    assert r["frac_excess"] < -3 * r["frac_null_sd"]
