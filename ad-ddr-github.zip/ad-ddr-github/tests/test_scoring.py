import numpy as np
import pandas as pd
import scipy.sparse as sp
from anndata import AnnData

from ad_ddr.scoring import ProgramScorer, cell_groups, depth_adjust


def test_depth_adjust_removes_within_donor_depth_but_keeps_donor_effect():
    rng = np.random.default_rng(0)
    rows = []
    for i, shift in enumerate([0.0, 0.0, 1.0, 1.0]):          # donors 2,3 truly higher
        depth = rng.normal(3.5 + 0.3 * i, 0.2, 400)           # depth also differs by donor
        score = shift + 2.0 * (depth - 3.5) + rng.normal(0, 0.05, 400)   # technical effect of absolute depth
        rows.append(pd.DataFrame({"donor": f"d{i}", "group": "A", "method": "x", "log_umi": depth, "s": score}))
    obs = pd.concat(rows, ignore_index=True)
    adj = depth_adjust(obs, ["s"])
    within = adj.groupby("donor").apply(lambda d: np.corrcoef(d["s"], d["log_umi"])[0, 1])
    assert within.abs().max() < 0.2
    means = adj.groupby("donor")["s"].mean()
    assert abs((means["d2"] + means["d3"]) / 2 - (means["d0"] + means["d1"]) / 2 - 1.0) < 0.15


def test_program_scorer_detects_upregulated_program():
    rng = np.random.default_rng(1)
    X = rng.poisson(1.0, (200, 300)).astype(float)
    X[:100, :10] += 3
    genes = [f"G{i}" for i in range(300)]
    ad = AnnData(sp.csr_matrix(np.log1p(X)), var=pd.DataFrame(index=genes))
    sc = ProgramScorer({"P": genes[:10]}, n_bins=5, ctrl_size=10).fit(ad)
    s = sc.score(ad)["rna_P"].to_numpy()
    assert s[:100].mean() > s[100:].mean() + 0.5


def test_cell_groups_splits_immune():
    obs = pd.DataFrame({"subclass": ["Immune", "Immune", "Astrocyte"],
                        "supertype": ["Micro-PVM_3-SEAAD", "Lymphocyte", "Astro_1"]})
    g = cell_groups(obs)
    assert g.iloc[0] == "Microglia-PVM" and pd.isna(g.iloc[1]) and g.iloc[2] == "Astrocyte"
