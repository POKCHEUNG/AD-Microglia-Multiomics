import numpy as np
import pandas as pd

from ad_ddr.stats import cps_association, rna_atac_concordance


def _pb(n=12, seed=0):
    rng = np.random.default_rng(seed)
    cps = np.linspace(0, 1, n)
    age = rng.normal(85, 6, n)
    return pd.DataFrame({
        "subclass": "Micro-PVM",
        "donor": [f"d{i}" for i in range(n)],
        "cps": cps,
        "age": age,
        "rna_up": 2 * cps + rng.normal(0, 0.2, n),
        "rna_null": rng.normal(0, 1, n),
        "rna_age": 0.1 * age + rng.normal(0, 0.05, n),
    })


def test_detects_true_association_and_not_null():
    res = cps_association(_pb(), ["rna_up", "rna_null"], n_perm=2000).set_index("score")
    assert res.loc["rna_up", "r"] > 0.8 and res.loc["rna_up", "p_perm"] < 0.01
    assert res.loc["rna_up", "slope"] > 1.5
    assert res.loc["rna_null", "p_perm"] > 0.01


def test_covariate_adjustment_removes_confounded_signal():
    pb = _pb()
    pb["cps"] = (pb["age"] - pb["age"].mean()) / 10 + np.random.default_rng(1).normal(0, 0.05, len(pb))
    raw = cps_association(pb, ["rna_age"], n_perm=2000).iloc[0]
    adj = cps_association(pb, ["rna_age"], covariates=["age"], n_perm=2000).iloc[0]
    assert raw["p_perm"] < 0.01
    assert abs(adj["r"]) < abs(raw["r"])


def test_missing_values_are_dropped_not_called_significant():
    pb = _pb()
    pb["atac_x"] = np.random.default_rng(3).normal(0, 1, len(pb))
    pb.loc[:1, "atac_x"] = np.nan
    res = cps_association(pb, ["atac_x"], n_perm=2000).iloc[0]
    assert res["n_donors"] == len(pb) - 2
    assert np.isfinite(res["r"]) and res["p_perm"] > 0.01


def test_concordance_ignores_donors_without_atac():
    pb = _pb()
    pb["rna_P"] = np.arange(len(pb), dtype=float)
    pb["atac_P"] = pb["rna_P"] * 2
    pb.loc[:1, "atac_P"] = np.nan
    c = rna_atac_concordance(pb[["subclass", "donor", "rna_P"]], pb[["subclass", "donor", "atac_P"]], ["P"]).iloc[0]
    assert c["n_donors"] == len(pb) - 2 and c["r"] > 0.99
